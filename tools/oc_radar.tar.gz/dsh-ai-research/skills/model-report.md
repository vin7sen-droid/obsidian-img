---
name: model-report
description: AI 模型的「实测 / 口碑体检」与同类横评 —— 给一个或多个模型名（如 Gemini 4 Argon、Claude Opus 5.5、GPT-6.1 Sol），汇总 13 路结构化跑分（Artificial Analysis 智能指数、Vals AI 50 个基准、SWE-bench 官方榜、SWE-rebench 滚动榜、ARC Prize、LMArena 人类盲测竞技场、llm-stats 三档跑分、benchlm 同尺度榜）、价格与上下文、多个模型重合基准的逐项对比，以及英文（Hacker News + X/Twitter + Reddit）、中文社区（B站实测视频与高赞评论、CSDN、微信公众号、掘金；知乎已接通、小红书走本机无头 Chrome 抓取）、GitHub 生态接入的真实讨论。报告默认带同类横评（自动挑 3 个段位相近的对手），每个源最多列 5 条**并逐段给出中文解读**，英文帖子（Hacker News 等）会连同**中文释义与结论**一起给。当用户问「某模型实测怎么样」「口碑如何」「跑分多少」「值得用吗」「A 和 B 哪个强」「横向对比一下」，或要求「解读一下这些帖子」时使用。
---

# model-report：模型实测 / 口碑体检 + 同类横评

> **路径与环境（先读这条）**：本文里的 `model-report/xxx.mjs`、`ai-news-radar/xxx.mjs`、`ai-model-radar/xxx.mjs`
> 都是**相对工具根目录**的路径 —— 源码仓库里工具根是 `tools/`（例：`tools/model-report/cli.mjs`），
> 插件 `dsh-ai-research` 的 `config.root` 同理；命令示例一律按工具根书写。
> 运行期状态（cookie / 缓存 / 限流与熔断状态）统一在 **`~/.dsh-ai-research/`**（`DSH_AI_RESEARCH_HOME` 可改：
> 缓存 `.cache/`、cookie `cookies.json`、小红书状态 `xhs-state.json`）。
> 出网代理按 `DSH_AI_RESEARCH_PROXY` → `MODEL_REPORT_PROXY` → `HTTPS_PROXY` / `HTTP_PROXY` 取，都没设就直连（`NO_PROXY` 生效）。
> 下文命令示例以 **Windows / PowerShell** 为准；macOS / Linux 把 `$env:X=...` 换成 `X=... 命令` 即可。

## 什么时候用

- **单模型体检**：用户提到某个具体模型，想知道跑分/实测表现、社区口碑、值不值得用、有没有人测过。
- **同类横评**：用户要比较 2~4 个同类模型（"Argon 和 Opus 5.5 哪个强""这几个旗舰放一起比"）。
- 若用户问的是「最近发了什么模型」，那是 `ai-model-radar` 的活。

## 13 路结构化源（全部实测可用，无 key、无第三方依赖）

| # | 源 | 取什么 | 说明 |
|---|---|---|---|
| 1 | llm-stats.com 首页（RSC `initialHomepageLLMModels`） | 408 个模型的统一字段：上下文、价格、GPQA/SWE-bench/HLE、arena_scores、发布日、开源与否 | 模型匹配 + 横评「统一字段」节 |
| 2 | llm-stats 单模型页 | 每项跑分的分数 + `verified`/`self_reported` 标记 + `verification_notes` | 分三档 ★独立/†第三方榜/‡厂商自报。**`verified` 实测恒为 false → ★ 恒为 0** |
| 3 | benchlm.ai 首页静态表（25 行） | 名次、综合分、Elo、价格、上下文、吞吐、延迟 | **唯一单一尺度**，跨模型比较以它为主 |
| 4 | OpenRouter `/api/v1/models`（JSON，462 个） | 是否在售、官方价格、上下文 | 缺字段时回填（报告标 `*`），也给 `--auto` 补价格 |
| 5 | Hacker News（hn.algolia.com，story + comment 全文） | 标题/▲分/评论数/评论正文 | 唯一能拿到**原文**的英文口碑源 |
| 6 | 掘金 `api.juejin.cn/search_api/v1/search` | 中文技术文标题、摘要、阅读/点赞数 | 只保留标题或摘要真含模型名的条目（`ctime` 是秒，勿当毫秒） |
| 7 | GitHub `search/issues`（`in:title`） | 带模型名的 issue/PR 数量与热度 | **生态接入速度**信号，不是模型好坏 |
| 8 | **Artificial Analysis**（`artificialanalysis.ai/leaderboards/models`，2.47MB RSC） | **700 个模型**：`intelligenceIndex`（自建刻度）、omniscience/HLE/GPQA 等 16 个分项、价格、上下文、吞吐、首答延迟；同一模型可能有 Max/High/Default 多档 | 耗时 ~17s（最慢），用 `--fast` 可跳过 |
| 9 | **Vals AI**（50 个基准，表在 `/benchmarks/<slug>` 服务端渲染） | 每榜名次/分数/成本/耗时；默认 8 榜：vals_index, terminal-bench-4, swebench, lcb, aime, gpqa, mmlu_pro, vibe-code | 列名因表而异（Accuracy / Score / Pass Rate），用 `valsScoreOf` 定位分数列 |
| 10 | **SWE-bench 官方站**（`swebench.com`，JS 数组内嵌） | 分榜（verified 116 / lite 58 / full 58 / bash-only 37 / multilingual 13）；模型、agent、解决率、单题成本、提交日 | **靠社区提交、明显滞后**（实测最新只到 2026-02），引用必须标"官方榜提交滞后" |
| 11 | **SWE-rebench**（`swe-rebench.com`，7.79MB RSC） | 115 个模型的**滚动窗口**解决率、样本 n、单题成本、分语言 | 口径 = 全区间窗口 `rangeStats.all[from:to]`；分语言**独立采样、不可相加** |
| 12 | **ARC Prize**（`arcprize.org/media/data/leaderboard/{v1,v2,v3}.json`） | 649 行：ARC-AGI-1/2/3 得分 + 每题成本；模型档位（如 120K High） | ARC-AGI-3 分数极低（0.5% 量级），别当能力暴跌 |
| 13 | **LMArena**（人类盲测竞技场；走 HuggingFace 官方数据集，站点本体被 Cloudflare 挡） | 5 个榜的 Elo / score、95% 区间、票数、文本榜 29 个题集与 WebDev / 视觉 / Agent 分榜 | 见「LMArena」节；**同一张榜内名次可比，跨榜不可比** |

**中文社区源另算一路（第 14 路起，见下节）**：B站 / CSDN / 微信公众号已能直接抓取**原文与评论**，知乎 / 小红书也已真机跑通（小红书要本机无头 Chrome，见下节）；Reddit 实测帖、YouTube 长测、X 仍拿不到，只能靠 `web_search` 补，并注明是**转引**。

## 中文社区源（第 14 路起，共 5 个源；实现单份在 `model-report/cn.mjs`）

| 源 | 登录态 | 取什么 | 实测状态 |
|---|---|---|---|
| B站（bilibili） | **不需要账号**（自取匿名 cookie buvid3 / b_nut） | 搜索命中数、按相关性+评论数排序的视频（播放▲/评论/时长/UP主/bvid）、头部视频的高赞评论**原文**（含 👍 数） | ✅ 真机通过（搜「Gemini 4 Argon 实测」约 1000 条，头部 ▲18.5 万 / 1789 评论） |
| CSDN | 不需要 | `so.csdn.net/api/v3/search` 的文章标题/摘要/链接 | ✅ 真机通过（8 条） |
| 微信公众号（经搜狗） | 不需要 | `weixin.sogou.com/weixin?type=2` 的文章标题、公众号名、摘要、日期；可选再解出 `mp.weixin.qq.com` 原文直链 | ✅ 真机通过（8 条，前几条已解出原文链接） |
| 掘金 | 不需要 | 见上表第 6 路 | ✅ 早已接入 |
| 知乎 | **需要**（登录 cookie，含 `z_c0`） | `api/v4/search_v3` 搜索 → 回答/文章标题、摘要、赞同数、评论数、**日期**、作者；同一问题下的多个回答按问题归并（留赞同最高那条，另记「同题另有 N 个回答」），并按赞同降序 | ✅ **真机通过（2026-10-15，本机已配 cookie）**：搜「Gemini 4 Argon」8 条命中，头部 329 赞同 / 139 评论，含卡兹克长文实测 |
| 小红书 | **需要**（登录 cookie，含 `web_session`）+ **本机无头 Chrome** | 搜索笔记：标题、作者、赞/藏/评/转数、链接、相对时间（「1天前」/「09-28」）；接口本身**不返回发布时间**，时间取自页面 DOM | ✅ **真机通过（2026-10-15，本机已配 cookie）**：搜「Gemini 4 Argon」8 条，头部 ♥7616/评 296（机器之心）、♥480（Artificial Analysis）；单次约 8s |

> **微博 / 贴吧 两源已于 2026-10-16 按用户要求删除**（长期拿不到 cookie：微博未登录即 HTTP 432 风控，贴吧搜索页 11KB、`s_post` 结果块为 0）。cookie 文件里若还留着这两个字段会被忽略（不影响其它源）。

**登录态怎么给**（两条路）：
① **剪贴板代劳**（推荐，实测可用）：让用户在浏览器里 F12 → 网络 → 任一条对该站请求 → Request Headers → `Cookie` 行右键 Copy value，然后**只留在剪贴板**；agent 跑
**Windows / PowerShell**（macOS 用 `MR_COOKIE="$(pbpaste)" node tools/model-report/set-cookie.mjs zhihu ["<模型名>"] --test`，Linux 用 `xclip -o` / `wl-paste`）：
```powershell
$env:MR_COOKIE = (Get-Clipboard -Raw); node tools/model-report/set-cookie.mjs zhihu ["<模型名>"] --test
```
（脚本剥 `cookie:` 前缀、把换行/制表符折成空格、去掉尾部 `;`，写进 cookie 文件（默认 `~/.dsh-ai-research/cookies.json`，`DSH_AI_RESEARCH_COOKIES` 可改），**从不回显 cookie 值**，只报长度/字段数/命中的票据名；`--test` 会真打一次 `zhihuBuzz` 报条数与前 3 条标题）。注意 **Node 里不一定能 spawn 到 `pwsh`（Windows 实测 `spawnSync pwsh ENOENT`），读剪贴板要用宿主提供的 shell 工具**。
② **手改文件**：把 `model-report/cookies.example.json` 复制成 `cookies.json`，往 `zhihu` / `xiaohongshu` 两个字段里填浏览器 F12 复制来的整条 Cookie（小红书要含 `web_session`；导入命令 `node model-report/set-cookie.mjs xiaohongshu ["<模型名>"] --test`）（要含登录票据的那种）。也可用环境变量 `ZHIHU_COOKIE` / `XIAOHONGSHU_COOKIE` 覆盖，或用 `MODEL_REPORT_COOKIES` 指向别的文件。**缺 cookie 时按「未配置登录态」显式报错并进 gaps，绝不静默返空。**
cookie 文件等同登录凭据：只留在本机 `~/.dsh-ai-research/`（在 `.gitignore` 里，别提交、别外发）。

**行为纪律**：只抓**公开页面**的公开内容，串行 + 间隔（B站每视频之间 350ms）；**匿名可抓 ≠ 可猛拉**，批量跑多个模型时不要并发；每个源失败都要在报告里如实记缺口。

**已知坑（真机踩过）**：中文源**并发一起打会全部返空且不报错**（B站/CSDN/搜狗同时出现 videos=0 / csdn=0 / weixin=0）→ `cnBrief` 已改为**串行 + 240~440ms 间隔**；`cnGather` 本来就是串行。B站搜索返回的标题带 `<em>` 高亮需清洗；CSDN 的 URL 要去掉 `?utm_source=...` 尾巴；搜狗结果链接是跳转地址，原文要再请求一次并在 HTML 里拼 `url += '...'` 分片（并还原 `&amp;`）。

### 小红书：只能走本机无头 Chrome + CDP（纯 HTTP 不通）

**为什么不能像其他源那样直接 fetch**：`POST https://so.xiaohongshu.com/api/sns/web/v2/search/notes` 要 `X-s: XYS_...` + `X-S-Common` + `X-t` 签名。站点 JS 里 `XYS_` / `_webmsxyw` 出现 **0 次**，签名由 `as.xiaohongshu.com/api/sec/v1/ds?appId=xhs-pc-web` 分发的混淆 SDK 在运行时生成；页面里那个 `window._webmsxyw(path, body)` 确实存在，但它签出来的是**旧版 `XYW_`**，`so.` 主机同样返 406。→ 结论：**签名只能由页面自己算**，我们只读结果。

**实现**：`model-report/xhs.mjs`（纯 Node，自带 40 行 CDP 客户端）。流程 = 确保 9222 上有一个无头 Chrome → 注入 cookie → `Page.addScriptToEvaluateOnNewDocument` 打钩子（包 `fetch`/`XMLHttpRequest`，把 `/search/notes` 的**响应体**推进 `window.__xhsCap`）→ 驱动页面自己搜（`#search-input` 原生 setter + `input` 事件 + Enter）→ 解析捕获到的 JSON。

- 启动参数（实测可用）：`--headless=new --disable-gpu --no-first-run --no-default-browser-check --disable-blink-features=AutomationControlled --remote-debugging-port=9222 --window-size=1440,1200 --lang=zh-CN --user-data-dir=%TEMP%\dsh-chrome-xhs about:blank`。**profile 路径用系统临时目录**（默认 Windows `%TEMP%\dsh-chrome-xhs`、macOS/Linux `/tmp/dsh-chrome-xhs`，可用 `DSH_AI_RESEARCH_CHROME_PROFILE` 指定），**不要用工作区路径**（带空格时 `-ArgumentList` 不会自动加引号，Chrome 会拿错参数）。浏览器可执行文件按 `DSH_AI_RESEARCH_CHROME` → `CHROME_PATH` → 平台常见安装位置 → `PATH` 顺序自动探测。
- **谁来启动 Chrome（2026-10-15 实测结论，别踩第二次）**：`xhs.mjs` 里的 `ensureChrome()` 用 Node `spawn` 拉起 Chrome，在 **run_code 的 Node 里不生效**（子进程受沙箱 Job 限制，20 次探活全失败、24s 后抛「无头 Chrome 起不来」）；因此**先由宿主 shell 工具把 Chrome 起好**，再 import `xhs.mjs`（`ensureChrome` 一探到 9222 有响应就直接复用）。可用命令（Windows / PowerShell；**别用 `Start-Process`，也别用 `pwsh -File`**；macOS / Linux 直接 `"$(node -e 'console.log(1)' >/dev/null; echo $CHROME)" --headless=new ... &` 这类前台起法即可）：
  ```powershell
  $exe = "C:\Program Files\Google\Chrome\Application\chrome.exe"
  $prof = Join-Path $env:TEMP "dsh-chrome-xhs"
  Remove-Item $prof -Recurse -Force -ErrorAction SilentlyContinue; New-Item -ItemType Directory -Path $prof -Force | Out-Null
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $exe; $psi.UseShellExecute = $false
  $psi.Arguments = '--headless=new --disable-gpu --no-first-run --no-default-browser-check --disable-blink-features=AutomationControlled --remote-debugging-port=9222 --window-size=1440,1200 --lang=zh-CN --user-data-dir="' + $prof + '" about:blank'
  [System.Diagnostics.Process]::Start($psi) | Out-Null; Start-Sleep -Seconds 6
  try { (Invoke-WebRequest -UseBasicParsing http://127.0.0.1:9222/json/version -TimeoutSec 6).Content } catch { "ERR " + $_.Exception.Message }
  ```
  - **`Start-Process` 为什么不行（Windows / PowerShell 7 特有）**：进程环境里同时存在 `NO_PROXY` 与 `no_proxy`，PowerShell 7 建环境块用的是大小写不敏感的字典 → 抛「已添加项。字典中的关键字:“NO_PROXY”所添加的关键字:“no_proxy”」，而这个异常会被吞掉，表现为「退出码 0、端口却不通」的静默失败。走 .NET `ProcessStartInfo` 绕开它。
  - **`pwsh -File x.ps1` 为什么不行**：本机执行策略禁止运行未签名脚本（`PSSecurityException`）；`.ps1` 里的 `[char]34` 之类也救不了。直接贴命令最省事。
  - 起 Chrome 前先 `Remove-Item $prof -Recurse -Force`：残留的 `SingletonLock` 会让新实例立刻退出。
- 页面 UA 是 `HeadlessChrome/...`，要 `Emulation.setUserAgentOverride` 换成真实 UA；**匿名会话看不到结果**（登录墙），必须注入用户的 cookie。
- 两条路线：**A 复用已开的搜索页**（`findSearchPage` → 换关键词 → `mode:"reuse-ui"`，不占 session 配额，更快）；**B 新开页面**（`mode:"page"`，`bumpSession` 计数）。
- 预算与熔断：状态文件 `model-report/.xhs-state.json`（`day/sessions/calls/lastAt/cooldownUntil`），新开页面默认**每天 ≤4 次**；命中真风控（`code` 300013/461/471 或 `msg` 含「安全限制/访问频繁/Account abnormal/请稍后再试/账号异常」）→ 写 **24h 冷却**并直接抛错。
- **踩过的坑（重要）**：风险判定最初扫的是**整段响应正文**，正文里出现普通词就误判风控 → 误写 24h 冷却（而那次响应其实是 `success:true`、30 张卡片正常渲染）。现改为**只看信封**（`code`/`msg`/`success`）；`code:-1`（未签名）与 `code:-101`（未登录）**不算风控**，交给上层报错。以后加新源的风险判定，一律照这个原则写。
- 搜索页 URL 会被 SPA 二次编码（`keyword=Claude%2520Fable%25205`），但接口拿到的关键词正确、结果相关，**别去修**。
- 搜索侧拿不到：`web_search` 查 `site:xiaohongshu.com` 返 No results；页面内自造 XHR 打 `so.` 返 406、打 `edith.` 网络层直接失败（CORS）。
- 用户可见的交付要写清「小红书笔记：标题 —— 作者（赞 N · 评 M）· 时间」并给 `xsec_token` 完整链接。

## 英文社区源（X / Reddit，2026-10-16 接入）

两路默认开（`opts.x === false` / `opts.reddit === false` 可关；CLI `--no-x` / `--no-reddit`），结果落在 `res.x` / `res.reddit`，渲染成「**X（Twitter）讨论**」「**Reddit 讨论**」两节（同样每节 ≤5 条、同样支持 `> **解读**：`）。

| 源 | 实现 | 发现通道 | 正文通道 | 硬限制 |
|---|---|---|---|---|
| X（Twitter） | `model-report/x.mjs` | ① Brave `site:x.com "<模型名>"` ② 账号时间线（20 个官号/榜单号，按厂商别名挑，预算 6 个） ③ `opts.xOpts.seeds` 直喂链接 | `api.fxtwitter.com/<user>/status/<id>`：完整正文 + 赞/转/评/浏览量，**无配额** | syndication 时间线 **30 次 / 15 分钟滚动窗口**（看 `x-rate-limit-*` 响应头）；429 即写 `.cache/x-ratelimit.json`、整轮放弃时间线；剩余 ≤2 提前停；时间线缓存 6h |
| Reddit | `model-report/reddit.mjs` | ① Brave `site:reddit.com` ② **火管**：r/LocalLLaMA(14 页) / singularity(6) / MachineLearning(4) 按 `sort=desc` 翻页 + 本地相关性过滤 | arctic-shift `photon-reddit.com`：`/api/posts/ids?ids=` + `/api/comments/search?link_id=<id>&limit=100`（取 score 前 5）→ 兜底 pullpush.io | reddit.com 本机直连/代理一律 403（`/search.json`、`.json`、`.rss` 都不可靠）；arctic `limit≤100`、`subreddit=A,B` 多值返空、**不支持关键词参数**（只能火管 + 本地过滤） |

**必须在配好代理的那个主进程里跑**：实测同一个 syndication 请求，一边 200，同时刻换 shell 起的 `node.exe` 就是 429 —— 两者出口/限流桶不同（本机代理按进程分流）。Brave 同样在 shell 下更容易 429。**别用另一个出口进程去判断这两个源通不通。**

相关性口径：`tokenize()` 把模型名切成 tokens 与 core（core 去掉 pro / flash / max / mini / lite / turbo / ultra 这类通用后缀），要求 **core 命中 ≥2**（单词模型名退化成 tokens ≥2）；匹配按**词边界**做（否则 `pro` 会命中 `performance`）。Reddit 另外给每条打 `weak` 标记（标题没命中、只是正文/评论里带到），渲染时标「旁及帖」。

Brave 限流：12h 磁盘缓存（`~/.dsh-ai-research/.cache/search/`）+ 10 分钟冷却文件；被限流时两个源自动降级为「时间线 / 火管」单腿，并在 `gaps` 里写明。

口径提醒：**X 侧主要是「官方发布 + 榜单号转引」**（@XiaomiMiMo、@ArtificialAnlys 这类），真实使用反馈基本在 Reddit；不要把 X 的高赞当作用户口碑。Reddit 火管按模型发布期取（默认 30 天，`opts.redditOpts = { days: 30 }`）。

```bash
node model-report/x.mjs "MiMo v2.6 Pro" --limit 8             # 单跑 X（--no-search 只走账号时间线；--seeds 直喂链接）
node model-report/reddit.mjs "MiMo v2.6 Pro" --days 30        # 单跑 Reddit 火管（--no-hose 只走 Brave 发现）
node model-report/cli.mjs "MiMo v2.6 Pro" --no-x --no-reddit  # 报告里关掉这两路
```

## LMArena（人类盲测竞技场，2026-10-16 接入）

**站点直连是死路**：`lmarena.ai` 的 `/`、`/leaderboard`、`/leaderboard/text`、`/api/leaderboard` 一律 403（Cloudflare `Just a moment...`）；第三方代理也不行（`r.jina.ai` 401 `bad IP reputation`、`api.codetabs.com/v1/proxy` 522）；Wayback 只有 2026-01 的旧快照。**真正可用的是 LMArena 官方在 HuggingFace 发布的数据集**（`lmarena-ai/leaderboard-dataset`，public / `gated:false` / cc-by-4.0，**每天更新**）：

- 文件路径：`https://huggingface.co/datasets/lmarena-ai/leaderboard-dataset/resolve/main/<榜>/latest-00000-of-00001.parquet`（每个榜另有 `full` split；全量清单走 `https://huggingface.co/api/datasets/lmarena-ai/leaderboard-dataset/tree/main?recursive=1`）。
- **parquet 本机自己解**（零依赖、约 40ms/11033 行）：`model-report/parquet.mjs` 导出 `readFooter/readParquet/toRows`，支持 UNCOMPRESSED / SNAPPY / GZIP / ZSTD + PLAIN / RLE_DICT + 数据页 v1/v2，**不支持嵌套列 / DELTA_* / BYTE_STREAM_SPLIT（遇到直接抛错，不静默）**。排查时加 `PQ_DEBUG=1` 会逐页打印 `[pq] <列> page@<偏移> type=… nv=… enc=… 已解 n/total`。
- 缓存：`.cache/lmarena-<榜>.parquet`（原件）+ `.cache/lmarena-<榜>.json`（解码后的 rows，TTL 6h）；`opts.fresh` 强刷。
- 实现单份在 `model-report/lmarena.mjs`。`datasets-server.huggingface.co` 只在排查时用：`/first-rows` 稳（前 100 行 + schema），`/rows` 会 **429**（等 ~8s 恢复），`/filter`、`/search` 常 500（index loading）。**别把它当中转主路。**

**默认取 5 个榜**（`ARENA_DEFAULT_BOARDS`；单模型报告 5 行表，横评 5 列对齐）：

| 榜 id | 内容 | 列 | 实测发布日 |
|---|---|---|---|
| `text` | 文本总榜 + **29 个题集**（编程 / 数学 / 难题集(中英) / 指令遵循 / 多轮 / 长提问 / 创意写作 / 专家题 / 行业×8 / 多语言） | model_name, organization, license, rating, rating_lower, rating_upper, variance, vote_count, rank, category, leaderboard_publish_date | 2026-10-15 |
| `text_style_control` | **风格控制后**的同一批票（把回答风格从偏好里剥掉） | 同上 | 2026-10-15 |
| `webdev` | 前端生成（overall / html / react / image→webdev） | 同上 | 2026-10-13 |
| `vision` | 图片理解（OCR / 图表 / 作业 / 中文…） | 同上 | 2026-10-09 |
| `agent` | 真实会话里的 agent 表现 | **score / score_ci_lower / score_ci_upper / observation_count / session_count**（**没有 rating**，分数是 0~1 量级） | 2026-10-14 |

- **读数口径**：`text`/`text_style_control`/`webdev`/`vision` 是 **Elo ~1500 制**（`rating`），必须连着 `rating_lower~rating_upper`（95% 区间）念 —— **区间重叠就说不了谁强**。`agent` 榜是 score（取值约 -0.1~0.2），票数要念成「N 个会话 / M 次观测」，**别跟 Elo 混算**。
- **匹配**：榜里是小写连字符名（`mimo-v2.6-pro`），我们查的是「MiMo v2.6 Pro」——`arenaScore()` 归一化后按**词**比（词序全等 100 / 前缀连续 88 / 中间连续 76 / 词集合包含 60），比之前先剥掉 `(High)`/`(Max)` 这类档位括号；同一模型的多个推理档位在榜上是分开排的行。
- **报告落点**：单模型报告的 **LMArena 段**紧跟 Artificial Analysis 之后（每榜一行：名次 / 分数 / 95% 区间 / 票数 + 文本榜分项表 + 「风格控制前后」对比行）；横评里是 **第 2 节「LMArena 同榜对齐」**（模型×榜名次表 + 文本榜分项对齐表，分项表最多 12 行、其余折成一行）。
- `--no-lmarena` 关掉它；`--fast`（`deep:false`）也会跳过；`res.lmarena` 缺失/未命中会写进 `gaps`。
- 单跑 / 排查：

```bash
node model-report/lmarena.mjs "MiMo v2.6 Pro"            # 单模型 × 5 榜（读缓存，秒出）
node model-report/lmarena.mjs --compare "A,B,C"          # 横评对齐表
node model-report/lmarena.mjs "MiMo v2.6 Pro" --fresh    # 忽略缓存重下 parquet
```
### 试过但拿不到（别重复探）

- 国内四榜 **OpenCompass / SuperCLUE / FlagEval / AGI-Eval**：页面只是前端壳，接口返回 SPA HTML，无可用数据接口。
- **tbench.ai / livebench.ai / epoch.ai**：数据在客户端取数，页面里没有数据本体。
- **lmarena.ai 站点本体（含 `/api/leaderboard`）**：Cloudflare 403 + `Just a moment...`，第三方代理与 Wayback 也拿不到当前数据 → **改走 HF 官方数据集**，见上一节。**HuggingFace 模型卡 / 讨论区正文、知乎正文、B站搜索 API**：仍未解析（HF 的 API 与数据集本身可达）。
- **reddit.com 本体**：403（含 `/search.json`、`.json`、`.rss`）—— 走 arctic-shift 归档 + Brave 发现，见「英文社区源」。**X 搜索页**要登录，绕开即可（Brave 发现 x.com 链接 + fxtwitter 取正文）。
- **aider.chat 榜单**：2025-10 后停更，弃。**Artificial Analysis 的 `/api/v2/data/llms/models`**：401 要 key，只能用页面 RSC。

## 单模型：怎么用（run_code 里跑，纯 Node 零依赖）

```js
const M = await import("file:///F:/DSH%20Projects/Untitled/model-report/lib.mjs");
// 推荐入口：一轮拿齐「本模型 + 3 个同类对手」
const { r, cmp } = await M.report("Gemini 4 Argon", { peers: 3 });
console.log(JSON.stringify(M.summarize(r), null, 1));
console.log(M.brief(r));                       // ① 解读素材包（含英文原句、insights JSON 模板）
// ② 我读完素材写 insights JSON（见下）③ 再渲染给人看的报告：
fs.writeFileSync("out.md", M.renderMarkdown(r, { insights, compare: cmp }));
```

只想拿原始数据（不要横评）：`const r = await M.gather("Gemini 4 Argon")`（13 路并行，deep 约 15~25 秒；LMArena 冷缓存多花约 2 秒）。
命令行（工作区根目录）：

```bash
node model-report/cli.mjs "Claude Sonnet 5.5" --peers 3 --brief --out results     # 先拿素材包
node model-report/cli.mjs "Claude Sonnet 5.5" --peers 3 --insights ins.json --out results   # 带解读出报告
```

`--out` 的相对路径以 `model-report/` 为基准（落 `model-report/results/`）。
**要快**：加 `--fast`（= `deep:false`，跳过第 8~13 号（Artificial Analysis / Vals / SWE-bench / SWE-rebench / ARC / LMArena），约 3 秒）；LMArena 也能单独用 `--no-lmarena` 关掉；`--per-source N` 改每源条数上限（默认 5）；`--no-peers` 关掉横评。

### gather 返回什么

- `detail.model`：档案（名称/厂商/发布日/上下文/价格/吞吐/开源与否/arena_scores）。
- `detail.independent / thirdParty / vendor`：跑分按**可信度分流**——`independent`（llm-stats 标 verified 且非自报，**实测恒为 0**）、`thirdParty`（第三方榜转引）、`vendor`（厂商发布稿数字）。**引用分数必须带上是哪一档**。
- `benchlmMatches[0]`：benchlm 聚合排名（名次/综合分/Elo/tok-s/延迟）。
- `aaMatches` / `valsMatches` / `swebenchMatches` / `rebenchMatch` / `arcMatches`：5 个新源的命中（详见上表）；deep 模式下无命中会写进 `gaps`。
- `openRouterMatches[0] / openRouter`：是否在售、官方价格、上下文。
- `lmarena`：LMArena 一包 —— `{ok, publishDate, boards:[{id,label,kind,publishDate,model,variant,overall:{rank,total,value,lower,upper,votes,sessions},variants[],categories[]}], hits, gaps}`（每榜独立失败隔离；没命中会进 `gaps`）。
- `hn`（帖子 ▲分/评论数/代表评论，`fullHit=true` 表示正文含完整模型名）、`juejin`（`exact` = 标题就写着该模型）、`github`（生态接入）。
- `cn`：中文社区一包 —— `{bilibili:{total,videos[],comments[]}, csdn[], weixin[], zhihu[], xiaohongshu[]}`，未启用/失败的源进 `cn.fail`（如 `"未配置登录态 cookie"`）。

### renderMarkdown 的节次

工具产出（单模型，`renderMarkdown`）：`# <模型> —— 实测 / 口碑体检` → 引用块（采集时间 / 耗时）→ `## 目录` → `## 摘要`（insights）→ **一、模型档案**（档案表）→ **二、跑分总览**（三档表 ★/†/‡ + 每档条数上限 + `> **解读**：…`）→ **三、榜单明细**（H3：benchlm.ai 聚合 / Artificial Analysis 独立榜 / LMArena 人类盲测竞技场（官方榜）/ SWE-bench 官方榜 / SWE-rebench 滚动榜 / ARC Prize 榜 / Vals AI）→ **四、价格与在售**（H3：OpenRouter 在售）→ **五、社区口碑**（H3：Hacker News 口碑 / X（Twitter）讨论 / Reddit 讨论 / 中文技术圈（掘金）/ B站实测视频 / CSDN 技术帖 / 微信公众号文章 / 知乎 / 小红书 / GitHub 生态接入）→ **六、同类横评**（`--peers` / `--auto` 时内嵌）→ **七、数据缺口与阅读须知**。**每个源段落末尾都会有一行 `> **解读**：…`**（来自 insights，缺则自动生成一句）。

工具产出（横评，`renderCompare`）：`# 横评：A vs B vs C` → 引用块 → `## 目录` → 一、同尺度榜 → 二、LMArena 同榜对齐 → 三、独立榜对照（H3：Artificial Analysis 智能指数 / Vals AI 同榜对齐 / SWE-rebench 滚动榜 / ARC Prize 榜）→ 四、统一字段 → 五、重合基准 → 六、各模型跑分构成 → 七、中文社区口碑 → 八、数据缺口 → 九、阅读须知。

## 输出排版（Markdown 骨架，2026-10-16 统一）

三套工具（ai-model-radar / model-report / ai-news-radar）与 **agent 手写的解读稿**共用同一套骨架，
编号 / 目录 / 分隔线的实现只有一份：`model-report/doc.mjs`。

1. **一份文档只有一个 H1**：`# <主题>`。改造前 model-report 的报告全文只有 1 个 `#`，其余全是 `**粗体**` 伪标题 —— 在 Markdown 阅读器里没有大纲，别再写回去。
2. **元信息走引用块**（紧跟 H1，两行）：`> 数据截止 … · 生成时间 …` / `> 全部来源为公开只读接口，仅供研究参考。`
3. **`## 目录` 由 `doc.mjs` 生成**：正文里先写占位符 `TOC_PLACEHOLDER`（`<!-- dsh-toc -->`），收尾时替换成带 GitHub 风格锚点的目录（H2 + H3 两级）。
4. **章标题自动编号**：正文写 `## 模型档案`，收尾时变成 `## 一、模型档案`。`cnNum()` 支持「十一、二十一」；**不要再用 `CN[Math.min(n-2, CN.length-1)]` 那种夹紧写法** —— 旧版 `ai-news-radar` 就是因此出现「十、社区热议」与「十、按公司看」重号。手写文档请自己写中文序号。
5. **三级标题不编号**：`### B站实测视频（约 1000 条命中）`；口径说明放斜体独立行（`*播放 / 评论为累计值*`），不要全塞进标题括号。
6. **章节之间一条 `---`**：`addRules()` 在每个编号章前插（目录章除外），生成物不必手写。
7. **收尾两章固定**：`## 数据缺口 …`（gaps / 失败源如实列出）＋ 合规声明引用块（研究参考，不构成投资建议）。
8. **表格只用于「≥3 行、列之间同质」的对照**（元信息 / 跑分 / 模型横评）；流程与层级关系用列表或 GenUI，不用表格硬摆。

`doc.mjs` 导出（改渲染逻辑时用）：`TOC_PLACEHOLDER` · `finalizeDoc(md, { skip, toc, rules })` · `cnNum(n)` · `slugifyHeading(text, used)` · `scanHeadings(md, levels)`（自动跳过围栏代码块）· `numberChapters(md, { skip })` · `addRules(md)` · `buildToc(md)`。
`finalizeDoc` 默认 `skip: ["目录", "摘要"]`（这两章不编号）；三套 lib 的 `renderMarkdown` / `renderCompare` 收尾都调它，**手写文档也可以 import 它收尾**。

## 横评（2~4 个模型）：compare

```js
const r = await M.compare(["Gemini 4 Argon", "Claude Opus 5.5", "Claude Fable 5"]);
console.log(JSON.stringify(M.summarizeCompare(r), null, 1));
console.log(M.renderCompare(r));   // 九节 Markdown
```

CLI：`node model-report/cli.mjs --vs "Gemini 4 Argon,Claude Opus 5.5,GPT-6.1" --out results`
（写出的文件名形如 `compare-<各模型 slug>-<日期>.md`；同样支持 `--fast` / `--no-lmarena` / `--no-x` / `--no-reddit`）

**不想自己挑对手**：只给一个模型 + `--auto N`，自动挑 N 个段位相近的对手：

```bash
node model-report/cli.mjs "Gemini 4 Argon" --auto 3 --out results
```

- 挑人逻辑（`peerModels`，`similarModels` 已统一到它）：**能力刻度优先** —— 有 AA 智能指数就用它（差值 ≤2 → +42，≤4 → +32，≤7 → +20，≤14 → +9，超过 14 直接淘汰），拿不到就退到 benchlm 综合分（同档位换算）；再叠加同价位 +18 / 价位接近 +8、同期发布(≤45 天) +12 / ≤120 天 +6、同开源属性 +8、上下文量级相近 +5、同厂商 +4（交叉厂商排序优先）。价格优先 llm-stats，缺则 OpenRouter 回填。
- 多样性：**同一系列只取一个**、同一厂商最多 1 个。`peerPicks` / `auto` 带每个对手的 `why[]` 理由。
- **自动挑的是「段位相近」，不是「最该比的」** —— 要精确对比就显式写 `--vs`。`--vs` 只给一个模型且没加 `--auto` 时 exit 1。

### compare 返回什么

- `models[]`：每个模型 {found, name, org, release, tiers, benchlm, or, `aa`/`aaBest`, `vals`, `rebench`, `arc`}；找不到时带 `near` 给最接近的名字。
- `shared[]`：**重合基准交集**（基准名归一化后取交集，≥2 个模型测过）。`sharedStats{all,shared,models}`、`arenaCoverage`。
- `models[].lmarena`：`lmarenaBrief()` 的紧凑结果 —— `{ok, publishDate, boards:{<榜>:{label,kind,rank,total,value,lower,upper,votes}}, cats:{<题集>:{zh,rank,total,value,votes}}, gaps}`；`opts.lmarena === false` 可整体关掉。
- `models[].cn`：该模型的中文社区一包（结构同 gather 的 `cn`；`opts.cn === false` 可整体关掉，会省掉每个模型 10~20 秒）。
- `valsAll` / `valsShared`：Vals 按 slug 分组；`valsShared` 只保留 ≥2 个模型命中的榜（同模型同表多行取名次更靠前的），**这是横评里唯一能跨模型对齐的第三方榜**。

renderCompare 的九节：① 同尺度榜（benchlm）；② **LMArena 同榜对齐（人类盲投，模型×榜名次 + 文本榜分项）**；③ **独立榜对照（AA / Vals / SWE-rebench / ARC）**；④ 统一字段；⑤ 重合基准交集表；⑥ 各模型跑分构成；⑦ **中文社区口碑（B站最热实测视频 + 高赞评论 + CSDN/微信条数）**；⑧ 数据缺口；⑨ 阅读须知。

档位标记：`★` 独立验证 · `†` 第三方榜转引 · `‡` 厂商自报。

### 横评口径纪律

- 分数与档位标记必须成对出现；★ 通常整列为 0，要明说"没有独立复现的分数"。
- **同名基准 ≠ 同一场考试**（harness、日期可能不同）——只能当方向参考。
- **AA 的 intelligenceIndex 是它自建刻度**，与 benchlm 综合分（如 80.87）不是一套，**不可混算、不可相加**；AA 只能各自内部比。
- **Vals 同一张表内的名次可比**；不同 slug（表）之间、SWE-rebench 与 ARC 跨榜之间不可比。
- SWE-rebench 引用时带 n；样本太小的窗口不可信。SWE-bench 官方榜要标"提交滞后"。
- **LMArena 同榜内可比**（同一批人类投票）：引用名次必须带 95% 区间，**区间重叠就不能说谁强**；它的 Elo 与 benchlm 的 Elo 不是一套算法（只是都叫 Elo）。
- 最稳的一栏：LMArena 文本榜名次（人类盲投）+ benchlm 综合分/Elo（单一尺度）+ Vals 同表对齐。
- 横评**必须**补主观口碑：每个模型各跑一次 `web_search`（中英各一条），归纳 3~5 条并注明样本量差异。

## 标准流程（照这个来）

1. **抓数据 + 挑对手**：`const { r, cmp } = await M.report("<模型名>", { peers: 3 })`（约 2~4 分钟；`--fast` 约 10 秒但会缺 AA/Vals/SWE 等）。
2. **读素材包**：`M.brief(r)` —— 它把六类信号压成一页，**英文原句也在里面（标 `[EN]`）**，末尾给出 insights JSON 的模板与硬要求。先把这一页读完再动笔。
3. **写 insights（关键步骤，不能跳）**：把下面这份 JSON 存成文件（字段说明见「insights 怎么写」），中文解读**必须是我读完素材后的判断**，不能只是复述标题。
4. **渲染**：`M.renderMarkdown(r, { insights, compare: cmp })`（或 CLI `--insights ins.json`）→ 得到带「一句话结论 + 每段解读 + 英文中译 + 同类横评」的成品。
5. **补主观口碑（仍要做）**：用 `suggestQueries(name)` 的查询调 `web_search`，挑 3~5 条要点补进报告/dsh-ui 卡（X 与 Reddit 已在第 1 步自动抓；这一步补 YouTube 长测 / 少数派 / 行业长评等仍抓不到的）。
6. **交付**：`--out results` 落 md+json（文件名自带日期，便于追踪对比），再用 dsh-ui 卡片呈现（跑分表 + 同类对齐 + 口碑 + 缺口 callout）。

### 交付前必做：把裸的美元符号转义（2026-10-16 实测确认）

报告与 dsh-ui 卡里有大量价格（4 美元 / 20 美元、0.16 美元每题这种）。**同一个段落里出现两个裸的美元符号，就会被聊天渲染器当成行内公式定界符**（Markdown 标准行为）；公式渲染器缺席时会回退成「等宽 + 字号偏大」样式，用户会看到一句话里某几个字突然变大，质疑渲染坏了。

- 实测三行对照（用户回执「①大②正常③正常」）：成对裸符号变大 · 单个裸符号正常 · 反斜杠转义正常。
- **规则**：写进对话 / 卡片的文本，金额一律写成「反斜杠 + 美元符号」；落盘产物（md / json / insights）同样转义，免得用户回头打开又看到大字。
- 转义写法：不要用 `String.replace(re, 替换串)` —— 替换串里的 $ 有特殊含义（会展开成 `$&` 之类），实测把 `200/月` 那段写坏成 `…198`。用函数式替换，或直接 `s.split("$").join("\\$")`。
- 渲染前把 `insights` 对象 `JSON.stringify` 落盘、再 `JSON.parse` 读回来**是最稳的传递方式**：本机实测手工拼的 insights 对象直接传给 `renderMarkdown` 会静默失效（`sources.*.read` 一个都不注入），JSON 往返后 17 段解读全部正常注入。

## insights 怎么写（报告的「人味」全靠它）

```json
{
  "verdict": "一句话结论（30~60 字，说清楚段位 + 最大优点 + 最大代价）",
  "points": ["3~6 条要点，每条一个判断，不要复述标题"],
  "caveats": ["口径提醒 / 样本量 / 该模型的自建基准"],
  "sources": { "lmarena": { "read": "名次与风格控制前后的差说明了什么（如「原始榜好看、风格控制后掉 16 位」）" }, "hn": { "read": "HN 在吵什么、结论是什么" }, "x": { "read": "X 上的发布/榜单转引结论" }, "reddit": { "read": "Reddit 的真实使用反馈与反对意见" }, "bilibili": { "read": "中文实测的共同结论" } },
  "quotes": [ { "en": "英文原句（照抄原文）", "zh": "中文释义（翻译 + 一句『他想说的是』）", "src": "HN", "url": "https://…" } ]
}
```

**硬要求（会自动检查）：**

- 每个论坛 / 源**最多 5 条**（`capReport` 已截断，超出的进 `.dropped` 计数）——**宁可少列，不要贴一堆标题**。
- 每条都要有**结论**：写「社区普遍认为推理链太长、同样的题 Opus 5.5 一次过」，不要只写「有一篇帖子叫《XX 实测》」。
- **英文帖子必须中译**：`quotes[].en` 照抄原文、`quotes[].zh` 给中文释义（含语气/结论），渲染时会以「英文原文 → 中文释义」引用块出现。
- 厂商自建基准（如 MiMo Cyber Bench）**不得当第三方**：写进 `caveats` 或在解读里点名。
- 拿不到的源要留在「数据缺口」里，别用摘要冒充原文。

## 口径纪律（重要）

- **厂商自报 ≠ 实测**：三档必须分开列；`independent` 为 0 时明说"没有独立复现的分数"。
- benchlm 的 Elo 与 llm-stats 的 `arena_scores` 口径不同，别相加、别当同一个榜；**LMArena 的 Elo 又是第三套**（llm-stats 那个 `arena_scores` 不是 LMArena，实测同一模型两边数值完全对不上）。
- **厂商自建基准**（小米 MiMo Cyber Bench 这类）不得当第三方分数；LMArena / benchlm / AA / Vals 都是第三方口径，可以并列为「别人测的」。
- HN ▲ 分高 ≠ 评价好，只是热度；引用评论要连链接一起给。
- 输出结尾固定声明：研究参考，不构成采购/投资建议。

## 实测不可达（2026-10-16 更新）

**lmarena.ai 站点本体**（Cloudflare）、**HuggingFace 模型卡 / 讨论区正文**、**知乎正文**、**B站搜索 API**，以及国内四榜（OpenCompass / SuperCLUE / FlagEval / AGI-Eval）与 tbench / livebench / epoch / 少数派 —— 别浪费时间重试；这些站的内容只能靠 `web_search` 摘要转引，并且**不要**把摘要当原文引用。

（B站 / CSDN / 微信公众号 / 掘金已可直接抓；**知乎、小红书已配好 cookie 并真机验证**（小红书额外需要本机无头 Chrome，见上）；**X 与 Reddit 2026-10-16 已接入**（见「英文社区源」，务必在 run_code 里跑）；**LMArena 2026-10-16 已接入**（走 HF 官方数据集 + 本机 parquet 解码，见「LMArena」节）；微博 / 贴吧 已删除。）
