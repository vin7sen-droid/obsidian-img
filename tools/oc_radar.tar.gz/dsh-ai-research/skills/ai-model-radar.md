---
name: ai-model-radar
description: AI 模型发布雷达 —— 一站式汇总"最近有哪些新模型发布/上线/开源"。当用户问「最近有什么新模型」「AI 模型发布动态」「某厂商是不是发新模型了」「大模型圈最近有什么动静」时使用。汇总发布追踪站、OpenRouter 上架记录、官方博客 RSS、GitHub release、arXiv 论文与 Hacker News 热度，去重合并后输出带来源链接的日报。
---

# AI 模型发布雷达（ai-model-radar）

> **路径与环境（先读这条）**：本文里的 `model-report/xxx.mjs`、`ai-news-radar/xxx.mjs`、`ai-model-radar/xxx.mjs`
> 都是**相对工具根目录**的路径 —— 源码仓库里工具根是 `tools/`（例：`tools/model-report/cli.mjs`），
> 插件 `dsh-ai-research` 的 `config.root` 同理；命令示例一律按工具根书写。
> 运行期状态（cookie / 缓存 / 限流与熔断状态）统一在 **`~/.dsh-ai-research/`**（`DSH_AI_RESEARCH_HOME` 可改：
> 缓存 `.cache/`、cookie `cookies.json`、小红书状态 `xhs-state.json`）。
> 出网代理按 `DSH_AI_RESEARCH_PROXY` → `MODEL_REPORT_PROXY` → `HTTPS_PROXY` / `HTTP_PROXY` 取，都没设就直连（`NO_PROXY` 生效）。
> 下文命令示例以 **Windows / PowerShell** 为准；macOS / Linux 把 `$env:X=...` 换成 `X=... 命令` 即可。

## 能力

一句话触发：拉取最近 N 天内**所有 AI 模型发布相关消息**，逐条带日期、来源与链接。

覆盖六类信号：

| 段 | 含义 | 来源 |
|---|---|---|
| 模型发布 / 已宣布 | 权威发布记录（厂商、模型名、开放权重与否） | aireleasetracker.com 页面内嵌 releases 数组 |
| 新上架 | 商业 API 市场上架时间 | openrouter.ai/api/v1/models（created 时间戳） |
| 官方公告 | 厂商博客新帖 | OpenAI / DeepMind / Google AI / NVIDIA / Qwen 的 RSS |
| 开源仓库 Release | 开源权重模型发布 | github.com 各仓库 releases.atom（免鉴权） |
| 论文 | 带模型名的新论文 | arXiv API（cs.CL 最新 40 条） |
| 社区热度 | 讨论热度 | Hacker News Algolia API（按分数过滤） |

## 怎么跑

代码在会话工作区 ai-model-radar/（**纯 Node，零依赖**，不要装包）：

- ai-model-radar/lib.mjs — 采集与渲染逻辑
- ai-model-radar/run.mjs — 入口，落盘到 ai-model-radar/digests/<YYYY-MM-DD>.md|.json

在 run_code 里（推荐，能顺手拿到结构化结果）：

```
const mod = await import("file:///F:/DSH Projects/Untitled/ai-model-radar/lib.mjs");
const res = await mod.collect({ days: 7 });        // 亦可 { include:["release","listed"] }
console.log(mod.summarize(res));                    // 各段条数 + 各源成败
const md = mod.renderMarkdown(res);                 // Markdown 日报
```

或者走入口脚本落盘（需要 shell；当前机器 shell 被沙箱拦，优先用上面的方式）：

```
node ai-model-radar/run.mjs --days 7
```

## 参数

- days — 窗口（默认 3）。发布追踪站的记录默认放宽到 releaseDays（默认 60）天，因为权威发布记录本身稀疏。
- include — 只要某几段，如 ["release","listed","announcement"]。
- releaseDays / minPoints（HN 分数门槛，默认 5）/ repos / feeds 可在 collect() 里覆盖。

## 输出排版（Markdown 骨架，2026-10-16 统一）

三套工具（ai-model-radar / model-report / ai-news-radar）与 **agent 手写的解读稿**共用同一套骨架，
编号 / 目录 / 分隔线的实现只有一份：`model-report/doc.mjs`。

1. **一份文档只有一个 H1**：`# <主题>`。改造前 model-report 的报告全文只有 1 个 `#`，其余全是 `**粗体**` 伪标题 —— 在 Markdown 阅读器里没有大纲，别再写回去。
2. **元信息走引用块**（紧跟 H1，两行）：`> 数据截止 … · 生成时间 …` / `> 全部来源为公开只读接口，仅供研究参考。`
3. **`## 目录` 由 `doc.mjs` 生成**：正文里先写占位符 `TOC_PLACEHOLDER`（`<!-- dsh-toc -->`），收尾时替换成带 GitHub 风格锚点的目录（H2 + H3 两级）。
4. **章标题自动编号**：正文写 `## 模型档案`，收尾时变成 `## 一、模型档案`。`cnNum()` 支持「十一、二十一」；**不要再用 `CN[Math.min(n-2, CN.length-1)]` 那种夹紧写法** —— 旧版 `ai-news-radar` 就是因此出现「十、社区热议」与「十、按公司看」重号。手写文档请自己写中文序号。
5. **三级标题不编号**：`### B站实测视频（约 1000 条命中）`；口径说明放斜体独立行（`*播放 / 评论为累计值*`），不要全塞进标题括号。
6. **章节之间一条 `---`**：`addRules()` 在每个编号章前插（目录章除外），生成物不必手写。
7. **收尾两章固定**：`## 数据缺口 …`（gaps / 失败源如实列出）＋ 合规声明引用块（研究参考，不构成投资建议）。
8. **表格只用于「≥3 行、列之间同质」的对照**（元信息 / 跑分 / 模型横评）；流程与层级关系用列表或 GenUI，不用表格硬摆。

`doc.mjs` 导出（改渲染逻辑时用）：`TOC_PLACEHOLDER` · `finalizeDoc(md, { skip, toc, rules })` · `cnNum(n)` · `slugifyHeading(text, used)` · `scanHeadings(md, levels)`（自动跳过围栏代码块）· `numberChapters(md, { skip })` · `addRules(md)` · `buildToc(md)`。
`finalizeDoc` 默认 `skip: ["目录", "摘要"]`（这两章不编号）；三套 lib 的 `renderMarkdown` / `renderCompare` 收尾都调它，**手写文档也可以 import 它收尾**。

本技能产出（示例见 `ai-model-radar/digests/2026-10-15.md`）：

```
# AI 模型发布雷达 · <日期>
> 数据窗口：最近 N 天（自 …） · 生成时间 …
> 全部来源为公开只读接口，仅供研究参考。

## 目录
---
## 一、采集说明          ← 表格：数据窗口 / 生成时间 / 去重后条目 / 采集成功 / 采集失败
## 二、模型发布 / 已宣布（N 条）
## 三、新上架（OpenRouter）（N 条）
## 四、官方公告（N 条）   ## 五、论文（N 条）   ## 六、社区热度（Hacker News）（N 条）
```

agent 自己写「本周模型圈简报」这类总结时，也用同一骨架（H1 + 元信息块 + `## 一、…` + `## 数据缺口` + 免责声明）。

## 使用要点

1. **先 summarize 再渲染**：源失败会写进 sources[].error（例如 arXiv 偶尔超时），日报里逐条声明，不要把空段落当成"没有新闻"。
2. **未来日期 = 已宣布未发布**：条目带 upcoming: true，渲染成「待发布/已宣布」。
3. **跨源自动合并**：同一次发布同时出现在追踪站和 OpenRouter 时，只留发布记录，其它链接挂在 meta.alsoOn。
4. **要补二手舆情（X/Reddit）再叠一层 web_search**：本机 X/Reddit 通道不通（见下），只能用 web_search 拿转述文章的标题与链接，**不要把它们当事实来源**。
5. **合规**：全部为公开只读接口，输出仅供研究参考；引用时保留日期。

## 本机已知边界（2026-10-15 实测，别重复踩）

- x_search 工具**恒定 degraded**（source=web），X 通道不可达，返回的是普通网页而不是推文。
- Reddit 全路不通：.json 403 / .rss 超时 / old.reddit 空壳 / 走代理（HTTPS_PROXY）仍 403 / PullPush 429 / web_fetch 403。
- HuggingFace（含 hf-mirror）直连与走代理都是 UND_ERR_CONNECT_TIMEOUT —— 所以没有 HF 新模型榜。
- autoglm-* 技能族依赖本地 token 服务 http://127.0.0.1:53699/get_token，当前 ECONNREFUSED（整族不可用）。
- 配了代理（示例 `http://127.0.0.1:7890`）时 x.com 可通（200），但返回 JS 壳，无浏览器取不出内容。
- 受限沙箱里 shell 子进程可能被整体拦掉（本机实测 pwsh 退出码 3221225794 = 0xC0000142）—— **别把技能写成依赖 shell 脚本**，直接 import 模块最稳。
