#!/usr/bin/env node
// 把一次剪贴板里的 Cookie 存进 cookies.json —— 用法（在 PowerShell 里）：
//   $env:MR_COOKIE = (Get-Clipboard -Raw); node model-report/set-cookie.mjs zhihu [--test]
// 也可以 MR_COOKIE="<整条 Cookie>" node model-report/set-cookie.mjs xiaohongshu
// （微博 / 贴吧 两源 2026-10-16 已删，不再接受）
// 设计：cookie 只经环境变量进入进程，脚本**从不打印 cookie 值**，只报长度与识别到的票据名。
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { cookiesPath } from "./home.mjs";

const FILE = cookiesPath();
const SITES = {
  zhihu: { name: "知乎", hint: ["z_c0=", "_xsrf="], must: "z_c0=" },
  xiaohongshu: { name: "小红书", hint: ["web_session=", "a1="], must: "web_session=" },
};
const KEY = (process.argv[2] || "").toLowerCase();
if (!SITES[KEY]) { console.error("用法: node model-report/set-cookie.mjs <" + Object.keys(SITES).join("|") + ">"); process.exit(2); }
const raw = process.env.MR_COOKIE;
if (!raw || !raw.trim()) { console.error("没读到 cookie：先把浏览器里复制好的 Cookie 放进剪贴板，或设 MR_COOKIE 环境变量。"); process.exit(3); }

let ck = String(raw)
  .replace(/^\s*cookie\s*:\s*/i, "")
  .replace(/[\r\n\t]+/g, " ")
  .replace(/\s{2,}/g, " ")
  .trim()
  .replace(/[";]\s*$/, "");
const S = SITES[KEY];
const names = ck.split(";").map((s) => s.split("=")[0].trim()).filter(Boolean);
const missing = S.must && ck.indexOf(S.must) < 0;

let db = {};
try { if (existsSync(FILE)) db = JSON.parse(readFileSync(FILE, "utf8")); } catch (e) { console.error("cookies.json 读不动（" + String(e.message).slice(0, 80) + "），将重建。"); db = {}; }
for (const k of Object.keys(db)) if (k.startsWith("_")) delete db[k];
db[KEY] = ck;
mkdirSync(dirname(FILE), { recursive: true });
writeFileSync(FILE, JSON.stringify(db, null, 2) + "\n", "utf8");

console.log("[" + S.name + "] 已写入 " + FILE);
const found = S.hint.filter((h) => ck.indexOf(h) >= 0);
console.log("  cookie 长度 " + ck.length + " · " + names.length + " 个字段 · 识别到关键票据：" + (found.length ? found.join(" ") : "（无）"));
if (missing) console.error("⚠️ 没看到 " + S.must + " —— 这多半不是**登录态** cookie（可能只是游客会话）。请确认已登录、且复制的是 www." + KEY + ".com 的请求头 Cookie。");
if (process.argv.indexOf("--test") >= 0) {
  const cn = await import("./cn.mjs");
  const posArg = process.argv.slice(3).filter((a) => !a.startsWith("--"))[0];
  const q = posArg || "Gemini 4 Argon";
  const fns = { zhihu: cn.zhihuBuzz, xiaohongshu: cn.xiaohongshuBuzz };
  try {
    const r = await fns[KEY](q, { limit: 5 });
    console.log("[自测] 搜「" + q + "」返回 " + (r && r.length) + " 条");
    for (const it of (r || []).slice(0, 3)) console.log("   - " + String(it.title || it.text || "").slice(0, 70));
  } catch (e) { console.error("[自测失败] " + String(e.message).slice(0, 220)); process.exit(1); }
}
