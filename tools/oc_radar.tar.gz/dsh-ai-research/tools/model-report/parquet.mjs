// parquet.mjs —— 极简 Parquet 读取器（零依赖）：只覆盖「扁平的 OPTIONAL 叶子列 + PLAIN / RLE_DICT / RLE 定义级别」
// 用途：LMArena 官方榜数据集（HF `lmarena-ai/leaderboard-dataset`）只发 parquet，613KB 一个文件，
//      一次 HTTP 拿全榜，比 datasets-server 分页（会被 429 限流）稳得多。
// 支持 codec：UNCOMPRESSED / SNAPPY(自实现) / GZIP / ZSTD(Node 22+ 自带)。
// 不支持：嵌套列、BYTE_STREAM_SPLIT、DELTA_* 编码 —— 遇到就直接抛错，不要静默给错数。
import zlib from 'node:zlib';

const TYPES = { 0: 'BOOLEAN', 1: 'INT32', 2: 'INT64', 3: 'INT96', 4: 'FLOAT', 5: 'DOUBLE', 6: 'BYTE_ARRAY', 7: 'FLBA' };
const CODEC = { 0: 'UNCOMPRESSED', 1: 'SNAPPY', 2: 'GZIP', 3: 'LZO', 4: 'BROTLI', 5: 'LZ4', 6: 'ZSTD', 7: 'LZ4_RAW' };
const ENC = { 0: 'PLAIN', 2: 'PLAIN_DICTIONARY', 3: 'RLE', 4: 'BIT_PACKED', 5: 'DELTA_BINARY_PACKED', 6: 'DELTA_LENGTH_BYTE_ARRAY', 7: 'DELTA_BYTE_ARRAY', 8: 'RLE_DICTIONARY', 9: 'BYTE_STREAM_SPLIT' };

// ---------------- snappy（raw 格式，自实现；Node 没有内置） ----------------
export function snappyDecompress(src) {
  let p = 0, len = 0, s = 1;
  for (;;) { const b = src[p++]; len += (b & 0x7f) * s; if (!(b & 0x80)) break; s *= 128; }
  const out = Buffer.alloc(len);
  let o = 0;
  while (p < src.length && o < len) {
    const t = src[p++], ty = t & 3;
    if (ty === 0) {
      let n = t >> 2;
      if (n < 60) n += 1;
      else { const extra = n - 59; let v = 0; for (let i = 0; i < extra; i++) v += src[p++] * Math.pow(256, i); n = v + 1; }
      src.copy(out, o, p, p + n); p += n; o += n;
    } else {
      let n, off;
      if (ty === 1) { n = ((t >> 2) & 7) + 4; off = ((t >> 5) << 8) | src[p++]; }
      else if (ty === 2) { n = (t >> 2) + 1; off = src[p] | (src[p + 1] << 8); p += 2; }
      else { n = (t >> 2) + 1; off = src[p] | (src[p + 1] << 8) | (src[p + 2] << 16) | (src[p + 3] << 24); p += 4; }
      if (off <= 0 || off > o) throw new Error('snappy: 拷贝偏移越界 off=' + off + ' @' + o);
      for (let i = 0; i < n; i++) { out[o] = out[o - off]; o++; }
    }
  }
  return out;
}

function decompress(codec, buf, uncompressedSize) {
  const name = CODEC[codec] || String(codec);
  if (codec === 0) return buf;
  if (codec === 1) return snappyDecompress(buf);
  if (codec === 2) return zlib.gunzipSync(buf);
  if (codec === 6) {
    if (typeof zlib.zstdDecompressSync !== 'function') throw new Error('本机 Node 不支持 zstd，无法读这个 parquet');
    return zlib.zstdDecompressSync(buf);
  }
  throw new Error('未实现的 parquet codec：' + name);
}

// ---------------- thrift compact ----------------
function thrift(b, start = 0) {
  let p = start;
  const rd = {
    pos: () => p,
    seek(n) { p = n; },
    byte() { return b[p++]; },
    varint() { let r = 0, s = 1; for (;;) { const x = b[p++]; r += (x & 0x7f) * s; if (!(x & 0x80)) return r; s *= 128; } },
    zigzag() { const v = this.varint(); return v % 2 ? -(v + 1) / 2 : v / 2; },
    double() { const v = b.readDoubleLE(p); p += 8; return v; },
    binary() { const n = this.varint(); const s = b.slice(p, p + n); p += n; return s; },
    str() { return this.binary().toString('utf8'); },
    skip(t) {
      switch (t) {
        case 1: case 2: return;
        case 3: p += 1; return;
        case 4: case 5: case 6: this.varint(); return;
        case 7: p += 8; return;
        case 8: this.binary(); return;
        case 9: case 10: { const h = this.byte(); let n = h >> 4; const et = h & 15; if (n === 15) n = this.varint(); for (let i = 0; i < n; i++) this.skip(et); return; }
        case 11: { const n = this.varint(); if (!n) return; const h = this.byte(); for (let i = 0; i < n; i++) { this.skip(h >> 4); this.skip(h & 15); } return; }
        case 12: this.struct(() => false); return;
        default: throw new Error('thrift 类型未知：' + t + ' @' + p);
      }
    },
    struct(cb) {
      let last = 0;
      for (;;) {
        const x = this.byte();
        if (x === 0) return;
        const t = x & 15;
        let id = x >> 4;
        if (id === 0) id = this.zigzag(); else id = last + id;
        last = id;
        if (!cb(id, t)) this.skip(t);
      }
    },
    list(itemFn) { const h = this.byte(); let n = h >> 4; const et = h & 15; if (n === 15) n = this.varint(); const o = []; for (let i = 0; i < n; i++) o.push(itemFn(et)); return o; }
  };
  return rd;
}

// ---------------- 页脚（FileMetaData） ----------------
export function readFooter(buf) {
  const flen = buf.readUInt32LE(buf.length - 8);
  if (buf.slice(buf.length - 4).toString('latin1') !== 'PAR1') throw new Error('不是 parquet 文件（缺 PAR1 magic）');
  const foot = buf.slice(buf.length - 8 - flen, buf.length - 8);
  const r = thrift(foot);
  const out = { numRows: 0, createdBy: null, leaves: [], rowGroups: [] };
  let schema = [];
  r.struct((id, t) => {
    if (id === 1) { r.zigzag(); return true; }
    if (id === 3) { out.numRows = r.zigzag(); return true; }
    if (id === 6) { out.createdBy = r.str(); return true; }
    if (id === 2 && t === 9) {
      schema = r.list(() => { const o = {}; r.struct((f) => {
        if (f === 1) { o.type = r.zigzag(); return true; }
        if (f === 3) { o.rep = r.zigzag(); return true; }
        if (f === 4) { o.name = r.str(); return true; }
        if (f === 5) { o.children = r.zigzag(); return true; }
        if (f === 6) { o.conv = r.zigzag(); return true; }
        return false;
      }); return o; });
      return true;
    }
    if (id === 4 && t === 9) {
      out.rowGroups = r.list(() => {
        const g = { rows: 0, cols: [] };
        r.struct((f) => {
          if (f === 2) { g.bytes = r.zigzag(); return true; }
          if (f === 3) { g.rows = r.zigzag(); return true; }
          if (f === 1 && true) {
            g.cols = r.list(() => { const c = {}; r.struct((cid, ct) => {
              if (cid === 2) { c.fileOffset = r.zigzag(); return true; }
              if (cid === 3) { r.struct((m) => {
                if (m === 1) { c.type = r.zigzag(); return true; }
                if (m === 2) { c.encodings = r.list(() => r.zigzag()); return true; }
                if (m === 3) { c.path = r.list(() => r.str()); return true; }
                if (m === 4) { c.codec = r.zigzag(); return true; }
                if (m === 5) { c.numValues = r.zigzag(); return true; }
                if (m === 6) { c.uncompressedSize = r.zigzag(); return true; }
                if (m === 7) { c.compressedSize = r.zigzag(); return true; }
                if (m === 9) { c.dataPageOffset = r.zigzag(); return true; }
                if (m === 11) { c.dictionaryPageOffset = r.zigzag(); return true; }
                return false;
              }); return true; }
              return false;
            }); return c; });
            return true;
          }
          return false;
        });
        return g;
      });
      return true;
    }
    return false;
  });
  // 扁平化叶子列（本数据集只有一层 group：root -> 11 个叶子）
  out.leaves = schema.filter(s => s.type != null).map(s => ({ name: s.name, type: TYPES[s.type] || s.type, rep: s.rep }));
  return out;
}

// ---------------- 取值解码 ----------------
function unpackBits(buf, startByte, bitWidth, n) {
  const out = new Array(n);
  let bitPos = startByte * 8;
  for (let i = 0; i < n; i++) {
    let v = 0;
    for (let k = 0; k < bitWidth; k++) {
      const byteIdx = (bitPos + k) >> 3, bitIdx = (bitPos + k) & 7;
      if (buf[byteIdx] & (1 << bitIdx)) v |= (1 << k);
    }
    out[i] = v;
    bitPos += bitWidth;
  }
  return out;
}

/** RLE / bit-packed 混合编码（parquet 的 def level 与字典索引都用它） */
function hybrid(buf, pos, bitWidth, count) {
  const out = [];
  let p = pos;
  const bw = Math.ceil(bitWidth / 8);
  while (out.length < count) {
    let hdr = 0, s = 1;
    for (;;) { const b = buf[p++]; hdr += (b & 0x7f) * s; if (!(b & 0x80)) break; s *= 128; }
    if (hdr & 1) {
      const groups = Math.floor(hdr / 2);
      const vals = unpackBits(buf, p, bitWidth, groups * 8);
      p += groups * bitWidth;
      for (const v of vals) if (out.length < count) out.push(v);
    } else {
      const runLen = Math.floor(hdr / 2);
      let v = 0;
      for (let i = 0; i < bw; i++) v += buf[p++] * Math.pow(256, i);
      for (let i = 0; i < runLen && out.length < count; i++) out.push(v);
    }
  }
  return { values: out, pos: p };
}

function plainValues(buf, pos, type, n) {
  const out = [];
  let p = pos;
  for (let i = 0; i < n; i++) {
    if (type === 'DOUBLE') { out.push(buf.readDoubleLE(p)); p += 8; }
    else if (type === 'FLOAT') { out.push(buf.readFloatLE(p)); p += 4; }
    else if (type === 'INT64') { const v = buf.readBigInt64LE(p); out.push(Number(v)); p += 8; }
    else if (type === 'INT32') { out.push(buf.readInt32LE(p)); p += 4; }
    else if (type === 'BOOLEAN') { out.push(!!(buf[p >> 3] & (1 << (p & 7)))); p++; }
    else if (type === 'BYTE_ARRAY') { const n2 = buf.readUInt32LE(p); p += 4; out.push(buf.slice(p, p + n2).toString('utf8')); p += n2; }
    else throw new Error('PLAIN 未支持的列类型：' + type);
  }
  return { values: out, pos: p };
}

/** 解一列（一个 row group 内的一个 column chunk） */
function decodeColumn(buf, col, type, maxDef, leafName) {
  const DBG = process.env.PQ_DEBUG === '1';
  const start = col.dictionaryPageOffset != null && col.dictionaryPageOffset > 0
    ? Math.min(col.dictionaryPageOffset, col.dataPageOffset) : col.dataPageOffset;
  let p = start;
  let dict = null;
  let decoded = 0;
  const vals = [];
  const total = col.numValues;
  let guard = 0;
  while (decoded < total) {
    if (++guard > 100000) throw new Error('页循环失控');
    const hr = thrift(buf, p); const hp = p;
    const head = { type: null, uncompressed: 0, compressed: 0, dph: null, dph2: null, dictPh: null };
    hr.struct((id) => {
      if (id === 1) { head.type = hr.zigzag(); return true; }
      if (id === 2) { head.uncompressed = hr.zigzag(); return true; }
      if (id === 3) { head.compressed = hr.zigzag(); return true; }
      if (id === 4) { hr.zigzag(); return true; }
      if (id === 5) { const o = {}; hr.struct((f) => {
        if (f === 1) { o.numValues = hr.zigzag(); return true; }
        if (f === 2) { o.encoding = hr.zigzag(); return true; }
        if (f === 3) { o.defEncoding = hr.zigzag(); return true; }
        if (f === 4) { o.repEncoding = hr.zigzag(); return true; }
        return false; }); head.dph = o; return true; }
      if (id === 7) { const o = {}; hr.struct((f) => {
        if (f === 1) { o.numValues = hr.zigzag(); return true; }
        if (f === 2) { o.encoding = hr.zigzag(); return true; }
        return false; }); head.dictPh = o; return true; }
      if (id === 8) { const o = {}; hr.struct((f) => {
        if (f === 1) { o.numValues = hr.zigzag(); return true; }
        if (f === 2) { o.numNulls = hr.zigzag(); return true; }
        if (f === 3) { o.numRows = hr.zigzag(); return true; }
        if (f === 4) { o.encoding = hr.zigzag(); return true; }
        if (f === 5) { o.defBytes = hr.zigzag(); return true; }
        if (f === 6) { o.repBytes = hr.zigzag(); return true; }
        if (f === 7) { o.isCompressed = hr.byte() === 1; return true; }
        return false; }); head.dph2 = o; return true; }
      return false;
    });
    const headerLen = hr.pos() - hp;  // thrift 读器的 pos() 是绝对偏移，这里换成头长
    if (DBG) console.log(`[pq] ${leafName} page@${hp} type=${head.type} nv=${head.dph ? head.dph.numValues : head.dph2 ? head.dph2.numValues : head.dictPh ? head.dictPh.numValues : '?'} enc=${head.dph ? head.dph.encoding : head.dph2 ? head.dph2.encoding : head.dictPh ? head.dictPh.encoding : '?'} unc=${head.uncompressed} comp=${head.compressed} 已解 ${decoded}/${total}`);
    p = hp + headerLen;
    const body = buf.slice(p, p + head.compressed);
    p += head.compressed;
    if (head.type === 2) {
      const raw = decompress(col.codec, body, head.uncompressed);
      try { dict = plainValues(raw, 0, type, head.dictPh.numValues).values; }
      catch (e) { throw new Error(`字典页解码失败 col=${leafName} type=${type} nv=${head.dictPh && head.dictPh.numValues} 解压后=${raw.length} 期望=${head.uncompressed}：` + e.message); }
      continue;
    }
    if (head.type === 0) {
      const raw = decompress(col.codec, body, head.uncompressed);
      const n = head.dph.numValues;
      let q = 0;
      let defsPage = new Array(n).fill(maxDef);
      if (maxDef > 0) {
        const dl = raw.readUInt32LE(0);
        const r = hybrid(raw, 4, Math.ceil(Math.log2(maxDef + 1)), n);
        defsPage = r.values; q = 4 + dl;
      }
      const present = defsPage.filter(d => d === maxDef).length;
      let pageVals = [];
      const enc = head.dph.encoding;
      if (enc === 8 || enc === 2) {
        const bw = raw[q]; q += 1;
        pageVals = hybrid(raw, q, bw, present).values;
        pageVals = pageVals.map(i => dict[i]);
      } else if (enc === 0) {
        pageVals = plainValues(raw, q, type, present).values;
      } else throw new Error('未实现的数据页编码：' + (ENC[enc] || enc));
      let vi = 0;
      for (const d of defsPage) vals.push(d === maxDef ? pageVals[vi++] : null);
      decoded += n;
      continue;
    }
    if (head.type === 3) {
      const h2 = head.dph2;
      const defLen = h2.defBytes || 0, repLen = h2.repBytes || 0;
      const levelsRaw = body.slice(0, defLen + repLen);
      const valueRaw = h2.isCompressed === false ? body.slice(defLen + repLen) : decompress(col.codec, body.slice(defLen + repLen), head.uncompressed - defLen - repLen);
      const n = h2.numValues;
      let defsPage = new Array(n).fill(maxDef);
      if (maxDef > 0 && defLen > 0) defsPage = hybrid(levelsRaw, repLen, Math.ceil(Math.log2(maxDef + 1)), n).values;
      const present = defsPage.filter(d => d === maxDef).length;
      const enc = h2.encoding;
      let pageVals = [];
      if (enc === 8 || enc === 2) { const bw = valueRaw[0]; pageVals = hybrid(valueRaw, 1, bw, present).values.map(i => dict[i]); }
      else if (enc === 0) pageVals = plainValues(valueRaw, 0, type, present).values;
      else throw new Error('未实现的 V2 数据页编码：' + (ENC[enc] || enc));
      let vi = 0;
      for (const d of defsPage) vals.push(d === maxDef ? pageVals[vi++] : null);
      decoded += n;
      continue;
    }
    // 统计/索引页：跳过
  }
  return vals;
}

/** 读整个 parquet（Buffer）→ { columns: {name: [...]}, numRows } */
export function readParquet(buf) {
  const f = readFooter(buf);
  const maxDefOf = (leaf) => (leaf.rep === 1 ? 1 : 0);
  const out = {};
  for (const leaf of f.leaves) out[leaf.name] = [];
  for (const g of f.rowGroups) {
    for (const leaf of f.leaves) {
      const col = g.cols.find(c => (c.path || []).join('.') === leaf.name);
      if (!col) throw new Error('row group 里找不到列 ' + leaf.name);
      const vals = decodeColumn(buf, col, leaf.type, maxDefOf(leaf), leaf.name);
      out[leaf.name].push(...vals);
    }
  }
  return { columns: out, numRows: f.numRows, createdBy: f.createdBy, leaves: f.leaves };
}

/** 转成行对象数组 */
export function toRows(buf) {
  const { columns, numRows, createdBy } = readParquet(buf);
  const names = Object.keys(columns);
  const rows = [];
  for (let i = 0; i < numRows; i++) { const o = {}; for (const n of names) o[n] = columns[n][i]; rows.push(o); }
  return { rows, createdBy, columns: names };
}
