// doc.mjs —— 三个研究工具的 Markdown 排版公共件（零依赖）
//
// 目标：让产出的 .md 在 Markdown 阅读器里有稳定的章节结构 ——
//   H1 标题 → 元信息 / 口径 → 目录 → 一、二、…（H2 章节）→ H3 小节 → 分隔线
//
// 用法约定：
//   1) 各 render* 函数按「不加编号」的方式 push 二级标题，例如 L.push("## 模型档案")；
//   2) 需要目录的位置 push 一行 TOC_PLACEHOLDER；
//   3) 最后统一 finalizeDoc(md) —— 自动编号（一、二、…）+ 生成目录 + 插分隔线。
//   4) 不想被编号的章节（目录 / 摘要 / 附录）用 opts.skip 指定，前缀匹配。
//
// 目录锚点按 GitHub 规则生成（小写、去标点、空白转连字符、保留中英文数字），
// GitHub / VS Code / Typora / Obsidian 均可点击跳转。

export const TOC_PLACEHOLDER = "<!-- dsh-toc -->";

const CN_DIGITS = "零一二三四五六七八九";
const FENCE = /^[ \t]*(?:`{3}|~~~)/;

/** 1 → 一，12 → 十二，21 → 二十一 */
export function cnNum(n) {
  n = Math.max(1, Math.round(Number(n) || 1));
  if (n < 10) return CN_DIGITS[n];
  if (n === 10) return "十";
  if (n < 20) return "十" + CN_DIGITS[n - 10];
  if (n < 100) {
    const t = Math.floor(n / 10), r = n % 10;
    return CN_DIGITS[t] + "十" + (r ? CN_DIGITS[r] : "");
  }
  return String(n);
}

/** 标题文本 → 锚点（模拟 GitHub 的 slug：小写、去标点、空白转 -、保留中英文与数字） */
export function slugifyHeading(text, used) {
  let s = String(text == null ? "" : text)
    .replace(/<[^>]*>/g, "")
    .replace(/[`*_~]/g, "")
    .trim()
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s_-]/gu, "")
    .replace(/\s+/g, "-");
  while (s.indexOf("--") >= 0) s = s.split("--").join("-");
  if (!s) s = "section";
  if (used) {
    const base = s;
    let i = 1;
    while (used.has(s)) s = base + "-" + i++;
    used.add(s);
  }
  return s;
}

/** 扫出正文里的 H2/H3 标题（跳过围栏代码块），返回 [{level, text}] */
export function scanHeadings(md, levels) {
  const want = levels || [2, 3];
  const out = [];
  let fence = false;
  for (const ln of String(md).split("\n")) {
    if (FENCE.test(ln)) { fence = !fence; continue; }
    if (fence) continue;
    const m = /^(#{1,6})\s+(.+?)\s*$/.exec(ln);
    if (!m) continue;
    const level = m[1].length;
    if (want.indexOf(level) < 0) continue;
    out.push({ level: level, text: m[2].replace(/\s*#+\s*$/, "").trim() });
  }
  return out;
}

/** 给没编号的二级标题加「一、二、…」；skip 里的章节保持原样 */
export function numberChapters(md, opts) {
  const o = opts || {};
  const skip = o.skip || ["目录", "摘要"];
  const used = new Set();
  let n = 0, fence = false;
  return String(md).split("\n").map(function (ln) {
    if (FENCE.test(ln)) { fence = !fence; return ln; }
    if (fence) return ln;
    const m = /^##\s+(.+?)\s*$/.exec(ln);
    if (!m) return ln;
    const text = m[1];
    if (/^[一二三四五六七八九十]+、/.test(text) || used.has(text)) return ln;
    if (skip.some(function (s) { return text === s || text.indexOf(s + "（") === 0 || text.indexOf(s + " ") === 0; })) { used.add(text); return ln; }
    n++;
    let title = cnNum(n) + "、" + text;
    while (used.has(title)) title += " ";
    used.add(title);
    return "## " + title;
  }).join("\n");
}

/** 每个带编号的二级章节前插一条分隔线（前后各留一个空行） */
export function addRules(md) {
  const out = [];
  for (const ln of String(md).split("\n")) {
    if (/^##\s+[一二三四五六七八九十]+、/.test(ln)) {
      while (out.length && out[out.length - 1].trim() === "") out.pop();
      if (out.length) out.push("", "---", "");
      else out.push("");
    }
    out.push(ln);
  }
  const fin = [];
  let blank = 0;
  for (const ln of out) {
    if (ln.trim() === "") { blank++; if (blank > 1) continue; } else blank = 0;
    fin.push(ln);
  }
  return fin.join("\n").replace(/\s+$/, "") + "\n";
}

/** 由正文生成目录（二级为条目，三级缩进一级） */
export function buildToc(md, opts) {
  const o = opts || {};
  const skip = o.skip || ["目录"];
  const heads = scanHeadings(md, [2, 3]).filter(function (h) {
    return !skip.some(function (s) { return h.level === 2 && h.text.indexOf(s) === 0; });
  });
  const used = new Set();
  const rows = [];
  for (const h of heads) {
    const slug = slugifyHeading(h.text, used);
    const label = h.text.replace(/([\[\]])/g, "\\$1");
    rows.push((h.level === 3 ? "  - " : "- ") + "[" + label + "](#" + slug + ")");
  }
  return rows.join("\n");
}

/**
 * 收尾：编号 → 分隔线 → 目录。
 * opts: { skip:[章节名前缀], toc:false 关目录, rules:false 关分隔线 }
 */
export function finalizeDoc(md, opts) {
  const o = opts || {};
  let out = String(md).replace(/\r\n/g, "\n").replace(/\s+$/, "") + "\n";
  const hasPlaceholder = out.indexOf(TOC_PLACEHOLDER) >= 0;
  out = numberChapters(out, o);
  if (o.rules !== false) out = addRules(out);
  if (o.toc !== false && hasPlaceholder) {
    const toc = buildToc(out, o);
    const block = toc ? "## 目录\n\n" + toc + "\n\n" : "";
    out = out.split(TOC_PLACEHOLDER).join(block);
  }
  return out.replace(/\n{3,}/g, "\n\n").replace(/\s+$/, "") + "\n";
}
