// xhs.mjs —— 小红书源（浏览器签名路线）
// 原理：小红书网页端搜索接口 (so.xiaohongshu.com/api/sns/web/v2/search/notes) 需要 x-s/x-t/x-s-common
// 签名，签名由站点运行时生成。这里不再逆向签名，而是用一个本地 Chrome/Edge 无头实例打开搜索页：
// 页面自己把签名算好、拿到真实 JSON；我们在页面里挂钩 fetch/XHR 把响应体捞出来。
// 需要用户登录态 cookie（web_session 等），从 <home>/cookies.json 的 xiaohongshu 字段读（见 home.mjs）。
// 安全纪律（见 skill xiaohongshu-safe-browsing）：单会话、慢节奏、出现风控立刻停手。
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

import { cookiesPath, statePath } from "./home.mjs";

// 无头实例的 profile 目录：默认放系统临时目录（用完可整目录删掉），可用环境变量覆盖。
export const PROFILE_DIR = process.env.DSH_AI_RESEARCH_CHROME_PROFILE || path.join(os.tmpdir(), "dsh-chrome-xhs");

// 浏览器可执行文件探测：环境变量优先 → 各平台常见安装位置 → PATH 里找。
export const CHROME_ENV = ["DSH_AI_RESEARCH_CHROME", "CHROME_PATH", "CHROME_BIN"];
export const CHROME_CANDIDATES = {
  win32: [
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
    "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  ],
  darwin: [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
  ],
  linux: [
    "/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/usr/bin/chromium",
    "/usr/bin/chromium-browser", "/snap/bin/chromium", "/usr/bin/microsoft-edge",
  ],
};
const CHROME_BIN_NAMES = { win32: ["chrome.exe", "msedge.exe"], darwin: ["Google Chrome"], linux: ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge"] };
export const CHROME_PATHS = CHROME_CANDIDATES[process.platform] || CHROME_CANDIDATES.linux;
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function findChrome() {
  for (const k of CHROME_ENV) { const v = process.env[k]; if (v) { try { if (fs.existsSync(v)) return v; } catch {} } }
  for (const p of CHROME_PATHS) { try { if (fs.existsSync(p)) return p; } catch {} }
  for (const d of String(process.env.PATH || "").split(path.delimiter).filter(Boolean)) {
    for (const n of (CHROME_BIN_NAMES[process.platform] || CHROME_BIN_NAMES.linux)) {
      const p = path.join(d, n);
      try { if (fs.existsSync(p)) return p; } catch {}
    }
  }
  return null;
}

export function loadCookie(site = "xiaohongshu") {
  const f = cookiesPath();
  try { const j = JSON.parse(fs.readFileSync(f, "utf8")); return String(j[site] || "").trim(); } catch { return ""; }
}

export function parseCookieString(raw) {
  return String(raw || "").split(/;\s*/).filter(Boolean).map((kv) => {
    const i = kv.indexOf("=");
    return { name: kv.slice(0, i).trim(), value: kv.slice(i + 1).trim() };
  }).filter((p) => p.name && p.value);
}

export async function cdpVersion(port) {
  try { const r = await fetch("http://127.0.0.1:" + port + "/json/version", { signal: AbortSignal.timeout(2500) }); return await r.json(); }
  catch { return null; }
}

export async function ensureChrome(opts = {}) {
  const port = opts.port || 9222;
  let v = await cdpVersion(port);
  if (v) return { port, launched: false, browser: v.Browser };
  const exe = findChrome();
  if (!exe) throw new Error("找不到 Chrome/Edge 可执行文件");
  fs.mkdirSync(PROFILE_DIR, { recursive: true });
  const args = ["--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
    "--disable-blink-features=AutomationControlled", "--remote-debugging-port=" + port,
    "--window-size=1440,1200", "--lang=zh-CN", "--user-data-dir=" + PROFILE_DIR, "about:blank"];
  const child = spawn(exe, args, { detached: true, stdio: "ignore", windowsHide: true });
  child.unref();
  for (let i = 0; i < 20; i++) { await sleep(1200); v = await cdpVersion(port); if (v) return { port, launched: true, browser: v.Browser }; }
  throw new Error("无头 Chrome 起不来（端口 " + port + " 无响应）。有些环境里从 Node 里直接 spawn 浏览器不生效（子进程受沙箱/Job 限制）→ 先由宿主 shell 把浏览器起好，再重试；命令见技能文档 model-report.md 的「小红书」一节。Windows / PowerShell 下另有两条坑：不要用 Start-Process（进程环境同时有 NO_PROXY 与 no_proxy，PowerShell 7 会抛「已添加项」并静默失败），也不要用 pwsh -File（执行策略可能禁止运行未签名脚本）。");
}

export async function newPage(port) {
  const r = await fetch("http://127.0.0.1:" + port + "/json/new?url=about:blank", { method: "PUT" });
  return await r.json();
}
export async function closePage(port, id) {
  try { await fetch("http://127.0.0.1:" + port + "/json/close/" + id); } catch {}
}

export function connect(wsUrl) {
  const ws = new WebSocket(wsUrl);
  let id = 0; const pend = new Map(); const waiters = []; const seen = [];
  ws.addEventListener("message", (ev) => {
    let m; try { m = JSON.parse(ev.data); } catch { return; }
    if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id); m.error ? p.rej(new Error(JSON.stringify(m.error))) : p.res(m.result); }
    else if (m.method) { seen.push(m); for (let i = waiters.length - 1; i >= 0; i--) if (waiters[i].fn(m)) { const w = waiters.splice(i, 1)[0]; clearTimeout(w.t); w.res(m); } }
  });
  const ready = new Promise((res, rej) => { ws.addEventListener("open", res); ws.addEventListener("error", () => rej(new Error("CDP ws 连接失败"))); });
  function send(method, params, timeoutMs = 45000) {
    const myId = ++id;
    return new Promise((res, rej) => {
      pend.set(myId, { res, rej });
      ws.send(JSON.stringify({ id: myId, method, params: params || {} }));
      setTimeout(() => { if (pend.has(myId)) { pend.delete(myId); rej(new Error("CDP 超时 " + method)); } }, timeoutMs);
    });
  }
  const waitFor = (fn, ms) => new Promise((res) => { const t = setTimeout(() => res(null), ms || 30000); waiters.push({ fn, res, t }); });
  return { ws, ready, send, waitFor, seen, close: () => { try { ws.close(); } catch {} } };
}

const HOOK = "(function(){ if(window.__xhsHookInstalled) return; window.__xhsHookInstalled=true; window.__xhsCap=[]; var of=window.fetch; window.fetch=function(){ var a=arguments; var p=of.apply(this,a); try{ var u=(typeof a[0]==='string')?a[0]:((a[0]&&a[0].url)||''); if(/search\\/notes/.test(u)){ p.then(function(r){ try{ r.clone().text().then(function(t){ window.__xhsCap.push(t); }); }catch(e){} }); } }catch(e){} return p; };"
  + " var OX=XMLHttpRequest.prototype.open, OS=XMLHttpRequest.prototype.send;"
  + " XMLHttpRequest.prototype.open=function(m,u){ this.__u=u; return OX.apply(this,arguments); };"
  + " XMLHttpRequest.prototype.send=function(){ var self=this; if(/search\\/notes/.test(self.__u||'')){ self.addEventListener('load', function(){ try{ window.__xhsCap.push(self.responseText); }catch(e){} }); } return OS.apply(this,arguments); }; })();";

const OK_MARK = "code=0";

// —— 预算 / 熔断 ——
const STATE_FILE = statePath("xhs-state.json");
function readState() { try { return JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); } catch { return { day: "", sessions: 0, calls: 0, lastAt: 0, cooldownUntil: 0 }; } }
function writeState(s) { try { fs.writeFileSync(STATE_FILE, JSON.stringify(s, null, 1), "utf8"); } catch {} }
function today() { return new Date().toISOString().slice(0, 10); }

export function xhsBudget() {
  const s = readState();
  const day = today();
  if (s.day !== day) { s.day = day; s.sessions = 0; s.calls = 0; }
  return { ...s, cooldownLeftMs: Math.max(0, (s.cooldownUntil || 0) - Date.now()), todaySessions: s.sessions };
}

export function tripCooldown(reason) {
  const s = readState();
  s.cooldownUntil = Date.now() + 24 * 3600 * 1000;
  s.cooldownReason = String(reason || "").slice(0, 200);
  writeState(s);
  return s.cooldownUntil;
}

function bumpCall(n = 1) {
  const s = readState();
  if (s.day !== today()) { s.day = today(); s.sessions = 0; s.calls = 0; }
  s.calls = (s.calls || 0) + n;
  s.lastAt = Date.now();
  writeState(s);
}


export async function installHook(c) {
  try { await c.send("Runtime.evaluate", { returnByValue: true, expression: HOOK }); return true; } catch { return false; }
}

// 用页面自己的搜索框发起一次搜索：站内 SPA 会带正确签名请求，我们只负责读响应
export async function xhsUiSearch(c, keyword, opts = {}) {
  const n0 = Number((await c.send("Runtime.evaluate", { returnByValue: true, expression: "(window.__xhsCap||[]).length" })).result.value || 0);
  const setExpr = "(function(){ var inp=document.querySelector('#search-input')||document.querySelector('input.search-input');"
    + " if(!inp) return 'no-input';"
    + " var setter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;"
    + " inp.focus(); setter.call(inp," + JSON.stringify(keyword) + ");"
    + " inp.dispatchEvent(new Event('input',{bubbles:true}));"
    + " inp.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));"
    + " return 'set:'+inp.value; })()";
  const setRes = await c.send("Runtime.evaluate", { returnByValue: true, expression: setExpr });
  if (String(setRes.result.value) === "no-input") throw new Error("页面里找不到搜索框");
  const waitMs = opts.timeoutMs || 22000;
  const t0 = Date.now();
  let clicked = false;
  while (Date.now() - t0 < waitMs) {
    await sleep(1000);
    const n = Number((await c.send("Runtime.evaluate", { returnByValue: true, expression: "(window.__xhsCap||[]).length" })).result.value || 0);
    if (n > n0) return { added: n - n0, waitedMs: Date.now() - t0 };
    if (!clicked && Date.now() - t0 > 6000) {
      clicked = true;
      await c.send("Runtime.evaluate", { returnByValue: true, expression: "(function(){ var b=document.querySelector('.search-icon')||document.querySelector('button.min-width-search-ico'); if(b){ b.click(); return 'clicked'; } return 'no-btn'; })()" });
    }
  }
  throw new Error("在页面里发起搜索后没有等到新的接口响应（超时 " + waitMs + "ms）");
}

export async function readCaps(c) {
  const r = await c.send("Runtime.evaluate", { returnByValue: true, expression: "JSON.stringify(window.__xhsCap||[])" });
  try { return JSON.parse(r.result.value || "[]"); } catch { return []; }
}

// —— 解析 ——
export function parseXhsSearch(payload, opts = {}) {
  const limit = opts.limit || 30;
  const arr = Array.isArray(payload) ? payload : [payload];
  const out = []; const seen = new Set();
  for (const j of arr) {
    let obj = j;
    if (typeof j === "string") { try { obj = JSON.parse(j); } catch { continue; } }
    if (!obj || !obj.data) continue;
    const items = obj.data.items || obj.data.notes || [];
    for (const it of items) {
      const nc = it.note_card || it.note || {};
      const id = it.id || nc.note_id || nc.id;
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const ii = nc.interact_info || {};
      const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
      const age = (opts.ages && opts.ages[id]) || "";
      out.push({
        id,
        title: String(nc.display_title || nc.title || "").trim(),
        author: String((nc.user && (nc.user.nickname || nc.user.nick_name)) || "").trim(),
        likes: num(ii.liked_count), collects: num(ii.collected_count),
        comments: num(ii.comment_count), shares: num(ii.shared_count),
        type: nc.type || "",
        age,
        url: "https://www.xiaohongshu.com/explore/" + id + "?xsec_token=" + encodeURIComponent(it.xsec_token || "") + "&xsec_source=pc_search",
      });
    }
  }
  return out.slice(0, limit);
}

async function domAges(c) {
  const expr = "(function(){ var m={}; var cards=[].slice.call(document.querySelectorAll('section.note-item, .note-item'));"
    + " cards.forEach(function(el){ var a=el.querySelector('a[href*=\"/explore/\"]'); if(!a) return;"
    + " var mm=/\\/explore\\/([0-9a-f]{24})/.exec(a.getAttribute('href')||''); if(!mm) return;"
    + " var t=el.querySelector('.time'); m[mm[1]] = t ? t.textContent.trim() : ''; }); return JSON.stringify(m); })()";
  try { const r = await c.send("Runtime.evaluate", { returnByValue: true, expression: expr }); return JSON.parse(r.result.value || "{}"); }
  catch { return {}; }
}

// 在页面上下文里自己发一次搜索请求（复用页面已就绪的签名环境）
export async function xhsApiInPage(c, o) {
  const body = { keyword: o.keyword, page: o.page || 1, page_size: o.pageSize || 20, search_id: o.searchId || "", sort: o.sort || "general", note_type: 0, ext_flags: [], geo: "", image_formats: ["jpg", "webp", "avif"], session_id: "" };
  const expr = "(function(){ return new Promise(function(resolve){ var x=new XMLHttpRequest();"
    + " x.open('POST','https://so.xiaohongshu.com/api/sns/web/v2/search/notes',true);"
    + " x.setRequestHeader('content-type','application/json;charset=UTF-8');"
    + " x.onload=function(){ resolve(JSON.stringify({__status:x.status,__body:x.responseText})); };"
    + " x.onerror=function(){ resolve(JSON.stringify({__status:-1,__body:''})); };"
    + " x.send(" + JSON.stringify(JSON.stringify(body)) + "); }); })()";
  const r = await c.send("Runtime.evaluate", { returnByValue: true, awaitPromise: true, expression: expr }, 45000);
  let payload; try { payload = JSON.parse(r.result.value); } catch { throw new Error("页面内请求未返回可解析内容"); }
  return payload;
}

export function riskSignal(text) {
  // 只看接口信封（code / msg / success），不要拿整段正文做关键词扫描
  // —— 实测教训：正文里出现 "risk" 之类的普通词会造成误熔断。
  const t = String(text || "");
  let code = null, msg = "", success = null;
  try { const j = JSON.parse(t); code = j.code; msg = String(j.msg || ""); success = j.success; } catch { return /安全限制|访问频繁|300013/.test(t); }
  if (code === 300013 || code === 461 || code === 471) return true;  // -1 / -101 属于「未签名 / 未登录」，不是限流，交给上层报错
  if (/安全限制|访问频繁|Account abnormal|请稍后再试|账号异常/.test(msg)) return true;
  return false;
}

// —— 主流程 ——
export async function xhsSearch(keyword, opts = {}) {
  const port = opts.port || 9222;
  const budget = xhsBudget();
  if (budget.cooldownLeftMs > 0) throw new Error("小红书处于熔断冷却中（" + Math.round(budget.cooldownLeftMs / 60000) + " 分钟后解除）：" + (budget.cooldownReason || "上次触发风控"));
  const cookie = opts.cookie || loadCookie("xiaohongshu");
  if (!cookie) throw new Error("未配置小红书登录态 cookie（~/.dsh-ai-research/cookies.json 的 xiaohongshu 字段）");
  await ensureChrome({ port });
  const limit = opts.limit || 30;
  const wantPages = Math.max(1, Math.min(opts.pages || 1, 3));

  // —— 路线 A：复用已经开着的搜索页（同一浏览会话，用页面 UI 触发搜索，签名由站点完成） ——
  if (!opts.fresh) {
    const exist = await findSearchPage(port);
    if (exist) {
      const c = connect(exist.webSocketDebuggerUrl);
      try {
        await c.ready; await c.send("Runtime.enable");
        await installHook(c);
        const caps0 = (await readCaps(c)).length;
        const ui = await xhsUiSearch(c, keyword, { timeoutMs: opts.uiTimeoutMs || 22000 });
        bumpCall(1);
        await sleep(opts.waitMs || 4000);
        const caps = (await readCaps(c)).slice(caps0);
        if (caps.some((b) => riskSignal(b))) { tripCooldown("复用页面搜索返回风控信号"); throw new Error("小红书返回风控信号，已熔断 24 小时"); }
        const ages = await domAges(c);
        let items = parseXhsSearch(caps, { limit: 100, ages });
        for (let pg = 2; pg <= wantPages && items.length; pg++) {
          await sleep(opts.spacingMs || 5000);
          const r = await xhsApiInPage(c, { keyword, page: pg, pageSize: opts.pageSize || 20, sort: opts.sort || "general" });
          bumpCall(1);
          if (riskSignal(r.__body)) { tripCooldown("分页请求返回风控信号"); break; }
          try { items = items.concat(parseXhsSearch(JSON.parse(r.__body), { limit: 100, ages })); } catch {}
        }
        if (items.length) {
          return { query: keyword, items: dedupe(items).slice(0, limit), pages: wantPages, mode: "reuse-ui", waitedMs: ui.waitedMs, wall: false, fetchedAt: new Date().toISOString() };
        }
      } catch (e) {
        if (/熔断/.test(String(e.message))) throw e;
      } finally { c.close(); }
    }
  }

  // —— 路线 B：新开一次会话（整页加载，页面自己完成签名） ——
  bumpSession(opts.maxSessions || 4);
  await closeSearchPages(port);
  const page = await newPage(port);
  const c = connect(page.webSocketDebuggerUrl);
  try {
    await c.ready;
    await c.send("Page.enable"); await c.send("Runtime.enable");
    await c.send("Network.enable", { maxTotalBufferSize: 200000000, maxResourceBufferSize: 50000000 });
    await c.send("Emulation.setUserAgentOverride", { userAgent: UA, platform: "Win32", acceptLanguage: "zh-CN,zh;q=0.9,en;q=0.8" });
    await c.send("Network.setCookies", { cookies: parseCookieString(cookie).map((p) => ({ name: p.name, value: p.value, domain: ".xiaohongshu.com", path: "/", secure: true, httpOnly: false, sameSite: "Lax" })) });
    await c.send("Page.addScriptToEvaluateOnNewDocument", { source: HOOK });
    const url = "https://www.xiaohongshu.com/search_result?keyword=" + encodeURIComponent(keyword) + "&source=web_explore_feed&type=51";
    const hit = c.waitFor((m) => m.method === "Network.responseReceived" && /search\/notes/.test(m.params.response.url), 45000);
    await c.send("Page.navigate", { url });
    await hit;
    bumpCall(1);
    await sleep(opts.waitMs || 6000);
    const cap = await c.send("Runtime.evaluate", { returnByValue: true, expression: "JSON.stringify(window.__xhsCap||[])" });
    const bodies = JSON.parse(cap.result.value || "[]");
    const txt = await c.send("Runtime.evaluate", { returnByValue: true, expression: "(document.body?document.body.innerText.slice(0,200):'')" });
    if (/登录后查看|扫码登录|手机号登录/.test(String(txt.result.value || ""))) throw new Error("小红书要求登录：cookie 可能已失效（页面提示「登录后查看搜索结果」）");
    if (bodies.some((b) => riskSignal(b))) { tripCooldown("搜索接口返回风控信号"); throw new Error("小红书返回风控信号，已熔断 24 小时"); }
    const ages = await domAges(c);
    let items = parseXhsSearch(bodies, { limit: 100, ages });
    for (let pg = 2; pg <= wantPages; pg++) {
      await sleep(opts.spacingMs || 3500);
      const r = await xhsApiInPage(c, { keyword, page: pg, pageSize: opts.pageSize || 20, sort: opts.sort || "general" });
      bumpCall(1);
      if (riskSignal(r.__body)) { tripCooldown("分页请求返回风控信号"); break; }
      try { items = items.concat(parseXhsSearch(JSON.parse(r.__body), { limit: 100, ages })); } catch {}
    }
    if (!items.length) throw new Error("页面没有捕获到笔记（风控或结构变化）");
    items = dedupe(items);
    return { query: keyword, items: items.slice(0, limit), pages: wantPages, mode: "page", wall: false, fetchedAt: new Date().toISOString() };
  } finally {
    c.close();
    if (!opts.keepPage) { /* 保留页面供同会话复用；下一次新会话开始时统一关闭 */ }
  }
}

function dedupe(items) {
  const seen = new Set();
  const out = items.filter((x) => (seen.has(x.id) ? false : (seen.add(x.id), true)));
  out.sort((a, b) => b.likes - a.likes);
  return out;
}

export async function xhsBuzz(query, opts = {}) {
  const r = await xhsSearch(query, opts);
  return { id: "xiaohongshu", name: "小红书", ok: true, total: r.items.length, items: r.items };
}


export async function findSearchPage(port) {
  try {
    const list = await (await fetch("http://127.0.0.1:" + port + "/json/list")).json();
    return (list || []).find((t) => t.type === "page" && /xiaohongshu\.com\/search_result/.test(t.url)) || null;
  } catch { return null; }
}

export async function closeSearchPages(port) {
  try {
    const list = await (await fetch("http://127.0.0.1:" + port + "/json/list")).json();
    for (const t of list || []) if (t.type === "page" && /xiaohongshu\.com\/search_result/.test(t.url)) await closePage(port, t.id);
  } catch {}
}

export function bumpSession(maxSessions) {
  const s = readState();
  if (s.day !== today()) { s.day = today(); s.sessions = 0; s.calls = 0; }
  if ((s.sessions || 0) >= (maxSessions || 4)) throw new Error("小红书今天已开 " + s.sessions + " 次会话，超过安全上限，已拒绝（明天再试；或复用已开页面）");
  s.sessions = (s.sessions || 0) + 1;
  writeState(s);
  return s.sessions;
}

export function xhsStatus() { return xhsBudget(); }
