// model-report/cn.mjs —— 中文社区口碑源（B站 / CSDN / 微信公众号 / 知乎 / 小红书）
// 零依赖、无第三方 import。需要登录态的源（知乎/小红书）从 cookies.json 或环境变量读 cookie，
// 微博 / 贴吧 两源 2026-10-16 按用户要求删除（长期没有 cookie，微博未登录即 432 风控、贴吧搜索页解析不出）。
// 缺 cookie 时 **显式抛错**（会被 gather 记进 sources[].error），绝不静默返回空数组。
import { readFileSync, existsSync } from "node:fs";
import { cookiesPath } from "./home.mjs";
export const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function req(url, opts) {
  opts = opts || {};
  const h = { "user-agent": UA, "accept-language": "zh-CN,zh;q=0.9,en;q=0.6", ...(opts.headers || {}) };
  if (opts.cookie) h.cookie = opts.cookie;
  if (opts.referer) h.referer = opts.referer;
  const r = await fetch(url, { headers: h, redirect: "follow", signal: AbortSignal.timeout(opts.timeout || 15000) });
  const body = await r.text();
  return { status: r.status, body: body, setCookie: (r.headers.getSetCookie ? r.headers.getSetCookie() : []), headers: r.headers };
}
export function day(ts) { if (!ts) return null; const d = new Date(Number(ts) * 1000); return isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10); }
function plain(s) {
  if (s == null) return "";
  return String(s)
    .replace(/<[^>]*>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/[\u0000-\u001f]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
export function iso(t) {
  const n = typeof t === "number" ? (t < 1e12 ? t * 1000 : t) : Date.parse(t);
  if (!n || isNaN(n)) return null;
  return new Date(n).toISOString().slice(0, 10);
}
function ckOf(res) { return (res.setCookie || []).map((c) => String(c).split(";")[0]).join("; "); }

// ── 登录态 cookie 存储：~/.dsh-ai-research/cookies.json（或 MODEL_REPORT_COOKIES 指向的文件） ──
let _cookies = null;
export function cookiePath() { return cookiesPath(); }
export function cookies() {
  if (_cookies) return _cookies;
  _cookies = {};
  const p = cookiePath();
  try {
    if (existsSync(p)) {
      const raw = JSON.parse(readFileSync(p, "utf8"));
      for (const k of Object.keys(raw)) if (typeof raw[k] === "string") _cookies[k] = raw[k];
    }
  } catch (e) { _cookies._error = "cookies.json 解析失败：" + String(e.message).slice(0, 120); }
  for (const k of ["zhihu", "xiaohongshu"]) {
    const env = process.env[k.toUpperCase() + "_COOKIE"];
    if (env) _cookies[k] = env;
  }
  return _cookies;
}
export function needsCookie(name, key) {
  const v = cookies()[key];
  if (!v) throw new Error("未配置" + name + "登录态：把 cookie 写进 " + cookiePath() + " 的 \"" + key + "\" 字段（或设环境变量 " + key.toUpperCase() + "_COOKIE）");
  return v;
}

// ── B站（匿名可抓：只需一次官网请求拿 buvid3，不需要账号） ──
let _bili = { ck: "", at: 0 };
export function cnToks(q) {
  return String(q || "").toLowerCase().split(/[^a-z0-9\u4e00-\u9fa5.]+/).filter((t) => t.length >= 3 && !/^[0-9.]+$/.test(t));
}
export function titleHits(title, toks) {
  const t = String(title || "").toLowerCase();
  let n = 0;
  for (const k of toks) if (t.indexOf(k) >= 0) n++;
  return n;
}
export async function biliCookie(force) {
  if (!force && _bili.ck && Date.now() - _bili.at < 1800e3) return _bili.ck;
  const r = await req("https://www.bilibili.com/", { timeout: 12000 });
  const ck = ckOf(r);
  if (!ck) throw new Error("B站首页未返回匿名 cookie（buvid3），可能被风控");
  _bili = { ck: ck, at: Date.now() };
  return ck;
}
export async function biliSearch(query, opts) {
  opts = opts || {};
  const ck = await biliCookie();
  const url = "https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword=" + encodeURIComponent(query) + "&page=1";
  const r = await req(url, { cookie: ck, referer: "https://search.bilibili.com/", headers: { "x-requested-with": "XMLHttpRequest" } });
  let j;
  try { j = JSON.parse(r.body); } catch (e) { throw new Error("B站搜索返回非 JSON（HTTP " + r.status + "）"); }
  if (j.code !== 0) throw new Error("B站搜索 code=" + j.code + " " + (j.message || ""));
  const list = (j.data && j.data.result) || [];
  return {
    total: (j.data && j.data.numResults) || list.length,
    items: list.slice(0, opts.limit || 8).map((v) => ({
      title: plain(v.title), author: v.author, play: v.play, danmaku: v.video_review, comments: v.review,
      duration: v.duration, bvid: v.bvid, url: "https://www.bilibili.com/video/" + v.bvid,
      date: v.pubdate ? iso(v.pubdate) : null, desc: plain(v.description).slice(0, 180),
    })).filter((v) => v.bvid),
  };
}
export async function biliComments(bvid, opts) {
  opts = opts || {};
  const ck = await biliCookie();
  const vr = await req("https://api.bilibili.com/x/web-interface/view?bvid=" + bvid, { cookie: ck });
  const aid = JSON.parse(vr.body).data && JSON.parse(vr.body).data.aid;
  if (!aid) throw new Error("B站 view 取 aid 失败：" + bvid);
  const r = await req("https://api.bilibili.com/x/v2/reply?type=1&oid=" + aid + "&pn=1&ps=20&sort=2", { cookie: ck, referer: "https://www.bilibili.com/video/" + bvid });
  let j; try { j = JSON.parse(r.body); } catch (e) { return []; }
  if (j.code !== 0) return [];
  return ((j.data && j.data.replies) || []).slice(0, opts.limit || 6).map((c) => ({
    text: plain(c.content && c.content.message).slice(0, 300), like: c.like,
    user: c.member && c.member.uname, date: iso(c.ctime), url: "https://www.bilibili.com/video/" + bvid,
  }));
}
export async function bilibiliBuzz(query, opts) {
  opts = opts || {};
  const s = await biliSearch(query, { limit: (opts.videos || 6) * 3 });
  const tk = cnToks(query);
  let items = s.items.filter((v) => v.bvid);
  if (tk.length) {
    const scored = items.map((v) => ({ v: v, hit: titleHits(v.title, tk) }));
    const good = scored.filter((x) => x.hit > 0);
    if (good.length >= 2) { good.sort((a, b) => (b.hit - a.hit) || ((b.v.play || 0) - (a.v.play || 0))); items = good.map((x) => x.v); }
  }
  const shown = items.slice(0, opts.videos || 6);
  const out = { total: s.total, videos: shown, comments: [] };
  // 取评论的视频：标题相关（已在 items 里排序）+ 评论数够多（评测类视频评论多，教程类多是"求资料"）
  const reviewish = /(实测|测评|评测|对比|体验|上手|点评|复盘|深度|教程)/;
  const cand = items.slice().sort((a, b) => ((reviewish.test(b.title) ? 1 : 0) - (reviewish.test(a.title) ? 1 : 0)) || ((b.comments || 0) - (a.comments || 0)));
  const rich = cand.filter((v) => (v.comments || 0) >= 20);
  const pool = rich.length ? rich : cand;
  for (const v of pool.slice(0, opts.commentVideos == null ? 2 : opts.commentVideos)) {
    try {
      const cs = await biliComments(v.bvid, { limit: 20 });
      v.commentCount = cs.length;
      out.comments.push(...cs.filter((c) => (c.text || "").length >= 8 && (c.like || 0) >= 1));
    } catch (e) { v.commentError = String(e.message).slice(0, 120); }
    await sleep(350);
  }
  out.comments.sort((a, b) => (b.like || 0) - (a.like || 0));
  return out;
}

// ── CSDN 搜索（匿名可用） ──
export async function csdnBuzz(query, opts) {
  opts = opts || {};
  const r = await req("https://so.csdn.net/api/v3/search?q=" + encodeURIComponent(query) + "&t=blog&p=1", { referer: "https://so.csdn.net/so/search" });
  let j; try { j = JSON.parse(r.body); } catch (e) { throw new Error("CSDN 搜索返回非 JSON（HTTP " + r.status + "）"); }
  const list = j.result_vos || j.result || [];
  return list.slice(0, opts.limit || 8).map((x) => ({
    title: plain(x.title), url: String(x.url || ("https://blog.csdn.net/" + (x.user_name || x.author || "") + "/article/details/" + (x.articleid || x.id || ""))).split("?")[0],
    brief: plain(x.description || x.brief || "").slice(0, 160),
    date: iso(x.create_time || x.createtime || x.publish_time), views: x.view_count, likes: x.digg_count, comments: x.comment_count,
    author: x.user_name || x.author || x.nickname,
  }));
}

// ── 微信公众号（经搜狗微信搜索，匿名可用；标题/摘要在 ul.news-list 里，跳转链接要再解一层） ──
export async function weixinResolve(href, cookie) {
  const url = href.startsWith("http") ? href : "https://weixin.sogou.com" + href;
  const r = await req(url, { cookie: cookie, referer: "https://weixin.sogou.com/" });
  const body = r.body || "";
  const parts = (body.match(/url \+= '[^']*';/g) || []).map((s) => s.replace(/^url \+= '/, "").replace(/';$/, ""));
  if (!parts.length) return null;
  return parts.join("").replace(/&amp;/g, "&").replace(/@/g, "");
}
export async function weixinBuzz(query, opts) {
  opts = opts || {};
  const r = await req("https://weixin.sogou.com/weixin?type=2&query=" + encodeURIComponent(query) + "&ie=utf8", { referer: "https://weixin.sogou.com/" });
  const html = r.body || "";
  if (/antispider|请输入验证码|访问过于频繁/.test(html)) throw new Error("搜狗微信触发反爬（验证码/频率限制），稍后再试或降频");
  const cookie = ckOf(r);
  const items = [];
  const blocks = html.match(/<li[\s\S]*?<\/li>/g) || [];
  for (const b of blocks) {
    if (b.indexOf("/link?url=") < 0) continue;
    const href = (b.match(/href="(\/link\?url=[^"]+)"/) || [])[1];
    const title = plain((b.match(/<h3>[\s\S]*?<a[^>]*>([\s\S]*?)<\/a>/) || [])[1]);
    if (!href || !title) continue;
    items.push({
      title: title,
      account: plain((b.match(/<span class="account"[^>]*>([\s\S]*?)<\/span>/) || b.match(/<a[^>]*class="account"[^>]*>([\s\S]*?)<\/a>/) || [])[1]),
      brief: plain((b.match(/<p class="txt-info"[^>]*>([\s\S]*?)<\/p>/) || [])[1]).slice(0, 160),
      date: iso(((b.match(/timeConvert\('(\d+)'\)/) || [])[1]) ? Number(((b.match(/timeConvert\('(\d+)'\)/) || [])[1])) : null),
      sogouUrl: ("https://weixin.sogou.com" + href).replace(/&amp;/g, "&"), url: null,
    });
    if (items.length >= (opts.limit || 8)) break;
  }
  if (!items.length) throw new Error("搜狗微信没解析出结果（页面结构可能变了，或该词无公众号文章）");
  for (const it of items.slice(0, opts.resolve || 5)) {
    try { const real = await weixinResolve(it.sogouUrl.replace("https://weixin.sogou.com", ""), cookie); if (real) it.url = real; }
    catch (e) { /* 解不开就留搜狗跳转链 */ }
    await sleep(400);
  }
  return items;
}

// ── 知乎（必须登录态；首页 cookie 不够，需要 z_c0 等登录 cookie） ──
export async function zhihuBuzz(query, opts) {
  opts = opts || {};
  const ck = needsCookie("知乎", "zhihu");
  const url = "https://www.zhihu.com/api/v4/search_v3?t=general&q=" + encodeURIComponent(query) + "&correction=1&offset=0&limit=20&filter_fields=&lc_idx=0&show_all_topics=0&search_source=Normal";
  const r = await req(url, { cookie: ck, referer: "https://www.zhihu.com/search?type=content&q=" + encodeURIComponent(query), headers: { "x-requested-with": "fetch" } });
  if (r.status !== 200) throw new Error("知乎 search_v3 HTTP " + r.status + "（" + (r.status === 400 ? "cookie 无效或未登录" : r.status === 403 ? "风控" : "接口变化") + "）");
  let j; try { j = JSON.parse(r.body); } catch (e) { throw new Error("知乎返回非 JSON（可能被风控拦截）"); }
  if (j.error) throw new Error("知乎接口报错：" + JSON.stringify(j.error).slice(0, 120));
  const items = [];
  for (const d of (j.data || [])) {
    const o = d.object || (d.highlight && d.highlight.object);
    if (!o) continue;
    const type = o.type || d.type;
    if (type === "answer") items.push({ kind: "回答", key: "q" + ((o.question && o.question.id) || o.id), title: plain((o.question && o.question.title) || o.title), excerpt: plain(o.excerpt).slice(0, 220), votes: o.voteup_count, comments: o.comment_count, author: o.author && o.author.name, date: day(o.created_time), updated: day(o.updated_time), url: "https://www.zhihu.com/question/" + ((o.question && o.question.id) || "") + "/answer/" + o.id });
    else if (type === "article") items.push({ kind: "文章", key: "a" + o.id, title: plain(o.title), excerpt: plain(o.excerpt).slice(0, 220), votes: o.voteup_count, comments: o.comment_count, author: o.author && o.author.name, date: day(o.created_time), updated: day(o.updated_time), url: "https://zhuanlan.zhihu.com/p/" + o.id });
  }
  // 同一问题下的多个回答会各占一行 → 按问题归并，保留赞同最高的那条，记下"另有 N 个回答"
  const byKey = new Map();
  for (const it of items) {
    const prev = byKey.get(it.key);
    if (!prev) { byKey.set(it.key, it); it.others = 0; }
    else { prev.others += 1; if ((it.votes || 0) > (prev.votes || 0)) { it.others = prev.others; byKey.set(it.key, it); } }
  }
  const merged = [...byKey.values()].sort((a, b) => (b.votes || 0) - (a.votes || 0));
  return merged.slice(0, opts.limit || 8);
}

// ── 微博 / 贴吧 两源已于 2026-10-16 删除（长期无 cookie，且平台风控/页面结构不支持稳定解析） ──

// ── 小红书（必须登录态；x-s 签名由本机无头 Chrome 的页面运行时生成，见 xhs.mjs） ──
export async function xiaohongshuBuzz(query, opts) {
  opts = opts || {};
  needsCookie("小红书", "xiaohongshu");
  const { xhsSearch } = await import("./xhs.mjs");
  const r = await xhsSearch(query, { limit: opts.limit || 8, pages: opts.pages || 1 });
  const items = r.items.map((x) => ({ title: x.title, author: x.author, likes: x.likes, comments: x.comments, age: x.age, url: x.url }));
  if (!items.length) throw new Error("小红书没有捕获到笔记（风控或结构变化）");
  return items;
}

// ── 汇总：给 gather 用的一站式入口（rec 是 lib.mjs 里带 try/catch 的记录器） ──
export async function cnGather(query, opts, rec, res) {
  opts = opts || {};
  // 显式关闭中文社区源（与 compare() 的 opts.cn === false 语义一致；每模型省 10~20 秒）
  if (opts.cn === false) { res.cn = res.cn || {}; return res.cn; }
  const [bili, csdn, wx, zh, xhs] = await Promise.all([
    rec("bilibili", () => bilibiliBuzz(query, opts)),
    rec("csdn", () => csdnBuzz(query, opts)),
    rec("weixin", () => weixinBuzz(query, opts)),
    rec("zhihu", () => zhihuBuzz(query, opts)),
    rec("xiaohongshu", () => xiaohongshuBuzz(query, opts)),
  ]);
  res.cn = { bilibili: bili, csdn: csdn, weixin: wx, zhihu: zh, xiaohongshu: xhs };
  return res.cn;
}

// ── 渲染：中文社区口碑一节（若所有中文源都空则返回空串，不占版面） ──
export function renderCnSection(r, cap) {
  cap = cap || 5;
  const cn = r.cn || {};
  const L = [];
  const b = cn.bilibili;
  if (b && b.videos && b.videos.length) {
    L.push("### B站实测视频（约 " + (b.total || b.videos.length) + " 条命中）");
    L.push("");
    L.push("*播放 / 评论为累计值*");
    L.push("");
    L.push("| 视频 | UP主 | 播放 | 评论 | 时长 | 发布 |");
    L.push("|---|---|---|---|---|---|");
    for (const v of b.videos) L.push("| [" + v.title + "](" + v.url + ") | " + (v.author || "-") + " | ▲" + (v.play || 0) + " | " + (v.comments || 0) + " | " + (v.duration || "-") + " | " + (v.date || "-") + " |");
    L.push("");
    if (b.comments && b.comments.length) {
      L.push("B站高赞评论（一手使用体验，非评测机构口径）：");
      for (const c of b.comments.slice(0, cap)) L.push("- 「" + c.text + "」（👍" + (c.like || 0) + (c.user ? " · " + c.user : "") + "）");
      L.push("");
    }
  }
  const cd = cn.csdn;
  if (cd && cd.length) {
    L.push("### CSDN 技术帖（" + cd.length + " 篇）");
    L.push("");
    for (const a of cd.slice(0, cap)) L.push("- [" + (a.title || "(无标题)") + "](" + a.url + ")" + (a.date ? "（" + a.date + (a.views != null ? " · 阅读 " + a.views : "") + "）" : ""));
    L.push("");
  }
  const w = cn.weixin;
  if (w && w.length) {
    L.push("### 微信公众号文章");
    L.push("");
    L.push("*经搜狗微信检索；公众号没有公开的阅读量 / 评论*");
    L.push("");
    for (const a of w.slice(0, cap)) L.push("- [" + (a.title || "(无标题)") + "](" + (a.url || a.sogouUrl) + ")" + (a.account ? " —— " + a.account : "") + (a.date ? "（" + a.date + "）" : ""));
    L.push("");
    if (w.some((x) => !x.url)) L.push("（带 sogou 跳转链的条目是搜狗中转页，公众号原文地址需要在浏览器里打开一次。）");
    L.push("");
  }
  const z = cn.zhihu;
  if (z && z.length) {
    L.push("### 知乎（" + z.length + " 条命中）");
    L.push("");
    L.push("*赞同数为累计值*");
    L.push("");
    for (const a of z.slice(0, cap)) L.push("- [" + a.kind + "] [" + (a.title || "(无标题)") + "](" + a.url + ")" + (a.votes != null ? "（赞同 " + a.votes + (a.comments != null ? " · 评论 " + a.comments : "") + (a.others ? " · 同题另有 " + a.others + " 个回答" : "") + "）" : "") + (a.date ? " · " + a.date : "") + (a.author ? " —— " + a.author : ""));
    L.push("");
    const q = z.filter((x) => x.excerpt).slice(0, 3);
    if (q.length) { L.push("摘要："); for (const a of q) L.push("- " + a.excerpt); L.push(""); }
  }
  const xhs = cn.xiaohongshu;
  if (xhs && xhs.length) {
    L.push("### 小红书（" + xhs.length + " 条）");
    L.push("");
    for (const a of xhs.slice(0, cap)) L.push("- " + (a.title || "") + (a.author ? " —— " + a.author : "") + (a.likes != null ? "（赞 " + a.likes + (a.comments != null ? " · 评 " + a.comments : "") + "）" : "") + (a.age ? " · " + a.age : "") + (a.url ? " " + a.url : ""));
    L.push("");
  }
  if (!L.length) return "";
  const missing = ["zhihu", "xiaohongshu"].filter((k) => {
    const s = (r.sources || []).find((x) => x.id === k);
    return s && !s.ok && /未配置|登录态/.test(s.error || "");
  });
  if (missing.length) L.push("（" + missing.join(" / ") + " 需要登录态：把 cookie 写进 ~/.dsh-ai-research/cookies.json 后自动启用。）");
  return "**中文社区口碑** —— 中文圈的一手讨论与实测\n\n" + L.join("\n");
}
export function cnSummary(r) {
  const cn = r.cn || {};
  const n = (v) => (Array.isArray(v) ? v.length : 0);
  return {
    bilibili: cn.bilibili ? { total: cn.bilibili.total, videos: n(cn.bilibili.videos), comments: n(cn.bilibili.comments) } : null,
    csdn: n(cn.csdn), weixin: n(cn.weixin), zhihu: n(cn.zhihu), xiaohongshu: n(cn.xiaohongshu),
  };
}

// ── 横评用：轻量抓一份中文口碑（不重复登记 sources，缺 cookie 的源记为 null 不报错） ──
export async function cnBrief(query, opts) {
  opts = opts || {};
  const ck = cookies();
  const out = { fail: {} };
  const seq = [
    ["bilibili", true, () => bilibiliBuzz(query, { videos: 3, commentVideos: 2, commentsPerVideo: 5 })],
    ["csdn", true, () => csdnBuzz(query, { limit: 5 })],
    ["weixin", true, () => weixinBuzz(query, { limit: 5, resolve: 0 })],
    ["zhihu", !!ck.zhihu, () => zhihuBuzz(query, { limit: 5 })],
    ["xiaohongshu", !!ck.xiaohongshu, () => xiaohongshuBuzz(query, { limit: 5 })]
  ];
  // 实测：中文源并发同时打会全部返空且不报错（B站/CSDN/搜狗 均 videos=0/csdn=0/weixin=0），必须串行 + 间隔
  for (const it of seq) {
    if (!it[1]) { out.fail[it[0]] = "未配置登录态 cookie"; continue; }
    try { out[it[0]] = await it[2](); } catch (err) { out.fail[it[0]] = String((err && err.message) || err).slice(0, 120); }
    await sleep(240 + Math.round(Math.random() * 200));
  }
  return out;
}
export function renderCnCompare(ms) {
  const rows = (ms || []).filter((e) => e && e.cn);
  if (!rows.length) return "";
  const anyData = rows.some((e) => (e.cn.bilibili && (e.cn.bilibili.videos || []).length) || (e.cn.csdn && e.cn.csdn.length) || (e.cn.weixin && e.cn.weixin.length) || (e.cn.zhihu && e.cn.zhihu.length) || (e.cn.xiaohongshu && e.cn.xiaohongshu.length));
  if (!anyData) return "";
  const L = [];
  L.push("## 中文社区口碑（B站 / CSDN / 微信公众号；知乎 / 小红书 需登录态）");
  L.push("");
  L.push("| 模型 | B站最热实测视频 | 播放 | 评论 | CSDN | 微信公众号 | 知乎最热 | 小红书最热 |");
  L.push("|---|---|---|---|---|---|---|---|");
  for (const e of rows) {
    const b = e.cn.bilibili;
    const v = b && (b.videos || [])[0];
    const z = cnSummary({ cn: e.cn });
    L.push("| " + (e.name || e.query) + " | " + (v ? "[" + v.title + "](" + v.url + ")" : "无") + " | " + (v ? "▲" + (v.play || 0) : "-") +
      " | " + (v ? (v.comments || 0) : "-") + " | " + (z.csdn ? z.csdn + " 篇" : "0") + " | " + (z.weixin ? z.weixin + " 篇" : "0") +
      " | " + ((e.cn.zhihu && e.cn.zhihu[0]) ? "[" + String(e.cn.zhihu[0].title || "").slice(0, 24) + "](" + (e.cn.zhihu[0].url || "") + ") ▲" + (e.cn.zhihu[0].votes || 0) : "无") +
      " | " + ((e.cn.xiaohongshu && e.cn.xiaohongshu[0]) ? "[" + String(e.cn.xiaohongshu[0].title || "").slice(0, 24) + "](" + (e.cn.xiaohongshu[0].url || "") + ") ♥" + (e.cn.xiaohongshu[0].likes || 0) + (e.cn.xiaohongshu[0].age ? " · " + e.cn.xiaohongshu[0].age : "") : "无") + " |");
  }
  L.push("");
  const pairs = [];
  const seen = [];
  const junk = /^(已三连|已关注|三连了|求知识库|沙发|前排|第一|打卡|来了|报道)/;
  for (const e of rows) {
    const cs = ((e.cn.bilibili && e.cn.bilibili.comments) || [])
      .filter((c) => (c.like || 0) >= 3 && c.text.length >= 12 && !junk.test(c.text))
      .slice(0, 2);
    for (const c of cs) {
      const sig = c.text.slice(0, 24);
      if (seen.indexOf(sig) >= 0) continue;
      seen.push(sig);
      pairs.push([e.name || e.query, c]);
    }
  }
  if (pairs.length) {
    L.push("B站高赞评论（一手使用体验，非机构口径）：");
    L.push("");
    for (const p of pairs) L.push("- **" + p[0] + "**：「" + p[1].text.slice(0, 160) + "」（👍" + (p[1].like || 0) + "）");
    L.push("");
  }
  const missing = ["zhihu", "xiaohongshu"].filter((k) => rows.some((e) => e.cn.fail && e.cn.fail[k]));
  if (missing.length) L.push("（" + missing.join(" / ") + " 本次未启用：缺登录态 cookie，见 ~/.dsh-ai-research/cookies.json。）");
  L.push("");
  return L.join("\n");
}
