// search.mjs —— 搜索引擎「发现」层（Brave）：覆盖 x.com / reddit.com 等站点，但按 IP 限流。
// 统一提供：磁盘缓存 + 429 熔断冷却 + 通用 snippet 解析，给 x.mjs / reddit.mjs 共用。
import fs from "node:fs";
import path from "node:path";
import { get, sleep } from "./net.mjs";
import { cacheDir } from "./home.mjs";

export const CACHE = cacheDir("search");

export function decodeEntities(s) {
  return String(s == null ? "" : s)
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ").replace(/&mdash;/g, "\u2014").replace(/&amp;/g, "&");
}

export function cacheGet(key, ttlMs) {
  try {
    const f = path.join(CACHE, key.replace(/[^a-z0-9._-]+/gi, "_").slice(0, 120) + ".json");
    const st = fs.statSync(f);
    if (Date.now() - st.mtimeMs > ttlMs) return null;
    return JSON.parse(fs.readFileSync(f, "utf8"));
  } catch { return null; }
}
export function cachePut(key, val) {
  try {
    fs.mkdirSync(CACHE, { recursive: true });
    const f = path.join(CACHE, key.replace(/[^a-z0-9._-]+/gi, "_").slice(0, 120) + ".json");
    fs.writeFileSync(f, JSON.stringify(val), "utf8");
  } catch {}
}

const COOLDOWN_FILE = "brave-cooldown.json";
/** 无参=读剩余冷却毫秒；带参=写入冷却 */
export function braveCooldown(ms) {
  const f = path.join(CACHE, COOLDOWN_FILE);
  if (ms === undefined) {
    try { const j = JSON.parse(fs.readFileSync(f, "utf8")); return Math.max(0, (j.until || 0) - Date.now()); }
    catch { return 0; }
  }
  try { fs.mkdirSync(CACHE, { recursive: true }); fs.writeFileSync(f, JSON.stringify({ until: Date.now() + ms }), "utf8"); } catch {}
  return 0;
}

/** Brave 结果页 → [{url, text}]。注意：标题在 line-clamp 的 div 里，没有 div.title / div.snippet-description。 */
export function braveSnippets(html) {
  const out = [];
  const parts = String(html || "").split('data-pos="');
  for (let i = 1; i < parts.length; i++) {
    const seg = parts[i].slice(0, 8000);
    const m = seg.match(/<a[^>]+href="(https?:\/\/[^"]+)"/);
    if (!m) continue;
    const txt = decodeEntities(seg.replace(/<script[\s\S]*?<\/script>/g, " ").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ")).trim();
    out.push({ url: m[1], text: txt });
  }
  return out;
}

/** 取 Brave 结果页；命中缓存直接返回，429 写入冷却。返回 {html,status,cached,degraded,note} */
export async function braveHTML(q, opts) {
  opts = opts || {};
  const ck = "brave_" + q;
  const cached = cacheGet(ck, opts.searchTtlMs || 12 * 3600 * 1000);
  if (cached) return { html: cached, status: 200, cached: true, degraded: false, note: "" };
  const cd = braveCooldown();
  if (cd > 0 && !opts.ignoreCooldown) {
    return { html: null, status: 0, cached: false, degraded: true, note: "Brave 429 冷却中，剩余 " + Math.round(cd / 1000) + "s" };
  }
  const res = await get("https://search.brave.com/search?q=" + encodeURIComponent(q), { timeout: 25000, retry: 1 });
  if (res.status === 429) {
    braveCooldown(opts.cooldownMs || 10 * 60 * 1000);
    return { html: null, status: 429, cached: false, degraded: true, note: "Brave 429，进入10分钟冷却" };
  }
  if (res.status !== 200 || !res.body || res.body.length < 5000) {
    return { html: null, status: res.status, cached: false, degraded: true, note: "Brave HTTP " + res.status };
  }
  cachePut(ck, res.body);
  return { html: res.body, status: 200, cached: false, degraded: false, note: "" };
}

/** 站点发现：跑若干条 query，按 href 正则收集去重链接 */
export async function discover(queries, urlRegex, opts) {
  opts = opts || {};
  const hits = new Map();
  const info = { queries: [], degraded: false, note: "", hits: 0 };
  const gapMs = opts.gapMs || 900;
  for (const q of queries) {
    let r;
    try { r = await braveHTML(q, opts); }
    catch (e) { info.queries.push({ q: q, status: "err" }); info.degraded = true; continue; }
    info.queries.push({ q: q, status: r.status, cached: r.cached });
    if (r.degraded) { info.degraded = true; info.note = r.note; if (r.status === 429) break; continue; }
    for (const s of braveSnippets(r.html)) {
      const m = s.url.match(urlRegex);
      if (m && !hits.has(m[1])) hits.set(m[1], { id: m[1], sub: m[2] || "", url: s.url, snippet: s.text.slice(0, 400), via: "brave" });
    }
    if (!r.cached) await sleep(gapMs);
  }
  info.hits = hits.size;
  return { items: Array.from(hits.values()), info: info };
}
