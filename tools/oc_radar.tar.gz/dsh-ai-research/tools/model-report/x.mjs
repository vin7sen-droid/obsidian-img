// x.mjs —— X（Twitter）讨论抓取：Brave 发现 + 账号时间线兜底 + fxtwitter 富化
// 本机 x.com / twitter.com 直连不可达；推文正文走 api.fxtwitter.com，账号时间线走 syndication.twitter.com。
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { get, getJSON, sleep } from "./net.mjs";
import { braveCooldown, braveSnippets, braveHTML, cacheGet, cachePut, decodeEntities, CACHE } from "./search.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));

// 常驻观察名单：厂商官号 + 评测/资讯号。时间线不需要登录，是搜索被限流时的兜底通道。
export const ROSTER = [
  "XiaomiMiMo", "Alibaba_Qwen", "deepseek_ai", "OpenAI", "AnthropicAI", "GoogleDeepMind",
  "GoogleAI", "AIatMeta", "MistralAI", "xai", "ArtificialAnlys", "lmsysorg", "huggingface",
  "_LuoFuli", "karpathy", "simonw", "TheTuringPost", "scaling01", "lmarena_ai", "OpenRouterAI",
];

// 账号别名：用查询词挑出相关官号，避免把 30 次/15 分钟的配额浪费在无关账号上。
export const ROSTER_ALIAS = {
  XiaomiMiMo: ["mimo", "xiaomi", "\u5c0f\u7c73"],
  Alibaba_Qwen: ["qwen", "tongyi", "\u901a\u4e49", "qwq"],
  deepseek_ai: ["deepseek", "deepseek-v", "dsv"],
  OpenAI: ["gpt", "openai", "sora", "o3", "o4"],
  AnthropicAI: ["claude", "opus", "sonnet", "haiku", "anthropic"],
  GoogleDeepMind: ["gemini", "gemma", "deepmind", "veo", "nano"],
  GoogleAI: ["gemini", "google", "gemma"],
  AIatMeta: ["llama", "meta"],
  MistralAI: ["mistral", "magistral", "codestral", "devstral"],
  xai: ["grok", "xai"],
  ArtificialAnlys: ["aa", "intelligence"],
  lmsysorg: ["arena", "lmsys"],
  lmarena_ai: ["arena", "lmarena"],
  huggingface: ["huggingface", "open weights"],
  OpenRouterAI: ["openrouter"],
  TheTuringPost: [], scaling01: [], karpathy: [], simonw: [], _LuoFuli: [],
};
const GENERAL = ["ArtificialAnlys", "lmsysorg", "lmarena_ai", "huggingface", "TheTuringPost", "scaling01", "karpathy", "simonw"];

export function pickRoster(query, budget) {
  const tk = tokenize(query);
  const q = " " + tk.tokens.join(" ") + " ";
  const vendors = [];
  for (const acct of Object.keys(ROSTER_ALIAS)) {
    if (GENERAL.indexOf(acct) >= 0) continue;
    const al = ROSTER_ALIAS[acct] || [];
    for (const a of al) {
      if (q.indexOf(" " + a) >= 0 || tk.tokens.indexOf(a) >= 0) { vendors.push(acct); break; }
    }
  }
  const out = vendors.slice(0, 4);
  for (const g of GENERAL) { if (out.length >= (budget || 10)) break; out.push(g); }
  return out.slice(0, budget || 10);
}

const STOP = new Set(["the","and","for","with","from","that","this","are","was","has","have","its","you","your","our","their","about","into","over","under","after","before","best","new","how","why","what","when","which","all","can","not","but","just","very","much","more","most","also","than","then","them","they","will","would","could","should","one","two","use","using","made","make","via","get","got","out","now","day","week","month","model","models","test","tests","review","reviews","real","release","released","launch","update","benchmark","benchmarks","score","scores"]);
const GENERIC = new Set(["pro","flash","max","mini","lite","turbo","ultra","next","beta","preview","plus","air","base","small","large","medium","standard","high","low","v2","v3","v4"]);

export function tokenize(q) {
  const toks = String(q || "").toLowerCase().replace(/[^a-z0-9.\u4e00-\u9fa5]+/g, " ").split(" ").map(function (s) { return s.replace(/^\.+|\.+$/g, ""); }).filter(function (s) { return s.length >= 3 && !STOP.has(s); });
  const uniq = Array.from(new Set(toks));
  const core = uniq.filter(function (t) { return !GENERIC.has(t); });
  return { tokens: uniq, core: core.length ? core : uniq };
}

export function tokenHit(text, tok) {
  const esc = String(tok).replace(/[.*+?^${}()|[\]\\]/g, function (ch) { return "\\" + ch; });
  return new RegExp("(^|[^a-z0-9])" + esc + "([^a-z0-9]|$)", "i").test(String(text || ""));
}
export function isRelevant(text, tk) {
  const t = String(text || "").toLowerCase();
  if (!t) return false;
  let core = 0, all = 0;
  for (const c of tk.core) if (tokenHit(t, c)) core++;
  for (const c of tk.tokens) if (tokenHit(t, c)) all++;
  if (tk.core.length >= 2) return core >= 2;
  return all >= Math.min(2, tk.tokens.length);
}

// ---------- 发现通道 1：Brave 搜索（x.com 结果） ----------
const RL_FILE = "x-ratelimit.json";
export function rlRead() {
  try { return JSON.parse(fs.readFileSync(path.join(CACHE, RL_FILE), "utf8")); } catch { return { remaining: null, reset: 0, at: 0 }; }
}
export function rlWrite(patch) {
  try {
    fs.mkdirSync(CACHE, { recursive: true });
    const cur = rlRead();
    fs.writeFileSync(path.join(CACHE, RL_FILE), JSON.stringify(Object.assign(cur, patch, { at: Date.now() })), "utf8");
  } catch {}
}
export function rlBlocked() {
  const r = rlRead();
  if (r.remaining === 0 && r.reset && Date.now() / 1000 < r.reset - 60) return r;
  return null;
}

export async function braveX(query, opts) {
  opts = opts || {};
  const variants = opts.variants || ['site:x.com "' + query + '"', '"' + query + '" x.com', 'site:x.com ' + query];
  const ids = new Map();
  const info = { queries: [], hits: 0, degraded: false, cooldownMs: 0, note: "" };
  for (const q of variants) {
    let html = null, status = 0, cached = false;
    try {
      const r = await braveHTML(q, opts);
      html = r.html; status = r.status || (r.cached ? 200 : 0); cached = r.cached;
      if (r.degraded) { info.degraded = true; info.note = r.note || "Brave 不可用"; }
    } catch (e) { info.degraded = true; info.note = "Brave 请求失败：" + String(e.message || e); }
    info.queries.push({ q: q, status: status, cached: cached });
    if (status === 429) break;
    if (!html) { await sleep(400); continue; }
    for (const s of braveSnippets(html)) {
      const m = s.url.match(/(?:x|twitter)\.com\/([A-Za-z0-9_]{2,20})\/status\/(\d{15,25})/);
      const a = s.url.match(/(?:x|twitter)\.com\/([A-Za-z0-9_]{2,20})\/article\/(\d{15,25})/);
      const hit = m || a;
      if (!hit) continue;
      if (!ids.has(hit[2])) ids.set(hit[2], { id: hit[2], user: hit[1], snippet: s.text.slice(0, 300), via: "brave" });
    }
    if (!cached) await sleep(900);
  }
  info.hits = ids.size;
  return { ids: Array.from(ids.values()), info: info };
}
// ---------- 发现通道 2：账号时间线（syndication，无需登录） ----------
function walkTweets(o, out) {
  if (!o || typeof o !== "object") return;
  if (Array.isArray(o)) { for (const v of o) walkTweets(v, out); return; }
  if (typeof o.full_text === "string" && o.id_str && (o.favorite_count !== undefined || o.permalink)) out.push(o);
  for (const k of Object.keys(o)) walkTweets(o[k], out);
}
export function timelineTweets(html) {
  const m = String(html || "").match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]*?)<\/script>/);
  if (!m) return [];
  let j = null;
  try { j = JSON.parse(m[1]); } catch { return []; }
  const out = [];
  walkTweets(j, out);
  return out;
}

async function oneAccount(acct, opts, info) {
  const ck = "xtl_" + acct;
  const blocked = rlBlocked();
  if (blocked && !opts.ignoreCooldown) {
    if (info) info.statuses[acct] = "quota(" + Math.round((blocked.reset - Date.now() / 1000) / 60) + "m)";
    return [];
  }
  let html = cacheGet(ck, opts.timelineTtlMs || 6 * 3600 * 1000);
  if (!html) {
    for (let attempt = 0; attempt < 3; attempt++) {
      let res = null;
      try {
        res = await get("https://syndication.twitter.com/srv/timeline-profile/screen-name/" + acct, { timeout: 20000, retry: 1 });
      } catch (e) {
        if (info) info.statuses[acct] = "err:" + String(e.message || e).slice(0, 40);
        return [];
      }
      rlWrite({ remaining: res.headers && res.headers["x-rate-limit-remaining"] !== undefined ? Number(res.headers["x-rate-limit-remaining"]) : undefined, reset: res.headers && res.headers["x-rate-limit-reset"] ? Number(res.headers["x-rate-limit-reset"]) : undefined });
      if (res.status === 200 && res.body && res.body.length > 3000) { html = res.body; cachePut(ck, html); break; }
      if (res.status === 429) { if (info) { info.statuses[acct] = "429 (quota)"; info.statuses.__blocked__ = "429"; } rlWrite({ remaining: 0, reset: res.headers && res.headers["x-rate-limit-reset"] ? Number(res.headers["x-rate-limit-reset"]) : Math.floor(Date.now() / 1000) + 900 }); return []; }
      if (res.status === 503) { if (info) info.statuses[acct] = "503 retry"; await sleep(4000 + attempt * 6000); continue; }
      if (info) info.statuses[acct] = "HTTP " + res.status + (res.status === 429 ? " (quota)" : "");
      if (res.status === 429) break;
      return [];
    }
  } else if (info) info.statuses[acct] = "cache";
  if (!html) { if (info && !info.statuses[acct]) info.statuses[acct] = "no-html"; return []; }
  const list = timelineTweets(html);
  if (info && !info.statuses[acct]) info.statuses[acct] = list.length + " tweets";
  return list.map(function (t) {
    return {
      id: String(t.id_str),
      user: (t.user && t.user.screen_name) || acct,
      name: (t.user && t.user.name) || acct,
      followers: (t.user && t.user.followers_count) || null,
      date: t.created_at ? new Date(t.created_at).toISOString().slice(0, 10) : "",
      likes: t.favorite_count || 0,
      retweets: t.retweet_count || 0,
      replies: t.reply_count || 0,
      quotes: t.quote_count || 0,
      views: t.views_count || null,
      text: decodeEntities(t.full_text),
      url: "https://x.com/" + ((t.user && t.user.screen_name) || acct) + "/status/" + t.id_str,
      lang: t.lang || "",
      via: "timeline",
    };
  });
}
export async function rosterTweets(tk, opts) {
  opts = opts || {};
  const raw = rlRead();
  const rlNow = (raw.remaining !== null && raw.reset && Date.now() / 1000 < raw.reset) ? raw : { remaining: null, reset: 0 };
  const budget = opts.budget || 6;
  let roster = opts.roster || pickRoster(opts.query || "", budget);
  if (!opts.roster && rlNow.remaining !== null && rlNow.remaining < roster.length) {
    roster = roster.slice(0, Math.max(1, rlNow.remaining - 1));
  }
  const gap = opts.concurrency || 3;
  const found = [];
  const info = { accounts: roster.length, roster: roster, tweaked: 0, matched: 0, errors: 0, statuses: {}, note: "" };
  const blocked = rlBlocked();
  if (blocked && !opts.ignoreCooldown) info.note = "syndication 配额 429 未恢复（reset " + new Date(blocked.reset * 1000).toISOString().slice(11, 16) + "Z），本轮跳过账号时间线";
  const rl0 = rlNow; // 只有仍在窗口内的配额记录才算数，过期的 remaining 0 不能拦住本轮
  if (rl0.remaining !== null && rl0.remaining <= 3) info.note = info.note || ("syndication 剩余配额仅 " + rl0.remaining + " 次，只取部分账号");
  for (let i = 0; i < roster.length; i += gap) {
    const batch = roster.slice(i, i + gap);
    const rs = await Promise.all(batch.map(function (a) { return oneAccount(a, opts, info).catch(function () { return []; }); }));
    if (info.statuses.__blocked__) break;
    const rlMidRaw = rlRead();
    // 配额窗口已过期时 remaining 仍是上一窗口的 0 —— 不能据此提前停止（实测会白白跳过整轮抓取）
    const rlMid = (rlMidRaw.remaining !== null && rlMidRaw.reset && Date.now() / 1000 < rlMidRaw.reset) ? rlMidRaw : { remaining: null, reset: 0 };
    if (rlMid.remaining !== null && rlMid.remaining <= 2) {
      info.note = (info.note ? info.note + "；" : "") + "syndication 剩余配额 " + rlMid.remaining + "，提前停止时间线抓取";
      info.statuses.__stopped__ = "remaining " + rlMid.remaining;
      break;
    }
    rs.forEach(function (list, bi) {
      if (!list.length) info.errors++;
      for (const t of list) {
        if (isRelevant(t.text, tk)) { info.matched++; found.push(t); }
      }
    });
    await sleep(250);
  }
  info.tweaked = found.length;
  return { tweets: found, info: info };
}

// ---------- 富化：fxtwitter ----------
export async function enrich(idOrUrl) {
  const m = String(idOrUrl).match(/(?:x|twitter)\.com\/([A-Za-z0-9_]{2,20})\/status\/(\d{15,25})/) || String(idOrUrl).match(/^([A-Za-z0-9_]{2,20})\/(\d{15,25})$/);
  const url = m ? "https://api.fxtwitter.com/" + m[1] + "/status/" + m[2] : (String(idOrUrl).indexOf("http") === 0 ? String(idOrUrl).replace(/(x|twitter)\.com/, "api.fxtwitter.com") : null);
  if (!url) return null;
  const r = await getJSON(url, { timeout: 20000, retry: 1 });
  const t = r.json && r.json.tweet;
  if (!t) return null;
  return {
    id: String(t.id || ""),
    user: (t.author && t.author.screen_name) || "",
    name: (t.author && t.author.name) || "",
    followers: (t.author && t.author.followers) || null,
    date: t.created_at ? new Date(t.created_at).toISOString().slice(0, 10) : "",
    likes: t.likes || 0,
    retweets: t.retweets || 0,
    replies: t.replies || 0,
    quotes: t.quotes || 0,
    views: t.views || null,
    text: decodeEntities(t.text),
    url: t.url || ("https://x.com/i/status/" + t.id),
    lang: t.lang || "",
    via: "fxtwitter",
  };
}

// ---------- 主入口 ----------
export async function xBuzz(query, opts) {
  opts = opts || {};
  const tk = tokenize(query);
  const limit = opts.limit || 6;
  const gaps = [];
  const channels = {};

  let brave = { ids: [], info: { queries: [], degraded: false, hits: 0 } };
  if (opts.search !== false) {
    try { brave = await braveX(query, opts); } catch (e) { gaps.push("X 之 Brave 发现失败：" + String(e.message || e)); brave.info.degraded = true; }
  }
  channels.brave = brave.info;

  let roster = { tweets: [], info: { matched: 0, errors: 0 } };
  if (opts.roster !== false) {
    try { roster = await rosterTweets(tk, Object.assign({ query: query }, opts)); } catch (e) { gaps.push("X 之账号时间线失败：" + String(e.message || e)); }
  }
  channels.roster = roster.info;
  if (roster.info && roster.info.note) gaps.push("X 账号时间线：" + roster.info.note);

  const seeds = Array.isArray(opts.seeds) ? opts.seeds : [];
  channels.seeds = seeds.length;

  const byId = new Map();
  const put = function (p) { if (p && p.id && !byId.has(p.id)) byId.set(p.id, p); };
  // 时间线已经带互动数，先用它占位；Brave / seed 只拿到 id，需要富化
  for (const t of roster.tweets) put(t);
  for (const s of seeds) { try { put(await enrich(s)); } catch {} }

  const need = brave.ids.filter(function (x) { return x.via === "brave"; });
  const budget = opts.enrichMax || 16;
  let enriched = 0, failed = 0;
  for (const cand of need.slice(0, budget)) {
    try {
      const p = await enrich(cand.user + "/" + cand.id);
      if (p) { p.via = "brave"; p.snippet = cand.snippet; put(p); enriched++; } else failed++;
    } catch { failed++; }
    await sleep(opts.gapMs || 250);
  }
  channels.enriched = enriched;
  if (failed) gaps.push("X 有 " + failed + " 条推文富化失败（fxtwitter）");

  let posts = Array.from(byId.values());
  // 相关度：时间线已过滤；Brave 来的用正文再筛一次（Brave 的 site: 查询偶尔会带偏）
  posts = posts.filter(function (p) { return p.via !== "brave" || isRelevant(p.text, tk) || isRelevant(p.snippet, tk); });
  posts.sort(function (a, b) { return (b.likes || 0) - (a.likes || 0); });
  const total = posts.length;
  if (brave.info.degraded) gaps.push("X 之 Brave 搜索被限流（429），本次仅用账号时间线/种子链接");
  if (!total) gaps.push("X 未找到有效讨论（可传 opts.seeds 由外部搜索补链接）");
  return { posts: posts.slice(0, Math.max(limit, opts.keep || limit)), total: total, tokens: tk.tokens, channels: channels, gaps: gaps, engine: "brave+syndication+fxtwitter" };
}

export { HERE as X_HERE };

// 独立运行：node x.mjs "MiMo v2.6 Pro" [--no-search] [--limit N] [--seeds url,url] [--roster-off]
if (process.argv[1] && process.argv[1].replace(/\\/g, "/").split("/").pop() === "x.mjs") {
  const argv = process.argv.slice(2);
  const opts = { limit: 8 };
  const pos = [];
  for (let i2 = 0; i2 < argv.length; i2++) {
    const a = argv[i2];
    if (a === "--no-search") opts.search = false;
    else if (a === "--roster-off") opts.roster = false;
    else if (a === "--accounts") opts.roster = String(argv[++i2] || "").split(",").filter(Boolean);
    else if (a === "--concurrency") opts.concurrency = Number(argv[++i2]) || 1;
    else if (a === "--ignore-cooldown") opts.ignoreCooldown = true;
    else if (a === "--limit") opts.limit = Number(argv[++i2]) || 8;
    else if (a === "--seeds") opts.seeds = String(argv[++i2] || "").split(",").filter(Boolean);
    else pos.push(a);
  }
  const q = pos[0] || "MiMo v2.6 Pro";
  const r = await xBuzz(q, opts);
  console.log(JSON.stringify({ query: q, total: r.total, channels: r.channels, gaps: r.gaps }, null, 1).slice(0, 3000));
  for (const p of r.posts.slice(0, 12)) console.log("  " + p.likes + "♥ [" + p.via + "] " + p.date + " @" + p.user + " " + String(p.text).replace(/\s+/g, " ").slice(0, 100));
}
