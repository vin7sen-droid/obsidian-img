#!/usr/bin/env node
// model-report CLI
//   单模型：node cli.mjs "Gemini 4 Argon" [--peers [N]] [--insights 解读.json] [--brief] [--per-source 5] [--json] [--out results] [--fast]
//   横评  ：node cli.mjs --vs "Gemini 4 Argon,Claude Opus 5.5,GPT-6.1" [--auto N] [--per-source 5] [--json] [--out results] [--fast]
//   --fast：跳过 5 个重型源（Artificial Analysis / Vals / SWE-bench / ARC / SWE-rebench），约 3s 出结果
//   --no-x / --no-reddit：关掉 X（Twitter）与 Reddit 两个英文社区源（默认开）
//   --no-lmarena：关掉 LMArena（HF 官方数据集，默认开；--fast 也会跳过）
//   --seeds "https://x.com/u/status/123,..."：给 X 源直喂推文链接（Brave 被限流 / 配额用尽时的替补）
//   --peers [N]：自动挑 N（默认 3）个段位相近的同类模型，报告里内嵌「同类横评」一节
//   --brief：只输出「解读素材包」（给模型读的一页素材 + insights JSON 模板），不出成品报告
//   --insights <file>：把写好的 insights JSON 塞进报告（一句话结论 / 每段解读 / 英文原句中译）
import { writeFileSync, mkdirSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { gather, report, renderMarkdown, brief, summarize, suggestQueries, compare, renderCompare, summarizeCompare, peerModels } from "./lib.mjs";

const argv = process.argv.slice(2);
// 注意：不能先 filter 掉 --xxx 再找 flag 的值 —— 那样 flag 名没了，值会被当成模型名（曾经的 bug）。
const outDirFlag = { v: null }, vsFlag = { v: null }, autoFlag = { v: null }, wantJsonFlag = { v: false }, fastFlag = { v: false };
const peersFlag = { v: 0 }, briefFlag = { v: false }, insightsFlag = { v: null }, perSourceFlag = { v: null };
const noXFlag = { v: false }, noRedditFlag = { v: false }, seedsFlag = { v: null }, noLmarenaFlag = { v: false };
const words = [];
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === "--json") wantJsonFlag.v = true;
  else if (a === "--fast") fastFlag.v = true;
  else if (a === "--brief") briefFlag.v = true;
  else if (a === "--no-x") noXFlag.v = true;
  else if (a === "--no-reddit") noRedditFlag.v = true;
  else if (a === "--no-lmarena") noLmarenaFlag.v = true;
  else if (a === "--seeds") { if (!argv[i + 1]) { console.error('--seeds 后面要跟逗号分隔的推文链接'); process.exit(2); } seedsFlag.v = argv[++i]; }
  else if (a === "--no-peers") peersFlag.v = 0;
  else if (a === "--peers") { const nv = Number(argv[i + 1]); if (nv >= 1 && nv <= 8) { peersFlag.v = nv; i++; } else peersFlag.v = 3; }
  else if (a === "--per-source") { const nv = Number(argv[i + 1]); if (!nv || nv < 1) { console.error("--per-source 后面要跟数字（每个源最多几条，如 --per-source 5）"); process.exit(2); } perSourceFlag.v = nv; i++; }
  else if (a === "--insights") { if (!argv[i + 1]) { console.error("--insights 后面要跟 JSON 文件路径"); process.exit(2); } insightsFlag.v = argv[++i]; }
  else if (a === "--out") { if (!argv[i + 1]) { console.error("--out 后面要跟目录"); process.exit(2); } outDirFlag.v = argv[++i]; }
  else if (a === "--vs") { if (!argv[i + 1]) { console.error('--vs 后面要跟 "A,B,C"'); process.exit(2); } vsFlag.v = argv[++i]; }
  else if (a === "--auto") { const nv = Number(argv[i + 1]); if (!nv || nv < 1) { console.error("--auto 后面要跟数字（挑几个对手，如 --auto 3）"); process.exit(2); } autoFlag.v = nv; i++; }
  else if (a.startsWith("--")) { console.error("未知参数 " + a); process.exit(2); }
  else words.push(a);
}
// --out 的相对路径以当前工作目录为基准（默认不落盘；显式 --out 才写文件）
const HERE = dirname(fileURLToPath(import.meta.url));
const outDir = outDirFlag.v ? resolve(process.cwd(), outDirFlag.v) : null;
const vs = vsFlag.v, wantJson = wantJsonFlag.v;
const perSource = perSourceFlag.v || 5;
const baseOpts = { deep: !fastFlag.v, perSource: perSource, x: !noXFlag.v, reddit: !noRedditFlag.v, lmarena: !noLmarenaFlag.v };
if (seedsFlag.v) baseOpts.xOpts = { seeds: seedsFlag.v.split(",").map(s => s.trim()).filter(Boolean) };
let insights = null;
if (insightsFlag.v) {
  const p = resolve(process.cwd(), insightsFlag.v);
  try { insights = JSON.parse(readFileSync(p, "utf8")); }
  catch (e) { console.error("读不到 / 解析不了 insights JSON：" + String((e && e.message) || e)); process.exit(2); }
}
const slugify = (s) => s.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, "-").replace(/^-|-$/g, "") || "model";

if (vs || (autoFlag.v && words.length)) {
  const queries = vs ? vs.split(",").map(s => s.trim()).filter(Boolean) : [words.join(" ")];
  if (queries.length < 2 && !autoFlag.v) { console.error('横评至少给两个模型：--vs "A,B,C"，或用 --auto N 自动挑对手'); process.exit(2); }
  const r = await compare(queries, { auto: autoFlag.v, deep: !fastFlag.v, perSource: perSource, lmarena: !noLmarenaFlag.v, x: !noXFlag.v, reddit: !noRedditFlag.v });
  const md = renderCompare(r);
  const day = r.generatedAt.slice(0, 10);
  const name = "compare-" + r.queries.map(slugify).join("-vs-") + (autoFlag.v ? "-auto" : "") + "-" + day;
  if (outDir) {
    mkdirSync(outDir, { recursive: true });
    writeFileSync(outDir + "/" + name + ".md", md, "utf8");
    writeFileSync(outDir + "/" + name + ".json", JSON.stringify({ summary: summarizeCompare(r), data: r }, null, 1), "utf8");
    console.log("[写出] " + outDir + "/" + name + ".md / .json");
  }
  if (wantJson) console.log(JSON.stringify(summarizeCompare(r), null, 1));
  else console.log(md);
  if (autoFlag.v) console.log("\n[对手由 --auto 挑出] " + (r.auto || []).map(a => a.name + "（" + a.why.join("、") + "）").join("；"));
  console.error("[口碑仍要网页补] 对每个模型分别跑 web_search，例如：" + r.queries.map(q => q + " 实测 口碑").join(" | "));
} else {
  const query = words.join(" ");
  if (!query) { console.error('用法: node cli.mjs "<模型名>" [--peers [N]] [--brief] [--insights f.json] | --vs "A,B,C" [--auto N] [--fast] [--json] [--out <目录>]'); process.exit(2); }
  const out = peersFlag.v > 0 ? await report(query, Object.assign({}, baseOpts, { peers: peersFlag.v })) : { r: await gather(query, baseOpts), cmp: null };
  const r = out.r, cmp = out.cmp;
  if (peersFlag.v > 0) console.error("[同行对手] " + ((cmp && cmp.peerPicks) || []).map(p => p.name + "（" + p.why.join("、") + "）").join("；"));
  const slug = slugify(query);
  const day = r.generatedAt.slice(0, 10);
  const md = briefFlag.v ? brief(r) : renderMarkdown(r, { insights: insights, compare: cmp });
  if (outDir) {
    mkdirSync(outDir, { recursive: true });
    const name = slug + "-" + day + (briefFlag.v ? "-brief" : "");
    writeFileSync(outDir + "/" + name + ".md", md, "utf8");
    writeFileSync(outDir + "/" + name + ".json", JSON.stringify({ summary: summarize(r), data: r, compare: cmp }, null, 1), "utf8");
    console.log("[写出] " + outDir + "/" + name + ".md / .json");
  }
  if (wantJson) console.log(JSON.stringify(summarize(r), null, 1));
  else console.log(md);
  if (!briefFlag.v && !insights) console.error("[提醒] 还没给 --insights：报告里只有自动解读。先用 --brief 拿素材写 insights JSON，再带 --insights 重跑渲染。");
  console.error("[建议用 web_search 补这些查询] " + suggestQueries(query).join(" | "));
}
