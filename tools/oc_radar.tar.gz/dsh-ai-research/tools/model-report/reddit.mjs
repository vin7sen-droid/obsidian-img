// reddit.mjs —— Reddit 讨论抓取。reddit.com 本体对本机出口 IP 全部 403（含 .json / .rss / web_fetch），
// 所以走两条路：① Brave 搜 site:reddit.com 拿帖子链接；② arctic-shift 归档的版块火管 + 关键词过滤。
// 帖子与评论正文都用 arctic-shift（Photon 归档），失败兜底 pullpush.io（更严的限流，只能慢用）。
import { get, getJSON, sleep } from "./net.mjs";
import { discover } from "./search.mjs";
import { tokenize, isRelevant } from "./x.mjs"; // 词法工具与 X 侧共用一份实现

const ARCTIC = "https://arctic-shift.photon-reddit.com";
const PULLPUSH = "https://api.pullpush.io/reddit/search";
export const SUBS_DEFAULT = { LocalLLaMA: 14, singularity: 6, MachineLearning: 4 };

/** 相关度：标题命中最强，其次核心词在正文的命中数（火管里很多帖子只是顺带提到模型名） */
export function relevanceOf(title, text, tk) {
  const t = String(title || "").toLowerCase();
  const b = String(text || "").toLowerCase();
  const titleHits = tk.core.filter(function (c) { return t.indexOf(c) >= 0; }).length;
  const coreHits = tk.core.filter(function (c) { return b.indexOf(c) >= 0; }).length;
  return { titleHits: titleHits, coreHits: coreHits, strong: titleHits > 0 };
}

function cut(s, n) { const t = String(s == null ? "" : s).replace(/\s+/g, " ").trim(); return t.length > n ? t.slice(0, n) + "…" : t; }

/** 版块火管：倒序翻页直到超出时间窗。返回 {rows, pages, since, oldest} */
export async function firehose(sub, opts) {
  opts = opts || {};
  const days = opts.days || 30;
  const since = Math.floor(Date.now() / 1000) - days * 86400;
  const maxPages = opts.maxPages || 8;
  const rows = [];
  let before = null, pages = 0, oldest = null;
  for (let p = 0; p < maxPages; p++) {
    const url = ARCTIC + "/api/posts/search?subreddit=" + encodeURIComponent(sub) + "&limit=100&sort=desc"
      + (before ? "&before=" + before : "&after=" + since);
    let data = null;
    try {
      const r = await getJSON(url, { timeout: 30000, retry: 1 });
      data = r.json && r.json.data;
    } catch (e) { break; }
    if (!data || !data.length) break;
    pages++;
    for (const d of data) rows.push(d);
    oldest = data[data.length - 1].created_utc;
    if (oldest <= since) break;
    before = oldest;
    await sleep(opts.gapMs || 250);
  }
  return { rows: rows, pages: pages, since: since, oldest: oldest };
}

function normPost(p) {
  return {
    id: p.id,
    sub: p.subreddit,
    title: cut(p.title, 200),
    score: p.score || 0,
    numComments: p.num_comments || 0,
    upvoteRatio: p.upvote_ratio || null,
    date: p.created_utc ? new Date(p.created_utc * 1000).toISOString().slice(0, 10) : "",
    author: p.author || "",
    url: p.permalink ? "https://www.reddit.com" + p.permalink : ("https://www.reddit.com/r/" + p.subreddit + "/comments/" + p.id),
    selftext: cut(p.selftext, 1400),
    via: "arctic",
    titleHits: p.__titleHits === undefined ? 0 : p.__titleHits,
  };
}

function normComment(c) {
  return {
    score: c.score || 0,
    author: c.author || "",
    date: c.created_utc ? new Date(c.created_utc * 1000).toISOString().slice(0, 10) : "",
    body: cut(String(c.body || "").replace(/\n{2,}/g, "\n"), 900),
  };
}

/** 取一条帖子的正文 + 高赞评论（arctic 优先，pullpush 兜底） */
export async function fetchThread(id, opts) {
  opts = opts || {};
  const topComments = opts.topComments || 5;
  let post = null, comments = [], engine = "arctic";
  try {
    const r = await getJSON(ARCTIC + "/api/posts/ids?ids=" + id, { timeout: 25000, retry: 1 });
    post = r.json && r.json.data && r.json.data[0];
  } catch {}
  if (post) {
    try {
      const c = await getJSON(ARCTIC + "/api/comments/search?link_id=" + id + "&limit=100", { timeout: 30000, retry: 1 });
      comments = (c.json && c.json.data) || [];
    } catch {}
  }
  if (!post) {
    engine = "pullpush";
    await sleep(1200);
    try {
      const r = await getJSON(PULLPUSH + "/submission/?ids=" + id, { timeout: 25000, retry: 1 });
      const d = (r.json && r.json.data) || [];
      post = d[0] ? { id: d[0].id, subreddit: d[0].subreddit, title: d[0].title, score: d[0].score, num_comments: d[0].num_comments, created_utc: d[0].created_utc, author: d[0].author, permalink: d[0].permalink, selftext: d[0].selftext } : null;
    } catch {}
    if (post && !comments.length) {
      await sleep(1500);
      try {
        const c = await getJSON(PULLPUSH + "/comment/?link_id=" + id + "&size=100&sort=desc&sort_type=score", { timeout: 25000, retry: 1 });
        comments = (c.json && c.json.data) || [];
      } catch {}
    }
  }
  if (!post) return null;
  const kept = comments
    .filter(function (c) { const b = String(c.body || ""); return b && b !== "[deleted]" && b !== "[removed]" && b.length > 30; })
    .sort(function (a, b) { return (b.score || 0) - (a.score || 0); })
    .slice(0, topComments)
    .map(normComment);
  const out = normPost(post);
  out.engine = engine;
  out.topComments = kept;
  out.commentTotal = comments.length;
  return out;
}

export async function redditBuzz(query, opts) {
  opts = opts || {};
  const tk = tokenize(query);
  const limit = opts.limit || 5;
  const days = opts.days || 30;
  const gaps = [];
  const channels = {};

  // 通道 A：Brave 发现帖子链接
  let brave = { items: [], info: { hits: 0, degraded: false, note: "" } };
  if (opts.search !== false) {
    const qs = opts.queries || ['site:reddit.com "' + query + '"', 'site:reddit.com/r/LocalLLaMA "' + query + '"'];
    try { brave = await discover(qs, /reddit\.com\/r\/(?:[A-Za-z0-9_]+)\/comments\/([a-z0-9]+)/, opts); }
    catch (e) { gaps.push("Reddit 之 Brave 发现失败：" + String(e.message || e)); }
  }
  channels.brave = brave.info;
  if (brave.info && brave.info.degraded && brave.info.note) gaps.push("Reddit 发现通道：" + brave.info.note);

  // 通道 B：版块火管 + 关键词过滤（不需要搜索引擎）
  const subs = opts.subs || SUBS_DEFAULT;
  const fire = [];
  let pages = 0, scanned = 0;
  if (opts.hose !== false) {
    const minHits = opts.minHits || 6;
    for (const sub of Object.keys(subs)) {
      try {
        const r = await firehose(sub, { days: days, maxPages: subs[sub], gapMs: opts.gapMs || 250 });
        pages += r.pages; scanned += r.rows.length;
        const hit = r.rows.filter(function (p) { return isRelevant((p.title || "") + " " + (p.selftext || ""), tk); });
        for (const h of hit) h.__titleHits = relevanceOf(h.title, "", tk).titleHits;
        hit.sort(function (a, b) { return (b.score || 0) - (a.score || 0); });
        for (const h of hit) fire.push(normPost(h));
        if (fire.length >= minHits) break;
      } catch (e) { gaps.push("Reddit 版块火管 " + sub + " 失败：" + String(e.message || e)); }
    }
  }
  channels.firehose = { subs: Object.keys(subs), pages: pages, scanned: scanned, hits: fire.length, days: days };

  // 合并候选：火管命中已有 score，Brave 链接只有标题片段
  const cand = new Map();
  for (const f of fire) cand.set(f.id, f);
  for (const b of brave.items) {
    if (!cand.has(b.id)) cand.set(b.id, { id: b.id, title: b.snippet ? cut(b.snippet, 160) : "", score: 0, via: "brave", needFetch: true });
  }
  channels.candidates = cand.size;

  const list = Array.from(cand.values()).sort(function (a, b) {
    const at = (a.titleHits || 0) > 0 ? 1 : 0, bt = (b.titleHits || 0) > 0 ? 1 : 0;
    if (at !== bt) return bt - at;
    return (b.score || 0) - (a.score || 0);
  });
  const budget = opts.enrichMax || 12;
  const threads = [];
  let fetched = 0, failed = 0;
  for (const c of list.slice(0, budget)) {
    let t = null;
    try { t = await fetchThread(c.id, opts); } catch { t = null; }
    if (t) {
      const rel = relevanceOf(t.title, t.selftext + " " + t.topComments.map(function (x) { return x.body; }).join(" "), tk);
      t.relevance = rel;
      t.weak = !rel.strong;
      t.via = c.via || "arctic";
      threads.push(t); fetched++;
    } else failed++;
    await sleep(opts.gapMs2 || 500);
  }
  channels.fetched = fetched;
  if (failed) gaps.push("Reddit 有 " + failed + " 条帖子取正文失败（arctic/pullpush 均无）");

  // 相关度优先、热度次之；弱相关的丢到后面
  threads.sort(function (a, b) {
    const at = a.relevance ? a.relevance.titleHits : 0, bt = b.relevance ? b.relevance.titleHits : 0;
    if (at !== bt) return bt - at;
    const ac = a.relevance ? a.relevance.coreHits : 0, bc = b.relevance ? b.relevance.coreHits : 0;
    if (!!a.weak !== !!b.weak) return a.weak ? 1 : -1;
    if (ac !== bc) return bc - ac;
    return (b.score || 0) - (a.score || 0);
  });
  const total = threads.length;
  if (!total) gaps.push("Reddit 未找到有效讨论（可调 opts.days / opts.subs，或传 opts.seeds）");
  return { threads: threads.slice(0, Math.max(limit, opts.keep || limit)), total: total, tokens: tk.tokens, channels: channels, gaps: gaps, engine: "brave+arctic-shift" };
}

// 独立运行：node reddit.mjs "MiMo v2.6 Pro" [--days N] [--limit N] [--no-search] [--no-hose]
if (process.argv[1] && process.argv[1].replace(/\\/g, "/").split("/").pop() === "reddit.mjs") {
  const argv = process.argv.slice(2);
  const opts = { limit: 5 };
  const pos = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--no-search") opts.search = false;
    else if (a === "--no-hose") opts.hose = false;
    else if (a === "--days") opts.days = Number(argv[++i]) || 30;
    else if (a === "--limit") opts.limit = Number(argv[++i]) || 5;
    else pos.push(a);
  }
  const q = pos[0] || "MiMo v2.6 Pro";
  const t0 = Date.now();
  const r = await redditBuzz(q, opts);
  console.log(JSON.stringify({ query: q, total: r.total, channels: r.channels, gaps: r.gaps, ms: Date.now() - t0 }, null, 1).slice(0, 2500));
  for (const t of r.threads.slice(0, 8)) {
    const rel = t.relevance || {};
    console.log("  [" + t.via + "] " + t.score + "\u2191 " + t.numComments + "\ud83d\udcac r/" + t.sub + " " + t.date + " titleHits=" + (rel.titleHits || 0) + " coreHits=" + (rel.coreHits || 0) + " weak=" + (!!t.weak));
    console.log("     TITLE: " + t.title);
    console.log("     BODY : " + String(t.selftext || "").slice(0, 260));
    for (const c of t.topComments.slice(0, 2)) console.log("      " + c.score + "\u2191 " + String(c.body).slice(0, 110));
  }
}
