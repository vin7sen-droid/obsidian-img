// home.mjs —— 运行期状态目录的单一来源（cookie / 缓存 / 熔断状态）。
// 为什么不在包目录里放状态：包可能被装进 node_modules（只读、且升级会整目录替换），
// 装到全局后又有多个会话共用同一份的问题 —— 所以状态一律外置到用户主目录。
//
// 目录优先级：DSH_AI_RESEARCH_HOME > MODEL_REPORT_HOME > ~/.dsh-ai-research
// cookie 文件：DSH_AI_RESEARCH_COOKIES > MODEL_REPORT_COOKIES > <home>/cookies.json
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

export function homeDir() {
  const raw = process.env.DSH_AI_RESEARCH_HOME || process.env.MODEL_REPORT_HOME || "";
  return path.resolve(raw.trim() ? raw.trim() : path.join(os.homedir(), ".dsh-ai-research"));
}
// 建不出来（只读环境 / 沙箱）不在这里抛：调用方真正写文件时才会失败，错误信息更贴上下文。
export function ensureHome() { const d = homeDir(); try { fs.mkdirSync(d, { recursive: true }); } catch {} return d; }
export function cacheDir(...parts) {
  const d = path.join(homeDir(), ".cache", ...parts.filter(Boolean));
  try { fs.mkdirSync(d, { recursive: true }); } catch {}
  return d;
}
export function statePath(name) { ensureHome(); return path.join(homeDir(), name); }
export function cookiesPath() {
  const raw = process.env.DSH_AI_RESEARCH_COOKIES || process.env.MODEL_REPORT_COOKIES || "";
  return raw.trim() ? path.resolve(raw.trim()) : path.join(homeDir(), "cookies.json");
}
export function describePaths() {
  return { home: homeDir(), cache: path.join(homeDir(), ".cache"), cookies: cookiesPath() };
}
