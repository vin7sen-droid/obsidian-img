// LMArena 官方榜接入。
// 为什么走 HuggingFace：lmarena.ai 站点与 /api/leaderboard 全被 Cloudflare 403，第三方代理（r.jina.ai / codetabs）也不可达。
// 官方数据集 lmarena-ai/leaderboard-dataset（public / cc-by-4.0）每天更新，按榜分目录给 latest / full 两个 split 的 parquet，
// 直下 parquet 再用本地 parquet.mjs 解码（零依赖，11033 行约 40ms），比 datasets-server 的 /rows 接口稳（后者会 429）。
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { getBuffer } from "./net.mjs";
import { toRows } from "./parquet.mjs";
import { cacheDir } from "./home.mjs";

const CACHE = cacheDir("lmarena");
const HF = "https://huggingface.co/datasets/lmarena-ai/leaderboard-dataset/resolve/main";
const TTL_MS = 6 * 60 * 60 * 1000;      // 榜每天更新，本地缓存 6 小时
const MEM = new Map();

export const ARENA_BOARDS = [
  { id: "text", label: "文本总榜", kind: "elo", note: "人类盲测综合偏好" },
  { id: "text_style_control", label: "文本 · 风格控制后", kind: "elo", note: "剥离回答风格（长度/排版/表情）后的偏好" },
  { id: "webdev", label: "WebDev 前端", kind: "elo", note: "生成/改网页的两两对比" },
  { id: "vision", label: "视觉（图片理解）", kind: "elo", note: "图片理解与图文创作" },
  { id: "agent", label: "Agent 真实会话", kind: "score", note: "官方 score 口径（实测量级约 -0.1~0.2），不是 Elo" },
];
export const ARENA_DEFAULT_BOARDS = ARENA_BOARDS.map(function (b) { return b.id; });
export function arenaBoardMeta(id) {
  for (const b of ARENA_BOARDS) if (b.id === id) return b;
  return { id: id, label: id, kind: "elo", note: "" };
}
// 文本榜里值得看的题集（按这个顺序渲染；不在表里的排在后面）
const CAT_ORDER = ["overall", "coding", "math", "hard_prompts", "hard_prompts_english", "instruction_following",
  "multi_turn", "longer_query", "creative_writing", "expert", "english", "chinese", "non_english"];
const CAT_ZH = {
  overall: "总榜", coding: "编程", math: "数学", hard_prompts: "难题集（中文）", hard_prompts_english: "难题集（英文）",
  instruction_following: "指令遵循", multi_turn: "多轮对话", longer_query: "长提问", creative_writing: "创意写作",
  expert: "专家题", english: "英文", chinese: "中文", non_english: "非英文", exclude_ties: "不计平局",
  industry_business_and_management_and_financial_operations: "行业·商管金融",
  industry_entertainment_and_sports_and_media: "行业·娱乐体育传媒",
  industry_legal_and_government: "行业·法律政务",
  industry_life_and_physical_and_social_science: "行业·生命与社科",
  industry_mathematical: "行业·数学", industry_medicine_and_healthcare: "行业·医疗健康",
  industry_software_and_it_services: "行业·软件与 IT", industry_writing_and_literature_and_language: "行业·写作与语言",
  webdev: "WebDev 总", "webdev-html": "WebDev·HTML", "webdev-react": "WebDev·React", image_to_webdev: "图生网页",
  captioning: "图片描述", creative_writing_vision: "图文创意", diagram: "图表理解", ocr: "OCR",
  homework: "作业/解题", humor: "幽默图", entity_recognition: "实体识别",
  russian: "俄语", japanese: "日语", korean: "韩语", german: "德语", french: "法语", spanish: "西班牙语", polish: "波兰语",
};
// 与 lib.mjs 的 btoks/wordHit 同一套词法口径（那边是通用匹配；这里额外拆出「(High)/(Max)」这类档位后缀）
function atoks(s) { return String(s == null ? "" : s).toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5.]+/g, " ").trim().split(" ").filter(Boolean); }
export function arenaScore(name, query) {
  const q = atoks(query);
  if (!q.length) return 0;
  const raw = String(name || "");
  const t = atoks(raw.replace(/\([^)]*\)/g, " "));
  if (!t.length) return 0;
  if (t.join(" ") === q.join(" ")) return 100;
  for (let i = 0; i + q.length <= t.length; i++) {
    let all = true;
    for (let k = 0; k < q.length; k++) if (t[i + k] !== q[k]) { all = false; break; }
    if (all) return i === 0 ? 88 : 76;
  }
  const set = new Set(t);
  let ok = true;
  for (const w of q) if (!set.has(w)) { ok = false; break; }
  return ok ? 60 : 0;
}
function variantOf(name) {
  const m = String(name || "").match(/\(([^)]*)\)/);
  return m ? m[1] : null;
}
function pickDate(rows) {
  for (const r of rows) if (r && r.leaderboard_publish_date) return r.leaderboard_publish_date;
  return null;
}
function num(x) { return typeof x === "number" && isFinite(x) ? x : (x == null ? null : Number(x)); }

export function arenaValue(row, kind) {
  if (!row) return { value: null, lower: null, upper: null, votes: null, sessions: null };
  if (kind === "score") return { value: num(row.score), lower: num(row.score_ci_lower), upper: num(row.score_ci_upper), votes: num(row.observation_count), sessions: num(row.session_count) };
  return { value: num(row.rating), lower: num(row.rating_lower), upper: num(row.rating_upper), votes: num(row.vote_count), sessions: null };
}

/** 取一个榜的整张表（带磁盘 + 内存缓存）。失败抛错，交由上层记进 gaps。 */
export async function lmarenaBoard(id, opts) {
  opts = opts || {};
  const key = id + "|" + (opts.fresh ? "f" + Date.now() : "c");
  if (MEM.has(key)) return MEM.get(key);
  const json = path.join(CACHE, "lmarena-" + id + ".json");
  if (!opts.fresh) {
    try {
      const j = JSON.parse(fs.readFileSync(json, "utf8"));
      if (j && j.rows && j.rows.length && Date.now() - (j.fetchedAt || 0) < TTL_MS) {
        const b = { id: id, meta: arenaBoardMeta(id), publishDate: j.publishDate, fetchedAt: j.fetchedAt, cached: true, rows: j.rows };
        MEM.set(key, b); return b;
      }
    } catch (e) { /* 没缓存或缓存坏了 → 走网络 */ }
  }
  const url = HF + "/" + id + "/latest-00000-of-00001.parquet";
  const r = await getBuffer(url, { timeout: 60000, retry: 2 });
  if (r.status !== 200) throw new Error("LMArena 榜 " + id + " 下载失败：HTTP " + r.status + "（" + url + "）");
  try { fs.mkdirSync(CACHE, { recursive: true }); fs.writeFileSync(path.join(CACHE, "lmarena-" + id + ".parquet"), r.body); } catch (e) { /* 缓存写失败不影响解码 */ }
  const parsed = toRows(r.body);
  const rows = parsed.rows.filter(function (x) { return x && x.model_name; });
  const b = { id: id, meta: arenaBoardMeta(id), publishDate: pickDate(rows), fetchedAt: Date.now(), cached: false, rows: rows, columns: parsed.columns };
  MEM.set(key, b);
  try { fs.writeFileSync(json, JSON.stringify({ id: id, publishDate: b.publishDate, fetchedAt: b.fetchedAt, rows: rows })); } catch (e) { /* 忽略 */ }
  return b;
}

/** 在一个榜里找模型（只在 overall 里匹配，返回带 _score 的候选，按分数/名次排） */
export function lmarenaFind(board, query, limit) {
  if (!board || !board.rows) return [];
  const out = [];
  for (const row of board.rows) {
    if (row.category !== "overall") continue;
    const sc = arenaScore(row.model_name, query);
    if (sc <= 0) continue;
    out.push(Object.assign({ _score: sc, _variant: variantOf(row.model_name) }, row));
  }
  out.sort(function (a, b) { return b._score - a._score || (a.rank || 9999) - (b.rank || 9999) || atoks(a.model_name).length - atoks(b.model_name).length; });
  return out.slice(0, limit == null ? 3 : limit);
}
function catTotal(board, cat) {
  let n = 0, max = 0;
  for (const r of board.rows) if (r.category === cat) { n++; if ((r.rank || 0) > max) max = r.rank; }
  return max || n;
}
function catRows(board, modelName, kind) {
  const out = [];
  for (const r of board.rows) {
    if (r.model_name !== modelName) continue;
    const v = arenaValue(r, kind);
    out.push({ category: r.category, zh: CAT_ZH[r.category] || r.category, rank: r.rank, total: catTotal(board, r.category), value: v.value, lower: v.lower, upper: v.upper, votes: v.votes, sessions: v.sessions });
  }
  out.sort(function (a, b) {
    const ia = CAT_ORDER.indexOf(a.category), ib = CAT_ORDER.indexOf(b.category);
    return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib) || String(a.category).localeCompare(String(b.category));
  });
  return out;
}

/** 单模型查询：跨榜匹配（每个榜独立失败隔离） */
export async function lmarenaLookup(query, opts) {
  opts = opts || {};
  const ids = opts.boards || opts.arenaBoards || ARENA_DEFAULT_BOARDS;
  const out = { ok: false, query: query, boards: [], hits: {}, gaps: [] };
  const lists = await Promise.all(ids.map(function (id) {
    return lmarenaBoard(id, opts).then(function (b) { return { id: id, board: b, err: null }; })
      .catch(function (e) { return { id: id, board: null, err: String((e && e.message) || e).slice(0, 160) }; });
  }));
  for (const it of lists) {
    if (it.err) { out.gaps.push("LMArena " + it.id + "：" + it.err); continue; }
    const b = it.board;
    const hits = lmarenaFind(b, query, 3);
    if (!hits.length) { out.gaps.push("LMArena " + b.meta.label + "（" + b.id + "，发布 " + (b.publishDate || "?") + "）没有这个模型"); continue; }
    const top = hits[0];
    const overall = hits.map(function (h) { const v = arenaValue(h, b.meta.kind); return { name: h.model_name, variant: h._variant, score: h._score, rank: h.rank, total: catTotal(b, "overall"), value: v.value, lower: v.lower, upper: v.upper, votes: v.votes, sessions: v.sessions, license: h.license || null, organization: h.organization || null }; });
    const cats = catRows(b, top.model_name, b.meta.kind);
    out.boards.push({ id: b.id, label: b.meta.label, kind: b.meta.kind, note: b.meta.note, publishDate: b.publishDate, cached: !!b.cached, model: top.model_name, variant: top._variant, score: top._score, overall: overall[0], variants: overall, categories: cats });
    out.hits[b.id] = top;
    out.ok = true;
  }
  if (out.boards.length) out.publishDate = out.boards[0].publishDate;
  return out;
}

/** 横评用紧凑版：每个榜只留总榜名次/分数 */
export async function lmarenaBrief(name, opts) {
  const la = await lmarenaLookup(name, Object.assign({}, opts, { brief: true }));
  const o = { ok: la.ok, query: la.query, publishDate: la.publishDate || null, boards: {}, cats: {}, gaps: la.gaps };
  for (const b of la.boards) {
    const st = null;
    o.boards[b.id] = { label: b.label, kind: b.kind, publishDate: b.publishDate, model: b.model, variant: b.variant, rank: b.overall.rank, total: b.overall.total, value: b.overall.value, lower: b.overall.lower, upper: b.overall.upper, votes: b.overall.votes, sessions: b.overall.sessions };
  }
  const text = la.boards.filter(function (b) { return b.id === "text"; })[0];
  if (text) for (const c of text.categories || []) o.cats[c.category] = { zh: c.zh, rank: c.rank, total: c.total, value: c.value, votes: c.votes };
  return o;
}

function fmtNum(x, d) { return x == null || !isFinite(x) ? "-" : Number(x).toFixed(d == null ? 1 : d); }
function dec(kind) { return kind === "score" ? 4 : 1; }
function fmtVotes(n) { if (n == null) return "-"; return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function ci(v) { return v.lower == null || v.upper == null ? "-" : fmtNum(v.lower) + "–" + fmtNum(v.upper) + ""; }

/** 单模型报告里的 LMArena 段（返回 markdown 字符串，没数据返回 null） */
export function renderLmArena(la, cap) {
  if (!la || !la.ok || !la.boards.length) return null;
  const n = cap || 5;
  const L = [];
  const dates = la.boards.map(function (b) { return b.publishDate; }).filter(Boolean);
  const uniq = dates.filter(function (d, i) { return dates.indexOf(d) === i; });
  L.push("### LMArena 人类盲测竞技场（官方榜）");
  L.push("");
  L.push("*数据发布 " + uniq.join(" / ") + " · 来源 HuggingFace 官方数据集 lmarena-ai/leaderboard-dataset（每天更新）*");
  L.push("");
  L.push("| 榜 | 名次 | 分数 | 95% 置信区间 | 票数 |");
  L.push("|---|---|---|---|---|");
  for (const b of la.boards) {
    const v = b.overall;
    const votes = b.kind === "score" ? fmtVotes(v.sessions) + " 会话 / " + fmtVotes(v.votes) + " 次观测" : fmtVotes(v.votes);
    const dg = dec(b.kind);
    L.push("| " + b.label + (b.variant ? "（" + b.variant + "）" : "") + " | #" + v.rank + "/" + v.total + " | " + fmtNum(v.value, dg) +
      " | " + (v.lower == null ? "-" : fmtNum(v.lower, dg) + "–" + fmtNum(v.upper, dg)) + " | " + votes + " |");
  }
  L.push("");
  const text = la.boards.filter(function (b) { return b.id === "text"; })[0];
  if (text && text.categories && text.categories.length > 1) {
    const rows = text.categories.filter(function (c) { return c.category !== "overall" && c.category !== "exclude_ties"; });
    const head = rows.slice(0, Math.max(6, n + 2));
    L.push("**文本榜分项** —— 同一张榜的不同题集，名次可比");
    L.push("");
    L.push("| 题集 | 名次 | Elo | 票数 |");
    L.push("|---|---|---|---|");
    for (const c of head) L.push("| " + c.zh + " | #" + c.rank + "/" + c.total + " | " + fmtNum(c.value) + " | " + fmtVotes(c.votes) + " |");
    L.push("");
    const rest = rows.slice(head.length);
    if (rest.length) {
      L.push("- 其余题集：" + rest.map(function (c) { return c.zh + " #" + c.rank + "（" + fmtNum(c.value) + "）"; }).join(" · "));
      L.push("");
    }
  }
  const style = la.boards.filter(function (b) { return b.id === "text_style_control"; })[0];
  if (text && style) {
    const dRank = (style.overall.rank || 0) - (text.overall.rank || 0);
    const dElo = (text.overall.value != null && style.overall.value != null) ? Math.round((text.overall.value - style.overall.value) * 10) / 10 : null;
    L.push("> 风格控制前后：" + text.label + " #" + text.overall.rank + "（" + fmtNum(text.overall.value, 1) + "） → " + style.label + " #" + style.overall.rank + "（" + fmtNum(style.overall.value, 1) + "）" +
      (dRank > 0 ? "，名次后移 " + dRank + " 位" : dRank < 0 ? "，名次前移 " + (-dRank) + " 位" : "，名次不变") +
      (dElo != null ? "，分差 " + (dElo > 0 ? "-" : "+") + Math.abs(dElo) + "" : "") + "（两榜票数相同，差的只是有没有把回答风格从偏好里剥掉）");
    L.push("");
  }
  L.push("> 口径：LMArena 是人类两两盲投出来的 Elo（同一套投票算法、同一批票），不是厂商自报；分数区间重叠的两个模型**不能说谁强**。同名的 (High)/(Max)/(xHigh) 是同一模型的不同推理档位，分开排。");
  L.push("");
  return L.join("\n");
}

/** 横评里的 LMArena 段：各模型在同榜的名次 + 文本榜分项对齐 */
export function renderLmArenaCompare(models, opts) {
  const ms = models || [];
  const ok = ms.filter(function (e) { return e.lmarena && e.lmarena.ok && e.lmarena.boards; });
  if (ok.length < 2) return null;
  const L = [];
  const ids = [];
  for (const e of ok) for (const k of Object.keys(e.lmarena.boards)) if (ids.indexOf(k) < 0) ids.push(k);
  L.push("## LMArena 同榜对齐（同一张榜、同一批人类投票 —— 名次与分数可直接比）");
  L.push("");
  L.push("| 模型 | " + ids.map(function (id) { return arenaBoardMeta(id).label; }).join(" | ") + " |");
  L.push("|---" + ids.map(function () { return "---"; }).join("|---") + "|");
  for (const e of ms) {
    const br = e.lmarena && e.lmarena.boards;
    if (!br || !e.lmarena.ok) { L.push("| " + (e.name || e.query) + " | " + ids.map(function () { return "未匹配"; }).join(" | ") + " |"); continue; }
    const cells = ids.map(function (id) {
      const b = br[id];
      if (!b) return "-";
      return "#" + b.rank + "/" + b.total + "（" + fmtNum(b.value, dec(b.kind)) + "）";
    });
    L.push("| " + (e.name || e.query) + " | " + cells.join(" | ") + " |");
  }
  L.push("");
  const withText = ok.filter(function (e) { return e.lmarena.cats && Object.keys(e.lmarena.cats).length; });
  const cats = [];
  for (const e of withText) for (const c of Object.keys(e.lmarena.cats)) if (c !== "overall" && c !== "exclude_ties" && cats.indexOf(c) < 0) cats.push(c);
  const use = cats.filter(function (c) {
    return withText.filter(function (e) { return e.lmarena.cats[c]; }).length >= 2;
  }).sort(function (a, b) {
    const ia = CAT_ORDER.indexOf(a), ib = CAT_ORDER.indexOf(b);
    return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib) || String(a).localeCompare(String(b));
  });
  if (use.length) {
    L.push("文本榜分项（同一张榜的不同题集；括号内是该题集的 Elo）");
    L.push("");
    L.push("| 题集 | " + withText.map(function (e) { return e.name || e.query; }).join(" | ") + " |");
    L.push("|---" + withText.map(function () { return "---"; }).join("|---") + "|");
    const rowOf = function (c) {
      return "| " + (CAT_ZH[c] || c) + " | " + withText.map(function (e) {
        const v = e.lmarena.cats[c];
        return v ? "#" + v.rank + "/" + v.total + "（" + fmtNum(v.value, 1) + "）" : "-";
      }).join(" | ") + " |";
    };
    const show = use.slice(0, (opts && opts.catCap) || 12);
    for (const c of show) L.push(rowOf(c));
    L.push("");
    const rest = use.slice(show.length);
    if (rest.length) {
      L.push("- 其余 " + rest.length + " 个题集（行业题集 / 多语言）：" + rest.map(function (c) {
        const v = withText.filter(function (e) { return e.lmarena.cats[c]; });
        return (CAT_ZH[c] || c) + " " + v.map(function (e) { return "#" + e.lmarena.cats[c].rank; }).join("/");
      }).join(" · "));
      L.push("");
    }
  }
  L.push("> LMArena 是盲测偏好票（不是厂商自报）：名次差在置信区间内 = 不能判定谁强。原始文本榜含回答风格带来的加成，风格控制后的名次见单模型报告。");
  L.push("");
  return L.join("\n");
}

/** 给 countOf 用：命中的榜数 */
export function lmarenaCount(la) { return la && la.boards ? la.boards.length : 0; }

// ── 单跑入口（排查 / 看原始名次用） ──
//   node model-report/lmarena.mjs "MiMo v2.6 Pro"                 # 单模型五个榜
//   node model-report/lmarena.mjs --compare "A,B,C"               # 横评对齐表
//   node model-report/lmarena.mjs "MiMo v2.6 Pro" --fresh         # 忽略缓存重下 parquet
if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const argv = process.argv.slice(2);
  const fresh = argv.includes('--fresh');
  const ci = argv.indexOf('--compare');
  const words = argv.filter(function (a) { return a !== '--fresh' && (ci < 0 || (a !== '--compare' && argv.indexOf(a) !== ci + 1)); });
  try {
    if (ci >= 0) {
      const qs = String(argv[ci + 1] || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean);
      if (qs.length < 2) { console.error('用法: node model-report/lmarena.mjs --compare "A,B,C"'); process.exit(2); }
      const ms = [];
      for (const q of qs) ms.push({ name: q, found: true, lmarena: await lmarenaBrief(q, { fresh: fresh }) });
      const md = renderLmArenaCompare(ms, { n: 2 });
      console.log(md || '（不足两个模型命中 LMArena）');
    } else {
      const q = words.join(' ');
      if (!q) { console.error('用法: node model-report/lmarena.mjs "<模型名>" [--fresh] | --compare "A,B,C"'); process.exit(2); }
      const r = await lmarenaLookup(q, { fresh: fresh });
      console.log(renderLmArena(r, 5) || '（这个模型没在 LMArena 上找到）');
      if (r.gaps.length) console.log('\n缺口：\n- ' + r.gaps.join('\n- '));
    }
  } catch (e) { console.error('失败：' + String((e && e.message) || e)); process.exit(1); }
}
