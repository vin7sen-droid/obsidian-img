// net.mjs —— 出网工具：零依赖，可选走 HTTP(S) 代理的 CONNECT 隧道。
// 代理来源（按顺序）：DSH_AI_RESEARCH_PROXY → MODEL_REPORT_PROXY → MR_PROXY → HTTPS_PROXY → HTTP_PROXY；
// 都没设、或值写成 off/0/none、或主机命中 NO_PROXY，则直连。
// 示例：DSH_AI_RESEARCH_PROXY=http://127.0.0.1:7890 node tools/model-report/cli.mjs "某模型"
import net from "node:net";
import tls from "node:tls";
import https from "node:https";
import http from "node:http";
import { URL } from "node:url";

export const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36";

const PROXY_ENV = ["DSH_AI_RESEARCH_PROXY", "MODEL_REPORT_PROXY", "MR_PROXY", "HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy"];

/** NO_PROXY / no_proxy 命中判定：逗号分隔，支持 *、example.com、.example.com、*.example.com */
function noProxyHit(host) {
  const raw = process.env.NO_PROXY || process.env.no_proxy || "";
  if (!raw || !host) return false;
  const h = String(host).toLowerCase();
  for (const item of String(raw).split(",")) {
    const p = item.trim().toLowerCase();
    if (!p) continue;
    if (p === "*") return true;
    const bare = p.replace(/^\./, "").replace(/^\*\./, "");
    if (h === bare || h.endsWith("." + bare)) return true;
  }
  return false;
}

/** 返回 { host, port } 或 null（= 直连）。传 host 时会应用 NO_PROXY。 */
export function proxySetting(host) {
  const raw = PROXY_ENV.map((k) => process.env[k]).find((v) => v && String(v).trim()) || "";
  if (!raw || /^(off|0|none)$/i.test(String(raw).trim())) return null;
  if (host && noProxyHit(host)) return null;
  try {
    const u = new URL(String(raw).includes("://") ? String(raw) : "http://" + String(raw));
    return { host: u.hostname, port: Number(u.port || (u.protocol === "https:" ? 443 : 80)) };
  } catch { return null; }
}

function tunnel(proxy, host, port, timeout) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(proxy.port, proxy.host, () => {
      sock.write("CONNECT " + host + ":" + port + " HTTP/1.1\r\nHost: " + host + ":" + port + "\r\n\r\n");
    });
    let buf = Buffer.alloc(0);
    const onData = (d) => {
      buf = Buffer.concat([buf, d]);
      const i = buf.indexOf("\r\n\r\n");
      if (i < 0) return;
      sock.removeListener("data", onData);
      const head = buf.slice(0, i).toString("latin1");
      if (!/ 200/.test(head.split("\r\n")[0])) return reject(new Error("proxy CONNECT 失败：" + head.split("\r\n")[0]));
      const rest = buf.slice(i + 4);
      if (rest.length) sock.unshift(rest);
      sock.setTimeout(0);
      resolve(sock);
    };
    sock.on("data", onData);
    sock.on("error", reject);
    sock.setTimeout(timeout, () => reject(new Error("代理连接超时")));
  });
}

async function once(url, { timeout = 25000, headers = {}, method = "GET", body = null, binary = false } = {}) {
  const u = new URL(url);
  const port = Number(u.port || (u.protocol === "http:" ? 80 : 443));
  const isHttps = u.protocol !== "http:";
  const proxy = proxySetting(u.hostname);
  let socket;
  if (proxy) socket = await tunnel(proxy, u.hostname, port, timeout);
  else socket = net.connect(port, u.hostname);
  if (isHttps) {
    const t = tls.connect({ socket, servername: u.hostname });
    await new Promise((res, rej) => { t.once("secureConnect", res); t.once("error", rej); });
    socket = t;
  } else if (!proxy) {
    await new Promise((res, rej) => { socket.once("connect", res); socket.once("error", rej); });
  }
  return await new Promise((resolve, reject) => {
    const mod = isHttps ? https : http;
    const r = mod.request({
      host: u.hostname, port, path: u.pathname + u.search, method,
      createConnection: () => socket,
      headers: Object.assign({
        "User-Agent": UA, Accept: "text/html,application/json;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9", "Accept-Encoding": "identity",
      }, headers),
    });
    r.on("response", (res) => {
      if (binary) {
        const chunks = []; let n = 0;
        res.on("data", (c) => { chunks.push(c); n += c.length; if (n > 24e6) r.destroy(); });
        res.on("end", () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
        return;
      }
      let b = ""; res.setEncoding("utf8");
      res.on("data", (c) => { b += c; if (b.length > 4e6) { r.destroy(); } });
      res.on("end", () => resolve({ status: res.statusCode, headers: res.headers, body: b }));
    });
    r.on("error", reject);
    r.setTimeout(timeout, () => r.destroy(new Error("读取超时")));
    if (body) r.write(body);
    r.end();
  });
}

/** GET，自动跟随 3 次重定向，失败重试 2 次 */
export async function get(url, opts = {}) {
  let cur = url;
  for (let attempt = 0; attempt < (opts.retry || 2); attempt++) {
    try {
      for (let hop = 0; hop < 4; hop++) {
        const r = await once(cur, opts);
        if (r.status >= 300 && r.status < 400 && r.headers.location) {
          cur = new URL(r.headers.location, cur).href;
          continue;
        }
        return r;
      }
      return { status: 0, body: "", headers: {} };
    } catch (e) {
      if (attempt === (opts.retry || 2) - 1) throw e;
      await sleep(600 + attempt * 900);
    }
  }
}

/** GET 二进制（图片 / parquet 等）：body 是 Buffer，不按 utf8 解码 */
export async function getBuffer(url, opts = {}) {
  let cur = url;
  for (let attempt = 0; attempt < (opts.retry == null ? 2 : opts.retry); attempt++) {
    try {
      for (let hop = 0; hop < 4; hop++) {
        const r = await once(cur, Object.assign({}, opts, { binary: true }));
        if (r.status >= 300 && r.status < 400 && r.headers.location) { cur = new URL(r.headers.location, cur).href; continue; }
        return r;
      }
      return { status: 0, body: Buffer.alloc(0), headers: {} };
    } catch (e) {
      if (attempt === (opts.retry == null ? 2 : opts.retry) - 1) throw e;
      await sleep(600 + attempt * 900);
    }
  }
}

export async function getJSON(url, opts = {}) {
  const r = await get(url, opts);
  try { return { status: r.status, json: JSON.parse(r.body), body: r.body }; }
  catch { return { status: r.status, json: null, body: r.body }; }
}

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 顺序执行 + 固定间隔：外网站点对突发并发很敏感（Reddit 直接 429） */
export async function series(items, fn, gap = 350) {
  const out = [];
  for (let i = 0; i < items.length; i++) {
    try { out.push(await fn(items[i], i)); }
    catch (e) { out.push({ __error: String(e && e.message || e) }); }
    if (i < items.length - 1) await sleep(gap);
  }
  return out;
}
