// model-report/lib.mjs —— 单个 AI 模型的「实测 / 口碑」采集器（纯 Node，零依赖）
// 数据源（2026-10-15 实测可用）：llm-stats.com（结构化跑分 + verified/self_reported 标记）、
// benchlm.ai（静态排行榜）、openrouter.ai（价格/上下文/真实用量）、hn.algolia.com（英文社区口碑）、
// api.juejin.cn（中文技术圈文章）。LMArena / Reddit / HuggingFace / 知乎 / B站搜索 在本机不可达。

export const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36";
// 中文社区口碑源（B站 / CSDN / 微信公众号 / 知乎 / 小红书）—— 实现单份在 cn.mjs 里
import { cnGather, cnBrief, cnSummary, renderCnCompare, renderCnSection } from "./cn.mjs";
import { xBuzz } from "./x.mjs";
import { redditBuzz } from "./reddit.mjs";
import { lmarenaLookup, lmarenaBrief, renderLmArena, renderLmArenaCompare } from "./lmarena.mjs";
import { finalizeDoc, TOC_PLACEHOLDER } from "./doc.mjs";
export { cnGather, cnSummary, renderCnSection } from "./cn.mjs";

const _cache = new Map();
export function clearCache() { _cache.clear(); }

// 取文本。5xx / 429 / 网络抖动会退避重试（llm-stats 单模型页实测偶发 502）；
// 4xx（除 429）视为确定性失败，不重试。
export async function getText(url, opts) {
  opts = opts || {};
  const timeout = opts.timeout || 25000;
  const tries = Math.max(1, opts.retries == null ? 3 : opts.retries);
  if (!opts.noCache && _cache.has(url)) return _cache.get(url);
  let lastErr = null;
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(url, {
        headers: Object.assign({ "user-agent": UA, accept: "*/*" }, opts.headers || {}),
        signal: AbortSignal.timeout(timeout),
      });
      const t = await r.text();
      if (r.status >= 500 || r.status === 429) throw new Error("HTTP " + r.status + " " + url + (i < tries - 1 ? "（第 " + (i + 1) + " 次尝试，将重试）" : ""));
      if (r.status >= 400) { const e = new Error("HTTP " + r.status + " " + url); e.fatal = true; throw e; }
      if (!opts.noCache) _cache.set(url, t);
      return t;
    } catch (e) {
      lastErr = e;
      if (e && e.fatal) break;
      if (i < tries - 1) await new Promise(function (res) { setTimeout(res, 400 * (i + 1) * (i + 1)); });
    }
  }
  throw lastErr;
}

// Next.js RSC 流：把 self.__next_f.push([1,"..."]) 分片拼回文本
export function nextRSC(html) {
  const re = /self\.__next_f\.push\(\[1,\s*"((?:[^"\\]|\\.)*)"\]\)/g;
  const parts = [];
  let m;
  while ((m = re.exec(html))) parts.push(m[1]);
  const joined = parts.join("");
  try { return JSON.parse('"' + joined + '"'); } catch (e) { return joined.replace(/\\"/g, '"').replace(/\\n/g, "\n"); }
}

// 从文本里按 key 取出一个完整的 JSON 值（数组或对象），用括号配平截取
export function extractJSON(text, key) {
  const at = text.indexOf('"' + key + '":');
  if (at < 0) return null;
  const start = text.slice(at).search(/[\[{]/) + at;
  if (start < at) return null;
  const open = text[start], close = open === "[" ? "]" : "}";
  let depth = 0, inStr = false, esc = false;
  for (let i = start; i < text.length; i++) {
    const c = text[i];
    if (inStr) { if (esc) esc = false; else if (c === "\\") esc = true; else if (c === '"') inStr = false; continue; }
    if (c === '"') { inStr = true; continue; }
    if (c === open) depth++;
    else if (c === close) { depth--; if (depth === 0) { try { return JSON.parse(text.slice(start, i + 1)); } catch (e) { return null; } } }
  }
  return null;
}

export function stripTags(s) {
  return String(s).replace(/<[^>]+>/g, " ")
    .replace(/&#x([0-9a-fA-F]+);/g, function (m0, h) { return String.fromCodePoint(parseInt(h, 16)); })
    .replace(/&#(\d+);/g, function (m0, d) { return String.fromCodePoint(Number(d)); })
    .replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ").trim();
}
export function norm(s) {
  return String(s || "").toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, "");
}
export function isoDay(d) { return new Date(d).toISOString().slice(0, 10); }
function pct(x) { return x == null ? null : Math.round(x * 1000) / 10; }

// ───────────────────────── llm-stats ─────────────────────────
export async function llmStatsIndex(opts) {
  const html = await getText("https://llm-stats.com/", opts);
  const t = nextRSC(html);
  const arr = extractJSON(t, "initialHomepageLLMModels");
  return Array.isArray(arr) ? arr : [];
}

export function scanModels(index, query, limit) {
  const q = norm(query);
  if (!q) return [];
  const scored = [];
  for (const m of index) {
    const id = norm(m.model_id), name = norm(m.name), org = norm(m.organization);
    let sc = 0;
    if (id === q || name === q) sc = 100;
    else if (id.startsWith(q) || name.startsWith(q)) sc = 88;
    else if (name.includes(q) || id.includes(q)) sc = 76;
    else if (q.includes(name) && name.length >= 4) sc = 66;
    else {
      const qs = String(query).toLowerCase().split(/[^a-z0-9\u4e00-\u9fa5]+/).filter(w => w.length > 1);
      const hay = (m.name + " " + m.organization + " " + m.model_id).toLowerCase();
      const hit = qs.filter(w => hay.includes(w)).length;
      if (qs.length && hit === qs.length) sc = 50 + Math.min(10, qs.length);
      else if (hit) sc = 20 + hit;
    }
    if (org && q.startsWith(org)) sc += 2;
    if (sc > 0) scored.push(Object.assign({ _score: sc }, m));
  }
  scored.sort((a, b) => b._score - a._score || String(b.release_date || "").localeCompare(String(a.release_date || "")));
  return scored.slice(0, limit || 5);
}

export async function llmStatsDetail(modelId, opts) {
  const html = await getText("https://llm-stats.com/models/" + encodeURIComponent(modelId), opts);
  const t = nextRSC(html);
  const benches = extractJSON(t, "benchmarks") || [];
  const meta = extractJSON(t, "model") || extractJSON(t, "model_data") || null;
  return { benchmarks: benches, meta: meta };
}

export function benchTier(b) {
  if (b.verified && !b.self_reported) return "independent";
  const note = String(b.verification_notes || "") + " " + String(b.self_reported_source || "") + " " + String(b.analysis_method || "");
  if (/third-party|third party|leaderboard|reproduc|harness/i.test(note)) return "thirdParty";
  return "vendor";
}
export function benchSplit(benchmarks) {
  const buckets = { independent: [], thirdParty: [], vendor: [], verified: [], self: [] };
  for (const b of benchmarks || []) {
    const row = {
      id: b.benchmark_id, name: b.name, score: b.score, norm: b.normalized_score, max: b.max_score,
      verified: !!b.verified, selfReported: !!b.self_reported, source: b.self_reported_source || null,
      note: b.verification_notes || null, method: b.analysis_method || null, cats: b.categories || [], tier: benchTier(b),
    };
    buckets[row.tier].push(row);
    (b.verified && !b.self_reported ? buckets.verified : buckets.self).push(row);
  }
  for (const k of Object.keys(buckets)) buckets[k].sort(function (a, b) { return (b.norm || 0) - (a.norm || 0); });
  return buckets;
}

// ───────────────────────── benchlm.ai ─────────────────────────
export async function benchlmRows(opts) {
  const html = await getText("https://benchlm.ai/", opts);
  const trs = [...html.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/g)].map(m => m[1]);
  if (!trs.length) return { header: [], rows: [] };
  const cells = (tr) => [...tr.matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/g)].map(m => stripTags(m[1]));
  const header = cells(trs[0]);
  const rows = [];
  for (const tr of trs.slice(1)) {
    const c = cells(tr);
    if (c.length < 4) continue;
    const o = {};
    header.forEach((h, i) => { o[h || ("col" + i)] = c[i] == null ? "" : c[i]; });
    o._cells = c;
    rows.push(o);
  }
  return { header: header, rows: rows };
}

// ───────────────────────── OpenRouter（价格 / 上下文 / 真实用量） ─────────────────────────
export async function openRouterModels(opts) {
  const t = await getText("https://openrouter.ai/api/v1/models", opts);
  const j = JSON.parse(t);
  return Array.isArray(j.data) ? j.data : [];
}
export function scanOR(models, query, limit) {
  const q = norm(query);
  const out = [];
  for (const m of models) {
    const id = norm(m.id.split("/").pop()), full = norm(m.id), name = norm(m.name);
    let sc = 0;
    if (id === q || name === q) sc = 100;
    else if (id.startsWith(q) || name.startsWith(q) || full.endsWith(q)) sc = 86;
    else if (name.includes(q) || full.includes(q)) sc = 74;
    else if (q.includes(name) && name.length >= 4) sc = 60;
    if (sc > 0) out.push(Object.assign({ _score: sc }, m));
  }
  out.sort((a, b) => b._score - a._score || (b.created || 0) - (a.created || 0));
  return out.slice(0, limit || 5);
}
export function orPrice(m) {
  const p = (m && m.pricing) || {};
  const in1 = p.prompt ? Number(p.prompt) * 1e6 : null;
  const out1 = p.completion ? Number(p.completion) * 1e6 : null;
  return { inPerM: in1, outPerM: out1, text: in1 == null ? null : "$" + round2(in1) + " / $" + round2(out1) + " per 1M tok" };
}
function round2(x) { return Math.round(x * 100) / 100; }

// OpenRouter 排行榜页面里的模型级真实 token 用量（解析失败则返回 null，不报错）
export async function openRouterUsage(slug, opts) {
  try {
    const html = await getText("https://openrouter.ai/rankings/models", opts);
    const t = nextRSC(html);
    const i = t.indexOf('"' + slug + '"');
    if (i < 0) return null;
    const win = t.slice(Math.max(0, i - 1200), i + 1200);
    const mt = win.match(/"total_tokens":"?(\d+)/);
    const mr = win.match(/"total_requests":"?(\d+)/);
    const mrank = win.match(/"rank":(\d+)/);
    if (!mt) return null;
    return { slug: slug, totalTokens: Number(mt[1]), totalRequests: mr ? Number(mr[1]) : null, rank: mrank ? Number(mrank[1]) : null };
  } catch (e) { return null; }
}

// ───────────────────────── Hacker News（英文社区口碑） ─────────────────────────
export async function hnBuzz(query, opts) {
  opts = opts || {};
  const limit = opts.limit || 20;
  const q = encodeURIComponent(query);
  const [st, cm] = await Promise.all([
    getText("https://hn.algolia.com/api/v1/search?query=" + q + "&tags=story&hitsPerPage=" + limit, opts),
    getText("https://hn.algolia.com/api/v1/search?query=" + q + "&tags=comment&hitsPerPage=" + (limit * 2), opts),
  ]);
  const sj = JSON.parse(st), cj = JSON.parse(cm);
  const toks = String(query).toLowerCase().split(/[^a-z0-9\u4e00-\u9fa5]+/).filter(w => w.length >= 4);
  const relevant = function (text) {
    const low = String(text || "").toLowerCase();
    return !toks.length || toks.some(w => low.includes(w));
  };
  const stories = (sj.hits || []).map(h => ({
    title: h.title, url: h.url || ("https://news.ycombinator.com/item?id=" + h.objectID),
    hnUrl: "https://news.ycombinator.com/item?id=" + h.objectID, points: h.points, comments: h.num_comments,
    date: (h.created_at || "").slice(0, 10), author: h.author,
  })).filter(s => s.title && relevant(s.title));
  const fullQ = String(query).toLowerCase();
  for (const s of stories) s.fullHit = s.title.toLowerCase().includes(fullQ);
  stories.sort((a, b) => (b.fullHit ? 1 : 0) - (a.fullHit ? 1 : 0) || (b.points || 0) - (a.points || 0));
  const comments = (cj.hits || []).map(h => ({
    text: stripTags(String(h.comment_text || "")).slice(0, 400),
    story: h.story_title || null, points: h.points, date: (h.created_at || "").slice(0, 10),
    url: "https://news.ycombinator.com/item?id=" + h.objectID,
  })).filter(c => c.text.length > 60 && /[a-zA-Z]/.test(c.text) && relevant(c.text));
  for (const c of comments) c.fullHit = c.text.toLowerCase().includes(fullQ);
  comments.sort((a, b) => (b.fullHit ? 1 : 0) - (a.fullHit ? 1 : 0) || (b.points || 0) - (a.points || 0));
  return { stories: stories.slice(0, 12), comments: comments.slice(0, 12), totalStories: sj.nbHits, totalComments: cj.nbHits };
}

// ───────────────────────── 掘金（中文技术圈） ─────────────────────────
export async function juejinBuzz(query, opts) {
  opts = opts || {};
  const url = "https://api.juejin.cn/search_api/v1/search?query=" + encodeURIComponent(query) + "&id_type=2&cursor=0&limit=" + (opts.limit || 20);
  const j = JSON.parse(await getText(url, opts));
  const out = [];
  for (const d of j.data || []) {
    const a = d.result_model && d.result_model.article_info ? d.result_model.article_info : (d.article_info || null);
    if (!a) continue;
    out.push({
      title: stripTags(a.title), brief: stripTags(a.brief_content || "").slice(0, 160),
      date: a.ctime ? isoDay(Number(a.ctime) > 1e11 ? Number(a.ctime) : Number(a.ctime) * 1000) : null,
      views: a.view_count != null ? Number(a.view_count) : null,
      likes: a.digg_count != null ? Number(a.digg_count) : null,
      comments: a.comment_count != null ? Number(a.comment_count) : null,
      url: "https://juejin.cn/post/" + a.article_id,
    });
  }
  const low = String(query).toLowerCase();
  const toks = low.split(/[^a-z0-9\u4e00-\u9fa5]+/).filter(w => w.length >= 4);
  for (const o of out) {
    const hay = (o.title + " " + o.brief).toLowerCase();
    o.exact = hay.includes(low);
    o.strong = toks.length > 0 && toks.every(w => hay.includes(w));
  }
  const keep = out.filter(o => o.exact || o.strong);
  const use = keep.length ? keep : out.slice(0, 3);
  use.sort((a, b) => (b.exact ? 1 : 0) - (a.exact ? 1 : 0) || ((b.likes || 0) + (b.views || 0) / 100) - ((a.likes || 0) + (a.views || 0) / 100));
  return use.slice(0, 12);
}

// ───────────────────────── GitHub（生态接入 / 集成问题） ─────────────────────────
export async function githubBuzz(query, opts) {
  opts = opts || {};
  const url = "https://api.github.com/search/issues?q=" + encodeURIComponent('"' + query + '" in:title') + "&sort=reactions&order=desc&per_page=15";
  const j = JSON.parse(await getText(url, Object.assign({}, opts, { headers: Object.assign({ accept: "application/vnd.github+json" }, opts.headers || {}) })));
  return {
    total: j.total_count || 0,
    items: (j.items || []).map(i => ({
      title: stripTags(i.title), repo: String(i.repository_url || "").split("/").slice(-2).join("/"), url: i.html_url,
      state: i.state, isPR: !!i.pull_request, reactions: i.reactions ? i.reactions.total_count : 0,
      comments: i.comments, date: (i.created_at || "").slice(0, 10),
    })),
  };
}

// ───────────────────────── 汇总 ─────────────────────────
export function pickBest(matches) { return matches && matches.length ? matches[0] : null; }

async function gatherRaw(query, opts) {
  opts = opts || {};
  const t0 = Date.now();
  const sources = [];
  const rec = async (id, fn) => {
    try { const v = await fn(); sources.push({ id: id, ok: true, count: countOf(v) }); return v; }
    catch (e) { sources.push({ id: id, ok: false, count: 0, error: String((e && e.message) || e).slice(0, 160) }); return null; }
  };
  // 重型源（Artificial Analysis 单源 ~17s）可以用 opts.deep=false 关掉
  const deep = opts.deep !== false;
  const skip = (id, fn) => (deep ? rec(id, fn) : null);
  // X / Reddit 是全流程里最慢的两条腿（各 20~70s），跟其它源并行起；opts.x === false / opts.reddit === false 可关
  const xP = opts.x === false ? null : rec("x", () => xBuzz(query, opts.xOpts || {}));
  const rP = opts.reddit === false ? null : rec("reddit", () => redditBuzz(query, opts.redditOpts || {}));
  const [index, bl, orModels, hn, juejin, gh, aa, swb, arc, rb, vals, lma, xRes, rRes] = await Promise.all([
    rec("llm-stats:index", () => llmStatsIndex(opts)),
    rec("benchlm", () => benchlmRows(opts)),
    rec("openrouter", () => openRouterModels(opts)),
    rec("hn", () => hnBuzz(query, opts)),
    rec("juejin", () => juejinBuzz(query, opts)),
    rec("github", () => githubBuzz(query, opts)),
    skip("artificialanalysis", () => aaIndex(opts)),
    skip("swebench", () => swebenchBoards(opts)),
    skip("arcprize", () => arcScores(opts)),
    skip("swe-rebench", () => sweRebench(opts)),
    skip("vals-ai", () => valsCore(opts)),
    opts.lmarena === false ? null : skip("lmarena", () => lmarenaLookup(query, opts)),
    xP, rP,
  ]);
  const res = { query: query, generatedAt: new Date().toISOString(), sources: sources, gaps: [] };

  res.llmStatsMatches = index ? scanModels(index, query, 5) : [];
  const top = pickBest(res.llmStatsMatches);
  if (top) {
    const detail = await rec("llm-stats:detail", () => llmStatsDetail(top.model_id, opts));
    if (detail) {
      const sp = benchSplit(detail.benchmarks);
      res.detail = { model: top, meta: detail.meta, independent: sp.independent, thirdParty: sp.thirdParty, vendor: sp.vendor, verified: sp.verified, selfReported: sp.self, benchmarkCount: (detail.benchmarks || []).length };
    }
  } else {
    res.gaps.push("llm-stats 未匹配到模型（可能是新发布/名称不同）");
  }
  res.benchlmMatches = bl ? matchBench(bl.rows, query, 3) : [];
  res.openRouterMatches = orModels ? scanOR(orModels, query, 3) : [];
  const orTop = pickBest(res.openRouterMatches);
  if (orTop) res.openRouter = { id: orTop.id, price: orPrice(orTop), context: orTop.context_length || null, created: orTop.created ? isoDay(orTop.created * 1000) : null };
  // 第二批评测源：都是可以横向比的独立/第三方榜，口径与 llm-stats 的厂商自报分开列
  res.aaMatches = aa ? aaFind(aa, query, 4) : [];
  res.swebenchMatches = swb ? swebenchFind(swb, query, 2) : {};
  res.arcMatches = arc ? arcFind(arc, query, 6) : [];
  res.rebenchMatch = rb ? (rebenchFind(rb, query, 1)[0] || null) : null;
  res.valsMatches = vals ? valsFind(vals, query, 6) : [];
  res.lmarena = lma || null;
  if (deep) {
    if (!res.aaMatches.length) res.gaps.push("Artificial Analysis 榜未匹配到该模型");
    if (!Object.keys(res.swebenchMatches).length) res.gaps.push("SWE-bench 官方榜没有该模型的提交记录（该榜提交滞后，新模型常常没有）");
    if (!res.arcMatches.length) res.gaps.push("ARC Prize 榜未匹配到该模型");
    if (!res.rebenchMatch) res.gaps.push("SWE-rebench 未匹配到该模型");
    if (!res.valsMatches.length) res.gaps.push("Vals AI 榜未匹配到该模型");
    if (!res.lmarena || !res.lmarena.ok) res.gaps.push("LMArena 未匹配到该模型（官方数据集 lmarena-ai/leaderboard-dataset，每日更新；新模型可能还没上榜）");
  } else {
    res.gaps.push("已跳过 6 个来源（Artificial Analysis / SWE-bench 官方 / ARC Prize / SWE-rebench / Vals AI / LMArena）：opts.deep=false");
  }
  res.hn = hn; res.juejin = juejin; res.github = gh;
  // 中文社区口碑（B站 / CSDN / 微信公众号 / 知乎 / 小红书）—— 登录态的源缺 cookie 时按失败记录
  await cnGather(query, opts, rec, res);
  const cnNeed = ["zhihu", "xiaohongshu"].filter(function (id) {
    const s = sources.filter(function (x) { return x.id === id; })[0];
    return s && !s.ok && /未配置|登录态/.test(s.error || "");
  });
  if (cnNeed.length) res.gaps.push("中文源 " + cnNeed.join(" / ") + " 未启用（缺登录态 cookie，见 ~/.dsh-ai-research/cookies.json）");
  if (xRes) { res.x = xRes; if (!(xRes.posts || []).length) res.gaps.push("X（Twitter）没有抓到相关讨论（Brave 限流 / syndication 配额用尽时，可用 opts.xOpts.seeds 传外部搜到的推文链接）"); }
  if (rRes) { res.reddit = rRes; if (!(rRes.threads || []).length) res.gaps.push("Reddit 没有抓到相关帖子（火管窗口内该模型的帖子可能确实没有）"); }
  if (res.cn && res.cn.bilibili && !(res.cn.bilibili.videos || []).length) res.gaps.push("B站没有该模型的实测视频");
  if (res.cn && res.cn.csdn && !res.cn.csdn.length) res.gaps.push("CSDN 没有相关中文技术帖");
  if (!hn || (!hn.stories.length && !hn.comments.length)) res.gaps.push("Hacker News 无相关讨论（新模型或英文圈没热度）");
  if (!juejin || !juejin.length) res.gaps.push("掘金无中文文章（中文圈可能还没人写）");
  if (!gh || !gh.items.length) res.gaps.push("GitHub 没有标题含该模型名的 issue/PR");
  res.elapsedMs = Date.now() - t0;
  return res;
}
function countOf(v) {
  if (v == null) return 0;
  if (Array.isArray(v)) return v.length;
  if (Array.isArray(v.boards)) return v.boards.length;  // LMArena lookup：命中的榜数
  if (v.posts) return (v.posts || []).length;
  if (v.threads) return (v.threads || []).length;
  if (v.rows) return v.rows.length;
  if (v.videos) return (v.videos || []).length + (v.comments || []).length;
  if (v.stories || v.comments) return (v.stories || []).length + (v.comments || []).length;
  if (v.benchmarks) return (v.benchmarks || []).length;
  if (typeof v === "object") return Object.keys(v).length;
  return 1;
}
// 按"词"比较，不按字符串包含 —— benchlm 的单元格形如 "#7 Gemini 4 Argon Google Supported"，
// 用 norm() 包含判断会让 "GPT-5" 命中 "GPT-5.6 Sol"（"gpt5" 是 "gpt56sol…" 的子串）。
function btoks(s) {
  return String(s || "").toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5.]+/g, " ").trim().split(" ").filter(Boolean);
}
export function matchBench(rows, query, limit) {
  const q = btoks(query);
  if (!q.length) return [];
  const out = [];
  for (const r of rows || []) {
    const raw = String(r["Model"] || r["model"] || "").replace(/^#\d+\s*/, "").trim();
    const t = btoks(raw);
    let at = -1;
    for (let i = 0; i + q.length <= t.length; i++) {
      if (q.every((w, k) => t[i + k] === w)) { at = i; break; }
    }
    if (at < 0) continue;                       // 词序不连续就算不上同一个模型
    const sc = at === 0 ? 100 : Math.max(60, 88 - at * 4);
    out.push(Object.assign({ _score: sc, _name: raw.replace(/\s+(Supported|Preview|Beta)$/i, "").trim() }, r));
  }
  out.sort((a, b) => b._score - a._score || btoks(a._name).length - btoks(b._name).length);
  return out.slice(0, limit || 3);
}

// ───────────────────────── 渲染 ─────────────────────────
export function suggestQueries(name, org) {
  const base = name + (org ? "" : "");
  return [
    base + " 实测 体验 评测",
    base + " 口碑 好用吗 缺点",
    base + " benchmark independent evaluation",
    base + " 问题 吐槽 翻车",
  ];
}

function renderMarkdownRaw(r) {
  const cap = r.__cap || 5;
  const L = [];
  const d = r.detail;
  const m = d ? d.model : null;
  L.push("# " + r.query + " —— 实测 / 口碑体检");
  L.push("");
  L.push("采集时间 " + r.generatedAt.slice(0, 16).replace("T", " ") + "（UTC） · 耗时 " + r.elapsedMs + "ms");
  L.push("");
  L.push(TOC_PLACEHOLDER);
  L.push("");
  if (m) {
    L.push("## 模型档案");
    L.push("");
    L.push("*数据来源：llm-stats.com 模型页（结构化字段）*");
    L.push("");
    L.push("| 项 | 值 |");
    L.push("|---|---|");
    L.push("| 名称 | " + m.name + " |");
    L.push("| 厂商 | " + (m.organization || "-") + " |");
    L.push("| 发布 | " + (m.release_date || "-") + (m.announcement_date && m.announcement_date !== m.release_date ? "（公布 " + m.announcement_date + "）" : "") + " |");
    const orCtx = r.openRouter && r.openRouter.context ? r.openRouter.context : null;
    L.push("| 上下文 | " + (m.context ? Math.round(m.context / 1024) + "K" : (orCtx ? Math.round(orCtx / 1024) + "K（OpenRouter）" : "-")) + " |");
    if (m.input_price != null) L.push("| 价格 | $" + m.input_price + " / $" + m.output_price + " 每百万 tok |");
    else if (r.openRouter && r.openRouter.price && r.openRouter.price.text) L.push("| 价格 | " + r.openRouter.price.text + "（OpenRouter） |");
    if (m.throughput != null) L.push("| 吞吐 | " + round2(m.throughput) + " tok/s |");
    L.push("| 开源 | " + (m.is_open_source ? "是" : "否") + " |");
    L.push("");
    if (m.arena_scores && Object.keys(m.arena_scores).length) {
      L.push("- **竞技场参考分**：" + Object.entries(m.arena_scores).map(function (kv) { return kv[0] + " " + round2(kv[1]); }).join(" · ") + "（llm-stats 自家口径，未标注是 Elo 还是名次，仅作参考）");
      L.push("");
    }
    if (m.gpqa_score != null || m.swe_bench_verified_score != null || m.hle_score != null) {
      const parts = [];
      if (m.gpqa_score != null) parts.push("GPQA " + pct(m.gpqa_score) + "%");
      if (m.swe_bench_verified_score != null) parts.push("SWE-bench Verified " + pct(m.swe_bench_verified_score) + "%");
      if (m.hle_score != null) parts.push("Humanity's Last Exam " + pct(m.hle_score) + "%");
      L.push("- **三个主榜**：" + parts.join(" · "));
      L.push("");
    }
  }
  if (d) {
    L.push("## 跑分总览");
    L.push("");
    const tiers = [
      ["independent", "独立第三方复现", "llm-stats 标记 verified —— 可信度最高", 14],
      ["thirdParty", "第三方榜单 / 评测机构", "Vals AI、Surge、SWE-bench 之类；别人跑的，但 harness 各家自建，口径要看清", 14],
      ["vendor", "厂商自报（自己跑的）", "发布稿数字，看的时候打折", 12],
    ];
    for (const [key, title, hint, cap] of tiers) {
      const rows = d[key] || [];
      if (!rows.length) continue;
      L.push("### " + title + "（" + rows.length + " 项）");
      L.push("");
      L.push("*" + hint + "*");
      L.push("");
      L.push("| 基准 | 得分 | 类别 |");
      L.push("|---|---|---|");
      for (const b of rows.slice(0, cap)) L.push("| " + b.name + " | " + fmtScore(b) + " | " + (b.cats.join("/") || "-") + " |");
      L.push("");
    }
    if (!(d.verified || []).length) {
      L.push("> 提示：llm-stats 对 " + m.name + " 的 " + d.benchmarkCount + " 项跑分里没有一项被标为 independent verified —— 数字全部来自厂商自跑或第三方榜转引。");
      L.push("");
    }
  }
  L.push("## 榜单明细");
  L.push("");
  if (r.benchlmMatches && r.benchlmMatches.length) {
    const b = r.benchlmMatches[0];
    const cell = String(b["Model"] || "");
    const rank = (cell.match(/^#(\d+)/) || [])[1];
    const clean = cell.replace(/^#\d+\s*/, "").replace(/\s*Supported\s*/g, " ").replace(/\s+/g, " ").trim();
    L.push("### 第三方榜单（benchlm.ai 聚合）");
    L.push("");
    L.push((rank ? "第 " + rank + " 名 · " : "") + clean +
      [b["Score"] ? "综合分 " + b["Score"] : null, b["Elo"] && b["Elo"] !== "—" ? "Elo " + b["Elo"] : null,
       b["Tok/s"] && b["Tok/s"] !== "Not measured" ? b["Tok/s"] + " tok/s" : null,
       b["Latency"] && b["Latency"] !== "Not measured" ? "延迟 " + b["Latency"] : null].filter(Boolean).map(x => " · " + x).join(""));
    L.push("");
  }
  if (r.aaMatches && r.aaMatches.length) {
    L.push("### Artificial Analysis 独立榜（同一模型按推理档位分行）");
    L.push("");
    L.push("*该指数与 benchlm 综合分不同刻度，不可混算*");
    L.push("");
    L.push("| 档位 | 智能指数 | 输入 / 输出价 | 上下文 | 吞吐 | 首答延迟 |");
    L.push("|---|---|---|---|---|---|");
    for (const a of r.aaMatches) {
      L.push("| " + a.name + " | " + (a.intelligenceIndex != null ? round2(a.intelligenceIndex) + (a.intelligenceIndexIsEstimated ? "（估）" : "") : "-") +
        " | " + (a.price1mInputTokens != null ? "$" + a.price1mInputTokens + " / $" + a.price1mOutputTokens : "-") +
        " | " + (a.contextWindowTokens ? Math.round(a.contextWindowTokens / 1024) + "K" : "-") +
        " | " + (a.medianOutputTokensPerSecond != null ? Math.round(a.medianOutputTokensPerSecond) + " tok/s" : "-") +
        " | " + (a.medianTimeToFirstAnswerTokenSeconds != null ? round2(a.medianTimeToFirstAnswerTokenSeconds) + "s" : "-") + " |");
    }
    L.push("");
    const aaRow = aaRows(r.aaMatches[0]);
    if (aaRow.parts.length) { L.push("分项（" + r.aaMatches[0].name + "）：" + aaRow.parts.join(" · ")); L.push(""); }
  }
  if (r.lmarena) {
    const laSec = renderLmArena(r.lmarena, cap);
    if (laSec) L.push(laSec);
  }
  const sbBoards = r.swebenchMatches || {};
  const sbKeys = Object.keys(sbBoards);
  if (sbKeys.length) {
    L.push("### SWE-bench 官方榜");
    L.push("");
    L.push("*分榜列示；该榜靠社区提交、明显滞后，看日期列*");
    L.push("");
    L.push("| 分榜 | 名次 | 模型 | 解决率 | 单题成本 | 提交日 |");
    L.push("|---|---|---|---|---|---|");
    for (const bk of sbKeys) for (const h of sbBoards[bk].slice(0, 2)) {
      L.push("| " + bk + " | #" + h._rank + "/" + h._total + " | " + h.model + " | " + round2(h.resolved) + "% | " +
        (h.instanceCost != null ? "$" + round2(h.instanceCost) : "-") + " | " + (h.date || "-") + " |");
    }
    L.push("");
    L.push("（同一模型换 agent 脚手架分数会变；harness 名在报告 JSON 的 agent 字段里。）");
    L.push("");
  }
  if (r.rebenchMatch) {
    const x = r.rebenchMatch;
    L.push("### SWE-rebench 滚动榜");
    L.push("");
    L.push("*口径：任务发布日期区间 " + x.rangeFrom + " ~ " + x.rangeTo + " 的全区间窗口；站点按此值排序*");
    L.push("");
    L.push("- " + x.name + (x.developer ? "（" + x.developer + "）" : "") + " **" + x.rate + "%** · 样本 n=" + x.n +
      (x.costPerTask != null ? " · 单题成本 $" + x.costPerTask : "") + (x.release ? " · 模型发布 " + x.release : ""));
    const lg = Object.entries(x.langs || {});
    if (lg.length) L.push("- 分语言：" + lg.map(function (kv) { return kv[0] + " " + kv[1].rate + "%（n=" + kv[1].n + "）"; }).join(" · ") + " —— 各语言独立采样，条数不可相加。");
    L.push("");
  }
  if (r.arcMatches && r.arcMatches.length) {
    L.push("### ARC Prize 榜");
    L.push("");
    L.push("*抽象推理；v3 目前所有模型得分都极低*");
    L.push("");
    L.push("| 数据集 | 模型 | 得分 | 每题成本 | 发布日期 |");
    L.push("|---|---|---|---|---|");
    for (const a of r.arcMatches) L.push("| " + a.set + " | " + a.model + " | " + pct(a.score) + "% | " + (a.costPerTask != null ? "$" + round2(a.costPerTask) : "-") + " | " + (a.release || "-") + " |");
    L.push("");
  }
  if (r.valsMatches && r.valsMatches.length) {
    L.push("### Vals AI 第三方榜（" + r.valsMatches.length + " 个基准命中）");
    L.push("");
    for (const v of r.valsMatches) {
      const pairs = [];
      for (let i = 0; i < v.values.length; i++) { const col = v.columns[2 + i]; if (col) pairs.push(col + " " + v.values[i]); }
      L.push("- **" + v.slug + "**：第 " + v.rank + "/" + v.total + " 名 · " + pairs.join(" · "));
    }
    L.push("");
  }
  L.push("## 价格与在售");
  L.push("");
  if (r.openRouterMatches && r.openRouterMatches.length) {
    const o = r.openRouterMatches[0], pr = orPrice(o);
    L.push("### OpenRouter 在售");
    L.push("");
    L.push("- " + o.id + (pr.text ? " · " + pr.text : "") + (o.context_length ? " · 上下文 " + Math.round(o.context_length / 1024) + "K" : ""));
    if (r.openRouterUsage) L.push("- 真实用量：" + human(r.openRouterUsage.totalTokens) + " tokens" + (r.openRouterUsage.rank ? "（站内第 " + r.openRouterUsage.rank + " 名）" : ""));
    L.push("");
  }
  L.push("## 社区口碑");
  L.push("");
  if (r.hn && (r.hn.stories.length || r.hn.comments.length)) {
    L.push("### Hacker News 口碑（" + r.hn.totalStories + " 帖 / " + r.hn.totalComments + " 评论命中）");
    L.push("");
    for (const s of r.hn.stories.slice(0, cap)) L.push("- ▲" + (s.points || 0) + " " + s.comments + " 评 · " + s.title + "（" + s.date + "）" + s.hnUrl);
    if (r.hn.comments.length) {
      L.push("");
      L.push("代表评论：");
      for (const c of r.hn.comments.slice(0, cap)) L.push("- 「" + c.text.slice(0, 180) + "…」 " + c.url);
    }
    L.push("");
  }
  if (r.x && (r.x.posts || []).length) {
    L.push("### X（Twitter）讨论（" + (r.x.total || r.x.posts.length) + " 条命中）");
    L.push("");
    for (const p of r.x.posts.slice(0, cap)) L.push("- ♥" + (p.likes || 0) + " 🔁" + (p.retweets || 0) + " 💬" + (p.replies || 0) + " · @" + p.user + "（" + p.date + "）：" + String(p.text || "").replace(/\s+/g, " ").slice(0, 240) + " " + p.url);
    L.push("");
  }
  if (r.reddit && (r.reddit.threads || []).length) {
    L.push("### Reddit 讨论（" + (r.reddit.total || r.reddit.threads.length) + " 个相关帖）");
    L.push("");
    for (const t of r.reddit.threads.slice(0, cap)) {
      L.push("- " + (t.score || 0) + "↑ " + (t.numComments || 0) + "💬 · r/" + t.sub + "（" + t.date + "）：" + t.title + (t.weak ? "（旁及帖：话题不是它，正文/评论里带到）" : "") + " " + t.url);
      for (const c of (t.topComments || []).slice(0, 3)) L.push("  - " + (c.score || 0) + "↑ 「" + String(c.body || "").replace(/\s+/g, " ").slice(0, 220) + "…」");
    }
    L.push("");
  }
  if (r.juejin && r.juejin.length) {
    L.push("### 中文技术圈（掘金）");
    L.push("");
    for (const a of r.juejin.slice(0, cap)) L.push("- " + a.title + "（" + a.date + " · 阅读 " + (a.views || 0) + " · 赞 " + (a.likes || 0) + "）" + a.url);
    L.push("");
  }
  const cnSec = renderCnSection(r, cap);
  if (cnSec) { L.push(cnSec); L.push(""); }
  if (r.github && r.github.items.length) {
    L.push("### 生态接入 / 集成动态（GitHub issue / PR）");
    L.push("");
    L.push("- " + r.github.total + " 条标题命中");
    L.push("");
    for (const g of r.github.items.slice(0, cap)) L.push("- " + (g.isPR ? "[PR] " : "[issue] ") + g.title + " —— " + g.repo + (g.reactions ? " ▲" + g.reactions : "") + "（" + g.date + "）" + g.url);
    L.push("");
    L.push("（这类条目多数是「某工具接入该模型」的适配请求，看的是生态跟进速度，不是模型好坏。）");
    L.push("");
  }
  L.push("## 数据缺口与阅读须知");
  L.push("");
  L.push("### 数据缺口 / 失败源");
  L.push("");
  if (r.gaps.length) for (const g of r.gaps) L.push("- " + g);
  for (const s of r.sources) if (!s.ok) L.push("- 源失败 " + s.id + "：" + s.error);
  L.push("- LMArena 走 HuggingFace 官方数据集 lmarena-ai/leaderboard-dataset（parquet 直下 + 本机解码）；lmarena.ai 站点被 Cloudflare 挡，不要直连。X 与 Reddit 走 x.mjs / reddit.mjs（Brave 发现 + fxtwitter / arctic-shift）。");
  L.push("- 中文社区源：B站 / CSDN / 微信公众号（搜狗入口）匿名可抓；知乎需登录态 cookie（~/.dsh-ai-research/cookies.json）、小红书走本机无头 Chrome。");
  L.push("- 还没接进来的口碑源：HuggingFace 模型卡/讨论区（API 可达但正文未解析）、少数派。英文长篇评测另用 web_search 补。");
  L.push("- 没接进来的评测站（已探过，别重复试）：国内四榜（OpenCompass / SuperCLUE / FlagEval / AGI-Eval）只有前端壳、拿不到数据接口；tbench.ai、livebench.ai、epoch.ai 的数据在客户端取数、页面里没有；aider 榜单 2025-10 后停更。");
  L.push("");
  L.push("> 仅研究参考，不构成采购或投资建议。自报分数与第三方验证分已分列，勿混用。");
  return L.join("\n");
}
function fmtScore(b) {
  if (b.score == null) return "-";
  if (b.max === 1) return pct(b.score) + "%";
  return String(Math.round(b.score * 100) / 100);
}
function human(n) {
  if (n == null) return "-";
  if (n >= 1e12) return round2(n / 1e12) + " 万亿";
  if (n >= 1e9) return round2(n / 1e9) + " 十亿";
  if (n >= 1e6) return round2(n / 1e6) + " 百万";
  return String(n);
}
export function summarize(r) {
  const o = {
    query: r.query, generatedAt: r.generatedAt,
    model: r.detail ? r.detail.model.name : null,
    org: r.detail ? r.detail.model.organization : null,
    release: r.detail ? r.detail.model.release_date : null,
    benches: r.detail ? { total: r.detail.benchmarkCount, independent: (r.detail.independent || []).length, thirdParty: (r.detail.thirdParty || []).length, vendor: (r.detail.vendor || []).length } : null,
    arena: r.detail && r.detail.model.arena_scores ? r.detail.model.arena_scores : null,
    lmarena: r.lmarena && r.lmarena.ok ? { publishDate: r.lmarena.publishDate, boards: (r.lmarena.boards || []).reduce(function (acc, b) { acc[b.id] = { rank: b.overall.rank, total: b.overall.total, value: b.overall.value, votes: b.overall.votes }; return acc; }, {}) } : null,
    aa: (r.aaMatches || []).map(a => ({ name: a.name, idx: a.intelligenceIndex, price: [a.price1mInputTokens, a.price1mOutputTokens] })),
    swebench: Object.keys(r.swebenchMatches || {}).map(k => k + "#" + r.swebenchMatches[k][0]._rank + "(" + round2(r.swebenchMatches[k][0].resolved) + "%)"),
    rebench: r.rebenchMatch ? { name: r.rebenchMatch.name, rate: r.rebenchMatch.rate, n: r.rebenchMatch.n, range: r.rebenchMatch.rangeFrom + "~" + r.rebenchMatch.rangeTo } : null,
    arc: (r.arcMatches || []).map(a => a.set + " " + pct(a.score) + "%"),
    vals: (r.valsMatches || []).map(v => v.slug + "#" + v.rank),
    hnStories: r.hn ? r.hn.stories.length : 0,
    hnComments: r.hn ? r.hn.comments.length : 0,
    juejin: r.juejin ? r.juejin.length : 0,
    cn: cnSummary(r),
    sources: r.sources.map(s => s.id + (s.ok ? ":" + s.count : ":FAIL")),
    gaps: r.gaps,
  };
  return o;
}

// ───────────────────────── 跨模型横评（同一基准 / 同一榜单口径） ─────────────────────────
export function bkey(name) {
  return norm(String(name || "")
    .replace(/\([^)]*\)/g, " ")
    .replace(/\[[^\]]*\]/g, " ")
    .replace(/\s+/g, " "));
}
export function tierMark(t) { return t === "independent" ? "★" : t === "thirdParty" ? "†" : "‡"; }

// 给一个模型自动挑 n 个「同段位对手」：同价位 > 同期发布 > 同榜段位 > 同开源属性 > 同厂商（只作小权重）。
// 同系列变体（Gemini 4 Argon 与 Gemini 4 Argon Cyber）会被排除 —— 那是同一只模型的不同版本，不是对手。
// 交叉厂商但同价位的候选另有加分，避免推出来全是自家兄弟。
// 自动挑 n 个「同段位对手」。挑人逻辑统一在 peerModels（能力刻度优先：有 AA 用 AA 智能指数，否则用 benchlm 综合分；
// 再叠加同价位 / 同期发布 / 同开源属性 / 上下文量级 / 同厂商）。同一系列变体与同厂商重复会被排除。
export function similarModels(index, query, n, benchRows, orModels, aaRows) {
  return peerModels(index, query, n, { benchRows: benchRows || null, orModels: orModels || null, aaRows: aaRows || null });
}
function orFill(e, orModels) {
  if (!orModels || !e || !e.name) return e;
  const or = pickBest(scanOR(orModels, e.name, 1));
  if (!or) return e;
  const pr = orPrice(or);
  e.or = { id: or.id, price: pr, context: or.context_length || null };
  return e;
}

// 横评主入口。queries 给 2 个以上模型名直接比；只给 1 个时配合 opts.auto=N 自动挑 N 个同段位对手。
export async function compare(queries, opts) {
  opts = opts || {};
  const t0 = Date.now();
  const sources = [];
  const rec = async (id, fn) => {
    try { const v = await fn(); sources.push({ id: id, ok: true, count: countOf(v) }); return v; }
    catch (e) { sources.push({ id: id, ok: false, count: 0, error: String((e && e.message) || e).slice(0, 160) }); return null; }
  };
  const deep = opts.deep !== false;
  const skip = (id, fn) => (deep ? rec(id, fn) : null);
  const [index, bl, orModels, aa, vals, rb, arc] = await Promise.all([
    rec("llm-stats:index", () => llmStatsIndex(opts)),
    rec("benchlm", () => benchlmRows(opts)),
    rec("openrouter", () => openRouterModels(opts)),
    skip("artificialanalysis", () => aaIndex(opts)),
    skip("vals-ai", () => valsCore(opts)),
    skip("swe-rebench", () => sweRebench(opts)),
    skip("arcprize", () => arcScores(opts)),
  ]);
  let qs = queries.slice();
  let autoPicked = null;
  if (qs.length === 1 && opts.auto && index) {
    autoPicked = similarModels(index, qs[0], Number(opts.auto) || 2, bl ? bl.rows : null, orModels, Array.isArray(aa) ? aa : null);
    qs = qs.concat(autoPicked.map(function (a) { return a.name; }));
  }
  const res = { queries: qs.slice(), auto: autoPicked, generatedAt: new Date().toISOString(), sources: sources, gaps: [], models: [] };
  let detailOk = 0, detailFail = 0;
  for (const q of qs) {
    const matches = index ? scanModels(index, q, 3) : [];
    const top = pickBest(matches);
    const e = { query: q, found: false, name: null, org: null, release: null, near: matches.map(function (m) { return m.name; }) };
    if (top) {
      e.found = true; e.model = top; e.name = top.name; e.org = top.organization || null; e.release = top.release_date || null;
      let detail = null;
      try { detail = await llmStatsDetail(top.model_id, opts); detailOk++; } catch (err) { detailFail++; }
      const sp = benchSplit(detail && detail.benchmarks);
      e.benchmarks = (detail && detail.benchmarks) || [];
      e.tiers = { total: e.benchmarks.length, independent: sp.independent.length, thirdParty: sp.thirdParty.length, vendor: sp.vendor.length };
      e.rows = [].concat(sp.independent, sp.thirdParty, sp.vendor);
      orFill(e, orModels);
      e.benchlm = bl ? pickBest(matchBench(bl.rows, e.name, 1)) : null;
      e.aa = aa ? aaFind(aa, e.name || q, 4) : [];
      e.aaBest = e.aa.length ? e.aa.reduce(function (best, x) {
        if (x.intelligenceIndex == null) return best;
        return (!best || x.intelligenceIndex > best.intelligenceIndex) ? x : best;
      }, null) : null;
      e.vals = vals ? valsFind(vals, e.name || q, 8) : [];
      e.rebench = rb ? (rebenchFind(rb, e.name || q, 1)[0] || null) : null;
      e.arc = arc ? arcFind(arc, e.name || q, 4) : [];
      e.cn = opts.cn === false ? null : await cnBrief(e.name || q, opts);
      e.lmarena = opts.lmarena === false ? null : await lmarenaBrief(e.name || q, opts);
    } else {
      res.gaps.push("llm-stats 未匹配到「" + q + "」" + (matches.length ? "，最接近：" + matches.slice(0, 2).map(function (m) { return m.name; }).join(" / ") : "（无相近名称）"));
    }
    res.models.push(e);
  }
  sources.push({ id: "llm-stats:detail", ok: detailFail === 0, count: detailOk, error: detailFail ? detailFail + " 个模型的详情页抓取失败" : undefined });
  const cnOk = res.models.filter(function (e) { return e.cn && ((e.cn.bilibili && (e.cn.bilibili.videos || []).length) || (e.cn.csdn || []).length || (e.cn.weixin || []).length); }).length;
  sources.push({ id: "中文社区（B站/CSDN/微信）", ok: cnOk > 0, count: cnOk, error: cnOk ? undefined : "所有查询都没命中中文源" });
  const cnMiss = ["zhihu", "xiaohongshu"].filter(function (k) { return res.models.some(function (e) { return e.cn && e.cn.fail && e.cn.fail[k]; }); });
  if (cnMiss.length) res.gaps.push("中文源 " + cnMiss.join(" / ") + " 未启用（缺登录态 cookie，见 ~/.dsh-ai-research/cookies.json）");
  const laOk = res.models.filter(function (e) { return e.lmarena && e.lmarena.ok; }).length;
  sources.push({ id: "LMArena", ok: laOk > 0, count: laOk, error: laOk ? undefined : "所有查询都没命中 LMArena（数据集每日更新，新模型可能还没上榜）" });
  const laMiss = res.models.filter(function (e) { return !(e.lmarena && e.lmarena.ok); }).map(function (e) { return e.name || e.query; });
  if (laMiss.length) res.gaps.push("LMArena 未匹配到：" + laMiss.join(" / "));

  // Vals AI 的表是同一 harness / 同一批次跑的 → 同 slug 下可以直接对齐名次与分数
  const vBySlug = new Map();
  for (const e of res.models) for (const v of (e.vals || [])) {
    let g = vBySlug.get(v.slug);
    if (!g) { g = { slug: v.slug, columns: v.columns, by: {} }; vBySlug.set(v.slug, g); }
    const sc = valsScoreOf(v);
    // 同一模型在一张表里可能出现多行（不同 harness），保留名次更靠前的那行
    const prev = g.by[e.name];
    if (!prev || (v.rank || 999) < (prev.rank || 999)) g.by[e.name] = { rank: v.rank, total: v.total, score: sc.value, col: sc.col, extra: sc.extra, model: v.model };
  }
  res.valsAll = Array.from(vBySlug.values());
  res.valsShared = res.valsAll.filter(function (x) { return Object.keys(x.by).length >= 2; })
    .sort(function (a, b) { return Object.keys(b.by).length - Object.keys(a.by).length || a.slug.localeCompare(b.slug); });

  const cells = new Map();
  for (const e of res.models) {
    if (!e.found || !e.rows) continue;
    for (const b of e.rows) {
      const k = bkey(b.name);
      if (!k) continue;
      let c = cells.get(k);
      if (!c) { c = { key: k, name: b.name, cats: b.cats || [], by: {} }; cells.set(k, c); }
      const prev = c.by[e.name];
      if (!prev || (b.score != null && (prev.score == null || b.score > prev.score))) c.by[e.name] = { score: b.score, max: b.max, tier: b.tier, source: b.source || null };
    }
  }
  const nFound = res.models.filter(function (e) { return e.found; }).length;
  const sharedAll = [];
  for (const c of cells.values()) {
    const n = Object.keys(c.by).length;
    if (n >= 2) { c.n = n; c.hasThird = Object.keys(c.by).some(function (k) { return c.by[k].tier !== "vendor"; }); sharedAll.push(c); }
  }
  sharedAll.sort(function (a, b) { return b.n - a.n || (b.hasThird ? 1 : 0) - (a.hasThird ? 1 : 0) || a.name.localeCompare(b.name); });
  res.shared = sharedAll;
  res.sharedStats = { all: cells.size, shared: sharedAll.length, models: nFound };
  if (!sharedAll.length && nFound >= 2) res.gaps.push("这几个模型在 llm-stats 上没有重合的基准（各测各的），只能用 benchlm 同尺度榜与统一字段比");
  res.arenaCoverage = res.models.filter(function (e) { return e.found && e.model.arena_scores && Object.keys(e.model.arena_scores).length; }).length;
  res.elapsedMs = Date.now() - t0;
  return res;
}

export function renderCompare(r) {
  const L = [];
  const ms = r.models;
  const names = ms.map(e => e.name || e.query);
  L.push("# 横评：" + names.join(" vs "));
  L.push("");
  L.push("采集时间 " + r.generatedAt.slice(0, 16).replace("T", " ") + "（UTC） · 耗时 " + r.elapsedMs + "ms · 匹配到 " + r.sharedStats.models + " / " + r.queries.length + " 个模型");
  L.push("");
  L.push(TOC_PLACEHOLDER);
  L.push("");
  if (r.auto && r.auto.length) {
    L.push("**对手由 --auto 自动挑出**（同系列变体已排除）：" + r.auto.map(function (a) { return a.name + "（" + (a.why || []).join("、") + "）"; }).join("；"));
    L.push("");
    L.push("> 自动挑的是「段位相近」，不是「最该比的」 —— 想指定就显式写 --vs \"A,B,C\"。");
    L.push("");
  }
  L.push("## 同尺度榜（benchlm.ai —— 同一份榜单、同一套算法，可横向比）");
  L.push("");
  L.push("| 模型 | 名次 | 综合分 | Elo | 价格 / 百万tok | 吞吐 |");
  L.push("|---|---|---|---|---|---|");
  for (const e of ms) {
    if (!e.found) { L.push("| " + e.query + " | 未匹配 | - | - | - | - |"); continue; }
    const b = e.benchlm;
    const price = e.model.input_price != null ? "$" + e.model.input_price + " / $" + e.model.output_price : (e.or && e.or.price ? "$" + e.or.price.inPerM + " / $" + e.or.price.outPerM : "-");
    if (!b) { L.push("| " + e.name + " | 未上榜 | - | - | " + price + " | - |"); continue; }
    const rank = String(b["Model"] || "").match(/#(\d+)/);
    L.push("| " + e.name + " | " + (rank ? "#" + rank[1] : "-") + " | " + (b["Score"] || "-") + " | " + (b["Elo"] || "-") + " | " + price + " | " + (b["Tok/s"] || "-") + " |");
  }
  L.push("");
  const laCmp = renderLmArenaCompare(ms, { n: 2 });
  if (laCmp) L.push(laCmp);
  L.push("## 独立榜对照（Artificial Analysis / Vals AI / SWE-rebench / ARC Prize）");
  L.push("");
  const anyNew = ms.some(e => e.aaBest) || ms.some(e => e.rebench) || ms.some(e => e.arc && e.arc.length) || (r.valsShared && r.valsShared.length);
  if (!anyNew) {
    L.push("本次没有模型命中这四个榜（它们只收有公开提交或收录的模型）。");
    L.push("");
  } else {
    if (ms.some(e => e.aaBest)) {
      L.push("### Artificial Analysis 智能指数");
      L.push("");
      L.push("*自建综合指数，与 benchlm 综合分不同刻度，不可混算；同模型多档位时取最高档*");
      L.push("");
      L.push("| 模型 | 档位 | 智能指数 | 输入 / 输出价 | 上下文 |");
      L.push("|---|---|---|---|---|");
      for (const e of ms) {
        const a = e.aaBest;
        if (!a) { L.push("| " + (e.name || e.query) + " | 未收录 | - | - | - |"); continue; }
        L.push("| " + e.name + " | " + a.name + " | " + (a.intelligenceIndex != null ? round2(a.intelligenceIndex) + (a.intelligenceIndexIsEstimated ? "（估）" : "") : "-") +
          " | " + (a.price1mInputTokens != null ? "$" + a.price1mInputTokens + " / $" + a.price1mOutputTokens : "-") +
          " | " + (a.contextWindowTokens ? Math.round(a.contextWindowTokens / 1024) + "K" : "-") + " |");
      }
      L.push("");
    }
    if (r.valsShared && r.valsShared.length) {
      L.push("### Vals AI 同榜对齐");
      L.push("");
      L.push("*同一份 harness、同一批次 —— 下表是各模型在同一张表里的实际名次与分数*");
      L.push("");
      const fn = ms.filter(e => e.found).map(e => e.name);
      L.push("| 基准 | " + fn.join(" | ") + " |");
      L.push("|---|" + fn.map(() => "---").join("|") + "|");
      for (const g of r.valsShared.slice(0, 14)) {
        const cs = fn.map(function (nm) {
          const v = g.by[nm];
          return v ? "#" + v.rank + "/" + v.total + " " + (v.score != null ? v.score : "-") : "—";
        });
        L.push("| " + g.slug + " | " + cs.join(" | ") + " |");
      }
      L.push("");
      const solo = (r.valsAll || []).filter(function (x) { return Object.keys(x.by).length === 1; }).map(function (x) { return x.slug; });
      if (solo.length) L.push("另有只被单个模型命中的 Vals 榜（无法对齐）：" + solo.join(" · "));
      L.push("");
    }
    if (ms.some(e => e.rebench)) {
      L.push("### SWE-rebench 滚动榜");
      L.push("");
      L.push("*口径：任务发布日期全区间窗口；各语言独立采样、条数不可相加*");
      L.push("");
      L.push("| 模型 | 全区间解决率 | 样本 n | 任务区间 | 分语言 |");
      L.push("|---|---|---|---|---|");
      for (const e of ms) {
        const x = e.rebench;
        if (!x) { L.push("| " + (e.name || e.query) + " | 未收录 | - | - | - |"); continue; }
        const lg = Object.entries(x.langs || {}).map(function (kv) { return kv[0] + " " + kv[1].rate + "%"; }).join(" · ");
        L.push("| " + e.name + " | " + x.rate + "% | " + x.n + " | " + x.rangeFrom + " ~ " + x.rangeTo + " | " + (lg || "-") + " |");
      }
      L.push("");
    }
    if (ms.some(e => e.arc && e.arc.length)) {
      const sets = [];
      for (const e of ms) for (const a of (e.arc || [])) if (sets.indexOf(a.set) < 0) sets.push(a.set);
      const fn = ms.filter(e => e.found).map(e => e.name);
      L.push("### ARC Prize 榜");
      L.push("");
      L.push("*抽象推理；同一 dataset 下按模型取最高分档*");
      L.push("");
      L.push("| 数据集 | " + fn.join(" | ") + " |");
      L.push("|---|" + fn.map(() => "---").join("|") + "|");
      for (const st of sets) {
        const cs = fn.map(function (nm) {
          const rows = ms.filter(function (e) { return (e.name || e.query) === nm; })[0].arc.filter(function (a) { return a.set === st; });
          if (!rows.length) return "—";
          const best = rows.reduce(function (p, c) { return (c.score || 0) > (p.score || 0) ? c : p; });
          return pct(best.score) + "%" + (best.costPerTask != null ? " / $" + round2(best.costPerTask) : "");
        });
        L.push("| " + st + " | " + cs.join(" | ") + " |");
      }
      L.push("");
    }
  }
  L.push("## 统一字段（llm-stats 首页同一份聚合，缺失用 OpenRouter 补）");
  L.push("");
  L.push("| 模型 | 厂商 | 发布 | 上下文 | 价格/百万tok | GPQA | SWE-bench | HLE | chat-arena |");
  L.push("|---|---|---|---|---|---|---|---|---|");
  for (const e of ms) {
    if (!e.found) { L.push("| " + e.query + " | - | - | - | - | - | - | - | - |"); continue; }
    const m = e.model;
    const ctx = m.context != null ? human(m.context) : (e.or && e.or.context ? human(e.or.context) + " *" : "-");
    const pr = m.input_price != null ? "$" + m.input_price + " / $" + m.output_price : (e.or && e.or.price ? "$" + e.or.price.inPerM + " / $" + e.or.price.outPerM + " *" : "-");
    const ar = m.arena_scores && Object.keys(m.arena_scores).length ? Object.entries(m.arena_scores).map(kv => kv[0] + " " + round2(kv[1])).join(" · ") : "-";
    L.push("| " + e.name + " | " + (e.org || "-") + " | " + (e.release || "-") + " | " + ctx + " | " + pr + " | " + (m.gpqa_score != null ? pct(m.gpqa_score) + "%" : "-") + " | " + (m.swe_bench_verified_score != null ? pct(m.swe_bench_verified_score) + "%" : "-") + " | " + (m.hle_score != null ? pct(m.hle_score) + "%" : "-") + " | " + ar + " |");
  }
  L.push("");
  if (r.shared.length) {
    L.push("## 重合基准（≥2 个模型被测过的同一项）");
    L.push("");
    L.push("档位标记：★ 独立验证 · † 第三方榜转引 · ‡ 厂商自报");
    L.push("");
    L.push("| 基准 | " + ms.filter(e => e.found).map(e => e.name).join(" | ") + " | 档位 |");
    L.push("|---|" + ms.filter(e => e.found).map(() => "---").join("|") + "|---|");
    for (const c of r.shared.slice(0, 40)) {
      const vals = ms.filter(e => e.found).map(e => {
        const v = c.by[e.name];
        return v ? fmtScore(v) + " " + tierMark(v.tier) : "—";
      });
      L.push("| " + c.name + " | " + vals.join(" | ") + " | " + (c.hasThird ? "含第三方" : "全厂商自报") + " |");
    }
    L.push("");
    L.push("共 " + r.sharedStats.all + " 项基准里有 " + r.sharedStats.shared + " 项被至少两个模型测过（上表最多列 40 项，按重合模型数排序）。");
  } else {
    L.push("## 重合基准");
    L.push("");
    L.push("没有重合项 —— 这些模型在 llm-stats 上各测各的，无法逐项对齐；以第 1、2、3 节为准。");
  }
  L.push("");
  L.push("## 各模型跑分构成");
  L.push("");
  L.push("| 模型 | 基准总数 | ★ 独立验证 | † 第三方榜 | ‡ 厂商自报 |");
  L.push("|---|---|---|---|---|");
  for (const e of ms) {
    const t = e.tiers || { total: 0, independent: 0, thirdParty: 0, vendor: 0 };
    L.push("| " + (e.name || e.query) + " | " + t.total + " | " + t.independent + " | " + t.thirdParty + " | " + t.vendor + " |");
  }
  L.push("");
  const cnCmp = renderCnCompare(ms);
  if (cnCmp) { L.push(cnCmp); }
  L.push("## 数据缺口");
  L.push("");
  if (r.gaps.length) for (const g of r.gaps) L.push("- " + g);
  else L.push("- 无（所有源本次均可达）");
  for (const s of r.sources) if (!s.ok) L.push("- 源失败 " + s.id + "：" + (s.error || ""));
  L.push("");
  L.push("## 阅读须知");
  L.push("");
  if (r.arenaCoverage === 0) L.push("- 本次模型均无 llm-stats 竞技场分（该字段只覆盖部分模型）。");
  else if (r.arenaCoverage < r.sharedStats.models) L.push("- 竞技场分只覆盖 " + r.arenaCoverage + " / " + r.sharedStats.models + " 个模型，不能直接当横评轴。");
  L.push("- ★ 独立验证项在本次横评里为 0：llm-stats 的 verified 字段实测恒为 false，能对齐的只有第三方榜转引与厂商自报。");
  L.push("- 带 * 的字段来自 OpenRouter（口径与 llm-stats 不同）；两个来源的价格都可能有地区差异。");
  L.push("- 同名基准可能是不同 harness / 不同日期跑的，跨模型只能当方向参考，不能当精确名次。");
  L.push("- benchlm 的综合分与 Elo 是同一套算法的单一尺度，是本次最可比的一栏；llm-stats 的 arena_scores 口径未标注。");
  L.push("- Artificial Analysis 的智能指数是它**自建**的刻度（几十个模型的相对值），与 benchlm 综合分、llm-stats 分数都不同源，只能各自内部比。");
  L.push("- LMArena 的 Elo（~1500 制）与 benchlm 的 Elo 也不是一套算法，只是都叫 Elo：跨表只能看名次，不能比分数。");
  L.push("- Vals AI 的表是同一 harness 跑出来的，同表内名次可比；SWE-rebench / ARC 的分是按各自任务集算的，跨表不可比。");
  L.push("- LMArena 是人类两两盲投出来的 Elo（同一批票、同一套算法）：同榜内可比，**置信区间重叠 = 不能判定谁强**；原始榜含回答风格加成，风格控制榜见单模型报告。");
  L.push("- 还没接进来的口碑源：HuggingFace 模型卡 / 讨论区、少数派 —— 主观口碑需另用 web_search 补。");
  L.push("");
  L.push("> 仅研究参考，不构成采购或投资建议。自报分数与第三方验证分已分列，勿混用。");
  return finalizeDoc(L.join("\n"), { skip: ["目录"] });
}

export function summarizeCompare(r) {
  return {
    queries: r.queries, auto: r.auto || null, generatedAt: r.generatedAt, matched: r.sharedStats.models,
    models: r.models.map(e => ({ query: e.query, name: e.name, found: e.found, org: e.org, release: e.release, tiers: e.tiers || null, benchlm: e.benchlm ? { rank: (String(e.benchlm["Model"] || "").match(/#(\d+)/) || [])[1] || null, score: e.benchlm["Score"], elo: e.benchlm["Elo"] } : null })),
    aa: r.models.filter(e => e.aaBest).map(e => ({ name: e.name, variant: e.aaBest.name, idx: e.aaBest.intelligenceIndex })),
    rebench: r.models.filter(e => e.rebench).map(e => ({ name: e.name, rate: e.rebench.rate, n: e.rebench.n })),
    valsShared: (r.valsShared || []).map(g => ({ slug: g.slug, models: Object.keys(g.by) })),
    shared: { all: r.sharedStats.all, shared: r.sharedStats.shared, top: r.shared.slice(0, 12).map(c => ({ name: c.name, by: Object.keys(c.by).length, hasThird: c.hasThird })) },
    sources: r.sources.map(s => s.id + (s.ok ? ":" + s.count : ":FAIL")),
    gaps: r.gaps, elapsedMs: r.elapsedMs,
  };
}

// ═══════════════════ 追加数据源（2026-10-15 实测接入）═══════════════════
// ① Artificial Analysis —— 自建综合智能指数 + 十几个基准 + 价格/吞吐/延迟（约 700 个模型）
// ② SWE-bench 官方站   —— verified / lite / multilingual / bash-only 等分榜的 resolved% 与成本
// ③ ARC Prize          —— ARC-AGI-1 / 2 / 3 分数与每题成本
// ④ SWE-rebench        —— 发布后新任务的累计解出率（滚动窗口）
// ⑤ Vals AI            —— 50 个独立基准的 HTML 表（Accuracy / 成本 / 时长）

const AA_URL = "https://artificialanalysis.ai/leaderboards/models";
const SWEBENCH_URL = "https://www.swebench.com/";
const REBENCH_URL = "https://swe-rebench.com/";
const VALS_LIST_URL = "https://www.vals.ai/benchmarks";
// 默认取这几个 Vals 榜（覆盖面 + 体量平衡）：综合指数 / 终端 / 编码 / 数学 / 知识 / CUA / 安全
export const VALS_CORE = ["vals_index", "terminal-bench-4", "swebench", "lcb", "aime", "gpqa", "mmlu_pro", "vibe-code"];

// 从文本里找出包含 marker 的第一个 JSON 数组（向后找最近的 "[{"，逐个试着配平解析）
function findArrayIn(text, marker) {
  const idx = text.indexOf(marker);
  if (idx < 0) return null;
  let from = idx, tries = 0;
  while (tries++ < 60) {
    const p = text.lastIndexOf("[{", from);
    if (p < 0) return null;
    const s = sliceBalanced(text, p);
    if (s) { try { const a = JSON.parse(s); if (Array.isArray(a) && a.length) return a; } catch (e) {} }
    from = p - 1;
  }
  return null;
}
export function sliceBalanced(text, start) {
  const open = text[start];
  if (open !== "[" && open !== "{") return null;
  const close = open === "[" ? "]" : "}";
  let depth = 0, inStr = false, esc = false;
  for (let i = start; i < text.length; i++) {
    const c = text[i];
    if (inStr) { if (esc) esc = false; else if (c === "\\") esc = true; else if (c === '"') inStr = false; continue; }
    if (c === '"') { inStr = true; continue; }
    if (c === open) depth++;
    else if (c === close) { depth--; if (depth === 0) return text.slice(start, i + 1); }
  }
  return null;
}
// 词序匹配（与 matchBench 同一套规则）：候选名里必须连续出现 query 的全部词
export function wordHit(name, query) {
  const q = btoks(query);
  if (!q.length) return 0;
  const t = btoks(String(name || "").replace(/\([^)]*\)/g, " "));
  if (!t.length) return 0;
  if (t.join(" ") === q.join(" ")) return 100;
  for (let i = 0; i + q.length <= t.length; i++) {
    if (q.every(function (w, k) { return t[i + k] === w; })) return i === 0 ? 88 : 76;
  }
  const set = new Set(t);
  if (q.every(function (w) { return set.has(w); })) return 60;
  return 0;
}
// 各榜命名不统一（SWE-rebench 叫 "Fable 5 [high]"、ARC 叫 "Claude Opus 4.6 (120K, High)"，
// 而查询通常是 llm-stats 的名字 "Claude Fable 5"）：严格匹配失败时去掉开头的厂商前缀再试，
// 且给 0.9 折扣，保证严格命中永远排在松匹配之前。只对已知厂商词生效，避免 "GPT-5" 被剥成 "5"。
const VENDOR_WORDS = new Set(["claude", "anthropic", "google", "gemini", "openai", "deepseek", "mistral", "qwen", "alibaba", "moonshot", "kimi", "xai", "grok", "microsoft", "nvidia", "zhipu", "glm", "minimax", "moonshotai"]);
export function looseMatches(name, query) {
  const full = wordHit(name, query);
  if (full > 0) return full;
  const toks = String(query == null ? "" : query).trim().split(/\s+/);
  if (toks.length > 1 && VENDOR_WORDS.has(toks[0].toLowerCase())) return wordHit(name, toks.slice(1).join(" ")) * 0.9;
  return 0;
}
function frac(x) { return x == null ? null : (x <= 1.0001 ? Math.round(x * 1000) / 10 : Math.round(x * 100) / 100); }

// ─────────── ① Artificial Analysis ───────────
export async function aaIndex(opts) {
  const html = await getText(AA_URL, opts);
  const txt = nextRSC(html);
  const arr = findArrayIn(txt, '"intelligenceIndex"');
  if (!arr) throw new Error("Artificial Analysis 模型数组未找到（页面结构可能变了）");
  return arr;
}
export const AA_BENCH = [
  ["hle", "Humanity's Last Exam"],
  ["gpqa", "GPQA Diamond"],
  ["scicode", "SciCode"],
  ["ifbench", "IFBench 指令跟随"],
  ["critpt", "CritPt 物理"],
  ["apexAgents", "APEX-Agents"],
  ["itbenchSre", "ITBench-SRE"],
  ["mmmuPro", "MMMU-Pro"],
  ["tau2", "τ²-bench 工具"],
  ["tauBanking", "τ²-bench Banking"],
  ["terminalbenchHard", "Terminal-Bench Hard"],
  ["terminalBench21", "Terminal-Bench 2.1"],
  ["terminalBench40", "Terminal-Bench 4.0"],
  ["gdpvalNormalized", "GDPval"],
  ["analystAgent", "Analyst Agent"],
  ["lcr", "LCR 长上下文"],
];
export function aaFind(index, query, limit) {
  const out = [];
  for (const o of index || []) {
    const sc = Math.max(looseMatches(o.name, query), looseMatches(o.shortName, query) - 1);
    if (sc > 0) out.push(Object.assign({ _score: sc }, o));
  }
  out.sort(function (a, b) { return b._score - a._score || (b.intelligenceIndex || 0) - (a.intelligenceIndex || 0); });
  return out.slice(0, limit || 3);
}
export function aaRows(a) {
  const rows = [];
  rows.push(["综合智能指数", (a.intelligenceIndex == null ? "-" : round2(a.intelligenceIndex)) + (a.intelligenceIndexIsEstimated ? "（估计）" : "")]);
  if (a.price1mInputTokens != null) rows.push(["价格", "$" + a.price1mInputTokens + " / $" + a.price1mOutputTokens + " 每百万 tok"]);
  if (a.contextWindowTokens != null) rows.push(["上下文", Math.round(a.contextWindowTokens / 1024) + "K"]);
  if (a.medianOutputTokensPerSecond != null) rows.push(["输出速度", round2(a.medianOutputTokensPerSecond) + " tok/s"]);
  if (a.medianTimeToFirstAnswerTokenSeconds != null) rows.push(["首答延迟", round2(a.medianTimeToFirstAnswerTokenSeconds) + "s"]);
  rows.push(["推理/开源", (a.isReasoning ? "推理模型" : "非推理") + " · " + (a.isOpenWeights ? "开放权重" : "闭源")]);
  const parts = [];
  for (const [k, label] of AA_BENCH) {
    const v = a[k];
    if (v == null) continue;
    parts.push(label + " " + frac(v) + (frac(v) != null && Math.abs(frac(v) - Math.round(frac(v))) < 2 || v > 1 ? "分" : "%"));
  }
  return { rows: rows, parts: parts };
}

// ─────────── ② SWE-bench 官方站 ───────────
const SWE_BOARDS = ["verified", "lite", "multilingual", "multimodal", "bash-only", "full"];
export async function swebenchBoards(opts) {
  const html = await getText(SWEBENCH_URL, opts);
  const entries = [], seen = new Set();
  const re = /\{\s*"agent":/g;
  let m;
  while ((m = re.exec(html))) {
    const s = sliceBalanced(html, m.index);
    if (!s) continue;
    let o = null;
    try { o = JSON.parse(s); } catch (e) { continue; }
    if (!o || !o.model_display) continue;
    const key = o.folder || (o.model_display + "|" + o.date);
    if (seen.has(key)) continue;
    seen.add(key);
    entries.push(o);
  }
  if (!entries.length) throw new Error("SWE-bench 条目未解析出来（页面结构可能变了）");
  const boards = {};
  for (const e of entries) {
    const board = sweBoardOf(e);
    (boards[board] = boards[board] || []).push({
      model: e.model_display, org: e.model_org, agent: e.agent,
      resolved: e.resolved, cost: e.cost, instanceCost: e.instance_cost, apiCalls: e.instance_calls,
      date: e.date || null, releaseDate: e.model_release_date || null, folder: e.folder || null,
    });
  }
  for (const k of Object.keys(boards)) boards[k].sort(function (a, b) { return (b.resolved || 0) - (a.resolved || 0); });
  return boards;
}
function sweBoardOf(e) {
  const parts = String(e.logs || "").split("/").filter(Boolean);
  const seg = parts.length > 2 ? parts[2] : "";
  if (SWE_BOARDS.indexOf(seg) >= 0) return seg;
  const f = String(e.folder || "");
  if (/multimodal/i.test(f)) return "multimodal";
  if (/multilingual/i.test(f)) return "multilingual";
  if (/lite/i.test(f)) return "lite";
  if (/verified/i.test(f)) return "verified";
  return "full";
}
export function swebenchFind(boards, query, limit) {
  const out = {};
  for (const board of Object.keys(boards || {})) {
    const rows = boards[board];
    const hits = [];
    for (let i = 0; i < rows.length; i++) {
      const sc = looseMatches(rows[i].model, query);
      if (sc > 0) hits.push(Object.assign({ _score: sc, _rank: i + 1, _board: board, _total: rows.length }, rows[i]));
    }
    hits.sort(function (a, b) { return b._score - a._score || a._rank - b._rank; });
    if (hits.length) out[board] = hits.slice(0, limit || 2);
  }
  return out;
}

// ─────────── ③ ARC Prize ───────────
export async function arcScores(opts) {
  const rows = [];
  for (const v of ["v1", "v2", "v3"]) {
    let j = null;
    try { j = JSON.parse(await getText("https://arcprize.org/media/data/leaderboard/" + v + ".json", opts)); } catch (e) { continue; }
    for (const e of (j.evaluations || [])) {
      rows.push({
        set: e.datasetDisplayName || v, model: e.modelDisplayName, modelId: e.modelId,
        provider: e.providerDisplayName || e.providerId || null,
        score: e.score, costPerTask: e.costPerTask != null ? e.costPerTask : e.cost,
        release: e.modelReleaseDate ? String(e.modelReleaseDate).slice(0, 10) : null,
        type: e.modelType || null, listed: e.display !== false,
      });
    }
  }
  if (!rows.length) throw new Error("ARC Prize 榜单 JSON 没取到");
  return rows;
}
export function arcFind(rows, query, limit) {
  const out = [];
  for (const r of rows || []) {
    const sc = looseMatches(r.model, query);
    if (sc > 0) out.push(Object.assign({ _score: sc }, r));
  }
  out.sort(function (a, b) { return b._score - a._score || (b.score || 0) - (a.score || 0) || String(a.set).localeCompare(String(b.set)); });
  return out.slice(0, limit || 5);
}

// ─────────── ④ SWE-rebench ───────────
export const REBENCH_LANGS = ["go", "java", "python", "rust", "typescript"];
export async function sweRebench(opts) {
  const html = await getText(REBENCH_URL, opts);
  const txt = nextRSC(html);
  // RSC 里 items 数组是「副本流」：整段文本里同一对象会重复出现（语言维度展开），
  // 必须按括号配平切出数组后 JSON.parse（parse 会自动按键去重），不能按 "{"modelId":" 切段。
  const at = txt.indexOf('"items":[{"modelId"');
  if (at < 0) throw new Error("SWE-rebench items 数组未找到（页面结构可能变了）");
  const items = JSON.parse(sliceBalanced(txt, txt.indexOf("[", at + 8)));
  const rows = [];
  for (const it of items) {
    const { from, to } = it.taskRangeTimestamp || {};
    const all = (it.rangeStats && it.rangeStats.all) || {};
    const full = all[from + ":" + to] || null;
    const langs = {};
    for (const lg of REBENCH_LANGS) {
      const v = (it.rangeStats && it.rangeStats[lg] && it.rangeStats[lg][from + ":" + to]) || null;
      if (v && v.passN > 0) langs[lg] = { rate: round2(v.resolvedRate), n: Math.round(v.passN) };
    }
    if (!it.modelName || !full || !(full.passN > 0)) continue;
    rows.push({
      name: it.modelName, id: it.modelId,
      developer: (it.meta && it.meta.developer) || null,
      agent: it.agentVersion || null,
      release: (it.release && it.release.date) || null,
      rangeFrom: isoDay(new Date(from).toISOString()), rangeTo: isoDay(new Date(to).toISOString()),
      rate: round2(full.resolvedRate), n: Math.round(full.passN),
      costPerTask: full.instanceCosts ? round2(full.instanceCosts) : null,
      langs: langs,
      boundaries: new Set(Object.keys(all).flatMap(function (k) { return k.split(":"); })).size,
    });
  }
  if (!rows.length) throw new Error("SWE-rebench 模型条目没解析出来");
  // 站点首页即按「全区间 resolvedRate」降序（实测确认），这里保持一致
  rows.sort(function (a, b) { return (b.rate || 0) - (a.rate || 0); });
  return rows;
}
export function rebenchFind(rows, query, limit) {
  const out = [];
  for (const r of rows || []) {
    const sc = looseMatches(r.name, query) || looseMatches(String(r.name).replace(/[-_]/g, " "), query);
    if (sc > 0) out.push(Object.assign({ _score: sc }, r));
  }
  out.sort(function (a, b) { return b._score - a._score || (b.rate || 0) - (a.rate || 0); });
  return out.slice(0, limit || 2);
}

// ─────────── ⑤ Vals AI ───────────
export async function valsBenchmarkList(opts) {
  const html = await getText(VALS_LIST_URL, opts);
  const set = new Set();
  for (const m of html.matchAll(/\/benchmarks\/([a-z0-9_\-]+)/g)) set.add(m[1]);
  return Array.from(set);
}
export async function valsTable(slug, opts) {
  const html = await getText(VALS_LIST_URL.replace("/benchmarks", "/benchmarks/" + slug), opts);
  return parseValsTable(html, slug);
}
export function parseValsTable(html, slug) {
  const i = html.indexOf("<table");
  if (i < 0) return null;
  const end = html.indexOf("</table>", i);
  const seg = html.slice(i, end < 0 ? html.length : end);
  const columns = [];
  const headRow = seg.match(/<tr>[\s\S]*?<\/tr>/);
  if (headRow) for (const m of headRow[0].matchAll(/<th[^>]*>([\s\S]*?)<\/th>/g)) columns.push(stripTags(m[1]));
  const rows = [];
  for (const tr of seg.matchAll(/<tr>([\s\S]*?)<\/tr>/g)) {
    const cells = [];
    for (const c of tr[1].matchAll(/<(td|th)[^>]*>([\s\S]*?)<\/\1>/g)) {
      cells.push({ text: stripTags(c[2]), href: (c[2].match(/href="([^"]+)"/) || [])[1] || null });
    }
    if (cells.length < 2) continue;
    if (/^rank$/i.test(cells[0].text)) continue;
    rows.push({
      rank: parseInt(cells[0].text, 10) || null,
      model: cells[1].text, modelUrl: cells[1].href,
      values: cells.slice(2).map(function (c) { return c.text; }),
    });
  }
  return { slug: slug, columns: columns, rows: rows };
}
export async function valsCore(opts) {
  const slugs = (opts && opts.vals) || VALS_CORE;
  const out = {};
  const got = await Promise.all(slugs.map(function (s) {
    return valsTable(s, opts).then(function (t) { return [s, t]; }).catch(function () { return null; });
  }));
  for (const g of got) if (g && g[1]) out[g[0]] = g[1];
  if (!Object.keys(out).length) throw new Error("Vals AI 榜单表格没取到");
  return out;
}
export function valsFind(tables, query, limit) {
  const out = [];
  for (const slug of Object.keys(tables || {})) {
    const t = tables[slug];
    for (const r of t.rows) {
      const sc = looseMatches(r.model, query);
      if (sc > 0) out.push({ slug: slug, score: sc, rank: r.rank, total: t.rows.length, model: r.model, columns: t.columns, values: r.values });
    }
  }
  out.sort(function (a, b) { return b.score - a.score || a.slug.localeCompare(b.slug); });
  return out.slice(0, limit || 8);
}


// Vals 表里「分数列」不是固定位置（Accuracy / Score / Pass Rate 各不相同），按列名找
export function valsScoreOf(row) {
  const cols = row.columns || [], vals = row.values || [];
  let idx = -1;
  for (let i = 0; i < vals.length; i++) {
    const c = String(cols[2 + i] || "");
    if (idx < 0 && /score|accuracy|pass ?rate|resolved|success/i.test(c)) idx = i;
  }
  const extra = [];
  for (let i = 0; i < vals.length; i++) if (i !== idx) extra.push((cols[2 + i] || "?") + " " + vals[i]);
  return { col: idx >= 0 ? cols[2 + idx] : null, value: idx >= 0 ? vals[idx] : null, extra: extra };
}

// ===== 2026-10-15 追加：每源限流 + 解读层 + 自动同类横评 =====
const DEF_CAP = 5;
// 每个源最多留 N 条，避免「把帖子堆在那里」。renderMarkdown 会按 r.__cap 渲染。
export function capReport(r, n) {
  const cap = n || DEF_CAP;
  if (!r) return r;
  r.__cap = cap;
  if (r.hn) { r.hn.stories = (r.hn.stories || []).slice(0, cap); r.hn.comments = (r.hn.comments || []).slice(0, cap); }
  r.juejin = (r.juejin || []).slice(0, cap);
  if (r.github) r.github.items = (r.github.items || []).slice(0, cap);
  if (r.cn) {
    for (const k of ['csdn', 'weixin', 'zhihu', 'xiaohongshu']) r.cn[k] = (Array.isArray(r.cn[k]) ? r.cn[k] : []).slice(0, cap);
    if (r.cn.bilibili) { r.cn.bilibili.videos = (r.cn.bilibili.videos || []).slice(0, cap); r.cn.bilibili.comments = (r.cn.bilibili.comments || []).slice(0, cap); }
  }
  if (r.x) r.x.posts = (r.x.posts || []).slice(0, cap);
  if (r.reddit) r.reddit.threads = (r.reddit.threads || []).slice(0, cap);
  r.openRouterMatches = (r.openRouterMatches || []).slice(0, 3);
  r.benchlmMatches = (r.benchlmMatches || []).slice(0, 3);
  return r;
}
// 单模型入口（带限流）。opts.perSource 改每源条数。
export async function gather(query, opts) {
  const r = await gatherRaw(query, opts || {});
  return capReport(r, (opts && opts.perSource) || DEF_CAP);
}
// gather + 自动同类横评（peers=3 表示自动挑 3 个对手）
export async function report(query, opts) {
  opts = opts || {};
  const r = await gather(query, opts);
  let cmp = null;
  const peers = opts.peers == null ? 0 : opts.peers;
  const peerN = peers === true ? 3 : Number(peers) || 0;
  if (peerN > 0) {
    try {
      const [index, bl, orModels] = await Promise.all([llmStatsIndex(opts), benchlmRows(opts).catch(function () { return null; }), openRouterModels(opts).catch(function () { return null; })]);
      let aaArr = null;
      try { aaArr = await aaIndex(opts); } catch (e2) { aaArr = null; }
      const picks = peerModels(index, query, peerN, { benchRows: bl ? bl.rows : null, orModels: orModels, aaRows: Array.isArray(aaArr) ? aaArr : null });
      if (picks.length) {
        const qs = [query].concat(picks.map(function (p) { return p.name; }));
        cmp = await compare(qs, opts);
        if (cmp) cmp.peerPicks = picks;
      } else r.gaps.push('同类横评：没有挑到段位相近的对手');
    } catch (e) { r.gaps.push('同类横评失败：' + String((e && e.message) || e).slice(0, 140)); }
  }
  return { r: r, cmp: cmp };
}
// 素材包：把「要解读的东西」压成一页给模型读（英文原句也在这里），读完再写 insights。
export function brief(r, opts) {
  const cap = (opts && opts.n) || r.__cap || DEF_CAP;
  const d = r.detail;
  const L = [];
  L.push('# 解读素材包 · ' + r.query);
  L.push('');
  L.push('> 读完后写 insights JSON，再用 renderMarkdown(r, { insights, compare }) 出给人看的报告。');
  L.push('> 硬要求：① 每个源最多 ' + cap + ' 条；② 每条给「结论」而不是标题复述；③ 英文原句必须给中文释义（en/zh 成对）；④ 小米自建那类厂商基准不得当第三方分数。');
  L.push('');
  if (d && d.model) {
    const m = d.model;
    L.push('## 档案');
    L.push('- ' + m.name + ' / ' + (m.organization || '-') + ' · 发布 ' + (m.release_date || '-') + ' · ' + (m.is_open_source ? '开源权重' : '闭源') + ' · 上下文 ' + (m.context ? Math.round(m.context / 1024) + 'K' : '-') + ' · 价格 ' + (m.input_price != null ? '$' + m.input_price + ' / $' + m.output_price : '-') + ' · 吞吐 ' + (m.throughput != null ? round2(m.throughput) + ' tok/s' : '-'));
    const ar = m.arena_scores && Object.keys(m.arena_scores).length ? Object.entries(m.arena_scores).map(function (kv) { return kv[0] + ' ' + round2(kv[1]); }).join(' · ') : '-';
    L.push('- 竞技场参考分：' + ar + '（**这是 llm-stats 自己的刻度，不是 LMArena 的 Elo，两者不可互相换算**）');
    L.push('');
  }
  if (d) {
    L.push('## 跑分（llm-stats，共 ' + d.benchmarkCount + ' 项）');
    const tiers = [['independent', '★ 独立验证'], ['thirdParty', '† 第三方桶（含厂商自建，注意甄别）'], ['vendor', '‡ 厂商自报']];
    for (const [k, label] of tiers) {
      const rows = (d[k] || []).slice(0, 24);
      if (!rows.length) continue;
      L.push('- ' + label + '：');
      for (const b of rows) {
        const selfMade = /mimo|xiaomi|小米/i.test(b.name) ? '【可能是厂商自建基准】' : '';
        L.push('  - ' + b.name + ' ' + fmtScore(b) + selfMade + (b.cats && b.cats.length ? '（' + b.cats.join('/') + '）' : ''));
      }
    }
    L.push('');
  }
  if (r.benchlmMatches && r.benchlmMatches.length) {
    const b = r.benchlmMatches[0];
    L.push('## benchlm（同尺度榜）');
    L.push('- ' + ['Model', 'Score', 'Elo', 'Price', 'Tok/s', 'Latency'].map(function (k) { return k + '=' + (b[k] || '-'); }).join(' · '));
    L.push('');
  }
  if (r.aaMatches && r.aaMatches.length) {
    const a = r.aaMatches[0];
    L.push('## Artificial Analysis');
    L.push('- ' + a.name + ' 智能指数 ' + (a.intelligenceIndex != null ? round2(a.intelligenceIndex) : '-') + ' · 价格 $' + a.price1mInputTokens + ' / $' + a.price1mOutputTokens + ' · 吞吐 ' + (a.medianOutputTokensPerSecond != null ? Math.round(a.medianOutputTokensPerSecond) + ' tok/s' : '-') + ' · 首答 ' + (a.medianTimeToFirstAnswerTokenSeconds != null ? round2(a.medianTimeToFirstAnswerTokenSeconds) + 's' : '-'));
    const row = aaRows(a);
    if (row.parts.length) L.push('- 分项：' + row.parts.join(' · '));
    L.push('');
  }
  if (r.lmarena && r.lmarena.ok) {
    L.push('## LMArena（人类盲测竞技场 · 官方数据集 lmarena-ai/leaderboard-dataset）');
    for (const b of r.lmarena.boards) {
      const v = b.overall;
      L.push('- ' + b.label + '：第 ' + v.rank + '/' + v.total + ' 名 · ' + (v.value == null ? '-' : round2(v.value)) + (b.kind === 'score' ? '（分数制，不是 Elo）' : '') +
        (v.lower != null ? ' · 95% 区间 [' + round2(v.lower) + ', ' + round2(v.upper) + ']' : '') +
        (v.votes ? ' · ' + (b.kind === 'score' ? v.sessions + ' 会话 / ' + v.votes + ' 次观测' : v.votes + ' 票') : '') + ' · 发布 ' + (b.publishDate || '-'));
    }
    const tx = (r.lmarena.boards || []).filter(function (b) { return b.id === 'text'; })[0];
    const st = (r.lmarena.boards || []).filter(function (b) { return b.id === 'text_style_control'; })[0];
    if (tx && st) L.push('- 风格控制前后：#' + tx.overall.rank + '（' + round2(tx.overall.value) + '）→ #' + st.overall.rank + '（' + round2(st.overall.value) + '）→ 名次' + (st.overall.rank > tx.overall.rank ? '后移 ' + (st.overall.rank - tx.overall.rank) + ' 位' : st.overall.rank < tx.overall.rank ? '前移 ' + (tx.overall.rank - st.overall.rank) + ' 位' : '不变') + '（差的只是有没有把回答风格从偏好里剥掉）');
    const cats = (tx && tx.categories) || [];
    const cc = cats.filter(function (c) { return c.category !== 'overall' && c.category !== 'exclude_ties'; });
    if (cc.length) {
      L.push('- 文本榜分项（共 ' + cc.length + ' 项，写解读时挑强弱两端讲）：');
      for (const c of cc) L.push('  - ' + c.zh + ' #' + c.rank + '/' + c.total + '（' + round2(c.value) + '，' + c.votes + ' 票）');
    }
    L.push('');
  }
  if (r.valsMatches && r.valsMatches.length) {
    L.push('## Vals AI');
    for (const v of r.valsMatches) {
      const pairs = [];
      for (let i = 0; i < v.values.length; i++) { const col = v.columns[2 + i]; if (col) pairs.push(col + ' ' + v.values[i]); }
      L.push('- ' + v.slug + '：第 ' + v.rank + '/' + v.total + ' 名 · ' + pairs.join(' · '));
    }
    L.push('');
  }
  const sb = r.swebenchMatches || {};
  if (Object.keys(sb).length) { L.push('## SWE-bench 官方榜'); for (const k of Object.keys(sb)) for (const h of sb[k].slice(0, 2)) L.push('- ' + k + ' #' + h._rank + '/' + h._total + ' ' + h.model + ' ' + round2(h.resolved) + '% · ' + (h.date || '-')); L.push(''); }
  if (r.rebenchMatch) { const x = r.rebenchMatch; L.push('## SWE-rebench'); L.push('- ' + x.name + ' ' + x.rate + '% n=' + x.n + (x.costPerTask != null ? ' $' + x.costPerTask + '/题' : '') + ' · 区间 ' + x.rangeFrom + '~' + x.rangeTo); L.push(''); }
  if (r.arcMatches && r.arcMatches.length) { L.push('## ARC Prize'); for (const a of r.arcMatches) L.push('- ' + a.set + ' ' + a.model + ' ' + pct(a.score) + '%' + (a.costPerTask != null ? ' $' + round2(a.costPerTask) + '/题' : '')); L.push(''); }
  if (r.hn && (r.hn.stories.length || r.hn.comments.length)) {
    L.push('## Hacker News（英文，必须给中文释义）');
    for (const s of r.hn.stories) L.push('- ▲' + (s.points || 0) + ' ' + s.comments + ' 评 · ' + s.title + '（' + s.date + '）' + s.hnUrl);
    if (r.hn.comments.length) { L.push('- 评论原文：'); for (const c of r.hn.comments) L.push('  - [EN] ' + String(c.text).replace(/\s+/g, ' ').slice(0, 420) + '  <' + c.url + '>'); }
    L.push('');
  }
  if (r.x && (r.x.posts || []).length) {
    L.push('## X（Twitter）—— 英文原句，必须给中文释义');
    for (const p of r.x.posts) L.push('- ♥' + (p.likes || 0) + ' 🔁' + (p.retweets || 0) + ' 💬' + (p.replies || 0) + ' 👁' + (p.views || 0) + ' · @' + p.user + (p.followers ? '（' + p.followers + ' followers）' : '') + ' ' + p.date + '  ' + p.url);
    for (const p of r.x.posts) L.push('  - [EN] ' + String(p.text || '').replace(/\s+/g, ' ').slice(0, 400));
    L.push('');
  }
  if (r.reddit && (r.reddit.threads || []).length) {
    L.push('## Reddit —— 帖子 + 高赞评论原文（英文，须给中文释义）');
    for (const t of r.reddit.threads) {
      L.push('- ' + (t.score || 0) + '↑ ' + (t.numComments || 0) + '💬 r/' + t.sub + '（' + t.date + '）' + t.title + '  ' + t.url);
      if (t.selftext) L.push('  - [EN] 正文：' + String(t.selftext).replace(/\s+/g, ' ').slice(0, 500));
      for (const c of (t.topComments || []).slice(0, 5)) L.push('  - [EN] ' + (c.score || 0) + '↑ ' + String(c.body || '').replace(/\s+/g, ' ').slice(0, 400));
    }
    L.push('');
  }
  if (r.juejin && r.juejin.length) { L.push('## 掘金'); for (const a of r.juejin) L.push('- ' + a.title + '（' + a.date + ' · 阅读 ' + (a.views || 0) + '）' + (a.brief ? ' —— ' + String(a.brief).slice(0, 120) : '') + ' ' + a.url); L.push(''); }
  const cnx = r.cn || {};
  if (cnx.bilibili && (cnx.bilibili.videos || []).length) {
    L.push('## B站（视频 + 高赞评论）');
    for (const v of cnx.bilibili.videos) L.push('- ▲' + (v.play || 0) + ' 💬' + (v.comments || 0) + ' · ' + v.title + ' —— ' + (v.author || '-') + ' ' + v.url);
    for (const c of cnx.bilibili.comments || []) L.push('  - 评论：' + String(c.text).replace(/\s+/g, ' ') + '（👍' + (c.like || 0) + '）');
    L.push('');
  }
  for (const [k, label] of [['zhihu', '知乎'], ['xiaohongshu', '小红书'], ['weixin', '微信公众号'], ['csdn', 'CSDN']]) {
    const arr = cnx[k] || [];
    if (!arr.length) continue;
    L.push('## ' + label);
    for (const a of arr) {
      const mt = [a.votes != null ? a.votes + ' 赞同' : null, a.likes != null ? '♥' + a.likes : null, a.comments != null ? a.comments + ' 评论' : null, a.date || null, a.author || a.account || null].filter(Boolean).join(' · ');
      L.push('- ' + (a.title || a.text || '(无标题)') + (mt ? '（' + mt + '）' : '') + (a.url ? ' ' + a.url : ''));
      if (a.excerpt) L.push('  - 摘要：' + String(a.excerpt).slice(0, 240));
    }
    L.push('');
  }
  if (r.github && r.github.items.length) { L.push('## GitHub 生态接入'); for (const g of r.github.items) L.push('- ' + (g.isPR ? '[PR] ' : '[issue] ') + g.title + ' —— ' + g.repo + (g.reactions ? ' ▲' + g.reactions : '') + ' ' + g.url); L.push(''); }
  L.push('## 缺口');
  for (const g of r.gaps) L.push('- ' + g);
  L.push('');
  L.push('## 要交的 insights JSON');
  L.push('```json');
  L.push('{');
  L.push('  "verdict": "一句话结论（定位 + 强项 + 代价）",');
  L.push('  "points": ["3~6 条判断，每条带数字"],');
  L.push('  "caveats": ["口径提醒：自建基准 / 版本差异 / 来源冲突"],');
  L.push('  "sources": { "x": {"read": "…X 上的结论与争议（英文原句给中文释义）"}, "reddit": {"read": "…Reddit 的真实使用反馈与反对意见"}, "benches": {"read": "…"}, "aa": {"read": "…"}, "benchlm": {"read": "…"}, "vals": {"read": "…"}, "hn": {"read": "…的中文解读，点出结论"}, "bilibili": {"read": "…"}, "zhihu": {"read": "…"}, "xiaohongshu": {"read": "…"}, "juejin": {"read": "…"}, "github": {"read": "…"} },');
  L.push('  "quotes": [{"en": "英文原句", "zh": "中文释义", "url": "…", "src": "HN"}]');
  L.push('}');
  L.push('```');
  return L.join('\n');
}
// 同类横评的紧凑版（嵌进单模型报告用）
export function renderPeersSection(cmp) {
  if (!cmp || !cmp.models) return '';
  const ms = cmp.models.filter(function (e) { return e.found; });
  if (ms.length < 2) return '';
  const L = [];
  L.push('## 同类横评（自动挑的段位相近对手）');
  L.push('');
  const picks = cmp.peerPicks || cmp.auto || [];
  if (picks.length) L.push('对手（按段位自动挑）：' + picks.map(function (a) { return a.name + '（' + (a.why || []).join('、') + '）'; }).join('；') + '。');
  L.push('');
  L.push('| 模型 | LMArena 文本榜 | benchlm 名次 | 综合分 | Elo | 价格/百万tok | 吞吐 | 跑分构成 ★/†/‡ |');
  L.push('|---|---|---|---|---|---|---|---|');
  for (const e of ms) {
    const b = e.benchlm;
    const rank = b ? String(b['Model'] || '').match(/#(\d+)/) : null;
    const price = e.model.input_price != null ? '$' + e.model.input_price + ' / $' + e.model.output_price : (e.or && e.or.price ? '$' + e.or.price.inPerM + ' / $' + e.or.price.outPerM + ' *' : '-');
    const t = e.tiers || { independent: 0, thirdParty: 0, vendor: 0 };
    const lar = e.lmarena && e.lmarena.ok && e.lmarena.boards && e.lmarena.boards.text ? e.lmarena.boards.text : null;
    const laCell = lar ? '#' + lar.rank + '/' + lar.total + '（' + round2(lar.value) + '）' : '-';
    L.push('| ' + e.name + ' | ' + laCell + ' | ' + (rank ? '#' + rank[1] : '未上榜') + ' | ' + (b ? b['Score'] : '-') + ' | ' + (b ? b['Elo'] : '-') + ' | ' + price + ' | ' + (b && b['Tok/s'] ? b['Tok/s'] : '-') + ' | ' + t.independent + '/' + t.thirdParty + '/' + t.vendor + ' |');
  }
  L.push('');
  if (cmp.shared && cmp.shared.length) {
    const fn = ms.map(function (e) { return e.name; });
    L.push('重合基准逐项对比（最多 12 项，档位：★ 独立 · † 第三方 · ‡ 厂商自报）：');
    L.push('');
    L.push('| 基准 | ' + fn.join(' | ') + ' |');
    L.push('|---|' + fn.map(function () { return '---'; }).join('|') + '|');
    for (const c of cmp.shared.slice(0, 12)) {
      const cells = fn.map(function (nm) { const v = c.by[nm]; return v ? fmtScore(v) + ' ' + tierMark(v.tier) : '—'; });
      L.push('| ' + c.name + ' | ' + cells.join(' | ') + ' |');
    }
    L.push('');
    L.push('共 ' + cmp.sharedStats.shared + ' / ' + cmp.sharedStats.all + ' 项基准被至少两个模型测过。');
    L.push('');
  }
  L.push('读法：先看 LMArena 文本榜（人类盲投、同一批票）与 benchlm 名次（同一套算法），再看重合基准的相对胜负；跨来源分数不要混算。');
  L.push('');
  return L.join('\n');
}
// 带解读层 / 横评的完整渲染：在原报告上插入「结论」「逐源解读」「英文原文对照」「同类横评」
export function renderMarkdown(r, opts) {
  opts = opts || {};
  const raw = renderMarkdownRaw(r);
  if (!opts.insights && !opts.compare) return finalizeDoc(raw, { skip: ["目录", "摘要"] });
  const ins = opts.insights || {};
  const lines = raw.split('\n');
  const out = [];
  let done = false;
  for (const ln of lines) {
    out.push(ln);
    if (!done && ln.trim() === TOC_PLACEHOLDER) {
      const blk = [];
      if (ins.verdict) blk.push('**一句话结论**：' + ins.verdict);
      if (ins.points && ins.points.length) { blk.push(''); for (const p of ins.points) blk.push('- ' + p); }
      if (ins.caveats && ins.caveats.length) { blk.push(''); blk.push('**口径提醒**：'); for (const c of ins.caveats) blk.push('- ' + c); }
      if (blk.length) { out.push('## 摘要'); out.push(''); for (const b of blk) out.push(b); out.push(''); }
      done = true;
    }
  }
  const SEC_KEYS = [
    ['benches', /^### (独立第三方复现|第三方榜单 \/ 评测机构|厂商自报（自己跑的）)/],
    ['benchlm', /^### 第三方榜单（benchlm\.ai 聚合）/],
    ['aa', /^### Artificial Analysis 独立榜/],
    ['lmarena', /^### LMArena/],
    ['swebench', /^### SWE-bench 官方榜/],
    ['rebench', /^### SWE-rebench 滚动榜/],
    ['arc', /^### ARC Prize 榜/],
    ['vals', /^### Vals AI 第三方榜/],
    ['arena', /^- \*\*竞技场参考分\*\*/],
    ['openrouter', /^### OpenRouter 在售/],
    ['hn', /^### Hacker News 口碑/],
    ['x', /^### X（Twitter）讨论/],
    ['reddit', /^### Reddit 讨论/],
    ['juejin', /^### 中文技术圈（掘金）/],
    ['bilibili', /^### B站实测视频/],
    ['csdn', /^### CSDN 技术帖/],
    ['weixin', /^### 微信公众号文章/],
    ['zhihu', /^### 知乎/],
    ['xiaohongshu', /^### 小红书/],
    ['github', /^### 生态接入 \/ 集成动态/],
  ];
  const arr = out.join('\n').split('\n');
  const marks = [];
  for (let i = 0; i < arr.length; i++) for (const kv of SEC_KEYS) if (kv[1].test(arr[i])) { marks.push({ key: kv[0], i: i }); break; }
  const adds = [];
  const usedKeys = new Set();
  for (let k = 0; k < marks.length; k++) {
    const key = marks[k].key, i = marks[k].i;
    const s = ins.sources && ins.sources[key];
    if (!s || !s.read) continue;
    if (usedKeys.has(key)) continue;
    usedKeys.add(key);
    let end = arr.length;
    for (let j = i + 1; j < arr.length; j++) { if (/^#{2,3} /.test(arr[j]) || /^> 仅研究参考/.test(arr[j])) { end = j; break; } }
    let at = end;
    while (at - 1 > i && arr[at - 1].trim() === '') at--;
    const add = ['> **解读**：' + s.read];
    if (key === 'hn' && ins.quotes && ins.quotes.length) {
      add.push('>');
      add.push('> **英文原文 → 中文释义**：');
      for (const q of ins.quotes.slice(0, 6)) add.push('> - 「' + q.en + '」 → ' + q.zh + (q.url ? '（' + (q.src || '链接') + '：' + q.url + '）' : ''));
    }
    adds.push({ at: at, add: add });
  }
  adds.sort(function (a, b) { return b.at - a.at; });
  for (const x of adds) arr.splice(x.at, 0, ...x.add);
  let text = arr.join('\n');
  if (opts.compare) {
    const sec = renderPeersSection(opts.compare);
    if (sec) {
      const anchor = '## 数据缺口与阅读须知';
      const i = text.indexOf(anchor);
      text = i > -1 ? text.slice(0, i) + sec + '\n' + text.slice(i) : text + '\n' + sec;
    }
  }
  return finalizeDoc(text, { skip: ["目录", "摘要"] });
}

// 段位感知的对手挑选：先用能力刻度（AA 智能指数 / benchlm 综合分）卡同段位，再看价位与发布时间。
// 与 similarModels 的区别：similarModels 主要按价位+时间挑，容易挑到「便宜的小模型」；这里要求能力接近。
export function peerModels(index, query, n, opts) {
  opts = opts || {};
  const benchRows = opts.benchRows || null, orModels = opts.orModels || null, aaRowsArr = opts.aaRows || null;
  const base = pickBest(scanModels(index, query, 1));
  if (!base) return [];
  const famOf = (name) => String(name || '').toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, ' ').trim().split(' ').slice(0, 2).join(' ');
  const baseFam = famOf(base.name);
  const benchScoreOf = function (name) {
    if (!benchRows) return null;
    const row = pickBest(matchBench(benchRows, name, 1));
    if (!row) return null;
    const v = parseFloat(String(row['Score'] || '').replace(/[^0-9.]/g, ''));
    return isNaN(v) ? null : v;
  };
  const aaOf = function (name) {
    if (!aaRowsArr || !aaRowsArr.length) return null;
    const q = String(name || '').toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '');
    if (!q) return null;
    const cands = aaRowsArr.filter(function (r) {
      const s = String(r.name || '').toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '');
      const sh = String(r.shortName || '').toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '');
      return s === q || (s && q.indexOf(s) === 0 && s.length >= 4) || (s && s.indexOf(q) === 0 && q.length >= 4) || (sh && sh === q);
    });
    if (!cands.length) return null;
    cands.sort(function (a, b) { return (b.intelligenceIndex || 0) - (a.intelligenceIndex || 0); });
    return cands[0].intelligenceIndex == null ? null : Number(cands[0].intelligenceIndex);
  };
  const priceOf = function (m) {
    const p = (m.input_price || 0) + (m.output_price || 0);
    if (p > 0) return p;
    if (!orModels) return 0;
    const o = pickBest(scanOR(orModels, m.name, 1));
    if (!o) return 0;
    const pr = orPrice(o);
    return (pr.inPerM || 0) + (pr.outPerM || 0);
  };
  const baseAA = aaOf(base.name);
  const baseBS = benchScoreOf(base.name);
  const baseP = ((base.input_price || 0) + (base.output_price || 0)) || priceOf(base);
  const baseT = base.release_date ? new Date(base.release_date).getTime() : 0;
  const out = [];
  for (const m of index || []) {
    if (!m || m.model_id === base.model_id) continue;
    if (baseFam && famOf(m.name) === baseFam) continue;
    const why = [];
    let sc = 0, capUsed = false;
    const a = aaOf(m.name), b = benchScoreOf(m.name);
    if (baseAA != null && a != null) {
      const d = Math.abs(a - baseAA);
      if (d > 14) continue;
      sc += d <= 2 ? 42 : d <= 4 ? 32 : d <= 7 ? 20 : 9;
      capUsed = true;
      why.push('AA 智能指数差 ' + d.toFixed(1));
    } else if (baseBS != null && b != null) {
      const d = Math.abs(b - baseBS);
      if (d > 14) continue;
      sc += d <= 3 ? 42 : d <= 6 ? 32 : d <= 10 ? 20 : 9;
      capUsed = true;
      why.push('benchlm 综合分差 ' + d.toFixed(1));
    }
    const p = priceOf(m);
    if (baseP > 0 && p > 0) {
      const r = p / baseP;
      if (r >= 0.5 && r <= 2) { sc += 18; why.push('同价位'); }
      else if (r >= 0.35 && r <= 3) { sc += 8; why.push('价位接近'); }
    }
    const mt = m.release_date ? new Date(m.release_date).getTime() : 0;
    if (baseT && mt) {
      const days = Math.abs(mt - baseT) / 86400000;
      if (days <= 45) { sc += 12; why.push('同期发布'); }
      else if (days <= 120) { sc += 6; why.push('发布时间接近'); }
    }
    if (!!m.is_open_source === !!base.is_open_source) { sc += 8; why.push(m.is_open_source ? '同为开源' : '同为闭源'); }
    if (base.context && m.context) { const cr = m.context / base.context; if (cr >= 0.5 && cr <= 2) { sc += 5; why.push('上下文量级相近'); } }
    if (m.organization && m.organization === base.organization) { sc += 4; why.push('同厂商'); }
    if (!capUsed) continue;
    out.push({ model_id: m.model_id, name: m.name, org: m.organization || null, release: m.release_date || null, aa: a, benchlmScore: b, price: m.input_price != null ? '$' + m.input_price + ' / $' + m.output_price : null, score: sc, why: why, crossVendor: m.organization !== base.organization });
  }
  if (aaRowsArr && aaRowsArr.length && baseAA != null) {
    const known = new Set((index || []).map(function (m) { return String(m.name || '').toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, ''); }));
    for (const r of aaRowsArr) {
      if (!r || r.intelligenceIndex == null || !r.name) continue;
      const key = String(r.name).toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '');
      if (!key || known.has(key)) continue;
      const d = Math.abs(Number(r.intelligenceIndex) - baseAA);
      if (d > 10) continue;
      const pr = r.price1mInputTokens != null ? '$' + r.price1mInputTokens + ' / $' + r.price1mOutputTokens : null;
      out.push({ model_id: null, name: r.name, org: r.organization || r.modelCreator || null, release: null, aa: Number(r.intelligenceIndex), benchlmScore: null, price: pr, score: (d <= 2 ? 42 : d <= 4 ? 32 : d <= 7 ? 20 : 9) - 2, why: ['AA 智能指数差 ' + d.toFixed(1) + '（llm-stats 未收录）'], crossVendor: true });
    }
  }
  out.sort(function (x, y) { return (y.score - x.score) || (x.crossVendor === y.crossVendor ? 0 : x.crossVendor ? -1 : 1) || String(y.release || '').localeCompare(String(x.release || '')); });
  const picked = [], perOrg = new Map(), perFam = new Set();
  for (const c of out) {
    const fam = famOf(c.name);
    if (perFam.has(fam)) continue;
    const k = c.org || '?', used = perOrg.get(k) || 0;
    if (used >= 1) continue;
    picked.push(c); perFam.add(fam); perOrg.set(k, used + 1);
    if (picked.length >= (n || 3)) break;
  }
  return picked;
}
