// 英文→中文翻译（薄转发层）
//
// 2026-11-15 用户定：真源放在 /root/workspace/tools/translate.mjs，
// 雷达 cli / 工具路径 / zh.mjs 共用同一份，避免拷贝分叉。
// 改代码请改 workspace 那份；npm 升级后由 reapply-radar-outbox.sh 重放本文件。
export * from "/root/workspace/tools/translate.mjs";
