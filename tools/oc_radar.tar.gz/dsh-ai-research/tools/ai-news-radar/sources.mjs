// ai-news-radar/sources.mjs —— 源清单（纯数据，无副作用）
//
// group 取值：
//   official  厂商 / 实验室官网与官方博客（一手发布）
//   media     英文科技财经媒体（AI 专栏 / 综合科技）
//   funding   融资与创投媒体
//   cn        中文科技媒体（量子位 / 智东西 / 雷峰网 …）
//   agg       聚合与简报（Techmeme / TLDR / smol.ai）
//   news      关键词检索（Google News / Bing News），见 NEWS_QUERIES
//   community 社区（HN / Reddit / X），在 lib.mjs 里单独抓
//
// filter: "ai" = 必须命中 AI 关键词才收（综合科技源必须加，否则整版噪音）
// parser: "anthropic" = 没有 RSS，走 HTML 解析（lib.mjs 的 parseAnthropic）
// weight: 1~10，越大越靠前（只影响排序，不影响是否收录）

export const FEEDS = [
  // ── 官方 / 一手（不过滤：官方账号发的基本都是 AI 圈的事） ──
  { id: "openai", name: "OpenAI", url: "https://openai.com/news/rss.xml", group: "official", lang: "en", weight: 10 },
  { id: "anthropic", name: "Anthropic", url: "https://www.anthropic.com/news", group: "official", lang: "en", weight: 10, parser: "anthropic" },
  { id: "deepmind", name: "Google DeepMind", url: "https://deepmind.google/blog/rss.xml", group: "official", lang: "en", weight: 9 },
  { id: "googleai", name: "Google AI", url: "https://blog.google/technology/ai/rss/", group: "official", lang: "en", weight: 9 },
  { id: "googleresearch", name: "Google Research", url: "https://blog.research.google/feeds/posts/default", group: "official", lang: "en", weight: 7 },
  { id: "huggingface", name: "Hugging Face", url: "https://huggingface.co/blog/feed.xml", group: "official", lang: "en", weight: 8 },
  { id: "qwen", name: "Qwen", url: "https://qwenlm.github.io/blog/index.xml", group: "official", lang: "en", weight: 8 },
  { id: "nvidia-blog", name: "NVIDIA Blog", url: "https://blogs.nvidia.com/blog/category/generative-ai/feed/", group: "official", lang: "en", weight: 7 },
  { id: "nvidia-dev", name: "NVIDIA Developer", url: "https://developer.nvidia.com/blog/feed/", group: "official", lang: "en", weight: 6 },
  { id: "aws-ml", name: "AWS Machine Learning", url: "https://aws.amazon.com/blogs/machine-learning/feed/", group: "official", lang: "en", weight: 5 },
  { id: "meta-eng", name: "Meta Engineering", url: "https://engineering.fb.com/feed/", group: "official", lang: "en", weight: 5 },

  // ── 英文媒体 ──
  { id: "techcrunch-ai", name: "TechCrunch AI", url: "https://techcrunch.com/category/artificial-intelligence/feed/", group: "media", lang: "en", weight: 8 },
  { id: "verge-ai", name: "The Verge AI", url: "https://www.theverge.com/rss/ai-artificial-intelligence/index.xml", group: "media", lang: "en", weight: 8 },
  { id: "venturebeat-ai", name: "VentureBeat AI", url: "https://venturebeat.com/category/ai/feed/", group: "media", lang: "en", weight: 7 },
  { id: "arstechnica-ai", name: "Ars Technica AI", url: "https://arstechnica.com/ai/feed/", group: "media", lang: "en", weight: 7 },
  { id: "mit-tr-ai", name: "MIT Technology Review", url: "https://www.technologyreview.com/topic/artificial-intelligence/feed", group: "media", lang: "en", weight: 7 },
  { id: "wired-ai", name: "WIRED AI", url: "https://www.wired.com/feed/tag/ai/latest/rss", group: "media", lang: "en", weight: 7 },
  { id: "ieee-ai", name: "IEEE Spectrum AI", url: "https://spectrum.ieee.org/feeds/topic/artificial-intelligence.rss", group: "media", lang: "en", weight: 7 },
  { id: "theregister-ai", name: "The Register AI/ML", url: "https://www.theregister.com/software/ai_ml/headlines.atom", group: "media", lang: "en", weight: 6 },
  { id: "theinformation", name: "The Information", url: "https://www.theinformation.com/feed", group: "media", lang: "en", weight: 9, filter: "ai" },
  { id: "semianalysis", name: "SemiAnalysis", url: "https://semianalysis.com/feed/", group: "media", lang: "en", weight: 8 },
  { id: "stratechery", name: "Stratechery", url: "https://stratechery.com/feed/", group: "media", lang: "en", weight: 7, filter: "ai" },
  { id: "bloomberg-tech", name: "Bloomberg Technology", url: "https://feeds.bloomberg.com/technology/news.rss", group: "media", lang: "en", weight: 6, filter: "ai" },
  { id: "ft-tech", name: "Financial Times Tech", url: "https://www.ft.com/technology?format=rss", group: "media", lang: "en", weight: 6, filter: "ai" },
  { id: "wsj-tech", name: "WSJ Tech", url: "https://feeds.a.dj.com/rss/RSSWSJD.xml", group: "media", lang: "en", weight: 6, filter: "ai" },
  { id: "nyt-tech", name: "NYT Technology", url: "https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml", group: "media", lang: "en", weight: 5, filter: "ai" },
  { id: "cnbc-tech", name: "CNBC Tech", url: "https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=19854910", group: "media", lang: "en", weight: 5, filter: "ai" },
  { id: "axios", name: "Axios", url: "https://api.axios.com/feed/", group: "media", lang: "en", weight: 5, filter: "ai" },
  { id: "zdnet-ai", name: "ZDNet AI", url: "https://www.zdnet.com/topic/artificial-intelligence/rss.xml", group: "media", lang: "en", weight: 5 },
  { id: "wired-biz", name: "WIRED Business", url: "https://www.wired.com/feed/category/business/latest/rss", group: "media", lang: "en", weight: 5, filter: "ai" },

  // ── 融资 / 创投 ──
  { id: "crunchbase", name: "Crunchbase News", url: "https://news.crunchbase.com/feed/", group: "funding", lang: "en", weight: 6, filter: "ai" },
  { id: "techcrunch-venture", name: "TechCrunch Venture", url: "https://techcrunch.com/category/venture/feed/", group: "funding", lang: "en", weight: 6, filter: "ai" },

  // ── 聚合 / 简报 ──
  { id: "techmeme", name: "Techmeme", url: "https://www.techmeme.com/feed.xml", group: "agg", lang: "en", weight: 7, filter: "ai" },
  { id: "smol-ai", name: "smol.ai", url: "https://news.smol.ai/rss.xml", group: "agg", lang: "en", weight: 6 },
  { id: "tldr-ai", name: "TLDR AI", url: "https://tldr.tech/api/rss/ai", group: "agg", lang: "en", weight: 6 },
  { id: "import-ai", name: "Import AI", url: "https://importai.substack.com/feed", group: "agg", lang: "en", weight: 6 },

  // ── 中文媒体（量子位 = 用户点名的"总结类账号"） ──
  { id: "qbitai", name: "量子位", url: "https://www.qbitai.com/feed", group: "cn", lang: "zh", weight: 9 },
  { id: "zhidx", name: "智东西", url: "https://www.zhidx.com/rss", group: "cn", lang: "zh", weight: 8 },
  { id: "leiphone", name: "雷峰网", url: "https://www.leiphone.com/feed", group: "cn", lang: "zh", weight: 7 },
  { id: "tmtpost", name: "钛媒体", url: "https://www.tmtpost.com/feed", group: "cn", lang: "zh", weight: 6, filter: "ai" },
  { id: "geekpark", name: "极客公园", url: "https://www.geekpark.net/rss", group: "cn", lang: "zh", weight: 6, filter: "ai" },
  { id: "infoq-cn", name: "InfoQ 中文", url: "https://www.infoq.cn/feed", group: "cn", lang: "zh", weight: 5, filter: "ai" },
  { id: "ithome", name: "IT之家", url: "https://www.ithome.com/rss/", group: "cn", lang: "zh", weight: 5, filter: "ai" },
  { id: "cnbeta", name: "cnBeta", url: "https://www.cnbeta.com.tw/backend.php", group: "cn", lang: "zh", weight: 5, filter: "ai" },
  { id: "sina-tech", name: "新浪科技", url: "https://rss.sina.com.cn/tech/rollnews.xml", group: "cn", lang: "zh", weight: 4, filter: "ai" },
  { id: "sspai", name: "少数派", url: "https://sspai.com/feed", group: "cn", lang: "zh", weight: 4, filter: "ai" },
];

// ── Google News 关键词检索：本工具覆盖面的主力（每条查询最多返 100 条） ──
// 注意：Google News 的 <link> 是 news.google.com 跳转链，服务端还原不出发布方原始 URL
// （base64 是 protobuf，不含明文 URL）。媒体名取 <source>，链接保留 GN 链（浏览器可点开）。
export const NEWS_QUERIES = {
  en: [
    { id: "gn-en-labs", q: '(OpenAI OR Anthropic OR xAI OR "Google DeepMind" OR "Meta AI") when:{d}d', weight: 9 },
    { id: "gn-en-funding", q: '("AI startup" OR "AI company" OR "AI lab") (raises OR funding OR valuation OR acquires) when:{d}d', weight: 9 },
    { id: "gn-en-model", q: '("AI model" OR "frontier model" OR LLM OR chatbot) (launch OR release OR "open weights" OR update) when:{d}d', weight: 8 },
    { id: "gn-en-people", q: '(AI OR "artificial intelligence") ("steps down" OR resigns OR appoints OR hires OR poaches OR layoffs) when:{d}d', weight: 8 },
    { id: "gn-en-chips", q: '(Nvidia OR "AI chip" OR "data center" OR "compute") (AI OR GPU OR TPU) when:{d}d', weight: 7 },
    { id: "gn-en-policy", q: '(AI OR "artificial intelligence") (regulation OR lawsuit OR "export controls" OR antitrust OR safety OR copyright) when:{d}d', weight: 7 },
    { id: "gn-en-agi", q: '(AGI OR "artificial general intelligence" OR superintelligence OR "AI safety") when:{d}d', weight: 5 },
  ],
  zh: [
    { id: "gn-zh-labs", q: '(OpenAI OR Anthropic OR 谷歌 OR 英伟达 OR 马斯克) (发布 OR 融资 OR 离职 OR 合作) when:{d}d', weight: 9 },
    { id: "gn-zh-funding", q: '(大模型 OR 人工智能 OR AI 公司) (融资 OR 估值 OR 收购 OR 上市) when:{d}d', weight: 9 },
    { id: "gn-zh-model", q: '(大模型 OR 智能体 OR 多模态) (发布 OR 开源 OR 上线 OR 更新) when:{d}d', weight: 8 },
    { id: "gn-zh-people", q: '(AI OR 大模型) (高管 OR 创始人 OR 团队) (离职 OR 加盟 OR 任命 OR 裁员) when:{d}d', weight: 8 },
    { id: "gn-zh-chips", q: '(算力 OR AI 芯片 OR 智算中心 OR 数据中心) when:{d}d', weight: 7 },
    { id: "gn-zh-policy", q: '人工智能 (监管 OR 政策 OR 法案 OR 标准 OR 备案) when:{d}d', weight: 6 },
  ],
};

export const GN_LOCALE = {
  en: { hl: "en-US", gl: "US", ceid: "US:en" },
  zh: { hl: "zh-CN", gl: "CN", ceid: "CN:zh-Hans" },
};

// Bing News：12 条/查询，链接可还原真实 URL（Google News 的兜底）
export const BING_NEWS = {
  url: "https://www.bing.com/news/search?q={q}&format=RSS",
  weight: 5,
  queries: [
    { id: "bing-ai-funding", q: "AI startup funding round" },
    { id: "bing-ai-lab", q: "OpenAI Anthropic model release" },
    { id: "bing-ai-cn", q: "大模型 发布 融资" },
  ],
};

// ── X 账号名单（2026-10-16 逐账号实测：能拉到时间线的才收） ──
// tier1 = 已验证活跃的官号 / 爆料号；tier2 = 官方但时间线最新日期偏旧、或偶尔空返（轮转取样，别当活跃度判据）
export const X_ACCOUNTS = [
  { acct: "OpenAI", name: "OpenAI", tier: 1, kind: "official" },
  { acct: "AnthropicAI", name: "Anthropic", tier: 1, kind: "official" },
  { acct: "GoogleDeepMind", name: "Google DeepMind", tier: 1, kind: "official" },
  { acct: "GoogleAI", name: "Google AI", tier: 1, kind: "official" },
  { acct: "OpenAIDevs", name: "OpenAI Devs", tier: 1, kind: "official" },
  { acct: "nvidia", name: "NVIDIA", tier: 1, kind: "official" },
  { acct: "AIatMeta", name: "Meta AI", tier: 1, kind: "official" },
  { acct: "Alibaba_Qwen", name: "Qwen", tier: 1, kind: "official" },
  { acct: "testingcatalog", name: "TestingCatalog（爆料）", tier: 1, kind: "insider" },
  { acct: "kimmonismus", name: "Kim（爆料/汇总）", tier: 1, kind: "insider" },
  { acct: "TheInformation", name: "The Information", tier: 1, kind: "media" },
  { acct: "TechCrunch", name: "TechCrunch", tier: 1, kind: "media" },
  { acct: "ArtificialAnlys", name: "Artificial Analysis", tier: 1, kind: "media" },
  { acct: "AndrewCurran_", name: "Andrew Curran（汇总）", tier: 1, kind: "insider" },
  { acct: "deepseek_ai", name: "DeepSeek", tier: 2, kind: "official" },
  { acct: "huggingface", name: "Hugging Face", tier: 2, kind: "official" },
  { acct: "MistralAI", name: "Mistral AI", tier: 2, kind: "official" },
  { acct: "_akhaliq", name: "AK（论文/发布速报）", tier: 2, kind: "insider" },
  { acct: "BTibor91", name: "BTibor91（爆料）", tier: 2, kind: "insider" },
  { acct: "TheTuringPost", name: "The Turing Post", tier: 2, kind: "media" },
  { acct: "scaling01", name: "scaling01（跑分/爆料）", tier: 2, kind: "insider" },
  { acct: "rowancheung", name: "Rowan Cheung", tier: 2, kind: "media" },
];
// 实测返 0 条，别加：xai、TheDecoder_、lmarena_ai

// ── Reddit：AI 相关子版（走 arctic-shift 归档火管） ──
export const REDDIT_SUBS = ["OpenAI", "singularity", "LocalLLaMA", "MachineLearning", "artificial", "Anthropic"];

// ── 微信公众号（搜狗微信，匿名可用但慢且易触发反爬；默认关，--wechat 打开） ──
export const WEIXIN_QUERIES = [
  { id: "wx-funding", q: "大模型 融资", weight: 8 },
  { id: "wx-people", q: "AI 公司 人事变动", weight: 8 },
  { id: "wx-model", q: "大模型 发布", weight: 7 },
];

// ── AI 关键词（综合科技源必须过这道闸） ──
export const AI_TERMS = {
  en: [
    "ai", "a.i.", "agi", "llm", "llms", "genai", "gpt", "chatgpt", "openai", "anthropic", "claude",
    "gemini", "deepmind", "grok", "xai", "mistral", "llama", "qwen", "deepseek", "kimi", "moonshot",
    "minimax", "zhipu", "glm", "ernie", "doubao", "copilot", "openrouter", "huggingface", "hugging face",
    "nvidia", "cuda", "transformer", "diffusion", "multimodal", "agentic", "ai agent", "inference",
    "fine-tuning", "neural", "machine learning", "deep learning", "generative ai", "text-to-image",
    "text-to-video", "sora", "midjourney", "stable diffusion", "world model", "foundation model",
    "frontier model", "chatbot", "superintelligence", "neural network", "ai chip", "ai model", "ai safety",
    "ai startup", "artificial intelligence", "open weights", "reasoning model", "gpu cluster",
  ],
  zh: [
    "人工智能", "大模型", "大语言模型", "生成式", "智能体", "算力", "机器学习", "深度学习", "多模态",
    "开源模型", "推理模型", "具身智能", "数字人", "AIGC", "神经网络", "预训练", "微调", "智算",
    "英伟达", "豆包", "文心", "通义", "混元", "智谱", "月之暗面", "百川智能", "商汤", "科大讯飞",
    "自动驾驶", "无人驾驶", "芯片", "OpenAI", "Anthropic", "DeepSeek", "AI 眼镜", "AI 应用",
  ],
};

export const THEMES = [
  { id: "model", name: "模型 / 产品发布" },
  { id: "funding", name: "融资 / 并购 / 估值" },
  { id: "chips", name: "算力 / 芯片 / 基建" },
  { id: "tech", name: "技术 / 研究" },
  { id: "people", name: "人事 / 组织变动" },
  { id: "policy", name: "政策 / 监管 / 法律" },
  { id: "biz", name: "商业 / 合作 / 落地" },
  { id: "other", name: "其它" },
];
