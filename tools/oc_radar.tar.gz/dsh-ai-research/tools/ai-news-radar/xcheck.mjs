// 交叉校验 + 质检（薄转发层）
//
// 2026-11-15 用户定：真源放在 /root/workspace/tools/xcheck.mjs，
// 雷达链路（lib.mjs 第 98 行的 export）与日报线（news-ai/xcheck_run.mjs、
// news-tools/xcheck_run.mjs）共用同一份代码，避免两份拷贝分叉。
// 改代码请改 workspace 那份；npm 升级后由 reapply-radar-outbox.sh 重放本文件。
export * from "/root/workspace/tools/xcheck.mjs";
