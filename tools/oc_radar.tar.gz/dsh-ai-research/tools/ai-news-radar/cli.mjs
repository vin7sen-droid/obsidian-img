#!/usr/bin/env node
// ai-news-radar/cli.mjs —— 命令行入口
//   node ai-news-radar/cli.mjs --days 1                 # 抓最近 1 天，落盘日报
//   node ai-news-radar/cli.mjs --days 3 --focus "OpenAI"  # 聚焦某家/某话题（额外加一轮关键词检索）
//   node ai-news-radar/cli.mjs --deep                   # X 账号 12 个 + 微信公众号检索
//   node ai-news-radar/cli.mjs --md                     # 只打印 markdown，不落盘
//   node ai-news-radar/cli.mjs --brief                  # 给 agent 的紧凑原料
//   node ai-news-radar/cli.mjs --json > out.json        # 全量 JSON
//   node ai-news-radar/cli.mjs --list-sources           # 打印源清单
//   node ai-news-radar/cli.mjs --fetch <url>            # 抓一篇文章正文（给摘要用）
import { setupProxy, translateRes, collect, renderMarkdown, brief, summarize, saveDigest, fetchArticle, FEEDS, X_ACCOUNTS, REDDIT_SUBS, RAW_DIR } from "./lib.mjs";
import { crossCheck, writeReviewList } from "./xcheck.mjs";

const argv = process.argv.slice(2);
const o = { days: 1, focus: "", deep: false, x: true, xBudget: 8, hn: true, reddit: true, news: true, bing: true, feeds: true, wechat: false, out: "", mode: "digest", json: false };
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  const val = () => argv[++i];
  if (a === "--days") o.days = Number(val()) || 1;
  else if (a === "--focus") o.focus = val() || "";
  else if (a === "--deep") { o.deep = true; o.xBudget = 12; o.wechat = true; }
  else if (a === "--out") o.out = val() || "";
  else if (a === "--x-budget") o.xBudget = Number(val()) || 8;
  else if (a === "--no-x") o.x = false;
  else if (a === "--x") o.x = true;
  else if (a === "--no-hn") o.hn = false;
  else if (a === "--no-reddit") o.reddit = false;
  else if (a === "--no-news") o.news = false;
  else if (a === "--no-bing") o.bing = false;
  else if (a === "--no-feeds") o.feeds = false;
  else if (a === "--wechat") o.wechat = true;
  else if (a === "--only") o.only = (val() || "").split(",").map((s) => s.trim()).filter(Boolean);
  else if (a === "--md") o.mode = "md";
  else if (a === "--brief") o.mode = "brief";
  else if (a === "--json") o.json = true;
  else if (a === "--quiet") o.quiet = true;
  else if (a === "--no-translate") o.translate = false;
  else if (a === "--xcheck") o.xcheck = true;
  else if (a === "--xc-engine") o.xcEngine = val();
  else if (a === "--xc-sample") o.xcSample = Number(val());
  else if (a === "--no-xcheck") o.xcheck = false;
  else if (a === "--list-sources") o.mode = "sources";
  else if (a === "--fetch") o.mode = "fetch", o.fetchUrl = val();
  else if (a === "--help" || a === "-h") o.mode = "help";
  else if (a.startsWith("--")) { console.error("未知参数：" + a + "（--help 看用法）"); process.exit(2); }
}

if (o.mode === "help") {
  console.log(require_help());
  process.exit(0);
}
if (o.mode === "sources") {
  console.log("RSS/HTML 源（" + FEEDS.length + "）：");
  for (const f of FEEDS) console.log("  " + f.id.padEnd(20) + f.name.padEnd(24) + f.group.padEnd(9) + (f.filter === "ai" ? "[需过 AI 过滤] " : "") + f.url);
  console.log("\nGoogle News 查询：见 sources.mjs 的 NEWS_QUERIES（en 7 条 / zh 6 条，每条最多 100 条）");
  console.log("Bing News 查询：" + "见 sources.mjs 的 BING_NEWS");
  console.log("\nX 账号（" + X_ACCOUNTS.length + "，按天轮转取样）：" + X_ACCOUNTS.map((a) => a.acct + "(t" + a.tier + ")").join(" "));
  console.log("Reddit 子版：" + REDDIT_SUBS.join(" "));
  process.exit(0);
}
if (o.mode === "fetch") {
  if (!o.fetchUrl) { console.error("--fetch 需要 URL"); process.exit(2); }
  const r = await fetchArticle(o.fetchUrl, { chars: 4000 });
  console.log(JSON.stringify({ url: r.url, status: r.status, error: r.error || null, title: r.title, chars: r.chars }, null, 1));
  if (r.text) console.log("\n" + r.text);
  process.exit(r.status === 200 ? 0 : 1);
}

const t0 = Date.now();
const proxy = await setupProxy();
if (o.verbose) console.error("[proxy] " + JSON.stringify(proxy));
const res = await collect({
  days: o.days, focus: o.focus || null, deep: o.deep, x: o.x, xBudget: o.xBudget,
  hn: o.hn, reddit: o.reddit, news: o.news, bing: o.bing, feeds: o.feeds, wechat: o.wechat,
  only: o.only, concurrency: 8,
});
res.proxy = proxy; // 与工具路径（index.js）一致：JSON 元数据里记录当轮代理状态

if (o.translate !== false) {
  try { await translateRes(res, { budgetMs: 240000, verbose: !!o.verbose }); }
  catch (e) { console.error("[translate] " + String((e && e.message) || e)); }
}

// 交叉校验（2026-11-15 定：默认开）。腾讯翻完用彩云小译重翻比对，差异条目出人工审清单。
// 彩云 636 条约 12s（谷歌要 189s 且易 429），所以默认就开；--no-xcheck 或 DSH_AI_RESEARCH_XCHECK=0 可关。
const xcheckOn = o.xcheck !== false && !/^(0|off|false|no)$/i.test(process.env.DSH_AI_RESEARCH_XCHECK || "");
if (xcheckOn && o.translate !== false) {
  try {
    const stamp = String(res.asOf || new Date().toISOString()).slice(0, 10);
    // 增量人工审（2026-11-16 借鉴 ai-news-daily SKILL.md）：旧版 JSON 存在时取其 URL 集，
    // crossCheck 把存量/新增分开，人工审清单新增排前、存量标 [存量] 可略读。
    let prevUrls = null;
    try {
      const oldPath = path.join(RAW_DIR, stamp + ".json");
      if (fs.existsSync(oldPath)) {
        prevUrls = new Set((JSON.parse(fs.readFileSync(oldPath, "utf-8")).items || []).map((x) => x.url).filter(Boolean));
        if (!prevUrls.size) prevUrls = null;
      }
    } catch { prevUrls = null; }
    const xc = await crossCheck(res, { concurrency: 3, engine: o.xcEngine, mmSample: o.xcSample, prevUrls });
    if (xc.flagged.length) {
      const tag = prevUrls ? "，新增 " + xc.fresh + " · 存量 " + xc.stale : "";
      console.error("[交叉校验] " + xc.checked + " 条已查，差异 " + xc.flagged.length + " 条（high " +
        xc.flagged.filter((f) => f.level === "high").length + tag + "）→ 人工审：");
      const rp = writeReviewList(RAW_DIR, stamp, xc.flagged, xc);
      if (rp) console.error("→ 清单：" + rp);
    } else if (xc.limited) {
      console.error("[交叉校验] Google 通道被限流（连续失败熔断），本轮跳过 " + xc.skipped + " 条，无差异结论");
    } else {
      console.error("[交叉校验] " + xc.checked + " 条已查，无差异" + (xc.failed ? "（" + xc.failed + " 条未参与比对）" : "") + "（" + xc.engine + "）");
    }
  } catch (e) { console.error("[交叉校验] 失败（不影响主产物）：" + String((e && e.message) || e)); }
}

if (o.json) {
  console.log(JSON.stringify({ asOf: res.asOf, days: res.days, focus: res.focus, stats: res.stats, gaps: res.gaps, sources: res.sources, items: res.items, buzz: res.buzz }, null, 1));
  process.exit(0);
}
if (o.mode === "brief") {
  console.log(brief(res, { perTheme: 8, community: 5 }));
  const p = saveDigest(res, { out: o.out || undefined });
  console.error("\n[落盘] " + p.md + (p.quick ? "\n[落盘] " + p.quick : "") + "\n[数据源] " + p.json + "\n[耗时] " + Math.round((Date.now() - t0) / 1000) + "s");
  process.exit(0);
}
if (o.mode === "md") { console.log(renderMarkdown(res, { topN: o.days > 2 ? 15 : 10, perTheme: o.days > 2 ? 12 : 8 })); process.exit(0); }

const p = saveDigest(res, { out: o.out || undefined });
console.log(renderMarkdown(res, { topN: o.days > 2 ? 15 : 10, perTheme: o.days > 2 ? 12 : 8 }));
console.error("\n" + summarize(res));
console.error("[落盘] " + p.md + (p.quick ? "\n[落盘] " + p.quick : "") + "\n[数据源] " + p.json + "\n[目录] " + p.dir);
console.error("[耗时] " + Math.round((Date.now() - t0) / 1000) + "s");

function require_help() {
  return [
    "ai-news-radar —— AI 圈新闻雷达（官方渠道 + 媒体 + 检索 + 社区）",
    "",
    "用法：node ai-news-radar/cli.mjs [选项]",
    "  --days N          时间窗（默认 1）",
    "  --focus \"词\"      聚焦某公司/话题（额外加一轮 Google News/Bing/微信检索）",
    "  --deep            深挖：X 账号 12 个 + 微信公众号检索",
    "  --no-x            不抓 X 账号时间线（默认抓 8 个，与 model-report 共用 30/15min 配额）",
    "  --no-reddit --no-hn --no-news --no-bing --no-feeds   关掉某一路",
    "  --xcheck          翻译后做交叉校验，差异条目出 <日期>_人工审.md（默认关，出日报那天加）",
  "  --xc-engine <e>   校验引擎：caiyun（默认，国内直连 40 条/批 0.6s）| mymemory（逐条 2s，额度 5 万字符/天）| google（clients5，易被 IP 限流）",
  "  --xc-sample <n>   MyMemory 抽样上限（默认 60 条；按字符算额度，约 100 字符/条）",
    "  --only id1,id2    只抓指定 RSS 源（id 见 --list-sources）",
    "  --out 目录        笔记落盘目录（默认 /sdcard/Obsidian/dsh/新闻/AI radar；只写 md，JSON 另存 $DSH_AI_RESEARCH_RAW 或 /root/workspace/digests）",
    "  --md | --brief | --json   输出形态（默认：落盘 + 打印 markdown）",
    "  --list-sources    打印源清单",
    "  --fetch <url>     抓一篇文章正文",
  ].join("\n");
}
