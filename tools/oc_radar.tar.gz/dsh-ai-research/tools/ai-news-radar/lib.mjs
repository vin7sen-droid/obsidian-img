// ai-news-radar/lib.mjs —— AI 圈新闻雷达：把几十个渠道的 AI 新闻汇总成一份带来源的日报。
// 纯 Node、零依赖；出网统一走 model-report/net.mjs 的代理隧道（本机直连外网不通）。
// 复用（保持实现单份）：model-report/net.mjs（出网）、search.mjs（实体解码/缓存）、
//   x.mjs（账号时间线）、reddit.mjs（arctic 火管）、cn.mjs（搜狗微信）。
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";
import zlib from "node:zlib";
import net from "node:net";
import { spawn } from "node:child_process";
import { get, getBuffer, getJSON, sleep } from "../model-report/net.mjs";
import { finalizeDoc, TOC_PLACEHOLDER } from "../model-report/doc.mjs";
import { decodeEntities, cacheGet, cachePut } from "../model-report/search.mjs";
import { rosterTweets } from "../model-report/x.mjs";
import { firehose } from "../model-report/reddit.mjs";
import { weixinBuzz } from "../model-report/cn.mjs";
import { FEEDS, NEWS_QUERIES, GN_LOCALE, BING_NEWS, X_ACCOUNTS, REDDIT_SUBS, WEIXIN_QUERIES, AI_TERMS, THEMES } from "./sources.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
// 落盘目录：默认 /sdcard/Obsidian/dsh/新闻/AI radar（本机 Obsidian dsh 库），
// 可用 DSH_AI_RESEARCH_OUT 环境变量或 opts.out 覆盖。
export const DIGEST_DIR = process.env.DSH_AI_RESEARCH_OUT ? path.resolve(process.env.DSH_AI_RESEARCH_OUT) : "/sdcard/Obsidian/dsh/新闻/AI radar";
// 落盘文件名前缀（Obsidian 里好认）：<前缀>_<日期>.md / _速览.md
export const DIGEST_PREFIX = process.env.DSH_AI_RESEARCH_PREFIX || "AI圈新闻雷达";
// 原始 JSON 存放目录：**不进** Obsidian 笔记库（2026-11-13 用户要求该目录只放 md），
// 只作数据源留档，供 renderFullMarkdown / json2radar_md.py 复算。
export const RAW_DIR = process.env.DSH_AI_RESEARCH_RAW ? path.resolve(process.env.DSH_AI_RESEARCH_RAW) : "/root/workspace/digests";
export { FEEDS, THEMES, X_ACCOUNTS, REDDIT_SUBS, NEWS_QUERIES };

// ── 出网代理（2026-11-14 更新）────────────────────────────────────
// 首选 127.0.0.1:7890 = 本机 proot mihomo（美国出口，51 节点订阅自动 fallback，见 /root/opt/mihomo/README.md）；
// 不通再试 127.0.0.1:3067 = 手机 Clash（香港出口），两者都探测失败才回落直连。
// 默认启用，但 Reddit 走代理会 403（直连可用），所以 NO_PROXY 例外名单固定带 reddit 域名。
// 关闭：DSH_AI_RESEARCH_PROXY=off；改地址：DSH_AI_RESEARCH_PROXY=http://host:port。
export const DEFAULT_PROXY = "http://127.0.0.1:7890";
export const FALLBACK_PROXIES = ["http://127.0.0.1:3067"];
export const PROXY_BYPASS = "reddit.com,redd.it,redditmedia.com,redditstatic.com";
const PROXY_KEYS = ["DSH_AI_RESEARCH_PROXY", "MODEL_REPORT_PROXY", "MR_PROXY", "HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy"];

function tcpProbe(proxyUrl, timeoutMs = 900) {
  return new Promise((resolve) => {
    let u;
    try { u = new URL(proxyUrl); } catch { return resolve(false); }
    const sock = net.connect(Number(u.port || 80), u.hostname, () => { sock.destroy(); resolve(true); });
    sock.setTimeout(timeoutMs, () => { sock.destroy(); resolve(false); });
    sock.on("error", () => { sock.destroy(); resolve(false); });
  });
}

// 首选代理（本机 mihomo）探不通时按需自动拉起；proot 没有 init，dsh 引擎也没有启动钩子，
// 这里是「用到才拉」的兜底。幂等：冷却锁 10 分钟内不重复 spawn，防配置损坏时反复起进程。
const MIHOMO_DIR = "/root/opt/mihomo";
const MIHOMO_LOCK = path.join(os.tmpdir(), ".mihomo-autostart-lock");
async function ensureMihomo() {
  try {
    const age = Date.now() - fs.statSync(MIHOMO_LOCK).mtimeMs;
    if (age < 10 * 60 * 1000) return false;
  } catch { /* 无锁 → 继续 */ }
  try { fs.closeSync(fs.openSync(MIHOMO_LOCK, "w")); } catch { /* 锁写失败也继续 */ }
  try {
    spawn(path.join(MIHOMO_DIR, "mihomo"),
      ["-d", MIHOMO_DIR, "-f", path.join(MIHOMO_DIR, "config-sub.yaml")],
      { detached: true, stdio: "ignore", cwd: MIHOMO_DIR }).unref();
  } catch { return false; }
  await sleep(2500); // 等 mihomo 起 mixed-port 并完成 fallback 测活（太早会 502）
  return tcpProbe(DEFAULT_PROXY);
}

/** 出网代理初始化：用户没配任何代理 env 时启用默认本机代理并加例外名单；探测不通则保持直连。 */
export async function setupProxy(opts = {}) {
  const existing = PROXY_KEYS.find((k) => process.env[k] && String(process.env[k]).trim());
  if (existing) {
    const v = String(process.env[existing]).trim();
    if (/^(off|0|none)$/i.test(v)) return { enabled: false, source: existing, reason: "显式关闭" };
    return { enabled: true, source: existing, proxy: v, bypass: process.env.NO_PROXY || "" };
  }
  const candidates = [opts.proxy || DEFAULT_PROXY, ...FALLBACK_PROXIES];
  let proxy = null;
  for (const c of candidates) {
    if (await tcpProbe(c)) { proxy = c; break; }
    if (c === DEFAULT_PROXY) {
      // 首选（mihomo）没起：按需自动拉起后再探一次；3067 是手机 Clash，proot 拉不了，不自动启
      if (await ensureMihomo()) { proxy = c; break; }
    }
  }
  if (!proxy) return { enabled: false, reason: "代理端口探测失败：" + candidates.join(" / ") };
  process.env.DSH_AI_RESEARCH_PROXY = proxy;
  // 例外名单去重后再并入（NO_PROXY 可能已含同名域，重复无害但难看）
  const have = new Set(String(process.env.NO_PROXY || "").split(",").map((x) => x.trim()).filter(Boolean));
  const add = PROXY_BYPASS.split(",").map((x) => x.trim()).filter((d) => d && !have.has(d));
  if (add.length) process.env.NO_PROXY = [process.env.NO_PROXY, add.join(",")].filter(Boolean).join(",");
  return { enabled: true, source: "default", proxy, bypass: process.env.NO_PROXY };
}

// 英文中文化：译文写 title_zh / summary_zh，原字段不动（渲染层 _zh 优先、回落原文）
export { translateRes, translateEnabled } from "./translate.mjs";
export { crossCheck, writeReviewList } from "./xcheck.mjs";

/** 渲染用取值：译文优先，没有就回落英文原文 */
export const dispTitle = (x) => S((x && (x.title_zh || x.title)) || "");
export const dispSummary = (x) => S((x && (x.summary_zh || x.summary)) || "");

const S = (x) => String(x == null ? "" : x);
export const cut = (x, n) => S(x).replace(/\s+/g, " ").trim().slice(0, n || 400);
export const dayKey = (ts) => new Date(ts).toISOString().slice(0, 10);

// ─────────────────────────── 解析 ───────────────────────────
export function html2text(s) {
  let x = S(s).replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1");
  x = x.replace(/&#x([0-9a-f]+);/gi, (m, h) => String.fromCodePoint(parseInt(h, 16)))
       .replace(/&#(\d+);/g, (m, d) => String.fromCodePoint(Number(d)))
       .replace(/&apos;/g, "'").replace(/&ldquo;|&rdquo;/g, '"').replace(/&lsquo;|&rsquo;/g, "'")
       .replace(/&hellip;/g, "\u2026").replace(/&ndash;/g, "\u2013").replace(/&mdash;/g, "\u2014");
  x = decodeEntities(x);
  x = x.replace(/<(script|style)\b[\s\S]*?<\/\1>/gi, " ").replace(/<br\s*\/?>/gi, " ").replace(/<\/p>/gi, " ");
  return cut(x.replace(/<[^>]+>/g, " "), 2000);
}

/** RSS 2.0 / Atom 通用解析（比 ai-model-radar 的 parseFeed 多出：媒体名、摘要、数字实体） */
export function parseRss(xml) {
  const out = [];
  const blocks = S(xml).match(/<(item|entry)\b[\s\S]*?<\/\1>/g) || [];
  for (const b of blocks) {
    const title = html2text((b.match(/<title[^>]*>([\s\S]*?)<\/title>/) || [])[1]);
    let url = "";
    const a1 = b.match(/<link[^>]*rel=["']alternate["'][^>]*href=["']([^"']+)["']/) || b.match(/<link[^>]*href=["']([^"']+)["']/);
    if (a1) url = decodeEntities(a1[1]);
    else url = html2text((b.match(/<link[^>]*>([\s\S]*?)<\/link>/) || [])[1]);
    const raw = (b.match(/<(pubDate|published|updated|dc:date|date)[^>]*>([\s\S]*?)<\/\1>/) || [])[2];
    const t = raw ? Date.parse(html2text(raw)) : NaN;
    if (!title || !Number.isFinite(t)) continue;
    out.push({
      title: title,
      url: url,
      date: new Date(t).toISOString(),
      ts: t,
      media: html2text((b.match(/<source[^>]*>([\s\S]*?)<\/source>/) || [])[1]),
      summary: html2text((b.match(/<(description|summary|content:encoded|content)[^>]*>([\s\S]*?)<\/\1>/) || [])[2]).slice(0, 400),
    });
  }
  return out;
}

/** Anthropic 官网没有 RSS，只能解析 Next.js 渲染出的新闻卡片 */
export function parseAnthropic(html) {
  const parts = S(html).split(/<a\b[^>]*href="\/news\//);
  const seen = new Set(), out = [];
  for (let i = 1; i < parts.length; i++) {
    const seg = parts[i].slice(0, 5000);
    const slug = (seg.match(/^([A-Za-z0-9._-]+)["']/) || [])[1];
    if (!slug || seen.has(slug)) continue;
    // 标题：优先 h1-h3；PublicationList 的列表项只有 <span class="...__title">，没有标题标签
    const title = html2text(
      (seg.match(/<h[1-3][^>]*>([\s\S]*?)<\/h[1-3]>/) || [])[1] ||
      (seg.match(/<[a-z]+[^>]*class="[^"]*(?:title|headline)[^"]*"[^>]*>([\s\S]*?)<\/[a-z]+>/i) || [])[1]
    );
    const dm = seg.match(/<time[^>]*>([\s\S]*?)<\/time>/);
    const t = dm ? Date.parse(html2text(dm[1])) : NaN;
    if (!title || !Number.isFinite(t)) continue;
    seen.add(slug);
    out.push({ title: title, url: "https://www.anthropic.com/news/" + slug, date: new Date(t).toISOString(), ts: t, media: "", summary: "" });
  }
  return out;
}

// ─────────────────── AI 相关性与主题分类 ───────────────────
const esc = (s) => s.replace(/[.*+?^{}()|[\]\\$]/g, (ch) => "\\" + ch);
const LATIN = AI_TERMS.en.filter((t) => /^[a-z0-9.\- ]+$/i.test(t)).sort((a, b) => b.length - a.length).map(esc).join("|");
const CJK = AI_TERMS.zh.map(esc).join("|");
export const AI_RE = new RegExp("(?:^|[^a-z0-9])(" + LATIN + ")(?:[^a-z0-9]|$)|(" + CJK + ")", "i");
export const isAI = (text) => AI_RE.test(S(text));

const RX = {
  funding: [/\b(raises?|raised|raising|funding|fund|financing|series [a-h]\b|valuation|valued at|seed|term sheet|backs|backed|invest(s|ed|ment|or)|acquir\w*|merger|merges|ipo|goes public|stake|unicorn|buyout)\b/i,
            /(融资|募资|轮融资|估值|领投|跟投|天使轮|种子轮|战略投资|收购|并购|入股|上市|IPO|增资|投资方|独角兽)/],
  people: [/\b(steps? down|resign(s|ed|ation)?|departs?|departure|leaves|joins?|joined|hires?|hired|appoints?|appointed|names .{0,24}(as )?(ceo|cto|coo|cro|head|chief)|poach\w*|layoffs?|lays off|restructur\w*|reorg\w*|board of directors|advis[eo]r)\b/i,
           /(离职|辞职|卸任|退任|加盟|加入|出任|任命|晋升|人事|裁员|组织架构|重组|高管|创始人|接任|挖角|跳槽|顾问)/],
  policy: [/\b(regulat\w+|regulator\w*|lawsuit|sues?|sued|court|judge|antitrust|export control\w*|sanction\w*|bill|legislation|act\b|compliance|guideline\w*|safety (rules|framework|board)|copyright|privacy|investigation|probe|fines?|fined|ban(s|ned|ning)?|policy)\b/i,
           /(监管|政策|法案|条例|法规|合规|诉讼|起诉|被诉|法院|判决|反垄断|出口管制|制裁|处罚|罚款|安全评估|备案|标准|版权|隐私|审查|禁令|约谈)/],
  chips: [/\b(gpu|gpus|cuda|tpu|npu|chip|chips|semiconductor|wafer|fab\b|hbm|data ?cent(er|re)s?|datacent\w*|compute cluster|supercomputer|inference cost|inference capacity|power (grid|demand|plant)|nvidia|broadcom|tsmc|amd|micron|asic)\b/i,
          /(芯片|算力|智算|数据中心|机房|显卡|英伟达|台积电|超算|集群|能耗|电力|存储|液冷|光模块|HBM|服务器|带宽)/],
  model: [/\b(launch\w*|release[sd]?|unveil\w*|introduc\w*|announc\w*|debut\w*|rolls? out|rolling out|ships?|now available|open[- ]?weight\w*|open[- ]?sourc\w*|model|models|chatbot|assistant|api\b|version \d|v\d+(\.\d+)?|benchmark\w*|upgrade\w*|preview|beta)\b/i,
           /(发布|上线|推出|开源|开放权重|公测|内测|正式版|预览版|升级|更新|模型|大模型|智能体|助手|接口|开放|新版)/],
  tech: [/\b(research\w*|paper|papers|study|studies|breakthrough|novel|technique|architecture|training method|algorithm\w*|benchmark\w*|dataset\w*|arxiv|reasoning|scaling laws?|state[- ]of[- ]the[- ]art|sota)\b/i,
          /(论文|研究|突破|技术|算法|架构|训练方法|数据集|基准|推理|预训练|微调|蒸馏|强化学习|开源框架|技术报告)/],
  biz: [/\b(partner\w*|deal|contract\w*|customer\w*|enterprise|revenue|pricing|subscription|cloud|deploy\w*|integrat\w*|licens\w*|expansion|market\w*|hiring)\b/i,
        /(合作|签约|客户|商业化|营收|价格|订阅|落地|部署|集成|授权|市场|生态|应用|订单|出海)/],
};

/** 主题分类：按优先级取第一个命中的类别（融资/人事/政策 > 算力 > 模型 > 技术 > 商业） */
export function classify(item) {
  const t = cut(S(item.title) + " " + S(item.summary), 300);
  for (const id of ["funding", "people", "policy", "chips", "model", "tech", "biz"]) {
    for (const rx of RX[id]) if (rx.test(t)) return id;
  }
  return "other";
}
export const themeName = (id) => ((THEMES.find((t) => t.id === id) || {}).name || id);

const GROUP_W = { official: 1.35, funding: 1.15, agg: 1.05, media: 1.0, cn: 1.0, news: 0.9 };
const THEME_BOOST = { funding: 1.6, model: 1.4, people: 1.3, chips: 0.9, policy: 0.8, tech: 0.3, biz: 0.2, other: 0 };

function scoreOf(it) {
  const base = (it.weight || 5) * (GROUP_W[it.group] || 1);
  const heat = it.heat ? Math.min(2, it.heat / 150) : 0;
  return Math.round((base + (THEME_BOOST[it.theme] || 0) + heat) * 100) / 100;
}

// ─────────────────────────── 去重 ───────────────────────────
export const normTitle = (t) => S(t).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
const urlKey = (u) => S(u).replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/[?#].*$/, "").replace(/\/+$/, "");

/** 同一件事会从多个渠道进来：按 URL、标题归一、短标题包含关系三级去重 */
export function dedupe(items) {
  const byUrl = new Map(), out = [];
  for (const it of items.slice().sort((a, b) => (b.score || 0) - (a.score || 0) || (b.ts || 0) - (a.ts || 0))) {
    const uk = urlKey(it.url);
    if (uk && byUrl.has(uk)) { const keep = byUrl.get(uk); (keep.also = keep.also || []).push({ source: it.source, url: it.url }); continue; }
    if (uk) byUrl.set(uk, it);
    out.push(it);
  }
  const kept = [];
  for (const it of out) {
    const nk = normTitle(it.title);
    if (nk.length < 8) { kept.push(it); continue; }
    let merged = false;
    for (const k of kept) {
      const kk = normTitle(k.title);
      if (kk === nk) { (k.also = k.also || []).push({ source: it.source, url: it.url }); merged = true; break; }
      const shorter = kk.length <= nk.length ? kk : nk;
      const longer = kk.length <= nk.length ? nk : kk;
      if (shorter.length >= 18 && longer.indexOf(shorter) >= 0) { (k.also = k.also || []).push({ source: it.source, url: it.url }); merged = true; break; }
    }
    if (!merged) kept.push(it);
  }
  return kept;
}

// ─────────────────────── 并发池 / 抓取 ───────────────────────
async function pool(tasks, limit) {
  const out = new Array(tasks.length);
  let i = 0;
  const n = Math.max(1, Math.min(limit || 6, tasks.length));
  await Promise.all(new Array(n).fill(0).map(async () => {
    for (;;) { const k = i++; if (k >= tasks.length) return; try { out[k] = await tasks[k](); } catch (e) { out[k] = { error: String((e && e.message) || e) }; } }
  }));
  return out;
}

/** 有些源无视 Accept-Encoding: identity 仍回 gzip（实测 deepmind.google/blog/rss.xml）→ 拿二进制自己解，否则 utf8 解码把字节毁掉 */
function bodyText(r) {
  const b = Buffer.isBuffer(r.body) ? r.body : Buffer.from(String(r.body || ""), "utf8");
  const enc = String((r.headers && (r.headers["content-encoding"] || r.headers["Content-Encoding"])) || "").toLowerCase();
  const gz = b.length > 2 && b[0] === 0x1f && b[1] === 0x8b;
  try {
    if (gz || enc.includes("gzip")) return zlib.gunzipSync(b).toString("utf8");
    if (enc.includes("deflate")) return zlib.inflateSync(b).toString("utf8");
    if (enc.includes("br")) return zlib.brotliDecompressSync(b).toString("utf8");
  } catch (e) { /* 解压失败就按原文处理 */ }
  return b.toString("utf8");
}

export async function fetchFeed(feed, opts = {}) {
  const t0 = Date.now();
  const r = await getBuffer(feed.url, { timeout: opts.timeout || 25000, retry: 1, headers: feed.headers });
  if (r.status !== 200) throw new Error("HTTP " + r.status);
  const text = bodyText(r);
  const rows = feed.parser === "anthropic" ? parseAnthropic(text) : parseRss(text);
  if (!rows.length) throw new Error("解析出 0 条（无 RSS / 页面结构可能变了）");
  return { rows: rows, ms: Date.now() - t0 };
}

/** 批量抓 RSS（并发池；单源失败只记缺口，不影响整体） */
export async function collectFeeds(opts = {}) {
  const ids = opts.only ? new Set(opts.only) : null;
  const feeds = FEEDS.filter((f) => !ids || ids.has(f.id));
  const since = opts.since || 0, items = [], sources = [], gaps = [];
  const results = await pool(feeds.map((f) => () => fetchFeed(f, opts)), opts.concurrency || 8);
  results.forEach((res, i) => {
    const f = feeds[i];
    if (!res || res.error) {
      sources.push({ id: f.id, name: f.name, group: f.group, status: "fail", count: 0, error: res && res.error });
      gaps.push("❌ " + f.name + "（" + f.id + "）：" + (res && res.error ? res.error : "未知错误") + " —— 该源本轮无数据");
      return;
    }
    let kept = 0, filtered = 0;
    for (const row of res.rows) {
      if (row.ts < since) continue;
      if (f.filter === "ai" && !isAI(row.title + " " + row.summary)) { filtered++; continue; }
      const it = {
        title: row.title, url: row.url, date: row.date, ts: row.ts, summary: row.summary || "",
        srcId: f.id, source: f.name, group: f.group, lang: f.lang, weight: f.weight,
      };
      it.theme = classify(it); it.score = scoreOf(it);
      items.push(it); kept++;
    }
    sources.push({ id: f.id, name: f.name, group: f.group, status: kept ? "ok" : "empty", count: kept, total: res.rows.length, filtered: filtered, ms: res.ms });
  });
  return { items: items, sources: sources, gaps: gaps };
}

// ─────────────── Google News / Bing News（关键词检索） ───────────────
export function gnUrl(q, days, locale) {
  const L = GN_LOCALE[locale] || GN_LOCALE.en;
  const query = q.replace("{d}", String(Math.max(1, days)));
  return "https://news.google.com/rss/search?q=" + encodeURIComponent(query) + "&hl=" + L.hl + "&gl=" + L.gl + "&ceid=" + L.ceid;
}

export async function collectGoogleNews(opts = {}) {
  const days = opts.days || 1;
  const focus = opts.focus;
  const langs = opts.newsLangs || ["en", "zh"];
  const extra = focus ? [{ id: "gn-focus", q: focus + " when:{d}d", weight: 10 }] : [];
  const items = [], sources = [], gaps = [];
  const tasks = [];
  for (const lang of langs) {
    for (const q of (NEWS_QUERIES[lang] || []).concat(lang === "en" ? extra : [])) tasks.push({ lang: lang, q: q });
  }
  const results = await pool(tasks.map((t) => async () => {
    const r = await get(gnUrl(t.q.q, days, t.lang), { timeout: 25000, retry: 1 });
    if (r.status !== 200) throw new Error("HTTP " + r.status);
    return parseRss(r.body);
  }), opts.concurrency || 4);
  results.forEach((rows, i) => {
    const t = tasks[i];
    if (!rows || rows.error) {
      sources.push({ id: t.q.id, name: "Google News：" + t.q.q.slice(0, 40), group: "news", status: "fail", count: 0, error: rows && rows.error });
      gaps.push("❌ Google News 查询失败（" + t.lang + "：" + t.q.q.slice(0, 60) + "）：" + (rows && rows.error ? rows.error : "?"));
      return;
    }
    let kept = 0;
    for (const row of rows) {
      if (row.ts < (opts.since || 0)) continue;
      const title = row.title.replace(/\s+-\s+[^-]{2,40}$/, "");
      // Google News 的 description 只是「标题 + 媒体名」，不是摘要 —— 与标题重复就丢弃（否则每行都拖一条废话）
      let sum = S(row.summary).replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
      if (row.media && sum.toLowerCase().endsWith(S(row.media).toLowerCase())) sum = sum.slice(0, sum.length - row.media.length).trim();
      if (sum.toLowerCase() === title.trim().toLowerCase()) sum = "";
      const it = {
        title: title, url: row.url, date: row.date, ts: row.ts, summary: sum,
        srcId: t.q.id, source: row.media || "Google News", group: "news", lang: t.lang,
        weight: t.q.weight, media: row.media || "",
      };
      it.theme = classify(it); it.score = scoreOf(it);
      items.push(it); kept++;
    }
    sources.push({ id: t.q.id, name: "Google News " + t.lang + "：" + t.q.q.slice(0, 36), group: "news", status: kept ? "ok" : "empty", count: kept, total: rows.length });
  });
  return { items: items, sources: sources, gaps: gaps };
}

export function bingRealUrl(link) {
  const m = S(link).match(/[?&]url=([^&]+)/);
  if (!m) return link;
  try { return decodeURIComponent(m[1]); } catch (e) { return link; }
}

export async function collectBingNews(opts = {}) {
  const qs = (opts.focus ? [{ id: "bing-focus", q: opts.focus }] : []).concat(BING_NEWS.queries);
  const items = [], sources = [], gaps = [];
  const results = await pool(qs.map((q) => async () => {
    const r = await get(BING_NEWS.url.replace("{q}", encodeURIComponent(q.q)), { timeout: 25000, retry: 1 });
    if (r.status !== 200) throw new Error("HTTP " + r.status);
    return parseRss(r.body);
  }), 2);
  results.forEach((rows, i) => {
    const q = qs[i];
    if (!rows || rows.error) {
      sources.push({ id: q.id, name: "Bing News：" + q.q, group: "news", status: "fail", count: 0, error: rows && rows.error });
      return;
    }
    let kept = 0;
    for (const row of rows) {
      if (row.ts < (opts.since || 0)) continue;
      const it = {
        title: row.title.replace(/\s+-\s+[^-]{2,40}$/, ""), url: bingRealUrl(row.url), date: row.date, ts: row.ts,
        summary: row.summary || "", srcId: q.id, source: row.media || "Bing News", group: "news", lang: "en", weight: BING_NEWS.weight,
      };
      it.theme = classify(it); it.score = scoreOf(it);
      items.push(it); kept++;
    }
    sources.push({ id: q.id, name: "Bing News " + q.q.slice(0, 30), group: "news", status: kept ? "ok" : "empty", count: kept, total: rows.length });
  });
  return { items: items, sources: sources, gaps: gaps };
}

// ─────────────────────────── 社区 ───────────────────────────
export async function collectHN(opts = {}) {
  const since = opts.since || 0;
  const days = opts.days || 1;
  const minPts = opts.minPoints || (days <= 1 ? 30 : days <= 3 ? 60 : 120);
  const url = "https://hn.algolia.com/api/v1/search?tags=story&numericFilters=created_at_i>" + Math.floor(since / 1000) + ",points>" + minPts + "&hitsPerPage=100";
  const r = await getJSON(url, { timeout: 25000, retry: 1 });
  const hits = (r.json && r.json.hits) || [];
  return hits.filter((h) => h.title && isAI(h.title)).map((h) => ({
    title: cut(h.title, 180), url: "https://news.ycombinator.com/item?id=" + h.objectID,
    article: h.url || "", points: h.points || 0, comments: h.num_comments || 0,
    date: new Date(h.created_at).toISOString(), ts: Date.parse(h.created_at),
  })).sort((a, b) => b.points - a.points);
}

export async function collectReddit(opts = {}) {
  const subs = opts.subs || REDDIT_SUBS;
  const days = Math.max(1, opts.days || 1);
  const since = opts.since || 0;
  const items = [], gaps = [], statuses = {};
  for (const sub of subs) {
    try {
      const r = await firehose(sub, { days: days, maxPages: 1, gapMs: 200 });
      let kept = 0;
      for (const p of (r.rows || [])) {
        const ts = (p.created_utc || 0) * 1000;
        if (ts < since) continue;
        if ((p.score || 0) < (opts.minScore || 5)) continue;
        items.push({
          title: cut(p.title, 200), url: p.permalink ? "https://www.reddit.com" + p.permalink : "https://www.reddit.com/r/" + p.subreddit + "/comments/" + p.id,
          sub: p.subreddit, score: p.score || 0, comments: p.num_comments || 0, date: new Date(ts).toISOString(), ts: ts,
          selftext: cut(p.selftext, 300),
        });
        kept++;
      }
      statuses[sub] = kept;
      if (!kept) gaps.push("⚠️ r/" + sub + "：窗口内无 ≥" + (opts.minScore || 5) + " 赞的帖子（该子版可能不活跃或改名）");
    } catch (e) { statuses[sub] = "err"; gaps.push("❌ Reddit r/" + sub + " 抓取失败：" + String((e && e.message) || e)); }
    await sleep(200);
  }
  return { items: items.sort((a, b) => b.score - a.score), statuses: statuses, gaps: gaps };
}

/** X：按天轮转取一部分账号（配额 30 次/15 分钟，账号时间线缓存 6h） */
export function pickAccounts(n, now) {
  const t1 = X_ACCOUNTS.filter((a) => a.tier === 1), t2 = X_ACCOUNTS.filter((a) => a.tier === 2);
  const day = Math.floor((now || Date.now()) / 86400000);
  const n1 = Math.max(1, Math.min(t1.length, Math.round(n * 0.75)));
  const n2 = Math.max(0, Math.min(t2.length, n - n1));
  const take = (arr, off, k) => { const o = []; for (let i = 0; i < k && i < arr.length; i++) o.push(arr[(off + i) % arr.length]); return o; };
  return take(t1, day % t1.length, n1).concat(take(t2, (day * 3) % Math.max(1, t2.length), n2));
}

export async function collectX(opts = {}) {
  const accounts = opts.accounts ? X_ACCOUNTS.filter((a) => opts.accounts.indexOf(a.acct) >= 0) : pickAccounts(opts.budget || 8, opts.now);
  const meta = new Map(accounts.map((a) => [a.acct.toLowerCase(), a]));
  const r = await rosterTweets({ tokens: [], core: [] }, { roster: accounts.map((a) => a.acct), concurrency: 3, query: "" });
  const since = opts.since || 0;
  const items = [], gaps = [];
  for (const t of (r.tweets || [])) {
    if (/^RT @/.test(t.text) || /^@/.test(t.text)) continue;
    const m = meta.get(S(t.user).toLowerCase());
    if (!m) continue; // syndication 时间线里会夹带被引用/相关的别家账号推文，只认名单内账号

    const ts = t.date ? Date.parse(t.date + "T12:00:00Z") : NaN;
    if (!Number.isFinite(ts) || ts < since) continue;
    if (!isAI(t.text)) continue;
    items.push({ user: t.user, name: m.name || t.name || t.user, kind: m.kind || "insider", text: cut(t.text, 400), url: t.url, likes: t.likes || 0, retweets: t.retweets || 0, replies: t.replies || 0, views: t.views || 0, date: t.date, ts: ts });
  }
  items.sort((a, b) => (b.likes + b.retweets * 2) - (a.likes + a.retweets * 2));
  const info = r.info || {};
  if (info.note) gaps.push("⚠️ X：" + info.note);
  const errs = Object.keys(info.statuses || {}).filter((k) => /err|HTTP|429|no-html/.test(S(info.statuses[k])));
  if (errs.length) gaps.push("⚠️ X 账号未取到：" + errs.join("、") + "（配额/缓存/风控，见 statuses）");
  return { items: items, statuses: info.statuses || {}, accounts: accounts.map((a) => a.acct), gaps: gaps };
}

/** 微信公众号（搜狗）：默认关闭，慢且易触发反爬 */
export async function collectWeixin(opts = {}) {
  const qs = opts.focus ? [{ id: "wx-focus", q: opts.focus, weight: 9 }] : WEIXIN_QUERIES;
  const items = [], gaps = [];
  const since = opts.since || 0;
  for (const q of qs) {
    try {
      const rows = await weixinBuzz(q.q, { limit: opts.limit || 6, resolve: 0 });
      let kept = 0;
      for (const it of rows) {
        const ts = it.date ? Date.parse(it.date) : NaN;
        if (Number.isFinite(ts) && ts < since) continue;
        items.push({ title: it.title, url: it.sogouUrl, account: it.account, summary: it.brief || "", date: it.date || "", ts: Number.isFinite(ts) ? ts : (opts.now || Date.now()), srcId: q.id, source: "微信公众号：" + (it.account || "?"), group: "cn", lang: "zh", weight: q.weight, theme: classify({ title: it.title, summary: it.brief }) });
        kept++;
      }
      if (!kept) gaps.push("⚠️ 微信公众号检索「" + q.q + "」窗口内无结果");
    } catch (e) { gaps.push("❌ 微信公众号检索「" + q.q + "」失败：" + String((e && e.message) || e)); }
    await sleep(600);
  }
  for (const it of items) it.score = scoreOf(it);
  return { items: items, gaps: gaps };
}

// ─────────────────────────── 汇总入口 ───────────────────────────
export async function collect(opts = {}) {
  const t0 = Date.now();
  const now = opts.now || Date.now();
  const days = opts.days == null ? 1 : Math.max(1, Number(opts.days) || 1);
  const since = now - days * 86400000;
  const o = Object.assign({}, opts, { days: days, since: since, now: now });
  const res = { asOf: new Date(now).toISOString(), days: days, focus: opts.focus || null, deep: !!opts.deep, items: [], buzz: { hn: [], reddit: [], x: [], weixin: [] }, sources: [], gaps: [], tookMs: 0 };

  const tasks = [];
  if (o.feeds !== false) tasks.push((async () => { const r = await collectFeeds(o); res.items.push.apply(res.items, r.items); res.sources.push.apply(res.sources, r.sources); res.gaps.push.apply(res.gaps, r.gaps); })());
  if (o.news !== false) tasks.push((async () => { const r = await collectGoogleNews(o); res.items.push.apply(res.items, r.items); res.sources.push.apply(res.sources, r.sources); res.gaps.push.apply(res.gaps, r.gaps); })());
  if (o.bing !== false) tasks.push((async () => { const r = await collectBingNews(o); res.items.push.apply(res.items, r.items); res.sources.push.apply(res.sources, r.sources); res.gaps.push.apply(res.gaps, r.gaps); })());
  if (o.hn !== false) tasks.push((async () => { try { res.buzz.hn = await collectHN(o); } catch (e) { res.gaps.push("❌ Hacker News 抓取失败：" + String((e && e.message) || e)); } })());
  if (o.reddit !== false) tasks.push((async () => { try { const r = await collectReddit(o); res.buzz.reddit = r.items; res.gaps.push.apply(res.gaps, r.gaps); res.buzz.__redditStatuses = r.statuses; } catch (e) { res.gaps.push("❌ Reddit 抓取失败：" + String((e && e.message) || e)); } })());
  if (o.x === true) tasks.push((async () => { try { const r = await collectX(o); res.buzz.x = r.items; res.buzz.__xAccounts = r.accounts; res.buzz.__xStatuses = r.statuses; res.gaps.push.apply(res.gaps, r.gaps); } catch (e) { res.gaps.push("❌ X 账号时间线抓取失败：" + String((e && e.message) || e)); } })());
  if (o.weixin === true) tasks.push((async () => { try { const r = await collectWeixin(o); res.buzz.weixin = r.items; res.gaps.push.apply(res.gaps, r.gaps); } catch (e) { res.gaps.push("❌ 微信公众号抓取失败：" + String((e && e.message) || e)); } })());
  await Promise.all(tasks);

  res.items.forEach((it) => { if (!it.theme) it.theme = classify(it); if (!it.score) it.score = scoreOf(it); });
  const before = res.items.length;
  res.items = dedupe(res.items);
  res.items.sort((a, b) => (b.score - a.score) || (b.ts - a.ts));
  res.stats = {
    fetched: before, kept: res.items.length, merged: before - res.items.length,
    byTheme: countBy(res.items, (it) => it.theme), byGroup: countBy(res.items, (it) => it.group),
    bySource: countBy(res.items, (it) => it.source).slice(0, 30),
    sourcesOk: res.sources.filter((s) => s.status === "ok").length, sourcesTotal: res.sources.length,
    community: { hn: res.buzz.hn.length, reddit: res.buzz.reddit.length, x: res.buzz.x.length, weixin: res.buzz.weixin.length },
  };
  res.tookMs = Date.now() - t0;
  return res;
}

function countBy(arr, fn) {
  const m = new Map();
  for (const x of arr) { const k = fn(x); m.set(k, (m.get(k) || 0) + 1); }
  return Array.from(m.entries()).map((e) => ({ key: e[0], n: e[1] })).sort((a, b) => b.n - a.n);
}

// ─────────────────────────── 渲染 ───────────────────────────
const fmtTime = (iso) => S(iso).slice(5, 16).replace("T", " ");
const esc1 = (s) => S(s).replace(/\|/g, "\\|");

export function byCompany(items) {
  const MAP = [
    ["OpenAI", /\bopenai|chatgpt|gpt-?\d|sora\b/i], ["Anthropic", /\banthropic|\bclaude\b/i],
    ["Google / DeepMind", /google|deepmind|gemini|gemma|alphabet|waymo/i], ["Meta", /\bmeta\b|llama|instagram|whatsapp/i],
    ["xAI", /\bxai\b|\bgrok\b/i], ["NVIDIA", /nvidia/i],
    ["Microsoft", /microsoft|azure|copilot/i], ["Apple", /\bapple\b|siri/i],
    ["Amazon / AWS", /amazon|\baws\b|alexa/i], ["DeepSeek", /deepseek|深度求索/i],
    ["Alibaba / Qwen", /alibaba|aliyun|qwen|通义|阿里/i], ["ByteDance", /bytedance|字节|doubao|豆包|tiktok/i],
    ["Tencent", /tencent|腾讯|混元|hunyuan/i], ["Baidu", /baidu|百度|ernie|文心/i],
    ["Moonshot / Kimi", /moonshot|kimi|月之暗面/i], ["Zhipu / GLM", /zhipu|智谱|\bglm\b/i],
    ["MiniMax", /minimax|海螺/i], ["Mistral", /mistral/i], ["Hugging Face", /hugging ?face/i],
    ["Stability / Midjourney", /stability ai|stable diffusion|midjourney/i],
  ];
  const out = [];
  for (const pair of MAP) {
    const hits = items.filter((it) => pair[1].test(it.title + " " + it.summary));
    if (hits.length) out.push({ company: pair[0], items: hits.slice(0, 6), n: hits.length });
  }
  return out.sort((a, b) => b.n - a.n);
}

export function renderMarkdown(res, opts = {}) {
  const o = Object.assign({ topN: 10, perTheme: 8, community: 5, companies: true, maxPerSource: 6 }, opts);
  const L = [];
  const it = res.items;
  L.push("# AI 圈新闻雷达 \u00b7 " + dayKey(Date.parse(res.asOf)));
  L.push("");
  L.push("> 窗口：近 " + res.days + " 天" + (res.focus ? " \u00b7 聚焦：「" + res.focus + "」" : "") + " \u00b7 采集于 " + res.asOf.slice(0, 16).replace("T", " ") + "Z");
  L.push("> 源 " + res.stats.sourcesOk + "/" + res.stats.sourcesTotal + " 成功 \u00b7 原始 " + res.stats.fetched + " 条 \u00b7 去重后 " + res.stats.kept + " 条（合并同题 " + res.stats.merged + " 条）\u00b7 社区 HN " + res.stats.community.hn + " / Reddit " + res.stats.community.reddit + " / X " + res.stats.community.x);
  L.push("> 本页是**确定性事实归集**（标题 + 时间 + 来源 + 链接），不含模型生成的解读；解读与摘要另附。");
  L.push("");
  L.push(TOC_PLACEHOLDER);
  L.push("");

  const mk = (list, n, opt) => {
    const cfg = opt || {};
    const capSrc = cfg.maxPerSource || o.maxPerSource;
    const out = [], perSrc = new Map(), perGroup = new Map();
    for (const x of list) {
      if (out.length >= n) break;
      const c = perSrc.get(x.source) || 0;
      if (c >= capSrc) continue;
      if (cfg.maxPerGroup && x.group !== "official") {
        const g = perGroup.get(x.group) || 0;
        if (g >= cfg.maxPerGroup) continue;
        perGroup.set(x.group, g + 1);
      }
      perSrc.set(x.source, c + 1);
      out.push(x);
    }
    return out;
  };

  L.push("## 要闻 Top " + o.topN);
  L.push("");
  mk(it, o.topN, { maxPerSource: o.maxPerSourceTop || 2, maxPerGroup: 3 }).forEach((x, i) => {
    L.push((i + 1) + ". **" + esc1(dispTitle(x)) + "** \u2014 " + x.source + " \u00b7 " + fmtTime(x.date) + " \u00b7 [链接](" + x.url + ")");
    const tags = [themeName(x.theme)];
    if (x.also && x.also.length) tags.push("另见 " + Array.from(new Set(x.also.map((a) => a.source))).slice(0, 3).join(" / "));
    L.push("   - " + tags.join(" \u00b7 "));
  });
  L.push("");

  for (const th of THEMES) {
    const list = it.filter((x) => x.theme === th.id);
    if (!list.length) continue;
    L.push("## " + th.name + "（" + list.length + " 条）");
    L.push("");
    mk(list, o.perTheme).forEach((x) => {
      L.push("- **" + esc1(dispTitle(x)) + "** \u2014 " + x.source + " \u00b7 " + fmtTime(x.date) + " \u00b7 [链接](" + x.url + ")" + (x.also && x.also.length ? "（另见 " + Array.from(new Set(x.also.map((a) => a.source))).slice(0, 2).join("/") + "）" : ""));
      const sm = dispSummary(x);
      if (sm) L.push("  - " + cut(sm, 160));
    });
    if (list.length > o.perTheme) L.push("- …另有 " + (list.length - o.perTheme) + " 条（用 --json 取全量）");
    L.push("");
  }

  const B = res.buzz;
  if (B.hn.length || B.reddit.length || B.x.length || B.weixin.length) {
    L.push("## 社区热议");
    L.push("");
    if (B.hn.length) {
      L.push("### Hacker News");
      B.hn.slice(0, o.community).forEach((x) => L.push("- **" + esc1(dispTitle(x)) + "**（\u2605" + x.points + " / " + x.comments + " 评论）\u2014 [HN](" + x.url + ")" + (x.article ? " \u00b7 [原文](" + x.article + ")" : "")));
      L.push("");
    }
    if (B.reddit.length) {
      L.push("### Reddit");
      B.reddit.slice(0, o.community).forEach((x) => L.push("- **" + esc1(dispTitle(x)) + "**（r/" + x.sub + " \u00b7 \u25b2" + x.score + " \u00b7 " + x.comments + " 评论）\u2014 [帖子](" + x.url + ")"));
      L.push("");
    }
    if (B.x.length) {
      L.push("### X（Twitter）");
      B.x.slice(0, o.community + 2).forEach((x) => L.push("- @" + x.user + "\uff08" + x.name + "\uff09：" + esc1(cut(x.text, 220)) + " \uff08\u2665" + x.likes + " \u21f2" + x.retweets + "\uff09\u2014 [链接](" + x.url + ")"));
      L.push("");
    }
    if (B.weixin.length) {
      L.push("### 微信公众号");
      B.weixin.slice(0, o.community).forEach((x) => L.push("- **" + esc1(dispTitle(x)) + "** \u2014 " + x.source + " \u00b7 " + (x.date || "") + " \u00b7 [搜狗跳转](" + x.url + ")"));
      L.push("");
    }
  }

  if (o.companies) {
    const comp = byCompany(it).slice(0, 8);
    if (comp.length) {
      L.push("## 按公司看");
      L.push("");
      comp.forEach((c) => L.push("- **" + c.company + "**（" + c.n + " 条）：" + c.items.map((x) => x.title.replace(/\|/g, "")).slice(0, 3).join("；")));
      L.push("");
    }
  }

  L.push("## 数据缺口 / 覆盖说明");
  L.push("");
  if (res.gaps.length) res.gaps.forEach((g) => L.push("- " + g));
  else L.push("- 本轮无源失败。");
  L.push("- 覆盖口径：官方博客（OpenAI / Anthropic / DeepMind / Google AI / HuggingFace / Qwen / NVIDIA …）+ 英文媒体 + 中文媒体（量子位 / 智东西 / 雷峰网 …）+ Google/Bing 关键词检索 + 社区（HN / Reddit / X）。");
  L.push("- 机器之心、新智元**没有可用的 RSS**（官网壳页 / 接口 404），中文覆盖靠量子位、智东西、雷峰网与 Google News 中文检索补；新智元只在微信公众号里，需 --wechat。");
  L.push("- Google News 的链接是 news.google.com 跳转链，**服务端还原不出发布方原始 URL**（base64 是 protobuf）；媒体名取自 <source>。要正文请用媒体名 + 标题自行检索，或改用 Bing News 那条（链接可还原）。");
  L.push("- X 只有账号时间线（syndication，30 次/15 分钟硬配额，缓存 6h），按天轮转取样；推文时间只精确到日。");
  L.push("- 本页由 ai-news-radar 自动汇总，仅为公开信息来源的整理，**不构成投资建议**；引用请注明采集时间。");
  return finalizeDoc(L.join("\n"), { skip: ["目录"] });
}

export function summarize(res) {
  const L = [];
  L.push("窗口 近" + res.days + "天 \u00b7 源 " + res.stats.sourcesOk + "/" + res.stats.sourcesTotal + " 成功 \u00b7 原始 " + res.stats.fetched + " \u2192 去重 " + res.stats.kept + "（合并 " + res.stats.merged + "）");
  L.push("主题分布：" + res.stats.byTheme.map((x) => themeName(x.key) + " " + x.n).join(" \u00b7 "));
  L.push("来源分布：" + res.stats.bySource.slice(0, 12).map((x) => x.key + " " + x.n).join(" \u00b7 "));
  L.push("社区：HN " + res.stats.community.hn + " \u00b7 Reddit " + res.stats.community.reddit + " \u00b7 X " + res.stats.community.x + " \u00b7 微信 " + res.stats.community.weixin);
  const fails = res.sources.filter((s) => s.status === "fail");
  if (fails.length) L.push("失败源：" + fails.map((s) => s.name + "(" + s.error + ")").join(" \u00b7 "));
  if (res.gaps.length) L.push("缺口：" + res.gaps.slice(0, 6).join(" | "));
  return L.join("\n");
}

/** 给 agent 的原料：条目 + 摘要 + 链接，用于挑选要深读的几条 */
export function brief(res, opts = {}) {
  const o = Object.assign({ perTheme: 6, community: 4 }, opts);
  const L = [];
  L.push("# AI 新闻雷达原料 \u00b7 " + dayKey(Date.parse(res.asOf)) + " \u00b7 近 " + res.days + " 天");
  L.push(summarize(res));
  L.push("");
  for (const th of THEMES) {
    const list = res.items.filter((x) => x.theme === th.id).slice(0, o.perTheme);
    if (!list.length) continue;
    L.push("## " + th.name);
    for (const x of list) {
      L.push("- " + x.title + " \u2014 " + x.source + " \u00b7 " + x.date.slice(0, 16).replace("T", " ") + " \u00b7 " + x.url);
      if (x.summary) L.push("  摘要：" + cut(x.summary, 200));
    }
    L.push("");
  }
  if (res.buzz.hn.length) { L.push("## HN"); res.buzz.hn.slice(0, o.community).forEach((x) => L.push("- " + x.title + "（\u2605" + x.points + " / " + x.comments + "）" + x.url)); L.push(""); }
  if (res.buzz.reddit.length) { L.push("## Reddit"); res.buzz.reddit.slice(0, o.community).forEach((x) => L.push("- r/" + x.sub + " \u25b2" + x.score + " " + x.title + " " + x.url)); L.push(""); }
  if (res.buzz.x.length) { L.push("## X"); res.buzz.x.slice(0, o.community + 2).forEach((x) => L.push("- @" + x.user + "：" + cut(x.text, 260) + " \u2665" + x.likes + " " + x.url)); L.push(""); }
  if (res.buzz.weixin.length) { L.push("## 微信公众号"); res.buzz.weixin.slice(0, o.community).forEach((x) => L.push("- " + x.title + " \u2014 " + x.source + " " + x.url)); L.push(""); }
  return L.join("\n");
}

// ─────────────────────────── 抓正文 & 落盘 ───────────────────────────
/** 抓一篇文章的正文纯文本，供 agent 提炼一句话摘要 / 判断真假 */
export async function fetchArticle(url, opts = {}) {
  if (/news\.google\.com\/rss\/articles/.test(url)) return { url: url, status: 0, error: "google-news-redirect", text: "" };
  const r = await get(url, { timeout: opts.timeout || 25000, retry: 1, headers: { Accept: "text/html,application/xhtml+xml" } });
  if (r.status !== 200) return { url: url, status: r.status, error: "HTTP " + r.status, text: "" };
  const html = S(r.body);
  const title = html2text((html.match(/<title[^>]*>([\s\S]*?)<\/title>/) || [])[1]);
  const m = html.match(/<article\b[\s\S]*?<\/article>/i) || html.match(/<main\b[\s\S]*?<\/main>/i) || html.match(/<body\b[\s\S]*?<\/body>/i);
  const text = html2text(m ? m[0] : html).slice(0, opts.chars || 3000);
  return { url: url, status: 200, title: title, text: text, chars: text.length };
}

/** ISO → 北京时间 `YYYY-MM-DD HH:MM`（采集时间用） */
const bjStamp = (iso) => {
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return "时间未知";
  const d = new Date(t + 8 * 3600 * 1000);
  const p = (n) => String(n).padStart(2, "0");
  return d.getUTCFullYear() + "-" + p(d.getUTCMonth() + 1) + "-" + p(d.getUTCDate()) + " " + p(d.getUTCHours()) + ":" + p(d.getUTCMinutes());
};

/** 条目时间 → 北京时间 `MM-DD HH:MM` */
const bjItem = (v) => {
  const t = typeof v === "number" ? v : Date.parse(v);
  if (!Number.isFinite(t)) return "时间未知";
  const d = new Date(t + 8 * 3600 * 1000);
  const p = (n) => String(n).padStart(2, "0");
  return p(d.getUTCMonth() + 1) + "-" + p(d.getUTCDate()) + " " + p(d.getUTCHours()) + ":" + p(d.getUTCMinutes());
};

/**
 * 全量 Markdown：把 res.items 里每一条按主题全部列出，**不截断、不抽样**。
 * 与 /root/workspace/json2radar_md.py 同一套规则（标题/时间/来源/摘要/另见 + 按来源 + 社区 + 缺口），
 * 改这里的排版时记得同步那个脚本，两边应能互相复算。
 */
export function renderFullMarkdown(res) {
  const items = res.items || [];
  const stats = res.stats || {};
  const com = stats.community || {};
  const buzz = res.buzz || {};
  const day = dayKey(Date.parse(res.asOf));
  const L = [];
  L.push("# " + DIGEST_PREFIX + " · 全量条目（" + day + "）");
  L.push("");
  L.push("> 由 ai-news-radar JSON 全量转出，**不截断**：每条含标题（原文链接）、北京时间、来源站点、摘要、另见来源。");
  L.push("> 采集于 " + bjStamp(res.asOf) + " · 窗口 " + res.days + " 天 · 源 " + stats.sourcesOk + "/" + stats.sourcesTotal +
    " 成功 · 原始 " + stats.fetched + " 条 → 去重 " + stats.kept + " 条（合并同题 " + stats.merged + " 条）· 社区 HN " +
    com.hn + " / Reddit " + com.reddit + " / X " + com.x);
  L.push("");

  const byTheme = new Map(THEMES.map((t) => [t.id, []]));
  for (const it of items) {
    const k = byTheme.has(it.theme) ? it.theme : "other";
    byTheme.get(k).push(it);
  }
  // 目录用 Obsidian 内部链接（[[#标题原文]]）：本机主读场景是 Obsidian 库，
  // GitHub 式 (#锚点) 与 Obsidian 的标题 normalize 规则不兼容（空格/标点处理不同），别换回去。
  L.push("## 目录");
  for (const th of THEMES) {
    const n = byTheme.get(th.id).length;
    if (!n) continue;
    L.push("- [[#" + th.name + "（" + n + " 条）]]");
  }
  L.push("- [[#按来源站点]]");
  L.push("- [[#社区热议]]");
  L.push("- [[#数据缺口]]");
  L.push("");

  const escT = (t) => S(t).replace(/\n/g, " ").replace(/\|/g, "｜").trim();
  for (const th of THEMES) {
    const group = byTheme.get(th.id);
    if (!group.length) continue;
    group.sort((a, b) => (b.ts || 0) - (a.ts || 0));
    L.push("## " + th.name + "（" + group.length + " 条）");
    L.push("");
    group.forEach((it, i) => {
      L.push((i + 1) + ". **[" + escT(dispTitle(it)) + "](" + it.url + ")**");
      const also = it.also || [];
      const extra = also.length ? "｜另见 " + also.map((a) => "[" + escT(a.source) + "](" + a.url + ")").join("、") : "";
      const meta = "（" + escT(it.source) + " · " + bjItem(it.ts || it.date) + "）" + extra;
      const summ = escT(dispSummary(it));
      L.push("   " + (summ ? summ + " " + meta : meta));
      L.push("");
    });
  }

  L.push("## 按来源站点");
  L.push("");
  const cnt = new Map();
  for (const it of items) cnt.set(it.source || "未知", (cnt.get(it.source || "未知") || 0) + 1);
  L.push("| 来源 | 条数 |");
  L.push("|---|---:|");
  for (const [s, n] of [...cnt.entries()].sort((a, b) => b[1] - a[1])) L.push("| " + escT(s) + " | " + n + " |");
  L.push("");

  L.push("## 社区热议");
  L.push("");
  L.push("> 热度信号，非事实来源。");
  L.push("");
  for (const key of ["hn", "reddit", "x", "weixin"]) {
    const arr = buzz[key] || [];
    if (!arr.length) continue;
    const label = { hn: "Hacker News", reddit: "Reddit", x: "X（Twitter）", weixin: "微信公众号" }[key] || key.toUpperCase();
    L.push("### " + label + "（" + arr.length + " 条）");
    L.push("");
    for (const b of arr) {
      if (!b || typeof b !== "object") continue;
      const title = S(b.title_zh || b.title || b.name || b.text || "");
      const url = b.url || b.link || "";
      let extra = "";
      if (b.points) extra += " ★" + b.points;
      if (b.score) extra += " ▲" + b.score;
      if (b.comments) extra += " · " + b.comments + " 条评论";
      if (b.sub) extra += " · r/" + b.sub;
      if (b.user) extra += " · @" + b.user;
      const art = b.article;
      L.push("- **" + escT(title) + "**" + extra + (url ? " — [讨论](" + url + ")" : "") + (art ? " ｜ [原文](" + art + ")" : ""));
    }
    L.push("");
  }

  L.push("## 数据缺口");
  L.push("");
  if ((res.gaps || []).length) res.gaps.forEach((g) => L.push("- " + escT(g)));
  else L.push("- 本轮无源失败。");
  L.push("");
  L.push("> 本页由 ai-news-radar 的 JSON 全量机械转出，仅为公开信息的确定性归集，不构成投资建议；Google News 条目为跳转链，正文核对请用媒体名 + 标题自行检索。");
  L.push("");
  return L.join("\n");
}

export function saveDigest(res, opts = {}) {
  const dir = opts.out ? (path.isAbsolute(opts.out) ? opts.out : path.resolve(process.cwd(), opts.out)) : DIGEST_DIR;
  const rawDir = opts.rawDir ? (path.isAbsolute(opts.rawDir) ? opts.rawDir : path.resolve(process.cwd(), opts.rawDir)) : RAW_DIR;
  fs.mkdirSync(dir, { recursive: true });
  fs.mkdirSync(rawDir, { recursive: true });
  const day = dayKey(Date.parse(res.asOf));
  const suffix = opts.focus ? "-" + String(opts.focus).replace(/[^\w\u4e00-\u9fa5]+/g, "").slice(0, 12) : "";
  const stamp = DIGEST_PREFIX + "_" + day + suffix;
  const md = path.join(dir, stamp + ".md");
  const quick = path.join(dir, stamp + "_速览.md");
  // JSON 是数据源，但**不放进笔记库**：只留档在 RAW_DIR，文件名就是 <日期>.json
  const js = path.join(rawDir, day + suffix + ".json");
  // 2026-11-14 用户定「JSON 不翻译」：JSON 只存原文，title_zh/summary_zh 只进内存与 md 渲染；
  // 剥离用副本，不改 res（md/速览渲染仍要用 _zh）。translateStats/proxy 是元数据，保留。
  // buzz 里除 hn/reddit/x/weixin 数组外还有 __xAccounts 等诊断字段（可能是对象），非数组原样保留
  const stripZh = (arr) => (Array.isArray(arr) ? arr.map((o) => { const { title_zh, summary_zh, ...rest } = o; return rest; }) : arr);
  const buzzRaw = {};
  for (const k of Object.keys(res.buzz || {})) buzzRaw[k] = stripZh(res.buzz[k]);
  const data = { asOf: res.asOf, days: res.days, focus: res.focus, stats: res.stats, gaps: res.gaps, sources: res.sources, items: stripZh(res.items), buzz: buzzRaw, translateStats: res.translateStats || null, proxy: res.proxy || null };
  // 顺序有讲究：先落 json（唯一数据源），再由它派生的全量 md / 速览 md。
  // 注意：JSON 已剥离译文，md 不能再「从 json 复算出中文标题」——复算会回落英文原文（dispTitle 优先 _zh、回落原 title）。
  fs.writeFileSync(js, JSON.stringify(data, null, 1), "utf8");
  fs.writeFileSync(md, opts.markdown || renderFullMarkdown(res), "utf8");
  let quickPath = null;
  if (opts.quick !== false) {
    fs.writeFileSync(quick, renderMarkdown(res, { topN: res.days > 2 ? 15 : 10, perTheme: res.days > 2 ? 12 : 8 }), "utf8");
    quickPath = quick;
  }
  return { dir: dir, md: md, quick: quickPath, json: js, rawDir: rawDir };
}
