// 人名保护表（薄转发层）
//
// 2026-11-15 用户定：真源放在 /root/workspace/tools/name-guard.mjs
// （数据文件 names-extra.json 同目录）。改代码请改 workspace 那份。
export * from "/root/workspace/tools/name-guard.mjs";
