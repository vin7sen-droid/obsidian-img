# -*- coding: utf-8 -*-
"""热评报告版式模板（用户 2026-11-09 定版「以后都这样」）。

用法：
    from report_style import CSS, TOC_JS, md_item_line
    # html: H.append('<style>'+CSS+'</style>') 或直接 '<style>'+CSS+'</style>'
    # html 结尾（</main></body></html> 之前）插入 TOC_JS
    # md: 用 md_item_line(header, body, time, url, src) 生成条目
"""

CSS = """*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:system-ui,-apple-system,'PingFang SC','Noto Sans SC',sans-serif;background:#f4f5f7;color:#222;line-height:1.78;padding:12px;font-size:16px;-webkit-text-size-adjust:100%}
main{max-width:720px;margin:0 auto}
header{background:linear-gradient(135deg,#1a2a4a,#2d4a7a);color:#fff;border-radius:14px;padding:20px 18px;margin-bottom:14px}
header h1{font-size:22px;margin-bottom:8px;line-height:1.5}
.meta{font-size:13px;opacity:.9;line-height:1.7}
.stats{display:flex;gap:10px;margin-top:12px;flex-wrap:wrap}
.stat{background:rgba(255,255,255,.14);border-radius:10px;padding:7px 13px;font-size:14px}
.stat b{font-size:17px}
.summary{background:#fff;border-radius:14px;padding:16px 16px;margin-bottom:14px;font-size:15.5px;line-height:1.8}
.summary h2{font-size:16.5px;color:#1a2a4a;margin-bottom:8px}
section{background:#fff;border-radius:14px;padding:16px 18px;margin-bottom:14px}
section h2{font-size:18.5px;color:#1a2a4a;margin-bottom:12px;padding-bottom:9px;border-bottom:1px solid #eef0f3;line-height:1.5}
section h3{font-size:15.5px;color:#555;margin:16px 0 10px;line-height:1.5}
.tag{font-size:12px;padding:2px 9px;border-radius:99px;vertical-align:2px;margin-left:6px}
.tag.ok{background:#e6f7ee;color:#0a7a43}.tag.warn{background:#fff4e0;color:#b26a00}
.tag.info{background:#e8f0fe;color:#1a56b0}.tag.off{background:#ececf0;color:#666}
.c{padding:9px 0;border-bottom:1px dashed #eef0f3}
.c:last-child{border-bottom:none}
.ch{font-size:14.5px;margin-bottom:5px;line-height:1.6}
.c p{font-size:16px;line-height:1.8;margin-top:4px}
.like{display:inline-block;font-size:12.5px;padding:2px 9px;border-radius:99px;margin-right:6px;font-weight:600}
.like.hi{background:#ffe8e8;color:#c0392b}.like.mid{background:#fff3d6;color:#a67c00}.like.lo{background:#f0f1f4;color:#666}
.toc{position:sticky;top:0;z-index:9;display:flex;gap:6px;flex-wrap:wrap;background:rgba(244,245,247,.94);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);padding:8px 2px;border-radius:10px;margin-bottom:12px;transition:transform .3s cubic-bezier(.22,.61,.36,1),opacity .25s ease;will-change:transform}
.toc a{font-size:13.5px;color:#1a2a4a;background:#fff;border:1px solid #e3e6ec;border-radius:99px;padding:6px 12px;text-decoration:none;line-height:1.6}
.toc a b{color:#c0392b;margin-left:3px;font-weight:600}
.toc.hide{transform:translateY(-118%);opacity:0;pointer-events:none}
.time{font-size:12.5px;color:#8b95a3;margin-left:6px;font-weight:400}
.src{font-size:13.5px;color:#1a56b0;text-decoration:none;display:inline-block;padding:2px 0}
.note{font-size:14.5px;color:#8a6d3b;background:#fffbf0;border-radius:8px;padding:10px 12px;margin-bottom:10px;line-height:1.75}
.fail{font-size:14.5px;color:#555;padding-left:18px;line-height:1.75}
.frow{padding:9px 0;border-bottom:1px dashed #eef0f3}
footer{text-align:center;font-size:12.5px;color:#999;padding:12px 0 24px}
.sum8 h3{font-size:16.5px;color:#0b2545;margin:20px 0 10px;padding-left:10px;border-left:3px solid #1d4e89;line-height:1.5}
.sum8 p{font-size:16px;margin-bottom:10px;line-height:1.8}
.sum8 table{width:100%;border-collapse:collapse;font-size:13.5px;margin:10px 0 12px;display:block;overflow-x:auto;white-space:nowrap}
.sum8 th{background:#eef3fa;color:#1d4e89;text-align:left;padding:7px 8px;font-weight:600;border-bottom:1px solid #dbe7f7}
.sum8 td{padding:6px 8px;border-bottom:1px solid #f2f3f6;vertical-align:top}
.sum8 tr:last-child td{border-bottom:none}
.sum8 .hl{background:#fff8e8}
.sum8 .num{font-variant-numeric:tabular-nums;text-align:right;white-space:nowrap}
.sum8 blockquote{background:linear-gradient(135deg,#0b2545,#1d4e89);color:#fff;border-radius:12px;padding:16px 17px;font-size:16px;line-height:1.85;margin-top:16px}
.sum8 .lead{font-size:14.5px;color:#8a6d3b;background:#fffbf0;border-left:3px solid #f0c36d;border-radius:6px;padding:10px 12px;margin-bottom:12px;line-height:1.75}
.sum8 ul{padding-left:20px;font-size:15.5px;line-height:1.8}
@media (max-width:600px){
  body{padding:10px;font-size:16.5px}
  header h1{font-size:21px}
  section h2{font-size:18px}
  .c p,.sum8 p{font-size:16.5px}
  .summary{font-size:16px}
  .toc{padding:6px 2px}
  .toc a{font-size:13px;padding:5px 10px}
  .sum8 table{font-size:13px}
}
.sum8 li{margin-bottom:5px}"""

TOC_JS = """<script>
(function(){var t=document.querySelector('.toc');if(!t)return;
var lastY=window.scrollY,raf=false;
function tick(){var y=window.scrollY;
if(y>lastY+8&&y>140){t.classList.add('hide')}else if(y<lastY-8||y<80){t.classList.remove('hide')}
lastY=y;raf=false}
window.addEventListener('scroll',function(){if(!raf){raf=true;requestAnimationFrame(tick)}},{passive:true});
})();
</script>"""


def md_item_line(head, body, time, u, src="原帖", clean=None):
    """md 条目：作者+赞数+正文一行，时间与链接缩进换行到第二行。"""
    c = clean or (lambda s: s)
    return f"- **{c(head)}** {c(body)}\n  `{time}` ｜ [{src}]({u})"
