#!/usr/bin/env python3
"""hotcomments.py — 按主题抓 B站高赞评论 + 微博热搜定位（全部匿名接口，免登录）
用法: python3 hotcomments.py "<主题>" [--videos 5] [--comments 8] [--out 输出.md]
"""
import os
import argparse, json, re, sys, time, urllib.request, urllib.parse, http.cookiejar, datetime


UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/124.0 Safari/537.36')

BILI_COOKIE_FILE = os.path.expanduser('~/.config/bili/cookies.json')

def load_bili_cookie():
    """读本地 B站 cookie（有则登录态抓评论，无则匿名）。存于 ~/.config/bili/cookies.json"""
    try:
        with open(BILI_COOKIE_FILE, encoding='utf-8') as f:
            ck = json.load(f)
        return '; '.join(f'{k}={v}' for k, v in ck.items())
    except Exception:
        return ''

BILI_CK = load_bili_cookie()

def make_opener():
    cj = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))

def get(opener, url, referer):
    h = {'User-Agent': UA, 'Referer': referer, 'Accept-Language': 'zh-CN,zh;q=0.9'}
    if BILI_CK and 'bilibili.com' in url:
        h['Cookie'] = BILI_CK
    req = urllib.request.Request(url, headers=h)
    return opener.open(req, timeout=20).read().decode('utf-8', 'ignore')

# ---------- B站 ----------
def bili_search(opener, kw):
    q = urllib.parse.quote(kw)
    d = json.loads(get(opener,
        f'https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword={q}',
        'https://www.bilibili.com/'))
    if d.get('code') != 0:
        return []
    out = []
    for v in d['data'].get('result', []):
        out.append({'aid': v['aid'],
                    'title': re.sub(r'<[^>]+>', '', v.get('title', '')),
                    'author': v.get('author', ''),
                    'play': v.get('play') or 0})
    return out

def bili_comments(opener, aid, topn, max_pages=3):
    """热门排序翻页抓评论。
    匿名：每视频仅 3 条根评论（平台限制）；有 cookie：ps=20 × pn 翻到空，实测约 39 条/视频，
    覆盖全部高赞主体（ps>20 报 -400 ps out of bounds）。"""
    out, seen = [], set()
    for pn in range(1, max_pages + 1):
        d = json.loads(get(opener,
            f'https://api.bilibili.com/x/v2/reply?type=1&oid={aid}&sort=1&ps=20&pn={pn}',
            'https://www.bilibili.com/'))
        if d.get('code') != 0:
            break
        arr = d.get('data', {}).get('replies') or []
        if not arr:
            break
        for r in arr:
            rid = r.get('rpid')
            if rid in seen:
                continue
            seen.add(rid)
            text = r['content']['message'].replace('\n', ' ')
            ts = datetime.datetime.fromtimestamp(
                int(r['ctime']), datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y-%m-%d %H:%M')
            out.append({'like': r.get('like', 0), 'user': r['member']['uname'],
                        'text': text, 'time': ts,
                        'url': f'https://www.bilibili.com/video/av{aid}#reply{rid}'})
        if pn < max_pages:
            time.sleep(0.7)
    out.sort(key=lambda x: -x['like'])
    return out[:topn]

# ---------- 微博 ----------
def weibo_hot(opener, kw):
    d = json.loads(get(opener, 'https://weibo.com/ajax/side/hotSearch', 'https://weibo.com/'))
    words = [w for w in re.split(r'[\s，。、！？/_-]+', kw) if len(w) >= 2]
    res = []
    for i, it in enumerate(d.get('data', {}).get('realtime', [])):
        w = it.get('word', '')
        if kw in w or any(t in w for t in words):
            res.append({'rank': i + 1, 'word': w, 'heat': it.get('num')})
    return res

# ---------- 主流程 ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('topic')
    ap.add_argument('--videos', type=int, default=5)
    ap.add_argument('--comments', type=int, default=8)
    ap.add_argument('--out', default=None)
    a = ap.parse_args()

    op = make_opener()
    try:
        get(op, 'https://www.bilibili.com/', 'https://www.bilibili.com/')  # 拿 buvid3
    except Exception:
        pass

    lines = [f'# {a.topic} — 高赞评论速览（{datetime.date.today()}）', '']
    print(f'== B站搜索「{a.topic}」==', file=sys.stderr)
    try:
        videos = sorted(bili_search(op, a.topic), key=lambda v: -v['play'])[:a.videos]
    except Exception as e:
        videos = []
        lines.append(f'B站搜索失败: {e}')
    for v in videos:
        url = f'https://www.bilibili.com/video/av{v["aid"]}'
        lines.append(f"## {v['title']}")
        lines.append(f"UP: {v['author']} ｜ 播放 {v['play']} ｜ [原视频]({url})")
        lines.append('')
        time.sleep(0.5)
        try:
            cs = bili_comments(op, v['aid'], a.comments)
        except Exception as e:
            cs = []
            lines.append(f'（评论抓取失败: {e}）')
        if not cs:
            lines.append('（暂无热评）')
        for c in cs:
            lines.append(f"- **[{c['like']}赞] {c['user']}**：{c['text']}（{c.get('time','时间未知')}） ｜ [链接]({c['url']})")
        lines.append('')
    print(f'== 微博热搜定位 ==', file=sys.stderr)
    try:
        hits = weibo_hot(op, a.topic)
    except Exception as e:
        hits = []
        lines.append(f'微博热搜获取失败: {e}')
    if hits:
        lines.append('## 微博热搜在榜')
        for h in hits:
            lines.append(f"- #{h['rank']} **{h['word']}**（热度 {h['heat']}）")
    else:
        lines.append('## 微博热搜在榜')
        lines.append('- 当前未在榜（热搜条目分钟级变化，话题出榜属正常）')
    report = '\n'.join(lines)
    print(report)
    if a.out:
        with open(a.out, 'w', encoding='utf-8') as f:
            f.write(report + '\n')
        print(f'\n已写入 {a.out}', file=sys.stderr)

if __name__ == '__main__':
    main()
