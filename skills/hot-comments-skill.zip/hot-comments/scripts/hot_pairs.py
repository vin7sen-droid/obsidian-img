#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""热评报告英中并注条目提取器（供 xcheck 机检送检用）。

用法: python3 hot_pairs.py <报告.md> [输出.json]
规则:
  - 抓取 `- **[N赞] 作者** 正文` 与 `  - ↳ **[N赞]** 正文` 两类条目行
  - 行尾配对的（……）视为中文译文，其余为英文原文
  - 剥离 X 元数据前缀「（推文，N 转发）」与「@user 」回复前缀（2026-11-16 实测 6/14 误报源）
  - 中文原文条目（en 侧 CJK 占比 >30%）跳过，不送检
  - 解释括号（如「（got fired 双关：…）」）保留在 en 侧之外：只取第一层译文括号
"""
import os, re, sys, json, tempfile

META = re.compile(r'^（推文[^）]*）\s*')
AT = re.compile(r'^@\S+\s+')

def cjk_ratio(s):
    s = s or ''
    if not s: return 0.0
    return sum(1 for c in s if '\u4e00' <= c <= '\u9fff') / len(s)

def split_pair(body):
    """行尾配对的（…）为译文；返回 (en, zh) 或 None"""
    body = body.strip()
    if not body.endswith('）'):
        return None
    depth = 0; start = None
    for i, ch in enumerate(body):
        if ch == '（':
            if depth == 0:
                start = i
            depth += 1
        elif ch == '）':
            depth -= 1
            if depth == 0:
                end = i
                # 只认最外层且必须顶到行尾
                if depth == 0 and end != len(body) - 1:
                    return None
                if start is None:
                    return None
                en = body[:start].strip()
                zh = body[start+1:end].strip()
                if en and zh:
                    return en, zh
                return None
    return None

def extract(md_path):
    items = []
    line_re = re.compile(r'^(\s*)- (?:↳ )?\*\*\[([\d,]+)赞\]([^*]*)\*\*\s*(.+)$')
    for ln, l in enumerate(open(md_path, encoding='utf-8'), 1):
        m = line_re.match(l.rstrip('\n'))
        if not m:
            continue
        who = m.group(3).strip()
        pair = split_pair(m.group(4))
        if not pair:
            continue
        en, zh = pair
        # 剥 X 元数据与 @ 前缀
        en2 = META.sub('', en)
        en2 = AT.sub('', en2)
        if cjk_ratio(en2) > 0.3:
            continue  # 中文原文条目
        if not re.search(r'[A-Za-z]{4,}', en2):
            continue
        items.append({'en': en2, 'zh': zh, 'who': who, 'line': ln})
    return items

if __name__ == '__main__':
    if len(sys.argv) < 2 or sys.argv[1].startswith("-"):
        sys.exit("用法: python3 hot_pairs.py <md 文件> [输出 json]")
    md = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(tempfile.gettempdir(), "hot_pairs_%d.json" % os.getpid())
    items = extract(md)
    json.dump(items, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'{md}: 提取 {len(items)} 对 → {out}')
