#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""发布前兜底校验：确认报告里没有漏译的条目。

用法：
    python3 check_untranslated.py <report.md> [more.md ...]

检查三项，任一命中即非零退出：
  1. 「（未译）」「[未译]」「TODO」「待译」等占位标记；
  2. 连续 3 行以上「拉丁字母占比 > 60% 且字符数 > 40」的正文段落
     （评论条目行、来源行、代码块、表格里的链接除外）；
  3. 条目正文里出现连续 8 个以上英文单词的句子（多半是原文没译）。

已知白名单：代码块、行内代码、链接、来源括注、英文原名作者名。
"""
import re
import sys

MASK = re.compile(r"`[^`]*`|\(https?://[^)]+\)|\[[^\]]*\]\([^)]*\)|\bhttps?://\S+")
PLACEHOLDER = re.compile(r"（未译）|\[未译\]|\(未译\)|TODO|待译|待翻译|{{.*?}}")
SKIP_LINE = re.compile(r"^\s*(#|>|\||-{3,}|\*{3,})")
CJK = re.compile(r"[\u4e00-\u9fff]")


def latin_ratio(s: str) -> float:
    letters = sum(1 for c in s if c.isalpha())
    latin = sum(1 for c in s if "a" <= c.lower() <= "z")
    return latin / letters if letters else 0.0


def check(path: str):
    problems = []
    lines = open(path, encoding="utf-8").read().split("\n")
    run = []
    for i, raw in enumerate(lines, 1):
        line = MASK.sub("", raw).strip()
        if not line:
            run = []
            continue
        if PLACEHOLDER.search(line):
            problems.append((i, "占位未译", raw.strip()[:80]))
            continue
        if re.match(r"^(?:- \*\*|\d+\. \*\*)", raw.strip()):
            # 条目行：主报告允许英中并注，但必须带中文
            body = re.sub(r"^-\s*\*\*.*?\*\*\s*", "", raw.strip(), count=1)
            if not CJK.search(MASK.sub("", body)):
                if len(re.findall(r"[A-Za-z][A-Za-z'-]+", body)) >= 4:
                    problems.append((i, "提示·条目无中文", raw.strip()[:80]))
            run = []
            continue
        if SKIP_LINE.match(raw.strip()) or raw.startswith(" "):
            run = []
            continue
        words = len(re.findall(r"[A-Za-z][A-Za-z'-]+", line))
        if len(line) > 60 and latin_ratio(line) > 0.7 and words >= 10 and not CJK.search(line):
            problems.append((i, "整行英文", line[:80]))
            run = []
        elif len(line) > 40 and latin_ratio(line) > 0.6:
            run.append(i)
            if len(run) == 2:
                problems.append((run[0], "连续英文段落", lines[run[0] - 1].strip()[:80]))
        else:
            run = []
    return problems


def main():
    if len(sys.argv) < 2 or sys.argv[1].startswith("-"):
        sys.exit(__doc__)
    hard_total = 0
    for p in sys.argv[1:]:
        probs = check(p)
        hard = [x for x in probs if not x[1].startswith("提示")]
        hard_total += len(hard)
        print(("✗ " if hard else "✓ ") + p + ("（硬失败 %d 处 / 提示 %d 处）" % (len(hard), len(probs) - len(hard))))
        for ln, kind, text in probs[:12]:
            print("   L%-5d %s：%s" % (ln, kind, text))
        if len(probs) > 12:
            print("   … 另有 %d 处（多为英中并注的英文原文条目，需人工确认是否漏译）" % (len(probs) - 12))
    sys.exit(1 if hard_total else 0)


if __name__ == "__main__":
    main()