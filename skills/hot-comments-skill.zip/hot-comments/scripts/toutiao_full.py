#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""toutiao_full.py — 今日头条评论区全量抓取（关键词 → 挖 gid → 逐篇翻页 → 去重排序）

用法:
  python3 toutiao_full.py "神舟二十四号 巴基斯坦 航天员" --outdir tt_data
  python3 toutiao_full.py "中国空间站 首位外籍航天员" --max-gids 40 --min-comments 1

输出:
  <outdir>/gids.json      挖到的 gid + 标题
  <outdir>/<gid>.json     每篇原始评论
  <outdir>/all.json       跨帖去重后的全部评论（按赞降序）
  <outdir>/summary.txt    各篇条数汇总
"""
import argparse, json, os, re, sys, time, datetime, urllib.request, urllib.parse

TZ = datetime.timezone(datetime.timedelta(hours=8))
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/124.0 Safari/537.36')

def get(url, referer='https://www.toutiao.com/'):
    req = urllib.request.Request(url, headers={
        'User-Agent': UA, 'Referer': referer, 'Accept-Language': 'zh-CN,zh;q=0.9'})
    return urllib.request.urlopen(req, timeout=25).read().decode('utf-8', 'ignore')

def comments_api(gid, offset=0, count=20, tab='hot'):
    url = (f'https://www.toutiao.com/article/v2/tab_comments/?aid=24&app_name=toutiao_web'
           f'&channel_id=0&group_id={gid}&item_id={gid}&tab_id={tab}'
           f'&count={count}&offset={offset}')
    req = urllib.request.Request(url, headers={
        'User-Agent': UA, 'Referer': f'https://www.toutiao.com/article/{gid}/',
        'Accept': 'application/json'})
    return json.load(urllib.request.urlopen(req, timeout=20))

def strip_tags(s):
    return re.sub(r'<[^>]+>', '', s or '')

def find_gids(keywords, per_kw_sleep=1.2):
    """多关键词走 SSR 搜索页，提取 'group_id' + 紧邻 title 配对"""
    found = {}
    for kw in keywords:
        q = urllib.parse.quote(kw)
        try:
            h = get(f'https://so.toutiao.com/search?dvpf=pc&keyword={q}&pd=synthesis')
            for m in re.finditer(r'"group_id"\s*:\s*"(\d{15,20})"', h):
                gid = m.group(1)
                if gid in found:
                    continue
                seg = h[m.end():m.end() + 3000]
                tm = re.search(r'"title"\s*:\s*"([^"]{5,160})"', seg)
                if tm:
                    found[gid] = strip_tags(tm.group(1))
            print(f'  [{kw}] 累计 {len(found)} 个 gid', file=sys.stderr)
        except Exception as e:
            print(f'  [{kw}] 搜索失败 {type(e).__name__}: {e}', file=sys.stderr)
        time.sleep(per_kw_sleep)
    return found

def fetch_all(gid, max_pages=30, sleep=0.6):
    """逐页翻到返回空为止（关键：不用固定页数猜）"""
    arr, offset, pages = [], 0, 0
    first = comments_api(gid, 0)
    batch = first.get('data') or []
    if not batch:
        return []
    arr += batch
    pages = 1
    offset = len(batch)
    while len(batch) >= 20 and pages < max_pages:
        time.sleep(sleep)
        batch = (comments_api(gid, offset).get('data') or [])
        if not batch:
            break
        arr += batch
        pages += 1
        offset += len(batch)
    return arr

def normalize(raw, gid, title):
    out = []
    for c in raw:
        cc = c.get('comment') or {}
        if not cc:
            continue
        u = cc.get('user') or {}
        name = cc.get('user_name') or u.get('name') or u.get('nickname') or '匿名'
        ts = cc.get('create_time')
        t = (datetime.datetime.fromtimestamp(int(ts), TZ).strftime('%Y-%m-%d %H:%M')
             if ts else '时间未知')
        out.append({
            'gid': gid, 'title': title,
            'u': name,
            'ip': cc.get('publish_loc_info') or '',
            'k': int(cc.get('digg_count') or 0),
            't': t,
            'x': strip_tags(cc.get('text')).replace('\n', ' ').strip(),
        })
    return out

JUNK = re.compile(r'^(图片评论|\[.{1,8}\]$|转发了|//@)')

def dedup(items):
    """同用户+正文前60字 去重，保留高赞那条"""
    seen, out = set(), []
    for c in sorted(items, key=lambda x: -x['k']):
        key = (c['u'], c['x'][:60])
        if key in seen:
            continue
        seen.add(key)
        if not c['x'] or len(c['x']) < 4 or JUNK.match(c['x']):
            continue
        out.append(c)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('keyword', help='主关键词')
    ap.add_argument('--extra-kw', nargs='*', default=[],
                    help='补充关键词（默认自动组合主题词变体）')
    ap.add_argument('--outdir', default='tt_data')
    ap.add_argument('--max-gids', type=int, default=40)
    ap.add_argument('--min-comments', type=int, default=1,
                    help='少于该条数的文章不写入 all.json')
    ap.add_argument('--max-pages', type=int, default=30)
    a = ap.parse_args()

    kw = [a.keyword] + a.extra_kw
    # 自动扩展：主词 + 拆词组合
    parts = [p for p in re.split(r'[\s　,，、]+', a.keyword) if len(p) >= 2]
    if len(parts) >= 2:
        kw.append(' '.join(parts[:2]))
        kw.append(' '.join(parts[-2:]))
    kw = list(dict.fromkeys(kw))

    os.makedirs(a.outdir, exist_ok=True)
    print(f'== 挖掘 gid（{len(kw)} 组关键词）==', file=sys.stderr)
    gids = find_gids(kw)
    gids = dict(list(gids.items())[:a.max_gids])
    json.dump(gids, open(f'{a.outdir}/gids.json', 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    print(f'共 {len(gids)} 个 gid\n', file=sys.stderr)

    allitems, summary = [], {}
    for i, (gid, title) in enumerate(gids.items(), 1):
        try:
            raw = fetch_all(gid, a.max_pages)
            items = normalize(raw, gid, title)
            json.dump(raw, open(f'{a.outdir}/{gid}.json', 'w', encoding='utf-8'),
                      ensure_ascii=False)
            allitems += items
            summary[gid] = {'title': title[:80], 'n': len(items)}
            print(f'[{i}/{len(gids)}] {len(items):4d} 条 | {title[:48]}', file=sys.stderr)
        except Exception as e:
            summary[gid] = {'title': title[:80], 'n': 0, 'err': str(e)[:80]}
            print(f'[{i}/{len(gids)}] FAIL {type(e).__name__} | {title[:40]}', file=sys.stderr)
        time.sleep(0.7)

    clean = dedup(allitems)
    clean = [c for c in clean if summary.get(c['gid'], {}).get('n', 0) >= a.min_comments]
    json.dump(clean, open(f'{a.outdir}/all.json', 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)

    lines = [f'原始 {len(allitems)} 条 → 去重过滤后 {len(clean)} 条', '']
    for gid, v in sorted(summary.items(), key=lambda kv: -kv[1]['n']):
        if v['n'] > 0:
            lines.append(f"{v['n']:4d} 条  {gid}  {v['title'][:60]}")
    open(f'{a.outdir}/summary.txt', 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    print('\n' + '\n'.join(lines))
    print(f'\n产出：{a.outdir}/all.json（含作者/IP/赞数/时间/正文/gid）')

if __name__ == '__main__':
    main()