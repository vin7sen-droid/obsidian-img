# hot-comments 技能包

按主题抓多平台高赞评论（B站/微博/头条/抖音/知乎/豆瓣/Reddit/YouTube/HN 等），产出带舆论总结的 md+html 报告（章节按总赞降序 + sticky 目录 + 逐条赞数/时间/来源链接）。任何识别 SKILL.md（Agent Skills 格式）的 AI 软件都能安装。

## 包内容
- SKILL.md —— 技能说明（AI 软件按它执行；含各平台已验证通道参数与版式规范）
- scripts/ —— 12 个脚本（评论抓取/头条全量/翻译机检/报告渲染），路径已自适应
- INSTALL.md —— 本文件

## 安装
| 软件 | 安装位置 |
|---|---|
| DSH（本包来源） | ~/.agents/skills/hot-comments/ |
| Claude Code | ~/.claude/skills/hot-comments/（或项目 .claude/skills/） |
| OpenClaw / OpenCode 等 | 各自的 skills 目录下建 hot-comments/，放入包内全部文件 |

## 环境要求
- python3 ≥3.10（纯标准库）+ node ≥18（zh.mjs 机翻打底、xcheck.mjs 数字交叉校验用）
- 报告落点：<OBSIDIAN_ROOT>/dsh/热点/（OBSIDIAN_ROOT 默认找 /sdcard/Obsidian，否则 ~/Obsidian）

## 凭据（全部可选，缺了自动降级）
| 凭据 | 路径（600 权限） | 用途 | 缺失时 |
|---|---|---|---|
| B站 cookie | ~/.config/bili/cookies.json | 登录态抓 B 站评论（80 条/视频） | 匿名 3 条/视频 |
| 翻译缓存 | ~/.dsh-ai-research/（自动建） | 机翻结果复用 | 每次真请求 |

## 降级差异
- 「精修队员」并行翻译是 DSH 多代理特性：其他软件里由主 agent 按 SKILL.md 的翻译规矩自己完成（机翻打底 zh.mjs → numcheck/xcheck 机检 → 人工过硬伤）。
- Tavily MCP 搜索边界是 DSH 特有：其他软件用自带的 web 搜索工具替代，只搜大方向不抓评论。
- 知乎英文镜像 / 韩日港台社区等通道墙与时点以 SKILL.md 内清单为准，失效通道按「宁可少而真」跳过。

## 更新
本包是 /root/workspace/（hotcomments.py、toutiao_full.py）与 /root/workspace/tools/ 真源的导出物；真源改动后需重新打包。
