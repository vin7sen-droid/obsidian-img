#!/usr/bin/env python3
"""把 ai-news-radar 的 items JSON 转成全量 Markdown（不截断）。

与插件内 lib.mjs 的 renderFullMarkdown() 同一套规则（主题顺序 / 条目格式 / 目录 / 按来源 / 社区 / 缺口），
两边应能互相复算——改排版时记得同步。

用法：
  python3 json2radar_md.py <雷达.json>                      # 默认落 Obsidian 新闻/AI radar，文件名 AI圈新闻雷达_<日期>.md
  python3 json2radar_md.py <雷达.json> --out <目录>          # 指定目录
  python3 json2radar_md.py <雷达.json> --stdout             # 只打印不写盘
  python3 json2radar_md.py <雷达.json> --name 前缀          # 改文件名前缀
"""
import os
import json, sys, os, datetime, collections

OBSIDIAN_ROOT = os.environ.get("OBSIDIAN_ROOT") or ("/sdcard/Obsidian" if os.path.isdir("/sdcard/Obsidian") else os.path.expanduser("~/Obsidian"))
DEFAULT_OUT = os.path.join(OBSIDIAN_ROOT, 'dsh', '新闻', 'AI radar')
DEFAULT_NAME = 'AI圈新闻雷达'

THEMES = [
    ('model',   '模型 / 产品发布'),
    ('funding', '融资 / 并购 / 估值'),
    ('chips',   '算力 / 芯片 / 基建'),
    ('tech',    '技术 / 研究'),
    ('people',  '人事 / 组织变动'),
    ('policy',  '政策 / 监管 / 法律'),
    ('biz',     '商业 / 合作 / 落地'),
    ('other',   '其它'),
]
BUZZ_NAME = {'hn': 'Hacker News', 'reddit': 'Reddit', 'x': 'X（Twitter）', 'weixin': '微信公众号'}


def bj(iso):
    """ISO UTC → 北京时间 YYYY-MM-DD HH:MM"""
    if not iso:
        return '时间未知'
    dt = datetime.datetime.strptime(iso[:19], '%Y-%m-%dT%H:%M:%S') + datetime.timedelta(hours=8)
    return dt.strftime('%Y-%m-%d %H:%M')


def _utc(v):
    """条目时间字段：epoch 毫秒(int) 或 ISO 字符串 → naive UTC datetime"""
    if isinstance(v, (int, float)):
        return datetime.datetime.fromtimestamp(v / 1000.0, datetime.timezone.utc).replace(tzinfo=None)
    return datetime.datetime.strptime(str(v)[:19], '%Y-%m-%dT%H:%M:%S')


def bj_short(v):
    if not v:
        return '时间未知'
    dt = _utc(v) + datetime.timedelta(hours=8)
    return dt.strftime('%m-%d %H:%M')


def esc(t):
    return (t or '').replace('\n', ' ').replace('|', '｜').strip()


def build(d):
    its = d.get('items') or []
    stats = d.get('stats') or {}
    gaps = d.get('gaps') or []
    buzz = d.get('buzz') or {}
    com = stats.get('community') or {}
    as_of = d.get('asOf') or ''
    # 日期取采集时刻的北京时间（不要用 items[0]['date']：那是条目时间，UTC 下会差一天）
    day = bj(as_of)[:10] if as_of else datetime.datetime.now().strftime('%Y-%m-%d')

    L = []
    L.append('# %s · 全量条目（%s）' % (DEFAULT_NAME, day))
    L.append('')
    L.append('> 由 ai-news-radar JSON 全量转出，**不截断**：每条含标题（原文链接）、北京时间、来源站点、摘要、另见来源。')
    L.append('> 采集于 %s · 窗口 %s 天 · 源 %s/%s 成功 · 原始 %s 条 → 去重 %s 条（合并同题 %s 条）· 社区 HN %s / Reddit %s / X %s' % (
        bj(as_of), d.get('days', 1), stats.get('sourcesOk'), stats.get('sourcesTotal'),
        stats.get('fetched'), stats.get('kept'), stats.get('merged'),
        com.get('hn'), com.get('reddit'), com.get('x')))
    L.append('')

    by_theme = collections.OrderedDict((k, []) for k, _ in THEMES)
    for it in its:
        by_theme.setdefault(it.get('theme') or 'other', []).append(it)

    # 目录：Obsidian 内部链接（本机主读场景是 Obsidian 库，GitHub 式 (#锚点) 与其 normalize 规则不兼容）
    L.append('## 目录')
    for k, name in THEMES:
        n = len(by_theme.get(k) or [])
        if n:
            L.append('- [[#%s（%d 条）]]' % (name, n))
    L.append('- [[#按来源站点]]')
    L.append('- [[#社区热议]]')
    L.append('- [[#数据缺口]]')
    L.append('')

    for k, name in THEMES:
        group = by_theme.get(k) or []
        if not group:
            continue
        group.sort(key=lambda it: it.get('ts') or 0, reverse=True)
        L.append('## %s（%d 条）' % (name, len(group)))
        L.append('')
        for i, it in enumerate(group, 1):
            # 译文优先：英文原文翻成中文后写 title_zh，原文留在 title（见 tools/ai-news-radar/translate.mjs）
            L.append('%d. **[%s](%s)**' % (i, esc(it.get('title_zh') or it.get('title')), it.get('url', '')))
            meta = '（%s · %s）' % (esc(it.get('source')), bj_short(it.get('ts') or it.get('date')))
            also = it.get('also') or []
            if also:
                extra = '、'.join('[%s](%s)' % (esc(a.get('source')), a.get('url')) for a in also)
                meta += '｜另见 %s' % extra
            summ = esc(it.get('summary_zh') or it.get('summary'))
            L.append('   %s %s' % (summ, meta) if summ else '   %s' % meta)
            L.append('')

    L.append('## 按来源站点')
    L.append('')
    by_src = collections.Counter(it.get('source') or '未知' for it in its)
    L.append('| 来源 | 条数 |')
    L.append('|---|---:|')
    for s, n in by_src.most_common():
        L.append('| %s | %d |' % (esc(s), n))
    L.append('')

    L.append('## 社区热议')
    L.append('')
    L.append('> 热度信号，非事实来源。')
    L.append('')
    for key in ('hn', 'reddit', 'x', 'weixin'):
        arr = buzz.get(key) or []
        if not arr:
            continue
        L.append('### %s（%d 条）' % (BUZZ_NAME.get(key, key.upper()), len(arr)))
        L.append('')
        for b in arr:
            if not isinstance(b, dict):
                continue
            title = b.get('title_zh') or b.get('title') or b.get('name') or b.get('text') or ''
            url = b.get('url') or b.get('link') or ''
            extra = ''
            if b.get('points'):
                extra += ' ★%s' % b['points']
            if b.get('score'):
                extra += ' ▲%s' % b['score']
            if b.get('comments'):
                extra += ' · %s 条评论' % b['comments']
            if b.get('sub'):
                extra += ' · r/%s' % b['sub']
            if b.get('user'):
                extra += ' · @%s' % b['user']
            art = b.get('article')
            tail = (' — [讨论](%s)' % url if url else '') + (' ｜ [原文](%s)' % art if art else '')
            L.append('- **%s**%s%s' % (esc(title), extra, tail))
        L.append('')

    L.append('## 数据缺口')
    L.append('')
    if gaps:
        for g in gaps:
            L.append('- %s' % esc(g))
    else:
        L.append('- 本轮无源失败。')
    L.append('')
    L.append('> 本页由 ai-news-radar 的 JSON 全量机械转出，仅为公开信息的确定性归集，不构成投资建议；Google News 条目为跳转链，正文核对请用媒体名 + 标题自行检索。')
    L.append('')
    return '\n'.join(L), day, len(its)


def main(argv):
    args = [a for a in argv[1:]]
    if not args or args[0] in ('-h', '--help'):
        print(__doc__)
        return 1
    src = args[0]
    out_dir, name, to_stdout = DEFAULT_OUT, DEFAULT_NAME, False
    i = 1
    while i < len(args):
        a = args[i]
        if a == '--out' and i + 1 < len(args):
            out_dir = args[i + 1]; i += 2
        elif a == '--name' and i + 1 < len(args):
            name = args[i + 1]; i += 2
        elif a == '--stdout':
            to_stdout = True; i += 1
        else:
            print('未知参数：%s' % a); return 1
    d = json.load(open(src, encoding='utf-8'))
    md, day, n = build(d)
    if to_stdout:
        sys.stdout.write(md)
        return 0
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, '%s_%s.md' % (name, day))
    open(out, 'w', encoding='utf-8').write(md)
    print('items:', n, '->', out)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))