// 转发层：真源在本技能包 scripts/xcheck.mjs（雷达链路与命令行工具共用一份实现）
export * from "../xcheck.mjs";
