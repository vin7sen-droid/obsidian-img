// ai-news-radar/coverage.mjs —— coverage 基准检查：防「静默丢数据」（借鉴另一管线 coverage.py 的设计）。
// 纯函数：不读文件、不写文件；读旧 JSON（上一轮落盘的雷达 digest）由调用方负责（见 cli.mjs）。
// 雷达 JSON 关键字段：items[]、stats:{sourcesOk,sourcesTotal,fetched,kept,merged,community:{hn,reddit,x}}、asOf、sources[]。

/**
 * 用上一轮（prevData）与本轮（curData）的雷达 JSON 对比，产出覆盖异常警告。
 * 三条规则：
 *   ① 条数骤减：cur.items.length < prev.items.length * 0.4
 *   ② 成功源骤减：prev.stats.sourcesOk - cur.stats.sourcesOk >= 8
 *   ③ 基准时间倒挂：prev.asOf > cur.asOf（旧 JSON 比本轮新，可能被并发覆盖）
 * prevData 为 null/undefined 时返回空 warns（首轮无基准，正常）。
 *
 * @param {object|null} prevData 上一轮 JSON（无基准传 null）
 * @param {object} curData 本轮 JSON
 * @returns {{warns: string[], prev: {items:number, sourcesOk:number, asOf:string}|null,
 *            cur: {items:number, sourcesOk:number, asOf:string}}}
 *   prev/cur.items 为条数（数组长度），sourcesOk 为成功源数，asOf 为基准时间字符串。
 */
export function coverageCheck(prevData, curData) {
  const shape = (d) => {
    if (!d || typeof d !== "object") return null;
    return {
      items: Array.isArray(d.items) ? d.items.length : 0,
      sourcesOk: Number(d.stats && d.stats.sourcesOk) || 0,
      asOf: String(d.asOf ?? ""),
    };
  };
  const cur = shape(curData);
  if (!cur) return { warns: [], prev: null, cur: { items: 0, sourcesOk: 0, asOf: "" } };
  const prev = shape(prevData); // null = 无基准

  const warns = [];
  if (prev) {
    // ① 条数骤减：本轮不足上一轮的 40%
    if (cur.items < prev.items * 0.4) {
      const pct = Math.round((1 - cur.items / prev.items) * 100);
      warns.push(`条数骤减：prev ${prev.items} → cur ${cur.items}（-${pct}%），疑似抓取残缺，建议重跑`);
    }
    // ② 成功源骤减：比上一轮少了 ≥ 8 个
    if (prev.sourcesOk - cur.sourcesOk >= 8) {
      warns.push(`成功源骤减：prev ${prev.sourcesOk} → cur ${cur.sourcesOk}`);
    }
    // ③ 基准时间倒挂：旧 JSON 比本轮还新（可能被并发覆盖）
    if (prev.asOf && cur.asOf && prev.asOf > cur.asOf) {
      warns.push("基准时间倒挂：旧 JSON 比本轮新，可能被并发覆盖");
    }
  }
  return { warns, prev, cur };
}
