// radar-proto/mustread.mjs —— 必看挑条打分（纯函数，无外部依赖，无 LLM）
// 借鉴 ai-news-daily mustread.py 的判定标准（影响面 × 信息增量 × 决策有用），
// 用启发式关键词 + 权威来源 + 跨源佐证打分，供速览两档与 review 报告共用。
// 挑 5 条时人工可再校准；这里是「自动打底、人工微调」的底座。

// 一线主体（公司/人物）：出现即加权
const BIG_ENTITIES = [
  "openai", "anthropic", "google", "deepmind", "nvidia", "meta", "microsoft",
  "apple", "amazon", "tesla", "xai", "字节", "阿里", "腾讯", "百度", "华为", "deepseek",
  "黄仁勋", "奥特曼", "奥尔特曼", "jensen huang", "sam altman", "dario amodei",
];

// 事件类别关键词 → 权重（影响面/信息增量/决策有用三维度合并）
const SIGNALS = [
  // 硬数字资本动作（$4.5B / 45亿美元 / 810亿 / 估值）
  { re: /[$€£¥₹]\s?\d|(\d[\d,.]*)\s*(billion|million|trillion)|\d+(\.\d+)?\s*(万亿|亿|百万)|valuation|估值|融资|raises?|raised?|funding|acquires?|acquisition|收购|并购|ipo|上市|share sale/i, w: 3, tag: "资本动作/硬数字" },
  // 监管从喊话升级到司法/执法
  { re: /lawsuit|sues?|sued|诉讼|起诉|antitrust|反垄断|probe|调查|ban(?:s|ned)?|禁令|regulator|监管|sec |doj |ftc |eu act|罚款|fine[d]?\b/i, w: 3, tag: "监管/司法" },
  // 改变竞争格局的产品/模型发布
  { re: /launch(?:es|ed)?|unveil(?:s|ed)?|releases?|introduc(?:es|ing)|发布|推出|Gemini \d|GPT-\d|Claude \d|Llama \d|Qwen\d|frontier model|旗舰|benchmark|sota|state-of-the-art/i, w: 2, tag: "产品/模型发布" },
  // CEO/高管级人事变动
  { re: /resign(?:s|ed)?|辞职|oust(?:ed|ing)?|离职|fired?|解雇|steps? down|卸任|new ceo|interim ceo|任命|appoints?/i, w: 3, tag: "人事变动" },
  // 大规模基建/算力
  { re: /gigawatt|gw\b|data ?center|数据中心|chip deal|芯片|gpu|算力|fab|晶圆|towers?|megawatt/i, w: 2, tag: "算力/基建" },
  // 安全事故/模型失控（低频但决策有用）
  { re: /safety incident|失控|jailbreak|越狱|hacked?|泄露|breach|malfunction|terrorist|deepfake|诈骗|scam/i, w: 2, tag: "安全事件" },
  // 创纪录/首次（信息增量）
  { re: /\bfirst\b|首个|首次|record|创纪录|largest|最大|biggest|破/i, w: 1, tag: "创纪录" },
];

// 权威来源（官方博客与一线媒体）加权
const TOP_SOURCES = /openai|anthropic|deepmind|google|nvidia|hugging ?face|qwen|bloomberg|reuters|ft|wsj|nytimes|cnbc|techcrunch|the information|the verge|wired|arstechnica|cnbeta|财联社|智东西|量子位|机器之心|新智元|it之家/i;

/** 单条打分：{score, tags[]} */
export function scoreItem(it) {
  const text = (it.title_zh || it.title || "") + " " + (it.summary_zh || it.summary || "");
  const src = it.source || "";
  let score = 0;
  const tags = [];
  for (const ent of BIG_ENTITIES) {
    if (text.toLowerCase().includes(ent)) { score += 2; tags.push("一线主体"); break; }
  }
  for (const s of SIGNALS) {
    if (s.re.test(text)) { score += s.w; tags.push(s.tag); }
  }
  if (TOP_SOURCES.test(src)) { score += 1; tags.push("权威源"); }
  const also = it.also && it.also.length ? it.also.length : 0;
  if (also >= 1) { score += Math.min(also, 3); tags.push("跨源佐证×" + also); }
  return { score, tags };
}

/**
 * 挑必看：按分数排序取前 n 条；平手按时间新→旧。
 * 同一来源最多 2 条（避免单源刷屏），同主题最多 3 条。
 * 返回 [{item, score, tags}]
 */
export function pickMustRead(items, opts = {}) {
  const n = opts.n || 5;
  const scored = (items || []).map((it) => ({ item: it, ...scoreItem(it) }))
    .filter((x) => x.score >= 3)               // 门槛：至少一线主体或一个强信号
    .sort((a, b) => (b.score - a.score) || ((b.item.ts || 0) - (a.item.ts || 0)));
  const out = [], perSrc = new Map(), perTheme = new Map();
  for (const x of scored) {
    if (out.length >= n) break;
    const s = perSrc.get(x.item.source) || 0;
    if (s >= 2) continue;
    const t = perTheme.get(x.item.theme) || 0;
    if (t >= 3) continue;
    perSrc.set(x.item.source, s + 1);
    perTheme.set(x.item.theme, t + 1);
    out.push(x);
  }
  return out;
}

/** 摘要关键信息加粗：硬数字与主体词，每条最多 3 处（借鉴日报 mustread 加粗约定） */
export function boldKey(text, max = 3) {
  if (!text) return text;
  let count = 0;
  // 硬数字（货币符/量级/百分比），已加粗的不重复包
  let out = String(text).replace(
    /(?<!\*\*)([$€£¥₹]?\s?\d[\d,.]*\s*(?:万亿|亿|万|billion|million|trillion|%|美元|美金|GW|吉瓦)|\d+(?:\.\d+)?%)(?!\*\*)/gi,
    (m) => (count++ < max ? "**" + m + "**" : m),
  );
  // 一线主体词加粗（剩余名额内）
  for (const ent of BIG_ENTITIES) {
    if (count >= max) break;
    const re = new RegExp("(?<!\\*\\*)(" + ent.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")(?!\\*\\*)", "i");
    if (re.test(out)) { out = out.replace(re, "**$1**"); count++; }
  }
  return out;
}
