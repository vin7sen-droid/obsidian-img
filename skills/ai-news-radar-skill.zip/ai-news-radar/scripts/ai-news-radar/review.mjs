// radar-proto/review.mjs —— 雷达 JSON 确定性 review 脚本（无 LLM）
//
// ⚠️ 确定性规则检查，结论供人工复核，不作自动修改。
//
// 四步检查：
//   1) 跨源同事件重复检测：标题字符 2-gram Jaccard ≥ 0.5 且 URL 不同 → 归组
//      （items 已做过同 URL 合并进 also[]，这里抓的是「措辞不同的同事件」）
//   2) 实体归一混用统计：固定变体表，标题里 ≥2 种变体同时出现才列出（不报警，供人工统一口径）
//   3) 分类边界抽查：三条规则找疑似放错主题的条目（可能合理，仅供人工复核）
//   4) 必看候选：复用 mustread.mjs 的 pickMustRead，取 top 8
//
// CLI：node review.mjs <json路径> [--out 报告.md]
//   无 --out 打印 stdout；--out 落 markdown（四大节）。
//
// 假阳/漏检观察（2026-11-20 实跑 ~/digests/2026-11-19.json，826 条）：
//  - 第③步 model 类 21 条里约半数是版式噪音假阳：新浪系标题尾部 tag 面包屑
//    （「|GPT-4o|RISC-V|CPU|ChatGPT|模型」）触发「模型」词；「周报/财报」聚合标题含「发布/推出」。
//    若要降噪，可先剥离标题最后一个「|」后的尾巴与「_手机新浪网」后缀再匹配。
//  - 第①步抓到的形态有两类真信号：a) FT 原链 vs Google News 跳转链同文未合并；
//    b) 同事件跨源措辞差异（如 Palo Alto 收购案 8 条横跨 funding/biz/other）——后者正是本步目标。
//  - 漏检（设计内取舍）：只比标题，标题改写大的同事件（如「Anthropic IPO」vs「OpenAI 竞对上市」）
//    Jaccard 到不了 0.5，抓不到；需人工或摘要级比对补。

import { pickMustRead } from "./mustread.mjs";
import fs from "node:fs";

/** 第③步降噪：剥新浪面包屑尾巴/站名后缀，聚合页标题直接跳过 */
function cleanTitle(t) {
  let s = String(t || "");
  s = s.replace(/_手机新浪网$/, "").replace(/_[^_|]*$/, (m, off, str) =>
    str.slice(0, off).includes("|") ? "" : m); // 仅当含面包屑「|」时剥最后一段
  const i = s.lastIndexOf("|");
  if (i >= 0) s = s.slice(0, i);
  return s.trim();
}
const AGG_RE = /周报|财报|日报|汇总|盘点|listing|roundup|一周|周末/i;

/* ---------------------------------------------------------------- 第 2 步实体表 */
// 变体写法混用统计表（canonical = 建议统一口径；variants 含全部已知写法）。
// 注：「黄光裕」是历史上腾讯引擎把 Huang 译错的真实案例，留在表里用于监测同类混用。
const ENTITY_TABLE = [
  { canonical: "黄仁勋", variants: ["黄仁勋", "Jensen Huang", "詹森·黄", "黄光裕"] },
  { canonical: "奥特曼", variants: ["奥特曼", "奥尔特曼", "Altman"] },
  { canonical: "Anthropic", variants: ["Anthropic", "Anthropic PBC"] },
  { canonical: "纳德拉", variants: ["纳德拉", "Nadella", "Satya Nadella"] },
  { canonical: "英伟达", variants: ["英伟达", "Nvidia", "NVIDIA", "辉达"] },
  { canonical: "马斯克", variants: ["马斯克", "Elon Musk", "马一龙"] },
  { canonical: "苏姿丰", variants: ["苏姿丰", "Lisa Su", "Lisa Su"] },
  { canonical: "OpenAI", variants: ["OpenAI", "Open AI", "openai"] },
  { canonical: "谷歌", variants: ["谷歌", "Google", "Alphabet"] },
  { canonical: "微软", variants: ["微软", "Microsoft"] },
  { canonical: "DeepSeek", variants: ["DeepSeek", "深度求索"] },
  { canonical: "扎克伯格", variants: ["扎克伯格", "Zuckerberg"] },
];

/* ---------------------------------------------------------------- 通用工具 */

/** 去空白与标点（全角半角），保留字母/数字/CJK */
function stripPunct(s) {
  return String(s || "").replace(/[^\p{L}\p{N}]/gu, "").toLowerCase();
}

/** 字符 2-gram 集合（中英混排都按字符切；去重后用于 Jaccard） */
function bigrams(s) {
  const t = stripPunct(s);
  if (t.length < 2) return new Set(t ? [t] : []);
  const set = new Set();
  for (let i = 0; i < t.length - 1; i++) set.add(t.slice(i, i + 2));
  return set;
}

function jaccard(a, b) {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const g of a) if (b.has(g)) inter++;
  return inter / (a.size + b.size - inter);
}

// 并查集
function ufFind(p, i) { while (p[i] !== i) { p[i] = p[p[i]]; i = p[i]; } return i; }
function ufUnion(p, a, b) { p[ufFind(p, a)] = ufFind(p, b); }

/* ---------------------------------------------------------------- 第 1 步：同事件重复 */

/**
 * 跨源同事件重复检测。
 * 返回 {pairs, groups}：pairs 全部命中对（调试用）；groups 是并查集归组结果，
 * 每组 {ids, maxJac, alsoLinked}，按组内最大重合度降序。
 */
export function detectDupes(items, { threshold = 0.5, maxGroups = 15 } = {}) {
  const grams = items.map((it) => bigrams(it.title_zh || it.title || ""));
  const pairs = [];
  for (let i = 0; i < items.length; i++) {
    if (grams[i].size < 3) continue; // 过短标题不参与（单字/两字没有可比性）
    for (let j = i + 1; j < items.length; j++) {
      if (items[i].url === items[j].url) continue; // URL 不同才比
      const jac = jaccard(grams[i], grams[j]);
      if (jac >= threshold) pairs.push({ i, j, jac });
    }
  }
  // 并查集归组
  const p = items.map((_, k) => k);
  for (const { i, j } of pairs) ufUnion(p, i, j);
  const byRoot = new Map();
  for (let k = 0; k < items.length; k++) {
    const r = ufFind(p, k);
    if (!byRoot.has(r)) byRoot.set(r, []);
    byRoot.get(r).push(k);
  }
  const groups = [];
  for (const ids of byRoot.values()) {
    if (ids.length < 2) continue;
    const inSet = new Set(ids);
    const inPairs = pairs.filter((x) => inSet.has(x.i) && inSet.has(x.j));
    // 组内是否已有 also 互挂（已合并/已挂「另见」的边）
    const alsoUrls = new Map(); // idx -> Set(also urls)
    for (const k of ids) {
      alsoUrls.set(k, new Set((items[k].also || []).map((a) => a.url)));
    }
    let alsoLinked = 0;
    for (const { i, j } of inPairs) {
      if (alsoUrls.get(i).has(items[j].url) || alsoUrls.get(j).has(items[i].url)) alsoLinked++;
    }
    groups.push({
      ids,
      maxJac: Math.max(...inPairs.map((x) => x.jac)),
      alsoLinked,
      edges: inPairs.length,
    });
  }
  groups.sort((a, b) => b.maxJac - a.maxJac || b.ids.length - a.ids.length);
  return { pairs, groups: groups.slice(0, maxGroups), groupCount: groups.length };
}

/* ---------------------------------------------------------------- 第 2 步：实体混用 */

/** 实体归一混用统计：每组统计标题里出现的变体；≥2 种才列出 */
export function entityMix(items, table = ENTITY_TABLE) {
  const titles = items.map((it) => String(it.title_zh || it.title || ""));
  const out = [];
  for (const ent of table) {
    const hits = new Map(); // 变体(合并同 lowercase 大小写形态) -> count
    for (const t of titles) {
      const low = t.toLowerCase();
      for (const v of ent.variants) {
        if (low.includes(v.toLowerCase())) {
          // 同一写法仅大小写不同的表内变体（如 Nvidia/NVIDIA）合并为一项
          const key = v.toLowerCase();
          const prev = [...hits.keys()].find((k) => k.toLowerCase() === key);
          const name = prev || v;
          hits.set(name, (hits.get(name) || 0) + 1);
        }
      }
    }
    if (hits.size >= 2) out.push({ canonical: ent.canonical, variants: hits });
  }
  return out;
}

/* ---------------------------------------------------------------- 第 3 步：分类边界 */

const THEME_RULES = [
  { name: "①疑似应归 funding", theme: "funding", re: /IPO|raises?|raised|funding|acquisition|acquire|估值|融资|收购|并购|上市/i },
  { name: "②疑似应归 policy", theme: "policy", re: /\b(lawsuit|sue[ds]?|suing|antitrust|SEC|FTC|DOJ|禁令|regulator|监管|调查)\b|诉讼|起诉|反垄断/i },
  { name: "③疑似应归 model", theme: "model", re: /\b(launch|unveil|releases|benchmark|LLM)\b|发布|推出|模型/i },
];

/** 分类边界抽查：每类返回全部命中（含限流后的展示列表） */
export function themeBoundary(items, { per = 5 } = {}) {
  const out = [];
  for (const rule of THEME_RULES) {
    const hits = [];
    for (const it of items) {
      if (!it.theme || it.theme === rule.theme) continue;
      const title = cleanTitle(String(it.title_zh || it.title || ""));
      if (!title || AGG_RE.test(title)) continue; // 降噪：聚合页/周报类跳过
      if (rule.re.test(title)) hits.push({ title, theme: it.theme, suggest: rule.theme, source: it.source || "" });
    }
    out.push({ ...rule, total: hits.length, list: hits.slice(0, per) });
  }
  return out;
}

/* ---------------------------------------------------------------- 第 4 步：必看候选 */

/** 必看候选：复用 mustread.mjs 的 pickMustRead */
export function mustRead(items, { n = 8 } = {}) {
  return pickMustRead(items, { n });
}

/* ---------------------------------------------------------------- 报告渲染 */

function esc(s) { return String(s ?? "").replace(/\|/g, "\\|"); }

function renderReport(res, results, meta) {
  const L = [];
  L.push(`# 雷达确定性 review 报告`);
  L.push("");
  L.push(`> ⚠️ **确定性规则检查，结论供人工复核，不作自动修改。**`);
  L.push("");
  L.push(`- 输入：\`${meta.jsonPath}\``);
  L.push(`- asOf：${res.asOf || "-"} ｜ items：${res.items.length} 条 ｜ buzz：${["hn", "reddit", "x", "weixin"].map((k) => `${k} ${(res.buzz[k] || []).length}`).join(" / ")}`);
  L.push(`- 生成时间：${meta.now}`);
  L.push("");

  // 一、跨源同事件重复
  L.push(`## 一、跨源同事件重复检测`);
  L.push("");
  L.push(`规则：标题字符 2-gram Jaccard ≥ ${meta.threshold} 且 URL 不同 → 归组。items 已做过同 URL 合并（进 also[]），这里抓的是「措辞不同的同事件」。`);
  L.push("");
  const dup = results.dupes;
  L.push(`**命中 ${dup.groupCount} 组，以下按组内最大重合度降序列前 ${dup.groups.length} 组。**`);
  L.push("");
  if (!dup.groups.length) {
    L.push("（无命中）");
  } else {
    dup.groups.forEach((g, gi) => {
      L.push(`### 组 ${gi + 1}（重合度 ${g.maxJac.toFixed(2)}，${g.ids.length} 条${g.alsoLinked ? `，组内 ${g.alsoLinked} 对已互挂 also` : ""}）`);
      L.push("");
      for (const k of g.ids) {
        const it = res.items[k];
        L.push(`- ${esc(it.title)}｜${esc(it.source)}｜theme=${it.theme}｜lang=${it.lang || "-"}`);
        L.push(`  <${it.url}>`);
      }
      L.push("");
      // 建议动作：组内含 Google News 跳转链且有原链 → 建议合并；否则人工确认
      const hasGN = g.ids.some((k) => /news\.google\.com/i.test(res.items[k].url || ""));
      const hasReal = g.ids.some((k) => !/news\.google\.com/i.test(res.items[k].url || ""));
      L.push(`**建议动作：${hasGN && hasReal ? "组内含 Google News 跳转链且已有原链 → 合并到原链（跳转链条目可降权）。" : "人工确认是否同一事件，若是可合并/互挂另见。"}**`);
      L.push("");
    });
  }

  // 二、实体归一
  L.push(`## 二、实体归一混用统计`);
  L.push("");
  L.push(`固定变体表 ${ENTITY_TABLE.length} 组；标题里 ≥2 种变体同时出现才列出。**混用统计，不报警，供人工统一口径。**`);
  L.push("");
  const mix = results.entity;
  if (!mix.length) {
    L.push("（无混用组）");
  } else {
    L.push(`**混用 ${mix.length} 组：**`);
    L.push("");
    L.push(`| 规范写法 | 出现的变体（次数） |`);
    L.push(`| --- | --- |`);
    for (const m of mix) {
      const vs = [...m.variants.entries()].map(([v, c]) => `${v}（${c}）`).join("、");
      L.push(`| ${m.canonical} | ${vs} |`);
    }
    L.push("");
  }

  // 三、分类边界
  L.push(`## 三、分类边界抽查`);
  L.push("");
  L.push(`**可能合理（如 IPO 兼具商业属性），仅供人工复核。**`);
  L.push("");
  const bd = results.boundary;
  const totalAll = bd.reduce((s, r) => s + r.total, 0);
  L.push(`三类合计疑似 **${totalAll}** 条：`);
  L.push("");
  for (const r of bd) {
    L.push(`### ${r.name}（命中 ${r.total} 条，列前 ${r.list.length}）`);
    L.push("");
    if (!r.list.length) {
      L.push("（无命中）");
    } else {
      L.push(`| 标题 | 实际 theme | 建议 theme | 来源 |`);
      L.push(`| --- | --- | --- | --- |`);
      for (const h of r.list) L.push(`| ${esc(h.title)} | ${h.theme} | ${h.suggest} | ${esc(h.source)} |`);
    }
    L.push("");
  }

  // 四、必看候选
  L.push(`## 四、必看候选（top ${results.must.length}）`);
  L.push("");
  L.push(`复用 mustread.mjs 的 pickMustRead（门槛 score≥3，同源≤2 条、同主题≤3 条）。`);
  L.push("");
  for (const m of results.must) {
    const it = m.item;
    L.push(`- **${esc(it.title)}** ｜ 分数 ${m.score} ｜ tags：${m.tags.join(" + ") || "-"}`);
    L.push(`  理由：${m.tags.join("；") || "无强信号"}`);
  }
  L.push("");
  L.push(`---`);
  L.push("");
  L.push(`*假阳/漏检观察记录在 review.mjs 头部注释。*`);
  return L.join("\n");
}

/* ---------------------------------------------------------------- main */

function usage() {
  console.error("用法：node review.mjs <json路径> [--out 报告.md]");
}

export async function main(argv) {
  const args = argv.filter((a) => a !== "--out");
  const outIdx = argv.indexOf("--out");
  const outPath = outIdx >= 0 ? argv[outIdx + 1] : null;
  const jsonPath = args[0];
  if (!jsonPath) { usage(); process.exit(2); }

  const raw = JSON.parse(fs.readFileSync(jsonPath, "utf8"));
  const res = {
    items: raw.items || [],
    buzz: raw.buzz || {},
    stats: raw.stats || {},
    asOf: raw.asOf || "",
  };

  const results = {
    dupes: detectDupes(res.items),
    entity: entityMix(res.items),
    boundary: themeBoundary(res.items),
    must: mustRead(res.items, { n: 8 }),
  };

  const meta = {
    jsonPath,
    now: new Date().toISOString(),
    threshold: 0.5,
  };

  const md = renderReport(res, results, meta);
  if (outPath) {
    fs.writeFileSync(outPath, md, "utf8");
    console.error(`[review] 报告已写入 ${outPath}（${md.length} 字符）`);
  } else {
    console.log(md);
  }

  // stdout 摘要（统计行，四步条数）
  const bd = results.boundary;
  console.log("");
  console.log(`==== review 统计（${jsonPath}） ====`);
  console.log(`① 同事件重复：${results.dupes.groupCount} 组（列前 ${results.dupes.groups.length} 组）`);
  console.log(`② 实体混用：${results.entity.length} 组（≥2 变体同现才列）`);
  console.log(`③ 分类边界：${bd.reduce((s, r) => s + r.total, 0)} 条疑似（三类各列前 5：${bd.map((r) => `${r.total}`).join("/")}）`);
  console.log(`④ 必看候选：${results.must.length} 条`);
  return results;
}

// CLI 入口（import 本模块时不执行）
import { fileURLToPath } from "node:url";
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  main(process.argv.slice(2)).catch((e) => { console.error(e); process.exit(1); });
}
