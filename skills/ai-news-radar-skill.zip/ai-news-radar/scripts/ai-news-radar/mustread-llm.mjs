// radar-proto/mustread-llm.mjs —— 必看终选：启发式预筛 + LLM 终选（用户 2026-11-20 指定 77/ywd/z-ai/glm-5.3-flash）
// 流程：pickMustRead 启发式打分取 top N（默认 12）→ LLM 按「影响面×信息增量×决策有用」终选 5 条。
// LLM 失败/超时/输出非法 → 静默回落启发式 top 5（绝不阻塞落盘）。
// 通道：magpie 网关 127.0.0.1:3425（OpenAI 兼容），key 明文 "magpie"（~/.dsh/.credentials.yaml CUSTOM_MAGPIE_API_KEY）。
// 实测（11-19 JSON 两轮）：同一 prompt 选出一致（1/2/4/10/12），耗时 107–142s —— 慢，cli 路径默认关，仅速览渲染显式开。

import { pickMustRead } from "./mustread.mjs";

const GATEWAY = process.env.MAGPIE_URL || "http://127.0.0.1:3425";
const KEY = process.env.MAGPIE_KEY || "magpie";
const MODEL = process.env.MAGPIE_MODEL || "77/ywd/z-ai/glm-5.3-flash";

/**
 * 必看终选。
 * @param {Array} items 雷达条目
 * @param {{n?: number, pool?: number, timeoutMs?: number, enabled?: boolean}} opts
 *   n=最终条数(5) pool=预筛候选数(12) enabled=false 时纯启发式
 * @returns {Promise<{list: Array<{item,score,tags,why?}>, engine: "llm"|"heuristic", elapsedMs: number}>}
 */
export async function pickMustReadLLM(items, opts = {}) {
  const n = opts.n || 5;
  const pool = opts.pool || 12;
  const timeoutMs = opts.timeoutMs || 120000;
  const t0 = Date.now();
  const cands = pickMustRead(items, { n: pool });
  const heurTop = cands.slice(0, n);
  if (opts.enabled === false || cands.length < 2) {
    return { list: heurTop, engine: "heuristic", elapsedMs: Date.now() - t0 };
  }
  try {
    const lines = cands.map((c, i) =>
      `${i + 1}. ${dispT(c.item)}（分 ${c.score}）`).join("\n");
    const prompt = `你是 AI 新闻编辑。候选 ${cands.length} 条（按打分降序）。挑必看 ${n} 条：不同事件优先（同一家公司同一场风波最多 2 条）、硬数字资本动作/监管司法/重大人事/大规模基建优先。\n只输出 JSON 数组：[{"n":编号,"why":"一句话理由"}] 恰好 ${n} 项。\n\n候选：\n${lines}`;
    const body = JSON.stringify({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
      max_tokens: 4000,
      reasoning_effort: "low",
    });
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    const resp = await fetch(GATEWAY + "/v1/chat/completions", {
      method: "POST",
      signal: ctrl.signal,
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + KEY },
      body,
    });
    clearTimeout(timer);
    if (!resp.ok) throw new Error("HTTP " + resp.status);
    const data = await resp.json();
    const content = (data.choices?.[0]?.message?.content || "").trim();
    // 提取首个 JSON 数组（容忍 ```json 围栏）
    const m = content.match(/\[[\s\S]*\]/);
    if (!m) throw new Error("no json array");
    const picks = JSON.parse(m[0]);
    if (!Array.isArray(picks) || picks.length < Math.min(3, n)) throw new Error("bad picks");
    const out = [];
    const used = new Set();
    for (const p of picks) {
      const idx = (p.n | 0) - 1;
      if (idx < 0 || idx >= cands.length || used.has(idx)) continue;
      used.add(idx);
      out.push({ ...cands[idx], why: String(p.why || "").slice(0, 80) });
      if (out.length >= n) break;
    }
    if (out.length < Math.min(3, n)) throw new Error("too few valid");
    return { list: out, engine: "llm", elapsedMs: Date.now() - t0 };
  } catch (e) {
    // 回落：启发式 top n（理由行标注回退原因，便于人工发现）
    return {
      list: heurTop.map((x) => ({ ...x, why: "LLM 终选失败回落启发式（" + String(e.message || e).slice(0, 40) + "）" })),
      engine: "heuristic",
      elapsedMs: Date.now() - t0,
    };
  }
}

function dispT(it) {
  return String(it.title_zh || it.title || "").replace(/\s+/g, " ").slice(0, 60);
}
