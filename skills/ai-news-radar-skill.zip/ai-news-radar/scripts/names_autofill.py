#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""人名表自动扩充 —— 从雷达 JSON 抽候选人名，查维基中文名，写进 names-extra.json。

背景：translate.mjs 的人名靠 name-guard.mjs 的 NAMES 表（238 条手工维护），表外的人名会被
腾讯/彩云随手音译（Jensen Huang 早年被译成「延森·黄」）。这个脚本把「新出现的人名」自动补上。

判定链路（每一步都能挡掉一类误报）：
  1. 从标题/摘要里抽「连续 2~3 个首字母大写的词」——候选人名，也包含公司名/地名
  2. 批量查 en.wikipedia：同时取 langlinks(zh) 与 description
  3. description 必须是人物类（businessman / executive / politician / (born 19xx) …）
     —— 公司（"American artificial intelligence company"）、动物（"Family of demersal cephalopod"）
     在这一步就掉出去
  4. 中文条目名不能等于英文原名（"Reality Labs" -> "Reality Labs" 说明没中文译名）
  5. 用 zh.wikipedia 的 varianttitles 转简体（维基中文名常是繁体：黃仁勳 -> 黄仁勋）
  6. 只把「表里没有的」写进 names-extra.json，不删不改已有条目

用法：
    python3 names_autofill.py                       # 用今天的 digests JSON
    python3 names_autofill.py <digest.json>         # 指定 JSON
    python3 names_autofill.py --dry                 # 只打印，不写文件
    python3 names_autofill.py --proxy ""            # 直连（默认走 127.0.0.1:7890）

产物：<插件>/tools/ai-news-radar/names-extra.json（name-guard.mjs 启动时合并进 NAMES）
"""
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

HOME = os.path.expanduser("~")
HERE = os.path.dirname(os.path.abspath(__file__))
DIGEST_DIR = os.environ.get("DSH_DIGESTS_DIR") or os.path.expanduser("~/digests")
EXTRA = os.path.join(HERE, "names-extra.json")
GUARD = os.path.join(HERE, "name-guard.mjs")
UA = {"User-Agent": "dsh-radar-names/1.0 (personal digest tool)"}

# 人物类描述：命中任一即认为条目是人
PERSON_RE = re.compile(
    r"\b(businessman|businesswoman|business executive|business magnate|executive|"
    r"politician|statesman|diplomat|engineer|scientist|researcher|physicist|"
    r"mathematician|economist|investor|entrepreneur|industrialist|technologist|"
    r"author|writer|journalist|professor|lawyer|attorney|academic|philosopher|"
    r"activist|founder|co-founder|CEO|chief executive|officer|banker|"
    r"computer scientist|software engineer|roboticist|neuroscientist|"
    r"born \d{4}|\(\s*born)\b", re.I)
# 非人物类描述：命中即排除（人物描述里偶尔也出现 company，所以只在没命中 PERSON_RE 时用）
ORG_RE = re.compile(
    r"\b(company|corporation|organization|organisation|firm|startup|"
    r"family of|species|genus|moth|fish|bird|plant|album|film|video game|"
    r"software|programming language|library|framework|university|institute|"
    r"agency|department|committee|party|team|league|stadium|city|town|"
    r"state|county|river|mountain|lake|island|building|museum)\b", re.I)

# 职位与机构短语：维基也有条目、description 也可能是人物组织，但绝不是「人名」
POSITION_RE = re.compile(
    r"^(chief |prime |deputy |assistant |vice |acting |former |senior |executive )|"
    r"(officer|minister|secretary|director|president|chairman|chairwoman|"
    r"department|ministry|bureau|agency|committee|council|association|"
    r"federation|institute|university|college|school|court|bank|fund|group|"
    r"office|administration|treasury|parliament|congress|senate)$", re.I)

CAND = re.compile(r"\b([A-Z][a-zA-Z'’\-]+(?:\s+[A-Z][a-zA-Z'’\-]+){1,2})\b")
# 明显不是人名的常见短语（省一次维基查询）
STOP = {
    "New York", "United States", "United Kingdom", "Silicon Valley", "Wall Street",
    "Hong Kong", "Los Angeles", "San Francisco", "White House", "Federal Reserve",
    "Supreme Court", "South Korea", "North Korea", "Saudi Arabia", "New Zealand",
    "Read More", "Read Also", "Sign In", "Privacy Policy", "Terms Of Service",
}


def opener(proxy):
    if not proxy:
        return urllib.request.build_opener()
    return urllib.request.build_opener(
        urllib.request.ProxyHandler({"http": proxy, "https": proxy}))


def get_json(op, url, tries=5):
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with op.open(req, timeout=25) as f:
                return json.loads(f.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            last = e
            # 429 是维基的软限流：等久一点，别把整批当「无条目」
            time.sleep(5.0 * (i + 1) if e.code == 429 else 1.5 * (i + 1))
        except Exception as e:  # noqa: BLE001 - 网络抖动统一重试
            last = e
            time.sleep(1.5 * (i + 1))
    print(f"  ! 请求失败：{url[:80]} … {type(last).__name__}: {last}", file=sys.stderr)
    return None


def chunks(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def pages_of(data):
    return ((data or {}).get("query") or {}).get("pages") or {}


def collect_candidates(path):
    d = json.load(open(path, encoding="utf-8"))
    texts = []
    for it in d.get("items") or []:
        texts.append(it.get("title") or "")
        texts.append(it.get("summary") or "")
    buzz = d.get("buzz") or {}
    for k in ("hn", "reddit", "x", "weixin"):
        for o in buzz.get(k) or []:
            if isinstance(o, dict):
                texts.append(o.get("title") or o.get("name") or o.get("text") or "")
    seen, out = set(), []
    for t in texts:
        for m in CAND.finditer(t):
            name = " ".join(m.group(1).split())
            if name in STOP or name in seen or POSITION_RE.search(name):
                continue
            seen.add(name)
            out.append(name)
    return out


def existing_pairs():
    """读 name-guard.mjs 的 NAMES 表，返回 {英文小写: 中文} 与英文集合。"""
    try:
        t = open(GUARD, encoding="utf-8").read()
    except OSError:
        return {}
    pairs = dict((m.group(1).lower(), m.group(2)) for m in
                 re.finditer(r'\[\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\]', t))
    return pairs


def load_extra():
    try:
        with open(EXTRA, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def main():
    args = [a for a in sys.argv[1:]]
    dry = "--dry" in args
    proxy = "http://127.0.0.1:7890"
    path = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--proxy":
            proxy = args[i + 1] if i + 1 < len(args) else ""
            i += 2
            continue
        if a == "--dry":
            i += 1
            continue
        if a.startswith("-"):
            print("未知选项：%s\n用法：names_autofill.py [digest.json] [--dry] [--proxy URL]" % a,
                  file=sys.stderr)
            return 2
        path = a
        i += 1
    if not path:
        today = time.strftime("%Y-%m-%d")
        path = os.path.join(DIGEST_DIR, today + ".json")
        if not os.path.exists(path):
            cands = sorted(f for f in os.listdir(DIGEST_DIR) if f.endswith(".json"))
            if not cands:
                print("没有可用的 digest JSON", file=sys.stderr)
                return 2
            path = os.path.join(DIGEST_DIR, cands[-1])
    if not os.path.exists(path):
        print("找不到 " + path, file=sys.stderr)
        return 2

    print(f"[1/4] 读 {path}")
    cands = collect_candidates(path)
    print(f"      候选（2~3 个首字母大写词）：{len(cands)} 个")

    op = opener(proxy)
    info = {}
    print(f"[2/4] 查英文维基（{len(list(chunks(cands, 50)))} 批，50/批）")
    for batch in chunks(cands, 50):
        u = ("https://en.wikipedia.org/w/api.php?action=query&prop=langlinks|description"
             "&lllang=zh&format=json&redirects=1&titles="
             + urllib.parse.quote("|".join(batch)))
        d = get_json(op, u)
        time.sleep(0.7)  # 维基对连续批量查询会 429，隔一下
        for _pid, p in pages_of(d).items():
            title = p.get("title") or ""
            ll = (p.get("langlinks") or [{}])[0].get("*") if p.get("langlinks") else None
            info[title] = {"zh": ll, "desc": p.get("description") or ""}

    known = existing_pairs()
    extra_old = load_extra()
    picked, stat = {}, {"无中文条目": 0, "描述不是人物": 0, "中文本名相同": 0, "表里已有": 0}
    for name, meta in info.items():
        zh, desc = meta["zh"], meta["desc"]
        if not zh:
            stat["无中文条目"] += 1
            continue
        if zh.strip().lower() == name.strip().lower():
            stat["中文本名相同"] += 1
            continue
        if POSITION_RE.search(name):
            stat["描述不是人物"] += 1
            continue
        if not PERSON_RE.search(desc) or (ORG_RE.search(desc) and not PERSON_RE.search(desc)):
            stat["描述不是人物"] += 1
            continue
        if name.lower() in known:
            stat["表里已有"] += 1
            continue
        picked[name] = zh

    print(f"[3/4] 转简体（{len(picked)} 条）")
    simp = {}
    for batch in chunks(list(picked.keys()), 20):
        zhs = [picked[n] for n in batch]
        u = ("https://zh.wikipedia.org/w/api.php?action=query&prop=info&inprop=varianttitles"
             "&variant=zh-cn&format=json&redirects=1&titles="
             + urllib.parse.quote("|".join(zhs)))
        d = get_json(op, u)
        time.sleep(0.7)
        rev = {}
        for _pid, p in pages_of(d).items():
            vt = (p.get("varianttitles") or {}).get("zh-cn")
            if vt:
                rev[p.get("title", "")] = vt
        for n in batch:
            simp[n] = rev.get(picked[n], picked[n])

    merged = dict(extra_old)
    added = 0
    for n, zh in sorted(simp.items()):
        if n not in merged:
            merged[n] = zh
            added += 1

    print(f"[4/4] 跳过原因：{stat}")
    if not added:
        print("没有新增人名。")
        return 0
    print(f"新增 {added} 条（累计 {len(merged)}）：")
    for n, zh in sorted(simp.items()):
        if n not in extra_old:
            print(f"  {n:28s} -> {zh}")
    if dry:
        print("\n--dry：未写文件")
        return 0
    os.makedirs(os.path.dirname(EXTRA), exist_ok=True)
    tmp = EXTRA + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(merged, f, ensure_ascii=False, indent=1, sort_keys=True)
        f.write("\n")
    os.replace(tmp, EXTRA)
    print(f"\n已写入 {EXTRA}")
    print("提示：改人名表后要清翻译缓存才会重新生效 —— "
          "cp -p ~/.dsh-ai-research/translate-cache.json ~/digests/ && echo '{}' > ~/.dsh-ai-research/translate-cache.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())