#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""radar_semantic.py —— 雷达线语义初筛适配器（清单制，不阻断落盘）

读雷达 JSON（须含 title_zh，2026-11-20 起 saveDigest 保留译文），把全部英文源条目的
标题对（en=title, zh=title_zh）送 semantic_check.py 的 LLM 初筛，人工审清单落
<JSON 同目录>/<日期>_semantic_人工审.md（与 xcheck 的 _人工审.md 同目录惯例，不进笔记库）。

用法:
    python3 radar_semantic.py <digest.json> [--out 清单.md]
    python3 radar_semantic.py --self          # 等价 semantic_check --self-test

- 英文判据：标题含 ≥6 连续拉丁字母且 CJK 占比 <30%（与 11-17 抽检基线一致）
- 无 title_zh 的条目跳过（旧版 JSON 无译文时 pairs=0，提示改跑新版）
- 语义初筛只出清单；语义错由人终审（机检只抓已知的错，见长记忆「机检天花板」）
"""
import importlib.util
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
_lat6 = re.compile(r"[A-Za-z]{6,}")


def _load_sem():
    spec = importlib.util.spec_from_file_location("semantic_check", os.path.join(HERE, "semantic_check.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _cjk_ratio(s):
    if not s:
        return 0.0
    cjk = sum(1 for c in s if "\u4e00" <= c <= "\u9fff")
    return cjk / max(len(s), 1)


def build_pairs(data):
    pairs = []
    for it in data.get("items") or []:
        en = (it.get("title") or "").strip()
        zh = (it.get("title_zh") or "").strip()
        if not en or not zh:
            continue
        if not _lat6.search(en):
            continue
        if _cjk_ratio(en) >= 0.3:  # 中文源条目
            continue
        pairs.append({"en": en, "zh": zh})
    return pairs


def write_review_list(out_path, flags, pairs, label):
    lines = [
        "# 语义初筛人工审（%s）" % label,
        "",
        "> 雷达线 LLM 语义初筛（semantic_check.py）；只列 flagged，语义错终审归人工。",
        "> 五类判定：语义偏差 / 数字量级 / 术语错 / 严重不通顺 / 方向性习语。",
        "",
        "| # | 类型 | 理由 | 中文标题（译文） | 英文标题（原文） |",
        "|---|---|---|---|---|",
    ]
    for f in flags:
        idx = f.get("idx")
        src = pairs[idx - 1] if isinstance(idx, int) and 0 <= idx - 1 < len(pairs) else {}
        why = str(f.get("why") or "").replace("|", "\\|").replace("\n", " ")
        zh = str(src.get("zh") or "").replace("|", "\\|")
        en = str(src.get("en") or "").replace("|", "\\|")
        lines.append("| %s | %s | %s | %s | %s |" % (idx, f.get("type"), why, zh, en))
    if not flags:
        lines.append("（无 flagged 条目）")
    lines.append("")
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))


def main():
    if len(sys.argv) < 2 or sys.argv[1].startswith("-h"):
        print(__doc__)
        sys.exit(2)
    if sys.argv[1] == "--self":
        sys.exit(_load_sem().self_test())
    js = sys.argv[1]
    data = json.load(open(js, encoding="utf-8"))
    pairs = build_pairs(data)
    out = None
    if "--out" in sys.argv:
        out = sys.argv[sys.argv.index("--out") + 1]
    if not out:
        day = (data.get("asOf") or "")[:10] or "unknown"
        out = os.path.join(os.path.dirname(os.path.abspath(js)), day + "_semantic_人工审.md")
    if not pairs:
        print("[semantic] 0 对可检（JSON 无 title_zh？旧版 JSON 需重跑生成），跳过")
        sys.exit(0)
    sem = _load_sem()
    flags = sem.run(pairs, os.path.basename(js))
    if flags is None:
        print("[semantic] 全批失败，跳过（不阻断）")
        sys.exit(0)
    write_review_list(out, flags, pairs, os.path.basename(js))
    print("[semantic] %d 对，flagged %d → 清单：%s" % (len(pairs), len(flags), out))


if __name__ == "__main__":
    main()
