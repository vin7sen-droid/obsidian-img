# 安装 ai-news-radar（AI 圈新闻雷达）

零 npm 依赖，只要 **Node ≥ 18**（RSS/检索/翻译/落盘全在 `.mjs` 里）；语义初筛与摘要机检可选装 `python3`。

## 1. 装进 DSH

```bash
mkdir -p ~/.agents/skills && cp -r ai-news-radar ~/.agents/skills/
```

## 2. 装进 Claude Code

```bash
mkdir -p ~/.claude/skills && cp -r ai-news-radar ~/.claude/skills/     # 用户级
# 或项目级：cp -r ai-news-radar <项目>/.claude/skills/
```

## 3. 装进 OpenClaw / OpenCode / 其它认 SKILL.md 的软件

把整个目录放进它的 skills 目录（OpenClaw `~/.openclaw/skills/`，OpenCode `~/.config/opencode/skills/`）；
不认目录的软件，把 SKILL.md 的内容作为系统提示装载，并保持 `scripts/` 与它同级即可。

## 4. 验证

```bash
cd <本技能目录>/scripts
node ai-news-radar/cli.mjs --list-sources     # 列出全部源 id（离线）
node ai-news-radar/cli.mjs --days 1           # 真跑一轮
```

成功标志：终端打印日报、`<OBSIDIAN_ROOT>/dsh/新闻/AI radar/` 下出现 `AI圈新闻雷达_<日期>.md` 与 `_速览.md`。

## 5. 路径与开关

| 项 | 默认 | 覆盖 |
|---|---|---|
| Obsidian 库根 | 手机 `/sdcard/Obsidian`，否则 `~/Obsidian` | `OBSIDIAN_ROOT` |
| 笔记目录 | `<库根>/dsh/新闻/AI radar/` | `DSH_AI_RESEARCH_OUT` / `--out` |
| JSON 存档 | `~/digests/` | `DSH_AI_RESEARCH_RAW` |
| 运行期状态（cookie/缓存/熔断） | `~/.dsh-ai-research/` | `DSH_AI_RESEARCH_HOME` |
| 出网代理 | 探测 7890 → 3067 → 直连 | `DSH_AI_RESEARCH_PROXY` / `=off` |
| mihomo 目录（自动拉起） | `~/opt/mihomo` | `MIHOMO_DIR` |

## 6. 可选能力与降级（缺了不影响主产物）

| 能力 | 需要 | 缺失时 |
|---|---|---|
| X 账号时间线 | 可出网的网络（或代理） | 该源 0 条，「数据缺口」里声明 |
| Reddit 社区热议 | 直连（走 arctic-shift 归档） | 同上 |
| 微信公众号 | `--deep` + 可出网 | 同上 |
| 全文抓取（`--fetch`） | 可出网 | 失败跳过，摘要用 feed 描述 |
| 语义初筛 `radar_semantic.py` | `python3` + LLM 凭据 `~/.config/tagllm/{key,base}` | 跳过初筛，清单不生成 |
| 机器翻译 | 无（腾讯通道免费） | 翻译失败保留原文，`--no-translate` 可关 |
| 交叉校验 `xcheck.mjs` | 无（彩云通道免费） | 退化为本地质检 |
| 人名自动扩充 `names_autofill.py` | `python3` + 维基可达 | 用自带 20 条人名表 |
| mihomo 自动拉起 | `~/opt/mihomo/mihomo` + `config-sub.yaml` | 直连，不拉起 |

## 7. 只留 md、JSON 不进笔记库

落盘目录只写 `AI圈新闻雷达_<日期>.md` 与 `_速览.md`；数据源 JSON 落 `~/digests/`（笔记库不被 JSON 污染）。
已落盘 JSON 想复算 md（改版式/补历史）：`python3 <本技能目录>/scripts/json2radar_md.py <json> [--out 目录] [--stdout]`。

## 8. 卸载

删掉技能目录即可；`~/.dsh-ai-research/`（缓存）与 `~/digests/`（JSON 存档）想清就一起删。
