---
name: ai-news-radar
description: AI 圈新闻雷达 —— 汇总"AI 行业最近发生了什么"：模型发布、融资/并购、人事变动、算力芯片、政策监管、商业合作与社区热议。当用户问「AI 圈最近有什么新闻」「AI 行业动态」「最近有什么 AI 大事」「帮我汇总今天的 AI 新闻」「盯着点 AI 融资/人事/爆料」时使用。渠道覆盖厂商官方博客与 X 账号、中英文科技媒体 RSS、Google/Bing 新闻检索、Hacker News / Reddit / 微信公众号，去重合并后输出带来源链接的日报，并声明数据缺口；用户要「解读 / 分析 / 为什么重要」时，可给出事实与判断分层、标注未核实项的跨源解读。
---

# AI 圈新闻雷达（ai-news-radar）

## 快速开始（技能包版）

```bash
cd <本技能目录>/scripts            # 本技能目录下的 scripts/，即工具根
node ai-news-radar/cli.mjs --days 1        # 抓取 + 落盘三件 + 打印日报
node ai-news-radar/cli.mjs --list-sources  # 只看源清单（离线，验证装好没）
```

- 落盘：`<OBSIDIAN_ROOT>/dsh/新闻/AI radar/AI圈新闻雷达_<日期>.md` ＋ `_速览.md`（只写 md）；JSON 另存 `~/digests/`（`DSH_AI_RESEARCH_RAW` 可改）。
- 运行期状态（cookie / 缓存 / 限流熔断 / 翻译缓存）统一在 `~/.dsh-ai-research/`，跨会话复用。
- **不需要任何代理也能跑**：`setupProxy()` 先探测 `127.0.0.1:7890`（本机 mihomo）→ `3067`（手机 Clash），都不通就**直连**；要指定就 `DSH_AI_RESEARCH_PROXY=http://host:port`，要关就 `=off`。
- 翻译/机检随包自带：腾讯 Transmart（`translate.mjs`）+ 彩云交叉校验（`xcheck.mjs`）+ MyMemory 兜底；人名表 `names-extra.json`，改完清 `~/.dsh-ai-research/translate-cache.json` 才生效。
- 降级（不影响主产物）：无 LLM 凭据 → `radar_semantic.py` 跳过语义初筛；无 mihomo → 直连；X/Reddit/微信源受限 → 该源记 0 条并在「数据缺口」里如实声明。


> **路径与环境（先读这条）**：本文里的 `model-report/xxx.mjs`、`ai-news-radar/xxx.mjs`、`ai-model-radar/xxx.mjs`
> 都是**相对工具根目录**的路径；**本技能包的工具根 = `<本技能目录>/scripts`**（例：`<本技能目录>/scripts/ai-news-radar/cli.mjs`、`<本技能目录>/scripts/model-report/xxx.mjs`）。
> 所以命令示例前面都先 `cd <本技能目录>/scripts`；下文 `node ai-news-radar/cli.mjs …` 即指该目录下的入口。
> 运行期状态（cookie / 缓存 / 限流与熔断状态）统一在 **`~/.dsh-ai-research/`**（`DSH_AI_RESEARCH_HOME` 可改：
> 缓存 `.cache/`、cookie `cookies.json`、小红书状态 `xhs-state.json`）。
> 出网代理按 `DSH_AI_RESEARCH_PROXY` → `MODEL_REPORT_PROXY` → `HTTPS_PROXY` / `HTTP_PROXY` 取，都没设就直连（`NO_PROXY` 生效）。
> 下文命令示例以 **bash** 为准（Windows PowerShell 把 `X=... 命令` 换成 `$env:X="..."; 命令`）。

## 能力

一句话触发：把最近 N 天**整个 AI 行业**的新闻按主题汇总成日报，逐条带时间、来源与链接。

| 段 | 覆盖 | 来源 |
|---|---|---|
| 官方渠道 | 厂商自己发的公告 | OpenAI / Anthropic（HTML 解析）/ Google DeepMind / Google AI / Google Research / Hugging Face / Qwen / NVIDIA 博客 / AWS ML / Meta Engineering 的 RSS |
| 官方 X 账号 | 抢跑与预告（很多消息先发在 X） | OpenAI、AnthropicAI、GoogleDeepMind、GoogleAI、OpenAIDevs、nvidia、AIatMeta、Alibaba_Qwen、testingcatalog、kimmonismus、TheInformation、TechCrunch、ArtificialAnlys、AndrewCurran_ 等 22 个账号（按天轮转取样） |
| 英文媒体 | 报道与独家 | TechCrunch、The Verge、VentureBeat、Ars Technica、MIT TR、Wired、IEEE Spectrum、The Register、The Information、SemiAnalysis、Stratechery、Bloomberg、FT、WSJ、NYT、CNBC、Axios、ZDNet、Crunchbase（融资）、Techmeme、smol.ai、TLDR AI、Import AI |
| 中文媒体 | 国内视角 | 量子位、智东西、雷峰网、InfoQ 中文、钛媒体、极客公园、IT之家、cnBeta、少数派、新浪科技 |
| 关键词检索 | 兜底全网（含未被 RSS 覆盖的媒体） | Google News RSS（中英各 6~7 组查询，每组最多 100 条）+ Bing News RSS（链接可还原成发布方原始 URL） |
| 社区热议 | 技术圈真实讨论 | Hacker News Algolia、Reddit（arctic-shift 归档：r/OpenAI、r/singularity、r/LocalLLaMA、r/MachineLearning、r/artificial、r/Anthropic） |
| 微信公众号 | 新智元等只在公众号发的号 | 搜狗微信检索（默认关闭，`--wechat` 开，慢且易触发反爬） |

主题分类（渲染时分节）：模型 / 产品发布 · 融资 / 并购 / 估值 · 算力 / 芯片 / 数据中心 · 技术 / 研究 · 人事 / 组织 · 政策 / 监管 · 商业 / 合作 · 其它。

## 怎么跑

代码在工作区 `ai-news-radar/`（**纯 Node，零依赖**，复用 `model-report/` 的出网与缓存模块）：

- `ai-news-radar/sources.mjs` — 源清单（改源改这里）
- `ai-news-radar/lib.mjs` — 采集、去重、分类、渲染
- `ai-news-radar/cli.mjs` — 命令行入口，落盘到 `<落盘目录>/AI圈新闻雷达_<日期>.md|.json`（目录见下节「落盘」）

## 落盘（2026-11-13 改版：新闻/AI radar + JSON 全量转 md）

- **默认笔记目录**：`<OBSIDIAN_ROOT>/dsh/新闻/AI radar/`（手机 = `/sdcard/Obsidian`，电脑 = `~/Obsidian`；与「新闻 / 热点 / 热榜」同级）。可用 `OBSIDIAN_ROOT` / `DSH_AI_RESEARCH_OUT` 覆盖，只写 md。
  可用环境变量 `DSH_AI_RESEARCH_OUT` 或工具参数 `out` 覆盖；`out` 只允许落在该目录内或会话工作区内，其它绝对路径直接报错。
- **笔记目录只放两个 md**，文件名前缀 `AI圈新闻雷达`（`DSH_AI_RESEARCH_PREFIX` 可改）：
  1. `AI圈新闻雷达_<YYYY-MM-DD>.md` — **从 JSON 全量转出**，873 条也一条不落：每条「标题(原文链接) + 北京时间 + 来源 + 摘要 + 另见」，末尾带「按来源站点 / 社区热议 / 数据缺口」。这是主产物。
  2. `AI圈新闻雷达_<YYYY-MM-DD>_速览.md` — Top10 + 每主题 8 条的确定性日报（`renderMarkdown` 那套，带自动目录与编号）。
- **JSON 不进笔记库**（2026-11-13 用户要求）：原始数据存 `<原始目录>/<YYYY-MM-DD>.json`，默认 `~/digests`（`DSH_AI_RESEARCH_RAW` 可改）。
- **JSON 不翻译**（2026-11-14 用户要求）：`saveDigest` 写 JSON 时剥离全部 `title_zh`/`summary_zh`（items 与 buzz 条目都剥），JSON 只存原文 + 元数据（translateStats/proxy 保留）；译文只存在内存与渲染出的 md 里。因此「md 从 JSON 复算」的旧约定只剩英文回落——`json2radar_md.py` 从纯 JSON 转出的 md 是英文标题（`dispTitle()` 优先 `_zh`、回落原 title）；要带中文的 md 必须在翻译后的当轮由 `renderFullMarkdown(res)` 生成。已落盘的含译文 JSON 改版式时，可用 Python 复算线或先从 md 侧取数。
- 已落盘的 JSON 要单独复算 md（改版式 / 补历史）：`python3 <本技能目录>/scripts/json2radar_md.py <雷达.json> [--out 目录] [--stdout]`，与 `lib.renderFullMarkdown()` 逐字节一致；`--out` 默认就是该目录。
- 目录用 Obsidian 内部链接 `[[#章节标题]]`（GitHub 式 `#锚点` 与 Obsidian 的 heading normalize 规则不兼容，别改回去）。

在 run_code 里（推荐）：

```js
const { pathToFileURL } = await import("node:url");
const U = (p) => pathToFileURL("F:/DSH Projects/Untitled/" + p).href;   // 相对 import 会以 PTC runtime 为基准，必须转绝对 URL
const lib = await import(U("ai-news-radar/lib.mjs"));
const res = await lib.collect({ days: 1, x: true, xBudget: 8 });         // 默认 1 天；deep:true 时 X 取 12 个 + 开微信公众号
console.log(lib.summarize(res));                                        // 各源成败 + 主题分布 + 缺口
const md  = lib.renderMarkdown(res, { topN: 10, perTheme: 8 });         // 确定性日报
const raw = lib.brief(res, { perTheme: 8, community: 5 });              // 给 agent 挑深读条目的紧凑原料
const p   = lib.saveDigest(res, {});                                    // 落盘，返回 { dir, json, md, quick }
// 不要传 markdown：saveDigest 会自己写「JSON 全量转出」的主 md（md 只是给对话看的那份日报）
```

命令行（需要 shell）：

```
node ai-news-radar/cli.mjs --days 1                 # 默认：抓取 + 落盘三件 + 打印日报
node ai-news-radar/cli.mjs --days 3 --focus "OpenAI"  # 聚焦某公司/话题（额外加一轮检索）
node ai-news-radar/cli.mjs --deep                   # X 12 个账号 + 微信公众号
node ai-news-radar/cli.mjs --no-x --brief           # 不碰 X 配额，只拿紧凑原料
node ai-news-radar/cli.mjs --only "qbitai,openai" --md
node ai-news-radar/cli.mjs --list-sources           # 看全部源 id
node ai-news-radar/cli.mjs --fetch <url>            # 抓一篇文章正文
```

## 推荐工作流（两种档位，先确认要哪种）

| 档 | 产出 | 代价 | 触发语 |
|---|---|---|---|
| **A · 日报**（默认） | 8 类主题分节 + 社区段，每条带时间 / 来源 / 链接 | 一次 `collect`，15~20s | 「今天发生了什么」「汇总一下」 |
| **B · 解读版** | A 之上：少而深的条目 + 跨源连线 + 明确判断 + 不确定性标注 | A + 3~6 次抓正文 + 若干检索，多 20~40s | 「解读」「分析」「为什么重要」「这意味着什么」 |

**只要用户说了「解读 / 分析 / 为什么重要」，就直接做 B 档，不要先交 A 档再问要不要加解读。**

### A 档流程

1. `collect({ days: 1 })` → 先看 `summarize(res)`：源失败、社区条数与缺口。**失败源必须写进最终交付**，不能当成「今天没新闻」。
2. 看 `renderMarkdown(res)` 的「要闻 Top」与各主题节，挑 5~10 条当天最重要的。
3. 对挑中的条目用 `lib.fetchArticle(url, { chars: 4000 })` 抓正文，写**一句话中文摘要 + 为什么重要**。抓不到就说明抓不到，**不要照标题脑补内容**。
4. 社区段（HN / Reddit / X）单列成「社区热议」，标注点赞与评论数——它是热度信号，**不是事实来源**。
5. 保留：采集时间（asOf）、时间窗、源覆盖（N/M 成功）、缺口清单；引用任何数字都要能指回链接。

## B 档：解读怎么做

**解读 ≠ 把标题改写成两句话。** 它的定义是：**给出跨条目的因果 / 对比判断，并且把「事实」和「我的判断」分开写清。** 六步做完才算：

1. **重排优先级，找回「反常项」。** 不要按主题分节顺序走。先问一句：今天哪一条**不是日程表上该发生的事**？模型发布是日程，agent 越界不是。当天最值得读的通常不是最大的发布，而是**唯一一件没有先例的事**。
2. **给关键新闻补定向检索。** 雷达只覆盖自己那几十个源；估值、财报、诉讼这类**要数字**的事，往往在 The Information / Reuters / Barron's / Bloomberg 这些**不在 RSS 里**的地方。用 `web_search` 补一手（**单次最多 4 个 query，超了直接报错**），再抓正文。
3. **优先一手，不引转述。** 可靠度顺序：官方博客 / 官方文档 > 一手报道正文（通讯社、地方台、当事公司自己发的） > 主流媒体转述 > 中文媒体二手标题。**中文科技媒体的标题常夹带编辑判断**（例：「AI 算力泡沫的第一道裂缝」是评论，不是事实），事实部分要回到一手。抓不到就换同题中文源，并**在交付里写明「据 X 报道、经 Y 转引」**。
4. **跨源连线——这是解读的核心产出。** 找同一天里**指向同一件事的三条以上**，再给读数。例：Anthropic 估值预期 2 万亿 → 1.5 万亿 ＋ DeepSeek 融资翻倍但投前估值不动 ＋ CoreWeave 创始人减持 33 亿美元 → 「资金还在进，是**折现率**变了，不是水量变了」。单条新闻给不出这个判断，三条一起才行。
5. **事实 / 判断分层，数字必须落地。** 每条写成：**事实**（谁、哪天、什么数字、来源链接）→ **解读**（我的判断，用「我认为 / 读数 / 意味着」明示）。能引到具体数字的一律给数字（$1.99/任务、2.7×、6-26 发生 / 9-25 才发现、53 分），**不要写「成本更低」这种无法证伪的话**。
6. **主动写不确定性——这一节不要省。** 凡没读到一手全文的（付费墙）、来自社交媒体转述的、或与早前报道时间线冲突的，**当场标注**，并在末尾单列「引用时避几个坑」。宁可在交付里写「这条未确认」，也不要让它看起来像已证实。**这一节是解读版区别于日报的关键。**

### 解读的纪律（最容易犯的六个错）

- **别把「工程可行性」说成「能力突破」**。例：谷歌 Willow 的魔态培育是误差降 40 倍的**工程**进展，**不等于量子优势**（它的意义是把「实用量子计算要多少 qubit」往下压）。
- **别把旧闻当突发**。例：中国 AI 出口管制的方向 Reuters 在 7 月就报过，10 月是新进展。定标题前先查同方向早前报道。
- **别给没有量级的对比**。说「更高 / 更低」要给倍数或百分比；说「更快」要说清是延迟还是吞吐。
- **别把热度当事实**。HN / Reddit / X 的赞数与评论数只能证「很多人关注」，不能证「这件事为真」。
- **转述链要标全**。A 转引 B、B 转引 C 时，链接给最上游那条，并写清「据 C 报道，经 B 转引」。
- **合规**：融资 / IPO / 收购一律「据 X 报道」，传闻不得写成事实；输出仅供研究参考，**不构成投资建议**。

### 交付形态（解读版）

1. 落盘 `<落盘目录>/AI圈新闻雷达_<日期>_解读.md`：事实带链接、解读分层、末尾「引用时避几个坑」——**骨架见下面「输出排版」一节**，样板 `digests/2026-10-16-解读.md`。
2. **对话里用 GenUI 给结构化版，不要用 markdown 表格**：`callout`（当天论点）+ `table` 三列「线索 / 今天的事实 / 读数」（一行一条主线）+ `callout`（引用注意）。
3. 正文散文按主线分小标题，**每条先摆事实、再单独成段给判断**；最后用 `present` 挂出解读版与原始日报两份文件。

## 输出排版（Markdown 骨架，2026-10-16 统一）

三套工具（ai-model-radar / model-report / ai-news-radar）与 **agent 手写的解读稿**共用同一套骨架，
编号 / 目录 / 分隔线的实现只有一份：`model-report/doc.mjs`。

1. **一份文档只有一个 H1**：`# <主题>`。改造前 model-report 的报告全文只有 1 个 `#`，其余全是 `**粗体**` 伪标题 —— 在 Markdown 阅读器里没有大纲，别再写回去。
2. **元信息走引用块**（紧跟 H1，两行）：`> 数据截止 … · 生成时间 …` / `> 全部来源为公开只读接口，仅供研究参考。`
3. **`## 目录` 由 `doc.mjs` 生成**：正文里先写占位符 `TOC_PLACEHOLDER`（`<!-- dsh-toc -->`），收尾时替换成带 GitHub 风格锚点的目录（H2 + H3 两级）。
4. **章标题自动编号**：正文写 `## 模型档案`，收尾时变成 `## 一、模型档案`。`cnNum()` 支持「十一、二十一」；**不要再用 `CN[Math.min(n-2, CN.length-1)]` 那种夹紧写法** —— 旧版 `ai-news-radar` 就是因此出现「十、社区热议」与「十、按公司看」重号。手写文档请自己写中文序号。
5. **三级标题不编号**：`### B站实测视频（约 1000 条命中）`；口径说明放斜体独立行（`*播放 / 评论为累计值*`），不要全塞进标题括号。
6. **章节之间一条 `---`**：`addRules()` 在每个编号章前插（目录章除外），生成物不必手写。
7. **收尾两章固定**：`## 数据缺口 …`（gaps / 失败源如实列出）＋ 合规声明引用块（研究参考，不构成投资建议）。
8. **表格只用于「≥3 行、列之间同质」的对照**（元信息 / 跑分 / 模型横评）；流程与层级关系用列表或 GenUI，不用表格硬摆。

`doc.mjs` 导出（改渲染逻辑时用）：`TOC_PLACEHOLDER` · `finalizeDoc(md, { skip, toc, rules })` · `cnNum(n)` · `slugifyHeading(text, used)` · `scanHeadings(md, levels)`（自动跳过围栏代码块）· `numberChapters(md, { skip })` · `addRules(md)` · `buildToc(md)`。
`finalizeDoc` 默认 `skip: ["目录", "摘要"]`（这两章不编号）；三套 lib 的 `renderMarkdown` / `renderCompare` 收尾都调它，**手写文档也可以 import 它收尾**。

本技能产出（示例见 `digests/2026-10-16.md`）：

```
# AI 圈新闻雷达 · <日期>
> 数据窗口 … / 源统计 / 社区统计 / 确定性事实归集声明
## 目录
---
## 一、要闻 Top 10         ← 有序列表，每条下挂「主题标签」子项
## 二、模型 / 产品发布（N 条） … ## 九、其它（N 条）
## 十、社区热议           ← H3：Hacker News / Reddit / X（Twitter）/ 微信公众号
## 十一、按公司看          ## 十二、数据缺口 / 覆盖说明
```

**agent 手写的解读稿**（`<落盘目录>/AI圈新闻雷达_<日期>_解读.md`）照下面这个骨架写；上游包内的样板是 `tools/model-report/digests/2026-10-16-解读.md`：

```
# <当天主线的一句话标题>
> 数据截止 <日期> <时段> · 来源：AI圈新闻雷达_<日期>.md（<N> 条去重后的事实归集）
## 一、<主线 1>            ← 每条主线一章；先摆事实（带链接），再单独成段给判断
### 1. <子事件>           ← 三级可编号，按你自己的叙事需要（与工具产出的 `###` 不强求一致）
## 侧记                    ← 不成主线但值得记的零碎
## 引用这份解读时的四个坑   ← 把「哪条是传闻 / 哪条是转引 / 哪个数字有口径问题」讲清
```

## 英文中文化 + 出网代理（2026-11-13 新增）

**翻译（默认开）**：`ai_news_radar` 抓完会调 `translate.mjs` 把英文标题/摘要/buzz 标题翻成中文，译文写 `title_zh` / `summary_zh`，**原字段保留**（渲染层 `dispTitle()` 优先 `_zh`、回落原文，可追溯可复算）。
- **长短分流（2026-11-14 用户定，借鉴热评报告规则）**：`collectTexts` 对 buzz（社区热议）按内容分流——纯表情/符号或 ≤12 字符的短梗（`lol`、`🔥🔥🔥` 这类）**不送机翻**（机翻只产噪音：纯表情被译成账号名、meme 直译成废话），渲染回落英文原文，跳过数计入 `translateStats.buzzSkipped`；资讯类长句照常机翻打底。items（新闻标题/摘要）不受此限。机翻给不了骨架的交给人工：交付前领队按「只修硬伤（人名/数字/否定/双关）」逐条过 buzz 译文，短梗直接人工写。
- 通道：腾讯 Transmart `POST https://transmart.qq.com/api/imt`（Google gtx 429 / Bing 401 / DeepLX 已收费化，均不可用）。
- 专名保护：翻前把公司/模型/产品名换成 `zqx<N>zqx` 占位符，翻完还原——否则 `Anthropic IPO`→「拟人化IPO」、`Gemini 4 Hydrogen`→「双子座4号氢气」。腾讯会把占位符里的数字拆出空格（`zqx 0 zqx`），`restore()` 已按允许空白匹配。
- 人名与单位保护（2026-11-15）：人名表与 zh.mjs 同源，见 `name-guard.mjs`（238 条内置 + `names-extra.json` 自动扩充，`names_autofill.py` 从当日新闻里查维基生成）；单位 `gigawatts/megawatts/kilowatts/terawatts`（含 `-hours`）在 `protect()` 里**先于 `PROTECT_RE`** 占位成「吉瓦/兆瓦/千瓦/太瓦」，还原即是本地化——腾讯对 `megawatts` 会译成「百万」并吞掉 `watts`，只能前置占位；`PROTECT_WORDS` 里的 `tts` 片段会先把 `megawatts` 切碎，所以单位必须排在它前面。
- **量级词占位两式（2026-11-17 补第二式，务必都保留）**：引擎对量级词系统性错译 10~100 倍，且换措辞救不了，只能翻前占位、还原时做确定性 SI 换算。
  - ①全称式 `SCALE_RE`：`($€£¥₹|Rs.)?数字 + trillion|billion|million|thousand|lakh crore|crore|lakh` → `$1.4 Trillion`→1.4万亿美元、`Rs 18 crore`→1.8亿卢比、`₹1.88 Lakh Crore`→1.88万亿卢比。
  - ②**缩写式 `ABBR_RE`（2026-11-17 实测补）**：`300B / $1.4T / 5.46M` 这类原来完全裸奔，引擎**把 B 当成「亿」**——`NATO uses up to 300B tokens` 译成「300亿个令牌」（应 3000亿，差 10 倍）。加 `ABBR_RE`（K/M/B/T 四档）后 300B→3000亿、5.46M→546万、$1.4T→1.4万亿美元。右边界 `(?![A-Za-z0-9])` 保证 `512MB RAM`、`4TB` 这类复合单位不被误伤、`Model B` 不动。
  - ③**纯千分位数字也占位**：引擎会把 `50,000` 输出成全角逗号「50，000」，占位后保持半角（这条反复手工改过 4 处）。
  - 换算阈值统一：`≥1e12 → 万亿`、`≥1e8 → 亿`、`≥1e4 → 万`；无货币符不加货币单位。改占位逻辑后**必须清 translate-cache 的坏 key**（旧坏译文会一直命中）。
- **人名保护（2026-11-14，2026-11-15 加自动扩充）**：`name-guard.mjs` 共享 NAMES 表（内置 238 条）+ `names-extra.json`（自动扩充，运行时合并，冲突时内置优先）——有人物专名且有通行中文译名的一律译中文（Jensen Huang→黄仁勋、Sam Altman→山姆·奥特曼），占位还原值=中文译名；`restore()` 内置 `swapNames()` 兜底（占位符被腾讯吞掉时译文残留英文人名，直接换中文）。该表是单一数据源：`zh.mjs`（CLI）与 `translate.mjs`（雷达）共用。
- **表外人名自动扩充（2026-11-15）**：`python3 <本技能目录>/scripts/names_autofill.py [digest.json] [--dry]` —— 从当日 JSON 抽「连续 2~3 个首字母大写词」当候选人名 → 批量查 en.wikipedia（`prop=langlinks|description`）→ 用 description 判定是否人物（businessman/executive/politician/`(born 19xx)`…，公司/动物/机构在这一步出局）→ 只留「有中文条目且中文名≠英文原名」的 → zh.wikipedia `varianttitles&variant=zh-cn` 转简体 → 与现有表比对后写进 `names-extra.json`（只增不删，可随时重跑）。实测 907 个候选 → 4 条新人名（Colette Kress、Howard Lutnick 等），耗时约 3 分钟（维基对连续批量查询会 429，脚本已内置 0.7s/批限速与退避）。**港台译名要人工看一眼**：`John Curtis` 查到的是台湾译名「匡希恒」，大陆应为「约翰·柯蒂斯」——这类靠 description 过滤不出来，脚本跑完抽查一遍新增清单再决定是否保留。改表后需清翻译缓存才重新生效。
- 整条几乎全是专名的标题（如 `Gemini 4 Hydrogen`）腾讯原样返回，视为无需翻译、渲染回落英文，计入 `translateStats.sameText`，不算失败。
- 缓存 `~/.dsh-ai-research/translate-cache.json`（key=文本 sha1 前 16 位）；重复跑几乎零请求。清缓存才会重新请求。
- 开关/预算：`DSH_AI_RESEARCH_TRANSLATE=off`、`DSH_AI_RESEARCH_TRANSLATE_BUDGET_MS`；工具层 `translate:false`、CLI `--no-translate`。失败/超预算一律保持英文、**绝不阻塞落盘**。
- **其他会话/脚本复用**：`import { translateTexts } from "<本技能目录>/scripts/ai-news-radar/translate.mjs"` → `await translateTexts(["text", ...])` 回同序中文数组（不需翻译处为 null）；命令行一行：`node <本技能目录>/scripts/zh.mjs "英文"` 或 `-f file.txt` 或走 stdin。缓存全局共享，重复文本零请求。剪藏链路另有 `tools/trans.py`（走 Google clients5、保 markdown 结构），两套并存互不影响。

**交叉校验 + 人工审（2026-11-15 用户定：**默认开**，`--no-xcheck` 或 `DSH_AI_RESEARCH_XCHECK=0` 关闭）**：腾讯翻完，`xcheck.mjs` 用**第二通道**把同一批原文重翻一遍（默认彩云小译：国内直连、40 条/批约 0.6s、数字与单位保留好，636 条约 12 秒；**彩云失败的对自动回退 MyMemory 兜底**——逐条约 2s、抽样上限 40 条、带 `de` 邮箱共 5 万字符/天额度，所以只在彩云整批失败时才用它；`--xc-engine google` 走 clients5 但易被 IP 限流 429），两边**数字按「数值×单位」归一到 SI 值**再比（90.4B ↔ 904亿 属合法换算自动放行；2T → 2000亿、18 crore → 18亿 这类真错才标出），差异条目写成 `<日期>_人工审.md`（落 `RAW_DIR`，不进笔记库），**终审归人工**：核对原文后直接改日报 md（主文件 + 速览），改完删清单。
- 判定档：high（数字/单位对不上，或腾讯译文显著短于谷歌=疑似漏译）、mid（部分数字对不上，可能换算差异）；全中不报。
- **换算口径（2026-11-15 按真实数据修正）**：数量级词（trillion/billion/crore/lakh/万/亿/十亿…）折算成数值后**按裸数字比**——`115,000` ↔「11.5万」、「2 trillion」↔「2万亿」放行；只有真计量单位（吉瓦/瓦/赫兹/字节）才要求两边都带单位。`607.8 tok/s` 这类词尾缩写不会被误认成 tera。年代词（`2010s` ↔「21世纪10年代」）两边写法天然不同，直接剔除不参与比对；站点样板句（"Audio playback is not supported on your browser" 等）在否定词判断前先剥掉。
- 抗抖动：谷歌成功结果落 `~/.dsh-ai-research/xcheck-cache.json`，重跑零请求；连续 8 次失败即熔断（Google 被 IP 限流时几十秒内收工，只记「跳过 N 条」，**绝不阻塞落盘**）。
- 已知：Google 翻译全系端点（clients5/gtx/clients4/translate.google.com）会按 IP 限流成 429，跑几百条后常见；限流时本轮不出清单，次日再跑通常已恢复。
- **本地质检（2026-11-15，不依赖第二引擎、对每一对译文都跑）**：①英文从句残留（译文里连续 ≥5 个英文词且带 the/of/and 等虚词——专名堆叠不含虚词，不会误报）②否定词丢失（原文有 not/denies/without，译文一个否定字都没有）。这两条是 636 对真实译文校准出来的：长度比与中文占比在正常译文上误报 26%/24%，**不能当指标**（中文里专名一多，占比天然就低）。命中进同一份人工审清单。
- **MyMemory 通道（`--xc-engine mymemory --xc-sample N`）**：逐条 2s、3 路并发后 169 对约 50 秒；额度按**字符**算（匿名 5 千/天，带 `de` 邮箱 5 万/天，邮箱存 `~/.dsh-ai-research/mm-email`），约 100 字符/条，`N` 默认 60、上限约 500 条。实测与彩云对比：注入 3 处数字错误后**两边同批全部命中**（title#2/7/13），原样数据**两边误报同为 0**；差异在语义层——MyMemory 人名更贴大陆习惯（黄仁勋正确、彩云给「延森·黄」）但会幻觉（`Huang Hires Paul Weiss` 译成「**黄晓明**聘请…」），彩云则对人名一律音译。两引擎都抓不到语义/双关错，仍要人工。
- **出日报后必做：语义抽查（`python3 <本技能目录>/scripts/radar_spotcheck.py`）**——机器校验只覆盖数字/单位/漏译，抓不到语义错。2026-11-15 实测 32 条样本挖出 5 条硬伤（≈15%）：`NasdaqGM`→「纳斯达克通用汽车公司」（GM 当成通用汽车）、`Anthropic PBC`→「中国人民银行」、模型名 `Bel`→「贝尔」、`Microduck`→`Microbuck`、`FAA Ground Stop`→「地面站」（应为停飞令）。抽查脚本默认抽 20 条，把英文原文与中文标题/摘要并排打出，逐条看五类：人名与机构名、金融与市场缩写、模型名与专名拼写、否定与因果是否反、「Watch / All About / What Is Known」这类视频标题引导词。
- **抽查修完必须回写缓存**：`translate-cache.json` 的 key 是原文 sha1 前 16 位，手工改的译文不回写的话，下次重跑又退回错译（JSON 不翻译、md 靠当轮渲染）；改 `PROTECT_WORDS` 或 `NAMES` 后同理要清对应 key 或回写。
- **整份 JSON 的译文抽检（2026-11-17 定，用户「抽检 json 翻译用 xcheck」）**：JSON 本身不存译文，所以抽检 = **按 URL 把 JSON 英文原文与 md 中文行配对**，再喂 `crossCheck()`。四个判据要点：
  - ①英文判据必须是「**含 ≥6 连续拉丁字母 且中文字符占比 <30%**」——用 `/\[A-Za-z\]{4,}/` 会把中文源条目（`AI CRM创企Dreamteam完成5300万美元融资`）当成英文配对，产生假阳。
  - ②**摘要侧不要套「省略号截断→疑似补完」规则**：JSON 的 `summary` 是截断版（以 `…` 结尾），md 摘要来自全量 `desc`，EN 被截断而 ZH 完整，规则本意不成立，必然大批假阳（2026-11-17 实测 8 条 flagged 全是这类）。**有效信号在标题侧**。
  - ③配对前要剥 md 摘要行尾的来源括注「（站点 · MM-DD HH:MM）」——里面的日期时间会被当数字。
  - ④`norm()` 已剥域名（`DOMAIN_RE`）：标题尾部的 `- Mi-3.com.au.` 的 `3` 曾把数字比对带偏成假 high。
  - 实测基线：11-17 期标题 409/409 全清；该轮挖出 5 处机器校验此前抓不到的真错（`OpenAI | ChatGPT…`→「公司简介｜…」丢主体、加州起诉 OpenAI 丢被告、`300B`→300亿、Urban Legend 标题丢主体与 1,400），全部修完并回写缓存。
- 开关：**默认开**（彩云 636 条 12 秒，成本可忽略）；要省时间/第三方配额时 `--no-xcheck`（工具参数 `xcheck:false`），或 `DSH_AI_RESEARCH_XCHECK=0`。AI 日报管线（radar.py）走 `--no-translate`，本来就没有译文可校验，不受影响。

**代理（首选 127.0.0.1:7890 本机 mihomo，后备 127.0.0.1:3067 手机 Clash）**：`setupProxy()` 在 collect 前按 7890→3067 顺序探测，探通哪个用哪个，都不通回落直连；7890 = ~/opt/mihomo（美国出口，跨会话可用）。例外名单固定含 `reddit.com,redd.it,redditmedia.com,redditstatic.com`（这些走代理会 403，直连可用；Reddit 数据本身走 arctic-shift，实测走代理 200）与 `hn.algolia.com,news.ycombinator.com`（2026-11-17 实测：HN Algolia 走代理频繁 TLS 断连，直连稳定，HN 帖子数从 0 → 14）。
- 关闭：`DSH_AI_RESEARCH_PROXY=off`；换地址：`DSH_AI_RESEARCH_PROXY=http://host:port`（设了任何代理 env 就完全尊重用户，不再套默认）。
- 实测（2026-11-13，40 个源）：走代理除 reddit 403 外全 200，国内源反而更快（ithome 0.2s / qbitai 0.3s / 36kr 0.3s）；整轮抓取 149s → 66s。

## 往期体检与术语纪律（2026-11-20 定版）

**原则**：改术语表后，已发往期 md 必须按新口径回修，避免「旧译法」在 Obsidian 里固化给人造成参考误导。

### 1. 术语表双轨口径（2026-11-20 用户定稿）
- ① 保留英文不译 = `PROTECT_WORDS`：agent 家族（agents/agent/agentic/multi-agent/swarm/agentic workflow）+ token 家族（tokens/token/tokenizer/tokenization，用户 2026-11-20 追加「tokens 不翻译」）+ Transformer/RLHF/RLVR/DPO/GRPO/SOTA + 既有公司/模型/缩写专名表。
- ② 其余 AI 术语按收件箱 181 篇 IT之家文章实测译法走中文定译：提示词/嵌入/微调/多模态/推理/推理模型/视觉模型/基座模型/基础模型/扩散/检查点/开源/开放权重/工具调用/向量数据库/上下文窗口/系统提示词/提示词注入/提示词工程/越狱/延迟/吞吐量/注意力机制/幻觉/检索增强生成/大语言模型（见 `translate.mjs` 的 `IDIOM_ZH`「AI 术语（IT之家口径）」段）。

### 2. 往期回修纪律
- 判定英文源：JSON 原文拉丁字母占比 ≥50%（`translate.mjs` 的 `isEn()` 逻辑）。仅英文源条目做：①人名译中文（Dario Amodei→达里奥·阿莫迪、Jensen Huang→黄仁勋等）；②术语按新表（智能体→agents、令牌/代币→tokens、Agentic→agents/Agent）；③坏译名黄光裕/詹森黄→黄仁勋。
- 中文源原文里的「智能体/令牌/代币」不改（是原文写法，非译文错）。
- 修前 `cp -p` 备份到 `<本技能目录>/scripts/../bak/radar/`，就地改同路径 `open(w)`（保 inode，Obsidian 排序不变），改后回写翻译缓存（删旧译特征 key）。

### 3. 三项改进体检工具（旧工作区雷达原型目录，不随包分发；需要时按本节自建）
- `coverage.mjs`：与前期对比（条数<40%/成功源差≥8/asOf倒挂）识别抓取残缺期（11-14/15 连续两期成功源 47→37→27）。
- `review.mjs` 四步：跨源同事件（2-gram Jaccard≥0.5）/实体混用/分类边界/必看候选；输出报告供人工复核，不自动改 md。
  - 高频问题：Google News 跳转链未解码导致同事件重复（11-13 29 组、11-14 13 组、11-17 27 组）；model 类分类边界假阳率高（融资/上市类本应归 funding）。
- `mustread.mjs`：启发式打分（score≥3/同源≤2/同主题≤3）产出每期 5 条必看候选。

### 4. 质检三件套（翻译链路）
- `zh.mjs` 主翻（腾讯 + 数字/人名/URL 三层占位 + 缓存） → `numcheck.py` 逐条数字机检（missing/extra 归零 + scale_risk 量级换算） → `xcheck.mjs` 交叉校验（彩云小译第二通道 + MyMemory 抽样，SI 归一对比差 10 倍标 high，兜底行补译 `refillFallback`）。
- 改占位/词表/人名表后必须清 `~/.dsh-ai-research/translate-cache.json` 与 `xcheck-cache.json`。

## 语义初筛 + JSON 保留译文（2026-11-20 定版）

- **JSON 保留译文**（覆盖 11-14「JSON 不翻译」）：saveDigest 落盘时不再剥离 title_zh/summary_zh（items 与 buzz 都带）。用途：往期 md 可从纯 JSON 全量复算；semantic/xcheck 抽检直接读 JSON 配对，不再解析 md。文件 +30% 体积。
- **零条目护栏**：抓到 0 条（断网/代理挂）时 JSON 改存 `<stamp>.empty-<HHMMSS>.json` 留证、不覆盖好池子；已有大 md（>50KB）也不被空稿覆盖。11-20 晚实测 0/62 全 TLS 失败曾把 865 条好池盖成 0，此护栏即为此加。
- **全量语义初筛**：cli 落盘后自动跑 `python3 <本技能目录>/scripts/ai-news-radar/radar_semantic.py <digest.json>`（semantic_check.py 的 LLM 初筛，约 1s/对）——JSON 英文 title × title_zh 全量配对（英文判据 ≥6 连续拉丁字母且 CJK 占比 <30%），人工审清单落 `<rawDir>/<日期>_semantic_人工审.md`。关闭：`--no-semantic` 或 `DSH_AI_RESEARCH_SEMANTIC=0`。清单制不阻断；模型慢时 cli 内超时 60min，可单独重跑适配器补清单。11-20 实测 546 对 flagged 237（43%），抽查真错率高（Isaacson 译名、harness→线束、Blue Origin 成分错乱、$1,000 股份语序）。
- **`await saveDigest` 修复（同日）**：cli 此前 fire-and-forget，[落盘]/[数据源] 打印 undefined、语义初筛拿到 undefined 路径；已改 await。

## 使用要点

- **窗口默认 1 天**：Google News 查询带 `when:{days}d`，窗口越大噪音越多；看一周的可以 `--days 7` 并把 `perTheme` 调大。
- **两种链接要区分**：Google News 的链接是 `news.google.com/rss/articles/...` 跳转链（base64 是 protobuf，服务端还原不出发布方 URL，浏览器能打开）；Bing News 的链接可还原成原始 URL。要抓正文优先用非 Google News 的条目（官方 RSS / 媒体 RSS / Bing）。
- **X 配额是硬约束**：账号时间线走 syndication，30 次 / 15 分钟，账号 HTML 缓存 6h。默认只取 8 个账号按天轮转；连拉 20 个就会把配额打光。配额打光时工具会自己降级并在缺口里写明，不要去重试刷。
- **中文覆盖的现实**：机器之心（jiqizhixin.com）与新智元（aiera.com.cn）**没有可用 RSS / 接口**，官网只是壳页；新智元只能在微信公众号里（`--wechat`），机器之心靠 Google News 中文检索与其它媒体转引。
- 每个源最多在每节出现 `maxPerSource` 条（默认 6）、Top 10 里最多 2 条同一来源且同一分组最多 3 条——避免一家媒体刷屏。
- **合规**：全部为公开只读信息，输出仅供研究参考，**不构成投资建议**；融资 / IPO 类消息写清"据 X 报道"，不要把传闻写成事实。

## 本机已知边界（2026-10-16 实测，别重复踩）

- **官方渠道**：x.ai/news 403；ai.meta.com / blogs.microsoft.com 的 RSS 400/410 —— 这几家用 X 账号或 Google News 补；`www.anthropic.com/news` 无 RSS，是 HTML 解析（标题在 `PublicationList__title` 的 span 里，不在 h1-h3）。
- **有些源无视 `Accept-Encoding: identity` 仍回 gzip**（实测 deepmind.google/blog/rss.xml）→ 已统一改成取二进制再判断 gzip/deflate/br 解压，别退回 utf8 直读。
- **the-decoder.com/feed 返回 0 字节**、zhidx.com/feed 500（用 `/rss`）、36kr / 机器之心 / 新智元 / semafor / a16z / reuters 的 feed 均为 HTML 或 404 —— 别再试。
- **semianalysis.com/feed 有时 403**（Cloudflare），失败会记进缺口；不要为此改重试次数。
- **Reddit** 走 arctic-shift 归档站（reddit.com 本体 403）：接口不支持关键词参数、`limit` 上限 100、多值 `subreddit=A,B` 返 0 行。
- **微信公众号**（搜狗）有反爬：并发一起打会静默返空，必须串行 + 间隔；默认关闭。
- **中文源并发会静默返空**：接新源先单发验证再上并发。
- shell 子进程在受限沙箱里会被拦（本机实测 pwsh 退出码 0xC0000142）；文件策略放宽到 workspace-write / danger-full-access 时才可用。**优先直接 import 模块**，命令行走 shell 只是备选。

- **抓正文（`lib.fetchArticle` / `ai_fetch_article`）实测失败清单**（2026-10-16，别重复试）：`openai.com/index/*` → 403；`reuters.com` → 401；Bloomberg / FT / Barron's / The Information → 付费墙（**只有标题可用**）；`m.36kr.com/p/*` → 火山引擎安全检测壳页；`technology.org` → 403。**能抓到的**：量子位 / 智东西 / cnBeta 等中文科技媒体、CoinDesk、6abc 等地方台、Artificial Analysis 文章页、Meta research blog。抓不到就换**同题的中文媒体或一方正文**，并在交付里标注「转述」。
- **`web_search` 单次最多 4 个 query**，超了报 `ToolCallError: queries must contain at most 4 queries`；要补的面多就分两次调。

## 与其他技能的分工

- 只想知道"最近发了哪些模型" → 用 `ai-model-radar`（发布追踪 + OpenRouter 上架 + arXiv）。
- 想知道"某模型实测/口碑/横评" → 用 `model-report`。
- 想扫"整个 AI 圈这一两天发生了什么（含融资、人事、政策、爆料）" → 用本技能。
