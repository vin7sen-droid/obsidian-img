---
name: today-hotlist
description: 五平台今日热榜 —— 一键抓取微博 / 知乎 / 百度 / 抖音 / B站 实时热搜热榜，无需任何 API Key；可只拿 JSON，也可一键生成深色自适应的 md + html 日报（含跨平台共现「今日看点」）落 Obsidian。用户说「今天热搜 / 热榜 / 微博热搜 / 知乎热榜 / 抖音热点 / 五平台热榜」或要选题、看舆情时用。
---

# 五平台今日热榜（today-hotlist）

> 接口配方源自 easyclaw-637-b（EasyClaw Link，作者 tuoxie），抓取与报告脚本为本技能实测版。
> 零依赖：纯 Python 3 标准库，不需要 pip 装任何东西。

## 能力

| 平台 | 接口 | 关键要求 |
|---|---|---|
| 微博 | `weibo.com/ajax/side/hotSearch` | 必须带 `Referer: https://weibo.com/` |
| 知乎 | `api.zhihu.com/topstory/hot-list?limit=10` | `limit` 参数被忽略，固定取前 10 |
| 百度 | `top.baidu.com/api/board?tab=realtime` | 返回 `data.cards[].content[].content[]` 双层嵌套，脚本已递归解 |
| 抖音 | `douyin.com/aweme/v1/web/hot/search/list/` | 必须带 `Referer: https://www.douyin.com/`；**偶发 TimeoutError，重试一次即成功**（报告脚本已内置每平台重试 1 次） |
| B站 | `api.bilibili.com/x/web-interface/popular?ps=10&pn=1` | 必须带 `Referer: https://www.bilibili.com/` |

全部移动端 UA、并发抓取、单平台失败不影响整体（报告里如实标注「抓取失败」）。

## 用法

```bash
cd <本技能目录>/scripts

# ① 一键：抓五平台 → 落盘 热榜-YYYY-MM-DD.md + .html
python3 gen_hotlist_report.py
#    落盘目录 = <OBSIDIAN_ROOT>/dsh/热榜/（手机 /sdcard/Obsidian，电脑 ~/Obsidian）
#    可用 HOTLIST_OUT_DIR 或 OBSIDIAN_ROOT 环境变量覆盖

# ② 只要数据：五平台并发，输出 JSON（word/title/hot/url）
python3 hotlist.py
```

## 触发词

- 「今天热搜 / 热榜」→ 跑 ①，把 md 里五平台榜单 + 今日看点读给用户
- 「微博热搜 / 知乎热榜 / 抖音热点 / B站热门」→ 跑 ② 只取该平台 JSON

## 已知坑（2026-11 实测）

1. **抖音热榜会偶发超时**（实测 22.6s TimeoutError），重试一次约 0.9s 即成功——`gen_hotlist_report.py` 已给每个平台内置重试 1 次，单独用 `hotlist.py` 时失败请重跑。
2. **微博热搜条目分钟级变化**，两次抓取结果不同属正常，不是脚本坏了。
3. 百度接口的双层嵌套结构靠 `walk()` 递归兜底，接口改版时先看 `hotlist.py` 的 `baidu()`。
4. 全部接口匿名可用、无需 cookie；若某平台突然全空，优先怀疑 Referer 头被去掉了。

## 降级

- 某平台接口失败：报告照常生成，该平台显示「本次未取到数据」并在开头标注失败原因。
- 无 Obsidian 库：设 `HOTLIST_OUT_DIR=/任意目录` 即可，产物同名。
