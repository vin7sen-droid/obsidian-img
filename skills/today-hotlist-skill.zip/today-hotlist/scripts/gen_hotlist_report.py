#!/usr/bin/env python3
# 生成 热榜-YYYY-MM-DD.md / .html 到 <OBSIDIAN_ROOT>/dsh/热榜
import os, sys, datetime, html, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hotlist import baidu, douyin, zhihu, bili, weibo


OBSIDIAN_ROOT = os.environ.get("OBSIDIAN_ROOT") or ("/sdcard/Obsidian" if os.path.isdir("/sdcard/Obsidian") else os.path.expanduser("~/Obsidian"))
OUT_DIR = os.environ.get("HOTLIST_OUT_DIR") or os.path.join(OBSIDIAN_ROOT, "dsh", "热榜")
os.makedirs(OUT_DIR, exist_ok=True)

# 抓取（单个平台失败不影响整体；每个平台失败重试 1 次——抖音接口超时是偶发）
fetchers = [("微博", "weibo", weibo), ("抖音", "douyin", douyin),
            ("百度", "baidu", baidu), ("知乎", "zhihu", zhihu), ("B站", "bili", bili)]
data, fails = {}, []
for label, key, fn in fetchers:
    err = None
    for attempt in (1, 2):
        try:
            data[key] = fn()[:10]
            err = None
            break
        except Exception as e:
            err = e
    if err is not None:
        data[key] = []
        fails.append((label, f"{type(err).__name__}: {err}"))

now = datetime.datetime.now().astimezone()
DAY = now.strftime("%Y-%m-%d")
HHMM = now.strftime("%H:%M")
md_path = os.path.join(OUT_DIR, f"热榜-{DAY}.md")
html_path = os.path.join(OUT_DIR, f"热榜-{DAY}.html")

META = {
    "weibo": ("🔥", "微博热搜", "https://weibo.com/"),
    "douyin": ("📱", "抖音热榜", "https://www.douyin.com/"),
    "baidu": ("🔍", "百度热搜", "https://top.baidu.com/board?tab=realtime"),
    "zhihu": ("💡", "知乎热榜", "https://www.zhihu.com/hot"),
    "bili": ("📺", "B站热门", "https://www.bilibili.com/v/popular/all"),
}
ORDER = ["weibo", "douyin", "baidu", "zhihu", "bili"]

def wan(n):
    try:
        n = int(n)
    except (TypeError, ValueError):
        return ""
    return f"{n/10000:.1f}万" if n >= 10000 else str(n)


def _norm(t):
    return re.sub(r"[\s\W_]+", "", str(t or "")).lower()

def _lcs(a, b):
    """最长公共子串长度"""
    if not a or not b: return 0
    prev = [0] * (len(b) + 1); best = 0
    for ca in a:
        cur = [0] * (len(b) + 1)
        for j, cb in enumerate(b, 1):
            if ca == cb:
                cur[j] = prev[j-1] + 1
                if cur[j] > best: best = cur[j]
        prev = cur
    return best

def build_overview(data, topn=3, min_common=7):
    """从当天数据里找跨平台共现话题，生成看点；找不到就退回各平台榜首。"""
    items = []  # (platform, title_norm, title_raw)
    for key in ORDER:
        for it in (data.get(key) or []):
            raw = it.get("word") or it.get("title") or ""
            if raw: items.append((key, _norm(raw), raw.strip()))
    if not items:
        return "本次未取到任何平台数据。"

    scored = []
    for i, (pk, nk, rk) in enumerate(items):
        hit = {pk}
        for j, (pj, nj, rj) in enumerate(items):
            if i == j or pj in hit: continue
            if _lcs(nk, nj) >= min_common:
                hit.add(pj)
        if len(hit) > 1:
            scored.append((len(hit), rk, hit))

    clusters, used = [], set()
    for n, raw, hit in sorted(scored, key=lambda x: -x[0]):
        k = _norm(raw)
        if k in used: continue
        if any(_lcs(k, _norm(c[1])) >= min_common for c in clusters): continue
        clusters.append((n, raw, hit))
        used.add(k)
        for _, r2, _ in scored:
            if _lcs(k, _norm(r2)) >= min_common: used.add(_norm(r2))
        if len(clusters) >= topn: break

    cn = {"weibo": "微博", "douyin": "抖音", "baidu": "百度", "zhihu": "知乎", "bili": "B站"}
    if clusters:
        parts = []
        for n, raw, hit in clusters:
            names = "·".join(cn[x] for x in ORDER if x in hit)
            parts.append(f"「{raw}」（{names} 同步上榜）")
        return "；".join(parts)
    # 兜底：各平台榜首
    tops = []
    for key in ORDER:
        d = data.get(key) or []
        if d:
            raw = (d[0].get("word") or d[0].get("title") or "").strip()
            tops.append(f"{cn[key]}榜首「{raw}」")
    return "；".join(tops[:3])

def row(key, i, it):
    """统一成 (标题, 链接, 热度)"""
    if key in ("weibo", "douyin", "baidu"):
        t = it.get("word", "")
        url = it.get("url", "")
        h = wan(it.get("hot")) if key in ("weibo", "douyin") else ""
        return t, url, h
    return it.get("title", "").strip(), it.get("url", ""), ""

OVERVIEW = build_overview(data)

# ---------- Markdown ----------
md = [f"# 今日热榜 · {DAY}", "",
      f"> 采集时间：{DAY} {HHMM}（Asia/Shanghai）  ", f"> **今日看点**：{OVERVIEW}", ""]
if fails:
    md += ["**抓取失败**：" + "；".join(f"{l}（{e}）" for l, e in fails), ""]
for key in ORDER:
    icon, name, home = META[key]
    md += [f"## {icon} {name}", ""]
    if not data.get(key):
        md += ["_本次未取到数据。_", ""]
        continue
    for i, it in enumerate(data[key], 1):
        t, url, h = row(key, i, it)
        suffix = f" · {h}" if h else ""
        md.append(f"{i}. [{t}]({url}){suffix}")
    md.append("")
md += ["---", "", f"_由 today-hotlist 技能抓取（接口配方源自 easyclaw-637-b）；原始接口：百度 board / 抖音 hot search / 知乎 topstory / B站 popular / 微博 hotSearch。_", ""]
open(md_path, "w", encoding="utf-8").write("\n".join(md))

# ---------- HTML ----------
def esc(s):
    return html.escape(str(s), quote=True)

cards = []
for key in ORDER:
    icon, name, home = META[key]
    items = data.get(key) or []
    rows = []
    for i, it in enumerate(items, 1):
        t, url, h = row(key, i, it)
        badge = f'<span class="hot">{esc(h)}</span>' if h else ""
        top = ' class="top3"' if i <= 3 else ""
        rows.append(
            f'<a class="item{top}" href="{esc(url)}" target="_blank" rel="noopener">'
            f'<span class="rank">{i}</span>'
            f'<span class="title">{esc(t)}</span>{badge}</a>')
    body = "\n".join(rows) if rows else '<p class="empty">本次未取到数据（接口失败）。</p>'
    cards.append(f'''
    <section class="card" data-platform="{key}">
      <header>
        <h2>{icon} {name}</h2>
        <a class="home" href="{esc(home)}" target="_blank" rel="noopener">原站 ↗</a>
      </header>
      {body}
    </section>''')

fail_html = ""
if fails:
    fail_html = '<p class="warn">抓取失败：' + "；".join(f"{esc(l)}（{esc(e)}）" for l, e in fails) + "</p>"

doc = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0e1117">
<title>热榜 {DAY}</title>
<style>
:root{{
  --bg:#0e1117; --card:#161b23; --card2:#1c2230; --txt:#e8edf5; --dim:#8a94a6;
  --line:#242c3a; --hi:#ff6b5e; --hi2:#ffa53c; --link:#7cc4ff;
}}
*{{box-sizing:border-box;-webkit-tap-highlight-color:transparent}}
body{{margin:0;padding:16px 14px 48px;background:var(--bg);color:var(--txt);
  font:16px/1.55 -apple-system,"PingFang SC","Noto Sans SC",system-ui,sans-serif;
  max-width:760px;margin-inline:auto}}
h1{{font-size:22px;margin:8px 0 4px;letter-spacing:.5px}}
.meta{{color:var(--dim);font-size:13px;margin-bottom:14px}}
.overview{{background:linear-gradient(135deg,#1d2735,#161b23);border:1px solid var(--line);
  border-left:3px solid var(--hi);border-radius:12px;padding:12px 14px;font-size:14.5px;
  line-height:1.7;margin-bottom:16px}}
.overview b{{color:var(--hi2)}}
.warn{{background:#2a1c1c;border:1px solid #5a2b2b;color:#ff9d9d;border-radius:10px;
  padding:10px 12px;font-size:13.5px}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:16px;
  padding:6px 12px 10px;margin-bottom:14px;overflow:hidden}}
.card header{{display:flex;align-items:center;justify-content:space-between;gap:8px;
  padding:10px 2px 8px;border-bottom:1px solid var(--line)}}
.card h2{{font-size:16.5px;margin:0;font-weight:650}}
.home{{color:var(--link);font-size:12.5px;text-decoration:none;white-space:nowrap}}
.item{{display:flex;align-items:flex-start;gap:10px;padding:11px 2px;
  border-bottom:1px solid rgba(255,255,255,.045);text-decoration:none;color:var(--txt)}}
.item:last-child{{border-bottom:none}}
.item:active{{background:var(--card2)}}
.rank{{flex:0 0 22px;height:22px;line-height:22px;text-align:center;border-radius:7px;
  background:#232b39;color:var(--dim);font-size:12.5px;font-weight:600;margin-top:1px}}
.item.top3 .rank{{background:linear-gradient(135deg,var(--hi),var(--hi2));color:#1a0f0c}}
.title{{flex:1;font-size:15px;line-height:1.5}}
.hot{{flex:0 0 auto;color:var(--hi2);font-size:12px;font-variant-numeric:tabular-nums;
  padding-top:3px;white-space:nowrap}}
.empty{{color:var(--dim);font-size:14px;padding:10px 2px}}
footer{{color:var(--dim);font-size:12px;text-align:center;margin-top:22px;line-height:1.8}}
@media (prefers-color-scheme: light){{
  :root{{--bg:#f5f7fa;--card:#fff;--card2:#eef2f8;--txt:#1a2029;--dim:#7a8699;
    --line:#e3e8f0;--hi:#e8503f;--hi2:#e08a12;--link:#0a72d0}}
  .overview{{background:linear-gradient(135deg,#fff,#fff8f2)}}
  .rank{{background:#eef1f6}}
  .item:active{{background:var(--card2)}}
  .warn{{background:#fff3f3;border-color:#f5c8c8;color:#b1372b}}
}}
</style>
</head>
<body>
<h1>今日热榜 · {DAY}</h1>
<div class="meta">采集 {HHMM} · 五平台实时接口抽取</div>
<div class="overview"><b>今日看点</b><br>{esc(OVERVIEW)}</div>
{fail_html}
{''.join(cards)}
<footer>由 today-hotlist 抓取 · 数据来自各平台公开接口<br>生成于 {DAY} {HHMM}</footer>
</body>
</html>'''
open(html_path, "w", encoding="utf-8").write(doc)

print("MD  :", md_path, os.path.getsize(md_path), "bytes")
print("HTML:", html_path, os.path.getsize(html_path), "bytes")
print("FAIL:", fails or "none")
for key in ORDER:
    print(f"  {key}: {len(data.get(key) or [])} 条")