import json, urllib.request, ssl, concurrent.futures as cf
from urllib.parse import quote

UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
CTX = ssl.create_default_context(); CTX.check_hostname = False; CTX.verify_mode = ssl.CERT_NONE

def get(url, headers=None, timeout=20):
    h = {"User-Agent": UA, "Accept": "*/*", "Accept-Language": "zh-CN,zh;q=0.9"}
    if headers: h.update(headers)
    with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout, context=CTX) as r:
        return r.read().decode("utf-8", "replace")

def walk(node, key):
    """递归找出所有含指定 key 的 dict"""
    out = []
    if isinstance(node, dict):
        if key in node: out.append(node)
        for v in node.values(): out += walk(v, key)
    elif isinstance(node, list):
        for v in node: out += walk(v, key)
    return out

def baidu():
    d = json.loads(get("https://top.baidu.com/api/board?tab=realtime"))
    items = walk(d["data"], "word")
    seen, res = set(), []
    for it in items:
        w = it.get("word")
        if not w or w in seen: continue
        seen.add(w)
        res.append({"word": w, "desc": it.get("desc", ""), "url": it.get("url")})
    return res[:10]

def douyin():
    d = json.loads(get("https://www.douyin.com/aweme/v1/web/hot/search/list/",
                       {"Referer": "https://www.douyin.com/"}))
    res = []
    for x in d["data"]["word_list"][:10]:
        w = x.get("word")
        res.append({"word": w, "hot": x.get("hot_value"),
                    "url": "https://www.douyin.com/search/" + quote(w)})
    return res

def zhihu():
    d = json.loads(get("https://api.zhihu.com/topstory/hot-list?limit=10"))
    res = []
    for x in d["data"][:10]:
        t = x.get("target", {})
        url = t.get("url", "")
        if "/questions/" in url:
            url = "https://www.zhihu.com/question/" + url.rstrip("/").split("/")[-1]
        res.append({"title": t.get("title"), "url": url})
    return res

def bili():
    d = json.loads(get("https://api.bilibili.com/x/web-interface/popular?ps=10&pn=1",
                       {"Referer": "https://www.bilibili.com/"}))
    res = []
    for x in d["data"]["list"][:10]:
        res.append({"title": x.get("title"),
                    "url": x.get("short_link") or "https://www.bilibili.com/video/" + x.get("bvid", "")})
    return res

def weibo():
    d = json.loads(get("https://weibo.com/ajax/side/hotSearch", {"Referer": "https://weibo.com/"}))
    res = []
    for x in d["data"]["realtime"][:10]:
        w = x.get("word")
        res.append({"word": w, "hot": x.get("num"),
                    "url": "https://s.weibo.com/weibo?q=" + quote("#" + w + "#")})
    return res

if __name__ == "__main__":
    jobs = {"baidu": baidu, "douyin": douyin, "zhihu": zhihu, "bili": bili, "weibo": weibo}
    res = {}
    with cf.ThreadPoolExecutor(5) as ex:
        futs = {n: ex.submit(f) for n, f in jobs.items()}
        for n, f in futs.items():
            try: res[n] = {"ok": True, "data": f.result()}
            except Exception as e: res[n] = {"ok": False, "err": f"{type(e).__name__}: {e}"}
    print(json.dumps(res, ensure_ascii=False, indent=1))