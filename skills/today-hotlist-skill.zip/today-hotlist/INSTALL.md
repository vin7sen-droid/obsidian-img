# 安装 today-hotlist（五平台今日热榜）

零依赖：Python 3 标准库即可，无需 pip。抓取走各平台公开接口，不需要 API Key / cookie / 代理。

## 1. 装进 DSH

```bash
mkdir -p ~/.agents/skills && cp -r today-hotlist ~/.agents/skills/
```

## 2. 装进 Claude Code

```bash
mkdir -p ~/.claude/skills && cp -r today-hotlist ~/.claude/skills/     # 用户级
# 或项目级：cp -r today-hotlist <项目>/.claude/skills/
```

## 3. 装进 OpenClaw / OpenCode / 其它认 SKILL.md 的软件

放进它的 skills 目录（OpenClaw `~/.openclaw/skills/`，OpenCode `~/.config/opencode/skills/`）；
不认目录的软件把 SKILL.md 内容作为系统提示装载，并保持 `scripts/` 与它同级。

## 4. 验证

```bash
cd <本技能目录>/scripts
python3 hotlist.py                 # 五平台并发，输出 JSON（秒级）
python3 gen_hotlist_report.py      # 落盘 md + html
```

成功标志：JSON 里五个平台 `"ok": true`；落盘目录出现 `热榜-YYYY-MM-DD.md` 与同名 `.html`（浏览器打开是深色自适应卡片页）。

## 5. 路径

| 项 | 默认 | 覆盖 |
|---|---|---|
| 落盘目录 | `<OBSIDIAN_ROOT>/dsh/热榜/`（手机 `/sdcard/Obsidian`，否则 `~/Obsidian`） | `HOTLIST_OUT_DIR` / `OBSIDIAN_ROOT` |
| 文件名 | `热榜-YYYY-MM-DD.md` / `.html` | — |

## 6. 卸载

删技能目录即可；落盘的热榜文件想清就一起删。
