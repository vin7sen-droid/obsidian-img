# clip-to-readitlater 技能包

把网页链接剪藏成 Obsidian 笔记（ReadItLater Inbox 版式：标题+标签+摘要+原文行+正文+IT之家评论区），支持图床托管、评论刷新、抖音/Instagram 分流、英文笔记机翻打底、摘要/译文数字机检。任何识别 SKILL.md（Agent Skills 格式）的 AI 软件都能安装。

## 包内容
- SKILL.md —— 技能说明（AI 软件按它执行）
- scripts/ —— 19 个脚本（剪藏/翻译/图床/机检），路径已自适应，无需改动
- INSTALL.md —— 本文件

## 安装
| 软件 | 安装位置 |
|---|---|
| DSH（本包来源） | ~/.agents/skills/clip-to-readitlater/ |
| Claude Code | ~/.claude/skills/clip-to-readitlater/（或项目 .claude/skills/） |
| OpenClaw / OpenCode 等 | 各自的 skills 目录下建 clip-to-readitlater/，放入包内全部文件 |

即：把整个 clip-to-readitlater/ 目录拷到对应 skills 目录即可。

## 环境要求
- python3 ≥3.10（纯标准库）+ node ≥18（zh.mjs 翻译、xcheck.mjs 数字校验）
- Obsidian 库：默认找 /sdcard/Obsidian（Android），否则 ~/Obsidian；环境变量 OBSIDIAN_ROOT 可覆盖
- 笔记落点：<OBSIDIAN_ROOT>/dsh/ReadItLater Inbox/

## 凭据（全部可选，缺了自动降级，不会中断）
| 凭据 | 路径（600 权限） | 用途 | 缺失时 |
|---|---|---|---|
| GitHub token | ~/.config/ghclip/token | 图片托管到图床仓库 | 保留源站原图链接 |
| 标签 LLM | ~/.config/tagllm/{key,base} | 内置词典查不到时 LLM 兜底标签 | 只用内置词典 |
| B站 cookie | ~/.config/bili/cookies.json | 剪藏 B 站内容 | 匿名降级 |
| 代理 | 环境变量 https_proxy 等 | 墙外站点抓取 | 直连 |

## 降级差异
- 「精修队员」是 DSH 的多代理特性：其他软件里由主 agent 按 SKILL.md 的精修规则自己完成（备份→改标签/摘要→译英文→清样板→机检三件套）。
- gh_sync 多设备同步、MacroDroid 分享触发器属 DSH 生态，包外可选。

## 更新
本包是 /root/workspace/tools/ 真源脚本的导出物；真源改动后需重新打包。
