---
name: clip-to-readitlater
description: 把用户粘贴的网页链接抓成 Obsidian 剪藏笔记存进 ReadItLater Inbox（固定版式：标题 + 标签行 + 摘要 + 原文行 + 正文 + IT之家评论区），并处理配图托管、评论刷新、抖音/Instagram 分流。用户说“存到稍后读/收集箱”、直接甩链接、或要刷新评论时用
---

## 路径与可移植性（打包版）

- `scripts/` 下所有路径相对**本技能目录**：命令示例里的 `scripts/clip.py` 即本技能目录下 scripts/clip.py。
- Obsidian 库根目录 = 环境变量 `OBSIDIAN_ROOT` 优先，否则有 `/sdcard/Obsidian`（Android）用之，否则 `~/Obsidian`；剪藏落点 `<OBSIDIAN_ROOT>/dsh/ReadItLater Inbox/`。
- 备份自动建于技能包上级 `bak/inbox/`（Android 上同时镜像 /sdcard/Download/DSH-Go/inbox-bak/）。
- 凭据缺失自动降级不中断（ghclip token=图床、tagllm=标签 LLM 兜底、B站 cookie=剪藏 B 站），详见 INSTALL.md。

# 链接 → ReadItLater Inbox（完整流程）

## 概览

用户丢一个 URL 过来就等于要：抓正文全文 → 生成 1–3 个标签 →（IT之家/快科技还要）抓全部评论 →
存成 md 到 `$OBSIDIAN_ROOT/dsh/ReadItLater Inbox/`，落库后自动把配图传到 GitHub。
不反问确认，直接做完再报结果。

```bash
python3 scripts/clip.py "<URL>" --tags "#标签1 #标签2"
```

本机没有 curl；脚本用 python urllib，自带 UA 和 gzip。URL 参数给引号。

## 写入范围（硬规则）

**只有 `$OBSIDIAN_ROOT/dsh/ReadItLater Inbox/` 是可写区。** 其余 Obsidian 目录（旧的
`/sdcard/Obsidian/my/` 库、Evernote 导入目录等）一律只读——要动必须用户当次点名，
并且只动被点名的文件。`my` 库的笔记要参与图片回收，也得用户显式命令。

## 固定版式（2026-11-13 用户定版：元信息进 frontmatter）

新剪藏一律先 frontmatter 再正文，**正文里不再有标签行与「原文：」行**（存量 141 篇旧笔记不动）：

**精修硬规则（2026-11-15 实测教训）**：改版式时必须保留 created/url（改前先 `head -8` 看原文件）；标签写进 `tags:` 行后、写盘后必须再 `head -8` 自查三行齐全才允许回报——曾有队员 replace 改 tags 静默失败，frontmatter 整块丢失且回报声称已补，比漏做更严重。tags 建议按行重建，不要用格式敏感的正则整块 replace。
**tags 插入位置与自查口径（2026-11-16 队员险情补强）**：①按行重建时新 tag 行必须 **in-place 插在 `tags:` 行的紧后方**，不能 append 到行列表末尾（会落到 `---` 之后，frontmatter 破损、YAML 解析丢 tags）；②frontmatter 操作后的自查要看足 `---` 结束行（验证 created/url/tags 全在两道 `---` 之间），只看前 8 行里「有没有 tags 字样」抓不住位置错误；③修复产生过重复行时，改完必须再跑一次 `head -8` + `grep -c "tags:"`（=1）确认无重复。

```yaml
---
created: 2026-10-06        ← 原文发布日期（取不到用剪藏当天）
url: https://…             ← 原文链接
author: Nathan Lambert     ← 没有作者则省略此行
tags:
  - 开放权重               ← 1–3 个，无 # 前缀
  - AI安全
---
# 中文标题

摘要：…（1 句，含关键数字）

正文……
```

```
# 标题

#标签1 #标签2

摘要：1–3 句，含关键数字，不复述首段，不抄 meta description。

原文：URL ｜ 2026/11/7 19:07 ｜ 作者

正文（段落、`**加粗**`、`![](图片地址)`）

---

## 评论区（48 条）

主楼 26 条 + 回复 21 条，按原文页顺序。

**1楼 · 昵称 · 11-07 19:08 · 赞 5 · 广东深圳**

评论正文

　　**↳ 某人 回复 楼主** · 11-07 19:56 · 赞 0
　　回复正文
```

要点：第一行就是 `# 标题`（不写 `[[ReadItLater]] [[Article]]`、不写 YAML frontmatter）；
标签行紧跟标题、只 1–3 个；「原文：」是普通行不是引用块；正文与评论区之间保留一行 `---`；
评论区条目头用加粗行 + 普通段落（禁 `###`、禁 `>`），热评置顶并放大一号；
**楼中楼（↳ 回复）紧凑缩进**：整条比主楼缩进两个全角空格「　　」，头行与正文连续两行、楼中楼条目之间不空行；主楼层块之间、主楼正文与其楼中楼块之间各空一行（用户 2026-11-14 三轮定：先缩进 →「太空了，再紧凑点」→「主楼与楼层空一行」；存量 161 篇已三轮批量套用，增量合并的条目切分与指纹均已兼容——指纹按「作者+去空白正文」比对，与版式无关）。

## 标签规则（用户四轮迭代定版）

1. 看主骨定数量——主骨唯一就 1 个（vivo X500 Ultra 篇只 `#vivoX500Ultra`）。
2. 厂牌限定保留：`#OPPO手机 #FindX9Ultra`、`#特斯拉 #Cybertruck`、`#苹果 #Siri`。
3. 小众/术语主词带联想维度：`#MacBookPro #Backglow`、`#先进封装 #CoWoS`、`#C909 #森林灭火`。
4. 真双主体保留 2 个：`#TikTok #欧盟`、`#马斯克 #Anthropic`。
5. 只删凑数词：零件级（`#LYTL910`）、冗余类别（`#漫步者` 的 `#蓝牙音箱`）、来源词（`#CPUZ`）、纯背景（`#国补`）。
6. 同主题系列统一主标签（iPhoneDuo 系、Cybertruck 系、Siri 系）。
7. 短名优先；标签内不能有 `.` `+`（Obsidian 会截断把尾巴漏在正文里，用 `-` 代替）。
8. **没有「一律保留」的特例**（2026-11-12 用户改）：`#黄仁勋 #英伟达` 系原本被点名不动，现改为**看文章实际内容定**——讲个人（道歉信、身价缩水、返岗开会）就只留 `#黄仁勋`；讲公司影响（股价重挫、股东诉讼、接班人）才 `#黄仁勋 #英伟达`；主骨是别的主题就换对应标签（如 `#黄仁勋 #AI竞赛`、`#马斯克 #黄仁勋`）。其他人物/公司同理。

**标签生成：LLM 直出 + 词典只做重复检测（2026-11-17 改版）**

剪藏时**没给 `--tags`** → `clip.py` 直接调 `tools/tag_llm.py` 让 LLM 出 1-3 个标签（GLM-5.3-flash 主 / laguna-xs-2.1 备），打印 `标签候选（LLM 生成，精修复核）: …` 并把结果填进初始 `tags:`；给 `--tags` 则以你给的为准；`--no-tag-suggest` 关闭。LLM 不可用（无凭据/限流/超时）才退回 `tag_suggest.py` 的词典候选兜底。

**词典为什么降级**：`tag_suggest.py` 是字符 n-gram 相似度检索，只认库里出现过的词——用 4 条库外新标题实测，高通骁龙 8 Gen6→`马斯克`、小米 17 Ultra→`OPPO手机/FindX9Ultra`、比亚迪销量→`储能/熙特尔`、红米 K90→`苹果/iPhone18`，**四条全错**。它现在只保留一个用途：**重复检测**——标题与库内某篇 top1 分值 ≥12 时打印 `⚠️库内已有同题`，这个信号可靠（同事件两篇报道能识别）。

拿不准标签时跑 `python3 tools/tag_llm.py "<标题文本>" --verbose` 看 LLM 判断（理由会一起打印）；确需查库里有没有同类文章再跑 `tag_suggest.py`。推理模型 `max_tokens` 必须 ≥2000（120/900 会被 reasoning 吃光变空响应），凭据在 `/root/.config/tagllm/{key,base}`（600，不进 gh_sync，新设备需自配）。

## 配图托管（2026-11-11 定版）

剪藏落库后 `clip.py` 自动调 `tools/gh_img.py` 处理配图，规则：

| 图片类型 | 处理 |
|---|---|
| 普通图 ≤300KB | 原图上传 GitHub，链接 `gh-proxy` |
| 普通图 >300KB | 先压到 300KB 以下再传（降质量 88→32，不够再缩尺寸 0.85→0.35；透明走 webp） |
| GIF | **完全不处理**，保留源站原图链接（不上传、不代理、不压缩） |

- 仓库 `vin7sen-droid/obsidian-img` 的 `clip/`，文件名 = 内容 `sha1[:12]` + 扩展名
- 链接模板 `https://gh-proxy.com/https://raw.githubusercontent.com/vin7sen-droid/obsidian-img/main/clip/<file>`
- 换前缀用 `python3 tools/img_prefix.py --to <名>`（可选 jsdelivr / jsdelivr-fastly / raw / ghfast / githack / statically 等 9 个实测可用前缀，`--check` 看现状）
- 下载一律取源站原图（`orig_url()` 解包 wsrv 包裹）——wsrv 会重编码，JPEG 92KB 压到 37KB
- 缓存 `<技能包上级>/bak/img_map.json`，重跑只处理新增 URL
- GIF 走原链的依据：Obsidian 客户端加载远程图**不带 Referer**，img.ithome.com 直接 200；wsrv 转 webp 只保留第 1 帧，动图会变静态

## 图片回收（手动，不自动）

```bash
python3 scripts/gh_img_gc.py --dry   # 先看清单
python3 scripts/gh_img_gc.py         # 确认后真删
```

- 判断依据：扫 **dsh 库**所有 md 里的 `clip/<file>` 引用，与仓库文件求差集，无引用者删
- 同时扫其他库（`my` 等）做**提醒**：某图只在其他库被引用时会列出来，但**不删**
- 用户明确要求：不设定时任务、不在剪藏链路里自动调用，只在用户开口时手跑

## 评论刷新

单篇（IT之家/快科技）：

```bash
python3 tools/clip.py "<URL>" --name "<文件名不含.md>" --refresh-comments
```

`--refresh-comments` 必须同时给 url 和 `--name`；写盘前有**减量护栏**——新评论数少于旧的会拒绝覆盖并提示
「疑似接口降级，已保留原文件」。老文章 PC 接口关门（endHint）时自动走移动端兜底，但只能拿到主楼。

批量：

```bash
python3 tools/refresh_all_comments.py --days 2 --dry   # 2 天内发布的，先预览
python3 tools/refresh_all_comments.py --days 2         # 6 线程并发
```

## 备份机制

- `clip.py` 每次写盘前自动备份（`_backup_or_die`，备份失败直接中止，绝不静默覆盖）
- 手工改笔记前先 `python3 scripts/bak.py "<笔记>"`，看到「已备份 → …」再动手
- 副本双写 `<技能包上级>/bak/inbox/` 与 `/sdcard/Download/DSH-Go/inbox-bak/`，按文件名时间戳留 24 小时
- 备份一律 `cp -p` / `shutil.copy2`，裸 `cp` 会毁 mtime 且不可追回

## 批量改写纪律（硬规则）

1. 先算精确清单：按内文特征筛（如「含 `<!-- 待精修 -->`」），**打印清单**再动手；禁止 `"$DIR"/*.md` 通配。
2. 改任何已存在笔记前先 `bak.py`；失败就停手回报。
3. 脚本必须幂等——检测已处理标记就 skip。
4. 出错后全量比对新旧目录，确认「非目标文件差异 0」才算收尾。

## 本地服务与触发入口

`scripts/clip_server.py` 监听 `127.0.0.1:8899`：

| 端点 | 作用 |
|---|---|
| `GET /clip?url=<url>` | 剪藏；也接未编码的中文/空格/多行文本 |
| `POST /clip`（body=分享文本） | 同上，多行分享内容用这个最稳 |
| `GET /refresh` | 刷新全部评论 |
| `GET /ping` | 健康检查 |

- 抖音链接自动分流到 `scripts/douyin_dl.py`，Instagram 分流到 `instagram_downloader_final.py`
- dsh-go 插件 `local-clip` 在引擎加载时自动拉起服务（probe → spawn → 轮询就绪）
- 手机侧 MacroDroid：分享触发用 POST `http://127.0.0.1:8899/clip`、body `{shared_text}`；
  通知栏按钮触发时 MacroDroid 会被拉到前台，能读剪贴板 `{clipboard}`（Android 13+ 后台读不到剪贴板）
- 探测服务用 python，别用 curl（本机没装 curl）

## 精修流程

按钮/自动剪藏落库的笔记带 `<!-- 待精修 -->` 标记，需要人工精修：

1. 领队 grep 出所有带标记的笔记，按「按量启用 + 工作量均衡」派给持久工位（2026-11-12 三次调版 + 2026-11-19 用户最终定）：**待精修 ≤5 篇时领队自己修，不派单**（单人少量更省时）；**6–10 篇只派 clip-refiner 一人**（第二队员不启用）；**超过 10 篇才启用 clip-refiner-2**，两人平分、余数给 clip-refiner。已停用的 -3～-8 不再派单。分配时先分档再凑数——**长稿（>150 行）与英文稿单独均摊，每人不超 2 篇长稿**，短稿成组补齐；纯按篇数分会让一个人手里的两篇长稿拖住全局。
2. 重写标签（1–3 个）、重写摘要（1–3 句带数字）、清站点样板、删标记与多余空行
3. 确认评论区在（缺失才 `--name ... --refresh-comments`）
4. 空壳笔记（标题「未命名」或正文 <100 字）直接删除并说明

### 派单四则（2026-11-12 用户定「都写」）

**⓪ 剪藏完直接派人精修（2026-11-15 用户定「以后直接」）。** 用户发链接剪藏落库后，不再询问「要派人精修吗」，直接按下方规则派单（领队先 bak.py 备份再派）；英文稿按「英文站点」节的三件套流程一并翻译。只有空壳/异常时才停下来报告。

**① 按工作量分配。** 派单前先按行数分档：>150 行算长稿、英文稿单独算一档、其余为短稿。长稿与英文稿在参与的人之间均摊（单人时按顺序做，双人时各分一半），短稿成组补齐。理由：一篇英文长稿 15–20 分钟，一篇中文短讯 1 分钟，只按篇数分，总时长永远被最长的那条拖着。

**② 领队统一预先备份。** 派单前领队一次性跑 `python3 scripts/bak.py "<文件1>" "<文件2>" …`（支持多文件），派单消息里注明「已备份，可直接改」。队员不再各自跑 bak.py —— 省掉每人一次工具调用；但队员若要对清单外文件动手，仍须自己备份。

**③ 固定回报格式。** 队员回报用一行一条：

```
文件名（可截断）| 标签 | 摘要首句 | 评论数 | 异常
```

领队据此直接汇总成表，并与预备份做 diff 校验，不必读长篇自由文本。

**④ 巡检代替盲等。** 派单后领队每约 2 分钟跑一次 `grep -l "待精修" <Inbox>/*.md | wc -l` 看剩余数，谁的文件先清空、谁卡住一目了然；超过 10 分钟没有任何变化且对应队员无回报，领队直接接手该篇，不等队员开口。

### 提速三则（2026-11-12 用户定「照你推荐做」）

**① 核对按需触发，不默认跑 `--stdout`。** 跑 `python3 tools/clip.py "<URL>" --stdout` 等于把整篇原文再抓一遍，中文短讯没必要。

**IT之家一律不核对**（用户 2026-11-12 明确「it 之家超行数不用重新抓」）——它是定制解析（`div#paragraph` + `clean_body` 内置样板剔除与尾部截断），行数再多也不跑核对，直接按笔记判断。

只有**非 IT之家站点**出现下列任一信号时才核对：

- 笔记超过 100 行
- 出现站点样板词（Most Popular、Subscribe、责任编辑、相关阅读、扫码下载、爆料群、Ad、广告）
- 英文站（The Verge / TechCrunch / Wired 等，作者卡与 newsletter 引导常长得像正文）

其余情况直接按笔记本身判断——成片短链接行、订阅措辞、分享按钮组都是强特征，肉眼可辨。**无论如何都不能裸跑 clip.py**（不带 `--stdout` 会覆盖同名笔记，红线）。

**② 一次写盘，不分步 edit。** 标签、摘要、样板清除合成一次写入，别「改标签 → 改摘要 → 清样板」来回读写整个文件。

**③ 摘要单主题默认 1 句。** 文章只有一个主骨时写一句带数字的即可，不硬凑 2–3 句；多要点才写多句。

**④ 摘要草稿已升级（2026-11-16 用户定）。** clip.py 落库时的初版摘要 = 正文前 3 段里第一个含数字的句子（已剥「[IT之家](url) N 月 N 日消息，」固定开头），找不到才回落首段前两句——队员精修时把它当草稿**核对压缩**即可，不必通读全文从零写。

**⑤ 摘要数字自查（2026-11-16 用户定，写盘后必跑；同日借鉴热评会话改为清单制 + SI 归一）。** `python3 scripts/summary_check.py "<笔记路径>"`——摘要里的数字与全文（H1/正文/评论区标题）比对，**只出清单不当阻断闸**：CHECK 列出摘要写了正文没有的数，由人 30 秒逐条判——编造/换算错必须修；约数改写（over six million→650 万）、补背景数（行业常识数）、SI 换算（摘要「130 亿」↔ 正文「$13 billion」、「40000 亿」↔「4 万亿」）放行。SI 归一只对带量级单位的 token 生效（裸数字不做跨比——「4 亿美元」与正文「第 4 页」的 4 数值相等但语义不同，真错量级照样抓获）；支持单位前缀（摘要「100 毫秒」↔ 正文「100ms」）与千分位。退出码 1=有 flag 待人工核对。三道闸分工：summary_check（摘要 vs 正文，清单 30 秒）→ xcheck（译文 vs 英文原文，交付前兜底）→ 人工抽查五处（语义/专名终审）。

## 英文站点：剪藏时自动机翻 + 人工润色（2026-11-19 用户定，覆盖 11-12 的「只标记不译」）

用户 m13127/m13129：「发链接剪藏文章应该直接 zh 翻译，再人工修饰」。

- **检测**：`tools/trans.py` 的 `is_english()` —— 英文字母 ≥300 且中文占比 <5%。中文站零开销。
- **落库行为（clip.py 自动做）**：检测到英文后立刻调 `_translate_zh()`（= `node tools/zh.mjs`，stdin 喂全文）翻 **标题 + 正文**，摘要随后从**中文正文**推导，再落库；末尾写 `<!-- 待精修：机翻译文，请人工润色（人名/数字/专名核对） -->`，打印「检测到英文文章：自动翻译中...」→「自动翻译完成，待人工润色」。`--no-translate` 可关。
- **译后自动清洗（clip.py 内置）**：`_fix_bold()` 修 `** 文字 **` 星号内空格、补 `##标题` 缺的空格；摘要剥掉 markdown 链接（避免截断在半截 URL 上）；clean_body 删 Engadget 类页头样板（`Add X on Google:`/`Preferred Source`/`Google Discover`/`By …`/`X for Y` 署名/`Nov. 17, 2026 7:00 pm EST` 日期行/`News`、`AI` 栏目单词/图片版权署名/`## 推荐`）；并删掉与 `meta description` 完全相同的正文行（dek 副标题与摘要重复）。
- **人工润色（领队剪完立刻做，不等队员）**：机翻常见硬伤——①术语：Gemini 语境 memory 是「记忆」不是「内存」、Personal Intelligence 是「个人智能」不是「个人情报」、Activity 是「活动记录」；②站名音译（Engadget→恩加吉特）删掉或还原英文；③人名按中文媒体习惯、品牌/产品名保留英文；④生硬直译改写（"build a profile of you"→「建立一份关于你的档案」）。用 bak.py 备份后一次写盘。
- **精修时怎么译（2026-11-15 用户定「新剪藏也要重新跑流程」——三篇 AWS 实测定版，**不再用 trans.py/Google clients5**）**：
  1. `node tools/zh.mjs -f <英文正文> > <译文>` —— 主通道（腾讯 + URL/人名/数字/量级词多层占位 + 习语定译表 + 行数守恒，占位符对账不齐的行自动保留英文兜底）。2026-11-16 起 zh.mjs/xcheck/name-guard 已被 AI 日报线升级（习语定译表 IDIOM_ZH、trillion/billion SI 换算占位、xcheck 第三票 MyMemory 裁决 + 译名一致性 aliasCheck + 截断编造防御、Huang 单姓兜底+整名优先）——接口不变，剪藏线零改动自动生效；改 NAMES/占位逻辑后必须清 `~/.dsh-ai-research/translate-cache.json`。
  2. `python3 tools/numcheck.py <原文> <译文>` —— 数字集合机检，missing 必须逐条归零（真丢失=回译该行或人工补）；（2026-11-17 起 numcheck.py 只是薄转发层，真源是 scripts/xcheck.mjs 的 numDiff：跨语言 SI 归一，`$13 billion↔130 亿` 自动放行、认 crore/lakh/万亿/亿/万千瓦与全角逗号；scale_risk 命中时 missing/extra 是同一处量级错，按一条算）
  2b. `python3 tools/summary_check.py --md <笔记.md>` —— 摘要数字机检（笔记「摘要：」行 vs 正文，SI 归一含英文数词），抓「约数被合理化成精确数」（over six million→650 万）；只出清单不当阻断闸——背景数放行、幻觉数必须修（30 秒人工判）；
  3. xcheck 交叉校验（彩云第二通道 + MyMemory 自动备份）：node 里 `import { crossCheck, writeReviewList, refillFallback } from "scripts/xcheck.mjs"`（真源，各会话统一），喂 `{items:[{title:原行,title_zh:译行}]}`；flagged>0 时落 `<stamp>_人工审.md`，按清单逐条人工终审。
  3b. **语义/文笔初筛（2026-11-20 用户定，GLM 成对判定）**：`note_zh.py` 加 `--semantic` 即在 xcheck 之后自动跑（复用同批中英成对，分批 ≤15 对防 token 爆）；或独立 `python3 tools/semantic_check.py --pairs pairs.json`。实测：18 对样本（10 已知错译+8 良译）10/10 验真、0 误报——能抓 xcheck 抓不到的语义错（$13 billion→10亿、agent 漂移、be months away 方向反、personal intelligence→个人情报）。清单落 `digests/<日期>_笔记译文_语义审.md`，人工只看 flagged。要点：max_tokens 4000、timeout 240s（GLM 推理慢）、判定规则已写进 PROMPT_HEAD（术语表/away 习语/产品名），发现新错类先补 prompt 再重跑。
  4. zh.mjs 兜底保留英文的行：调 `refillFallback(英文行数组, 译文行数组)` 一次性补译——优先彩云、失败回退 MyMemory，URL 自动占位防改坏，标题/图片/围栏行自动跳过（实测含链接行 URL 完好、数字全保留）；兜底行极少时也可手动 `node tools/mm.mjs -f` 补译（含链接行补译后必须回填原链接）。
  - 判读口径：zh.mjs/numcheck 的 missing = 真丢失；MyMemory 量级换算（$44.1B→441 亿）产生的 missing 需人工判「换算≠丢失」。
- **人工抽查语义（2026-11-15 用户定「三处固定抽」）**：机检只保数字/链接/人名准确，语义仍要人抽。三处固定——①每个小节首段（主题句错译最致命）②numcheck 扫出的数字所在句的上下文（数字对了语境可能反）③否定句（not/unlike/反话机翻最易翻反）；xcheck flagged 行必读。回报里每篇加一行「抽查：读过 X 处 / 发现 Y 处需修（修了什么）」。
- **摘要机翻打底随派单（2026-11-16 借鉴 AI 日报线 dispatch.py「机翻打底」）**：领队派英文稿精修单前，先 `node tools/zh.mjs "<标题>. <meta description 或首段>"` 把标题与摘要素材翻好（缓存命中秒回），随派单发两行——`摘要素材（机翻打底，先校再压缩）：<中文译文>` 与 `原文：<英文>`；队员以此打底校对（数字/人名/语序）压缩成 1 句摘要，不再自己等翻译。翻译失败/超时则退回队员自跑三件套，不阻塞派单。
- **精确数回源警示（2026-11-16 借鉴 AI 日报线四期实测）**：队员摘要里写精确数（如「650 万行」）时，领队抽验必须回源核对——英文原稿常是 "over six million" 这类约数，队员/机翻会合理化成精确数；真信号=数字、否定、away 习语（「X months away」是「只剩 X 个月」不是「还要等 X」），「实体丢失」是浓缩噪音不必管。
- **机检分工与养表纪律（2026-11-16 借鉴 AI 日报线）**：机检（xcheck/numcheck）只能抓表里已有的错——flagged 为 0 不等于没有语义错（AP→「美联社」这类错译，表里没有线索就永远抓不到，可能撞运气才逮住）。正确分工：**机检兜底、占位防错、人工终审**（人工抽查三处固定）。配套「养表」：每轮修完真错，顺手把坏译名回写 `tools/xcheck.mjs` 的 ALIAS_BAD 表、习语定译回写 translate.mjs 的 IDIOM_ZH——越用越准；改表后必须清 `~/.dsh-ai-research/translate-cache.json` 才生效。
- **标题一起译**；人名按中文媒体习惯（Nvidia→英伟达），品牌与产品名保留英文（Gemini/Claude/ChatGPT/iPhone）。
- **文件名改成中文**（2026-11-12 用户定「以后都要中文」）：剪藏时按英文原题建的文件名，队员译完正文后必须同时 `mv` 成中文标题（去掉 `\/:*?"<>|`，全角 `：` 可留），并核对目标名不与已有笔记冲突。
- 反爬站点：openai.com 需完整浏览器头 + URL 尾斜杠才 200（仅 UA 仍 403；剪藏工具暂不支持，手动抓）；TechCrunch/Ars Technica 405。抓不到正文与翻译无关。

## AI 术语中译速查（2026-11-13 定，翻译精修时人工把关）

**链接保留（2026-11-13 用户定「文章里的链接保留」）**：剪藏端已把 `include_links=True` + `<a>` 转 `[文字](URL)`（外链保留、javascript:/mailto:/锚点只留文字）；翻译端 zh.mjs 已加 URL 占位保护（URL 不被全角化、不被人名子串误换）。队员翻译时：**链接文字可译成中文，URL 一字不动**（`[谷歌发布新模型](https://blog.google/...)` 保留整个 URL）；译完抽查每条链接 `](` 是否半角、URL 是否完整。

机器翻译会把这些**普通英文词**译错（专名保护表管不到，队员译完逐条对照改）：

| 英文 | 易错译 | 正确 |
|---|---|---|
| token | 代币 | **保留 token**（用户 2026-11-13 定，不译） |
| agent | 代理人 | **保留 agent**（用户 2026-11-13 定，不译；「AI agent」同样保留） |
| inference | 推断 | 推理 |
| frontier model | 边境模型 | 前沿模型 |
| context window | 语境窗口 | 上下文窗口 |
| grounding | 接地 | 落地 / 锚定 |
| precision / recall（评测语境） | 精密度 / 回忆 | 精确率 / 召回率 |
| yield（芯片语境） | 收益 | 良率 |
| foundry | 铸造厂 | 晶圆代工厂 |
| chiplet | 芯片 | 芯粒 |
| advanced packaging | 高级包装 | 先进封装 |
| tape-out | 磁带输出 | 流片 |
| gigawatt | 十亿瓦 | 吉瓦 |
| Elo | 埃洛 | 等级分（或保留 Elo） |
| fine-tuning | 精调 | 微调 |
| alignment | 结盟 | 对齐 |
| evals | 评估 | 评测 |

模型版本名保留英文（Opus/Sonnet/Haiku 不译成十四行诗/作品/俳句）；人名有通行中文译名的一律中文（译名表见 `scripts/zh.mjs` 的 NAMES，缺的名人加一行 `["英文名","中文译名"]`）。机器打底只解决 70%，这类语境词是交付前的最后一道人工关。

### 数字保真三件套（2026-11-15 用户定「改动」，已转正）
AWS SageMaker 篇实测（21,507 字符 / 173 个数字 token）：基线丢 21 个数字 + 多 30 个（幻觉"8"、percent 错位、$25.251286 丢美元符、6000/8000 真丢）；增强后剩 7 处且全是标点边界噪音，**零数值错误**。
1. **zh.mjs 已内置数字占位**（NUM[A-Z] 机制）：价格、百分比、千分位、版本号、实例型号（ml.g5.8xlarge）整段不过引擎；代码围栏（```）内整段跳过；行数守恒（非空行必须出非空译文，否则单行重翻）。队员无感，直接用。
2. **发布前跑数字回源校验**：`python3 scripts/numcheck.py <原文文件> <译文文件>`——missing（原文有译文无）/ extra（译文有原文无）必须逐条人工判读；边界噪音（`99.` vs `99`、序号）可放过，**数值缺失/错位必须修**。
3. **单位换算白名单**（机翻常错，人工把关）：billion=10 亿、million=100 万、trillion=万亿；注意「1.5 billion」是 15 亿不是 1.5 亿。

**mm.mjs 抽样纪律（2026-11-15 两轮实测定，--refresh/--no-cache 已落地）**：MyMemory 是翻译记忆引擎，数字能力**分两面**——
- **可靠面（15 类样本 15/15 全对）**：量级换算（$44.1B→441 亿、63.4T→63.4 万亿）、百分比、版本号、日期、价格小数、区间、千分位、倍数、真实股价句全对。
- **坑面（本地清不掉）**：**高频融资搭配在服务端 TM 语料里固化了坏译文**——"raised $13 billion"→「30 亿美元」、"raised $40 billion in its latest round"→「00 亿美元」，`--refresh` 清本地缓存后依然错（坏值在服务端语料，不在本地）；但同数字换个搭配立即正确（"13 billion dollars"→130 亿、加长句 "…at a $183 billion valuation"→130 亿全对）。
- 三条纪律：①抽样遇可疑数字，先改写措辞/加长上下文用 `--refresh` 重测再下结论（变体对照是鉴定手段）；②短句译文只看语义，数字一律 numcheck.py 机检；③numcheck 判读口径：MyMemory 做量级换算（$44.1B→441 亿），missing 需人工判「换算≠丢失」——与 zh.mjs（数字占位保真、missing 即真丢失）口径不同。

## 站点适配

- **IT之家**：正文 `div#paragraph`；图片真址 `data-original`；评论 `cmt.ithome.com/api/webcomment/getnewscomment?sn=<#post_comm 的 data-id>`，分页 `&cid=`
- **快科技**：评论 `comment8.mydrivers.com/ReviewAjax.aspx?...&Tid=<tid>&Cid=1`
- **通用**：首选 trafilatura；不足 400 字回退自研容器识别；正文 <300 字说明靠 JS 渲染，如实说抓不到

- **Hacker News**（2026-11-17 接入）：帖页 `news.ycombinator.com/item?id=<id>` 只作入口——正文自动跳到帖子指向的原文页（Ask HN 无外链时用帖内自述），标题取 HN 帖标题、`created` 取发帖日；评论走 `hn.algolia.com/api/v1/items/<id>`（一请求拿整棵 `children` 树，免登录）。
  - 缩进：最多 2 个全角（`HN_MAX_INDENT=2`），第 3 层起不再加深、改在头行标 `↳层级`；评论不限条数。
  - **超过 200 条楼层（`HN_DEEP_LIMIT`）后只保留主楼层**（跳过其后的楼中楼），控制体积；评论区说明里会写明已裁剪。
  - **楼中楼筛选（用户 2026-11-17 定「主楼全收 + 精选楼中楼 + 全量底稿」）**：`--deep pick`（默认）主楼层全收，楼中楼按「长度 ≥400/+2、200–399/+1、<100/−1；深度 1 层/+2、2 层/+1、≥4 层/−2；被回复 ≥2 人/+2、1 人/+1；带链接或代码/+1；作者 karma ≥5000/+1、≥1000/+0.5；发帖后 6 小时内/+0.5」打分，取 score≥2（`HN_PICK_MIN=2.0`）并**补齐父链**（子楼入选则父楼必须入选，防断链），上限 120 条（`HN_PICK_LIMIT`，真正的量闸——阈值只定及格线，上限防大帖爆量）；`--deep all` 全量不筛。
  - 精选模式下评论区头部写明「主楼 N + 精选楼中楼 M（原始 X 条）」与打分规则；同时自动写全量底稿 `<笔记名>_评论全量.md` 到 `ReadItLater Inbox/_底稿/`（**全英文原文、不筛选、不翻译**，头部说明指向阅读版），不混进笔记列表。
  - karma 走 `bak/hn_karma.json` 缓存（只查有希望入选的作者，预算 60 次/篇，失败静默记 0）；xz 帖实测 367 条 → 281 条（主楼 176 + 子楼 105），断链 0；阈值从 3.0 降到 2.0 是因为 3.0 砍掉的多是有信息的技术澄清（oss-fuzz 链接、FreeBSD 不受影响的说明），增量只占 5% 体积，大帖由 80 条上限兜底。
  - 坑：评论常写「interesting!<a>链接</a>」，转 markdown 成 `![…](url)` 会被当图片上传 → `_hn_clean` 末尾 `re.sub(r"!\[", "! [")` 断开；Algolia 大响应用默认 `fetch` 会 IncompleteRead，改用轻头 `_hn_get()` 重试 + 进程内缓存。
  - **精修口径（用户 2026-11-17 定）：只译正文 + 主楼层（depth 0），楼中楼保留英文原文**；用 `python3 tools/note_zh.py <note> --pick depth0 --xcheck`。
  - **译完必做英文残留扫描**：zh.mjs 批量请求失败的行会静默回落原文（实测 176 主楼里 91 行没译），跑完要按「主楼层、字母≥25、汉字≤3、非代码行」筛一遍，把剩下的行再送 `mdzh.translate_lines()` 补译；纯代码行（hexdump/docker/echo/chmod）保持原样。

- **Reddit**（2026-11-17 接入）：**reddit.com 本体对本机出口 IP 全 403**（`.json`／`.rss`／网页 HTML／`api.reddit.com`／`old.reddit.com` 一律 `HTTP Error 403: Blocked`，走代理也一样），帖与评论都改走 Photon 归档：主 `arctic-shift.photon-reddit.com/api`，兜底 `api.pullpush.io/reddit/search`。
  - 入口识别：URL 里抓 `/comments/<id>`（或 `redd.it/<id>`）→ `posts/ids?ids=<id>` 取帖元信息（title/subreddit/score/num_comments/created_utc/author/url/selftext/permalink）。
  - 正文：**self post 直接用归档里的 `selftext` 当正文**（原样 markdown，列表与代码块都保真）；**link post 抓它指向的外链页**当正文，标题/`created`/`author` 仍用 Reddit 帖（author 带 `u/` 前缀，与站内编辑作者区分）。
  - 评论：`comments/search?link_id=<id>&limit=100`，**翻页用 `&before=<本页最早 created_utc>`**（`after` 无效），每页约 13–21s、最多 3 页（`REDDIT_MAX_PAGES`）。
  - 层级：评论的 `parent_id` 是 `t1_<评论id>`（父评论）或 `t3_<帖id>`（顶层），据此算 depth；渲染沿用楼中楼缩进（最多 2 个全角，更深的标 `↳层级`）。条目头 `**作者 · 日期 · N 赞**`。
  - **筛选（真实赞数，不用打分代理）**：主楼取 ≥1 赞（`REDDIT_MAIN_MIN`，Reddit 主楼常有大量被踩的噪音，与 HN「主楼全收」不同）、楼中楼取 ≥2 赞（`REDDIT_PICK_MIN`）并补齐父链、上限 120（`REDDIT_PICK_LIMIT`）；`--deep all` 全量不筛（会含负分主楼）。
  - 精选模式另存全量底稿 `ReadItLater Inbox/_底稿/<笔记名>_评论全文.md`，头部写明讨论页与赞数。
  - 坑：`REDDIT_ARCTIC` 常量已含 `/api`，拼路径时不要再写 `/api/...`（写过一次 → 双 `/api` → 404）；归档响应是 chunked 大包，偶发读超时，`_rd_get()` 带重试。

### 作者与发布时间：多源兜底（2026-11-17 加）

`title_fix.py` 的 `author_fallback()` / `date_fallback()` 在定制链取不到时兜底，
`clip.py` 已接入（author 为空时、date 弱命中时各调一次）。

- **author 优先级**：JSON-LD `author`/`creator` → `meta[author]` → `meta[article:author]`
  → `meta[twitter:creator]` → `a[rel=author]` → schema.org microdata（`property="author"`，AWS blog 用它）
  → `class*=author` 节点文本。
  噪声过滤：长度 2–40、不含 URL/@、`_BAD_AUTHOR` 表（admin/editor/作者/责任编辑/主作者/联合作者…）。
- **date 优先级**：JSON-LD `datePublished` → `meta[article:published_time]` → `meta[datePublished]`
  → `meta[date]`/`pubdate` → `<time datetime>` → 最后才 `dateModified`/`article:modified_time`。
  **必须严格「发布 > 修改」**——substack 的 `article:modified_time` 常排在 `published_time` 前面，
  按出现顺序取会拿到修改时间。
- **只有日期算弱命中**：`meta` 里只有 `2026-11-10` 时不要就地定稿成 `T00:00:00` 并终止，
  要让兜底再试一次 JSON-LD（那里常有完整时间，如 Google blog 的 `2026-11-10T19:00:00`）。
- **中文站定制正则（2026-11-17 加，clip.py 里在 V2EX 分支之前）**：
  - 量子位：作者 `class="author".*?rel="author"[^>]*>([^<]+)<`；时间 `<span class="date">YYYY-MM-DD</span>`
    + `<span class="time">HH:MM:SS</span>` 两个节点拼接。
  - 快科技：作者 `责任编辑[：:]\s*([^<\s]{1,20})`；时间 `var g_PostDateStr = new Date('YYYY-MM-DD HH:MM:SS')`
    （在页面 `<script>` 里，不是 meta）。
  - 少数派：`author_fallback` 的 JSON-LD 已覆盖，不需额外正则。
- **实测覆盖边界**：英文站（the-decoder / interconnects / importai / Google blog / Engadget）
  作者与时间 5/5 全部拿到；中文站靠上面三条定制正则 + IT之家 span#author_baidu / span#pubtime_baidu。
- **keywords 兜底要防标题**：快科技的 `meta[keywords]` 常直接等于标题整句，被当标签写进 frontmatter。
  clip.py 已剔除「与标题相同（去非词字符后比对）」或长度 >20 的 keywords 项。

## 坑

- `curl` / `file` 没装，用 python
- 中文标题里的 `：`、`……` 可进文件名；`\/:*?"<>|` 替换成空格
- 落库前先看 Inbox 有没有同名文件（会整篇覆盖，把刚精修的标签/摘要冲掉）
- Obsidian 里 `>` 变灰变小、`###` 放大，所以评论区一律加粗行 + 普通段落
- 代码块注释写成 `# 内容`（`#` 后带空格），裸 `#内容` 会被统计成标签
- `--tags` 内部硬截 2 个，需要 3 个标签要落库后手工补

## --inspect 只读核对 + 质量闸 + 翻译检查（2026-11-19 用户定三项优化）

```bash
python3 tools/clip.py "<URL>" --inspect
```

- `--inspect`：只抓正文并打印 `[inspect] 标题 / 正文 N 字 / 图片 N / 评论 N / 标签`；**不翻译、不传图、不调标签 LLM、不写盘、不同步**（精修核对用它，别用 `--stdout`——后者会跑完整翻译/标签/评论链路）。
- **正文质量闸（自动，落库前）**：`body_quality()` 检查——<100 字「❌ 疑似空壳/JS 页」、<300 字「⚠️ 疑似不完整」、正文几乎全是图片/链接行、导航词命中 ≥4 且 <600 字「⚠️ 疑似导航/样板页」。只打印警示不阻断（后续人工判断）。
- **翻译检查（自动，`--stdout` 时）**：`translate_check()` 检查标题/正文英文残留（字母 ≥25 的非代码行）、坏术语表（恩加吉特/个人情报/詹森·黄），输出「翻译检查：通过 / ⚠️ …」；不阻断，提示人工润色重点。

## 验证

```bash
f="$OBSIDIAN_ROOT/dsh/ReadItLater Inbox/<标题>.md"
sed -n '1,8p' "$f"                     # 标题 + 标签 + 摘要 + 原文
sed -n '/## 评论区/,+6p' "$f"          # 评论区版式
grep -c '^\*\*[0-9]*楼' "$f"           # 主楼条数
grep -c '^\*\*↳' "$f"                  # 回复条数
grep -c '<!-- 待精修 -->' "$f"         # 应为 0
ls -l --time-style=+%F\ %H:%M "$f"     # 确认 mtime 没被意外改动
```
