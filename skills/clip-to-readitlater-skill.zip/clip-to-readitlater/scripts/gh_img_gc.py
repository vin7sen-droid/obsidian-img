#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""回收 GitHub 仓库里没人引用的图片（笔记删了 → 图成孤儿）。

用法：
  python3 tools/gh_img_gc.py --dry     # 只列出孤儿，不删
  python3 tools/gh_img_gc.py           # 删除孤儿
选项：--min-age 小时  只删仓库里存在超过 N 小时的（默认 24，防误删刚传的）
"""
import os
import argparse, json, re, sys, time, urllib.request
from pathlib import Path

OBSIDIAN_ROOT = os.environ.get("OBSIDIAN_ROOT") or ("/sdcard/Obsidian" if os.path.isdir("/sdcard/Obsidian") else os.path.expanduser("~/Obsidian"))
ROOTS = [Path(OBSIDIAN_ROOT) / "dsh"]   # 只扫 dsh 库；其他库只做提醒
OTHER_ROOTS = [Path(OBSIDIAN_ROOT)]  # 其他库：只统计提醒，不参与"是否删"的判断
_TOK_PATH = Path(os.path.expanduser("~/.config/ghclip/token"))
TOK = _TOK_PATH.read_text().strip() if _TOK_PATH.exists() else ""
if not TOK:
    print("ghclip token 缺失（~/.config/ghclip/token），孤儿回收不可用", file=sys.stderr)
    sys.exit(2)
OWNER, REPO, BRANCH, SUBDIR = "vin7sen-droid", "obsidian-img", "main", "clip"
REF = re.compile(re.escape(SUBDIR) + r"/([A-Za-z0-9._-]+\.[A-Za-z0-9]+)")


def api(path, method="GET", body=None, timeout=120):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request("https://api.github.com" + path, data=data, method=method,
        headers={"Authorization": "Bearer " + TOK, "User-Agent": "clip-gc/1.0",
                 "Accept": "application/vnd.github+json", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
        return json.loads(raw) if raw else {}


def repo_files():
    """返回 [(path, size)]，递归列 clip/ 下所有文件（带重试）。"""
    last = None
    for _ in range(4):
        try:
            ref = api("/repos/%s/%s/git/ref/heads/%s" % (OWNER, REPO, BRANCH))
            tree_sha = api("/repos/%s/%s/git/commits/%s" % (OWNER, REPO, ref["object"]["sha"]))["tree"]["sha"]
            t = api("/repos/%s/%s/git/trees/%s?recursive=1" % (OWNER, REPO, tree_sha))
            return [(x["path"], x.get("size", 0)) for x in t.get("tree", [])
                    if x["type"] == "blob" and x["path"].startswith(SUBDIR + "/")]
        except Exception as e:
            last = e; time.sleep(3)
    raise last


def scan_md(roots):
    out = []
    for root in roots:
        if root.exists():
            out.extend(sorted(x for x in root.rglob("*.md")
                             if ".obsidian" not in x.parts and ".trash" not in x.parts))
    return out


def names_in(files):
    names = set()
    for f in files:
        names.update(REF.findall(f.read_text(encoding="utf-8", errors="replace")))
    return names


def used_names():
    names = set()
    files = []
    for root in ROOTS:
        if root.exists():
            files.extend(sorted(x for x in root.rglob("*.md") if ".obsidian" not in x.parts and ".trash" not in x.parts))
    for f in files:
        names.update(REF.findall(f.read_text(encoding="utf-8", errors="replace")))
    return names, files


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--min-age", type=float, default=24, help="只删存在超过 N 小时的图")
    a = ap.parse_args()

    used, files = used_names()
    files_repo = repo_files()
    names_repo = {Path(p).name: p for p, _ in files_repo}
    orphans = sorted(set(names_repo) - used)
    print("笔记 %d 篇 / 引用图 %d 个 / 仓库图 %d 个 / 孤儿 %d 个"
          % (len(files), len(used), len(names_repo), len(orphans)))
    # 提醒：其他库（非 dsh）里还引用着哪些图——这些不能删，但会显示出来供确认
    others = [f for f in scan_md(OTHER_ROOTS) if "/dsh/" not in str(f)]
    other_names = names_in(others) & set(names_repo)
    if other_names:
        print("⚠️ 另外 %d 篇其他库笔记还引用着 %d 张图（不参与删除判断，仅提醒）：" % (len(others), len(other_names)))
        for n in sorted(other_names)[:10]:
            print("    其他库引用:", n)
        if len(other_names) > 10:
            print("    ... 共 %d 张" % len(other_names))
    if not orphans:
        print("没有孤儿图，无需清理。")
        return
    for n in orphans[:20]:
        print("  孤儿:", n)
    if len(orphans) > 20:
        print("  ... 共 %d 个" % len(orphans))
    if a.dry:
        print("（dry-run，未删除）")
        return

    # 批量删除：一个 commit 干掉全部
    ref = api("/repos/%s/%s/git/ref/heads/%s" % (OWNER, REPO, BRANCH))
    commit = api("/repos/%s/%s/git/commits/%s" % (OWNER, REPO, ref["object"]["sha"]))
    entries = [{"path": names_repo[n], "mode": "100644", "type": "blob", "sha": None} for n in orphans]
    new_tree = api("/repos/%s/%s/git/trees" % (OWNER, REPO), "POST",
                   {"base_tree": commit["tree"]["sha"], "tree": entries})
    new_commit = api("/repos/%s/%s/git/commits" % (OWNER, REPO), "POST",
                     {"message": "gc: 删除 %d 张无引用图片" % len(orphans),
                      "tree": new_tree["sha"], "parents": [ref["object"]["sha"]]})
    api("/repos/%s/%s/git/refs/heads/%s" % (OWNER, REPO, BRANCH), "PATCH",
        {"sha": new_commit["sha"]})
    print("已删除 %d 张孤儿图" % len(orphans))


if __name__ == "__main__":
    main()
