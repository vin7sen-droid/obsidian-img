#!/usr/bin/env python3
import argparse, instaloader, os, urllib.request, re, sys
BASE = "/sdcard/download/ins" if os.path.isdir("/sdcard") else os.path.join(os.path.expanduser("~"), "Downloads", "ins")

def classify(e):
    """把 instaloader 异常归成可读的错误类别，供上层给出中文提示"""
    n=type(e).__name__
    m=str(e).lower()
    byname={"LoginRequiredException":"login_required",
            "PrivateProfileNotFollowedException":"private",
            "ProfileNotExistsException":"not_found",
            "QueryReturnedNotFoundException":"not_found",
            "QueryReturnedBadRequestException":"not_found",
            "TooManyRequestsException":"rate_limited",
            "ConnectionException":"network",
            "AbortDownloadException":"network"}
    if n in byname:
        return byname[n]
    # 类型名兜不住时按消息兜底（instaloader 喜欢包一层 "Fetching Post metadata failed."）
    if "please wait a few minutes" in m or "429" in m or "rate" in m:
        return "rate_limited"
    if "login" in m or "logged in" in m or "401" in m:
        return "login_required"
    if "private" in m:
        return "private"
    if "404" in m or "not found" in m or "metadata failed" in m or "does not exist" in m:
        return "not_found"
    if "timed out" in m or "connection" in m or "resolve" in m:
        return "network"
    return "other"

def download_url(url):
    m=re.search(r"/(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)", url if url.endswith("/") else url+"/")
    if not m:
        print("skip",url, file=sys.stderr); return
    sc=m.group(1)
    o=instaloader.Instaloader()
    try:
        p=instaloader.Post.from_shortcode(o.context, sc)
    except Exception as e:
        print(f"FAIL\t{sc}\t{classify(e)}\t{e}", file=sys.stderr)
        return "fail"
    username=getattr(p,"owner_username",sc)
    folder=os.path.join(BASE, username)
    os.makedirs(folder, exist_ok=True)
    nodes=list(p.get_sidecar_nodes()) if p.typename=="GraphSidecar" else [p]
    cnt=0
    for i,n in enumerate(nodes):
        is_video=getattr(n,"is_video",False)
        # 轮播侧车节点是 InstaloaderNode，属性是 display_url / video_url；
        # 原来取 n.url 取不到，会 fallback 到父帖封面，导致 N 张图全是同一张。
        if is_video:
            url_media=getattr(n,"video_url",None) or getattr(p,"video_url",None)
        else:
            url_media=getattr(n,"display_url",None) or (None if n is not p else getattr(p,"url",None))
        if not url_media:
            continue
        ext=".mp4" if is_video else ".jpg"
        fname=f"{username}_{sc}_{i:03d}{ext}"
        dst=os.path.join(folder,fname)
        if os.path.exists(dst) and os.path.getsize(dst) > 8192:
            print(f"{username}/{fname} exists, skip")
            continue
        try:
            with urllib.request.urlopen(urllib.request.Request(url_media), timeout=120) as r:
                data=r.read()
            open(dst,"wb").write(data)
            cnt+=1
            print(f"{username}/{fname} saved")
        except Exception as e:
            print(f"FAIL\t{sc}\tmedia\t{e}", file=sys.stderr)
    print(f"{username} -> {folder} ({cnt} files)")

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("urls", nargs="+")
    args=ap.parse_args()
    fails=0
    for u in args.urls:
        if download_url(u)=="fail":
            fails+=1
    sys.exit(3 if fails else 0)
