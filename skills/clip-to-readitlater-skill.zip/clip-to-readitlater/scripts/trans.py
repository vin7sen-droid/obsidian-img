#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""英文文章 → 中文翻译工具（clip.py 剪藏链路用）

通道：clients5.google.com/translate_a/t?client=dict-chrome-ex
（免费、无需 key；本机实测 2026-11-12 可用，translate.googleapis.com 的 gtx 端点反而 429）

用法：
    import trans
    if trans.is_english(body):
        title = trans.tr(title)
        body  = trans.translate_md(body)
"""
import os
import json
import re
import urllib.parse
import urllib.request

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")
EP = "https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=%s&tl=%s&q=%s"
SEG = 3400          # 单次请求的字符上限（留余量）
TIMEOUT = 45


def is_english(text, min_en=300, zh_ratio=0.05):
    """正文是否以英文为主。中文占比低于 5% 且英文 ≥300 字母时才判为英文。"""
    if not text:
        return False
    zh = len(re.findall(r"[\u4e00-\u9fff]", text))
    en = len(re.findall(r"[A-Za-z]", text))
    return en >= min_en and zh < max(20, int(en * zh_ratio))


def tr(text, sl="en", tl="zh-CN"):
    """翻译单段纯文本；失败抛异常由调用方兜底。"""
    text = (text or "").strip()
    if not text:
        return text
    url = EP % (sl, tl, urllib.parse.quote(text))
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    raw = urllib.request.urlopen(req, timeout=TIMEOUT).read().decode("utf-8", "replace")
    d = json.loads(raw)
    if isinstance(d, list):
        return "".join(x if isinstance(x, str) else "".join(x) for x in d).strip()
    if isinstance(d, dict):                       # 部分返回 {sentences:[{trans:..}]}
        sents = d.get("sentences") or []
        if sents:
            return "".join(s.get("trans", "") for s in sents).strip()
        return d.get("trans", "") or str(d)
    return str(d)


# 需要在翻译时原样保留的片段
_INLINE = re.compile(r"(!\[[^\]]*\]\([^)]+\))"     # 图片
                      r"|(\[[^\]]+\]\([^)]+\))"     # 链接
                      r"|(`[^`]+`)"                 # 行内代码
                      r"|(<[^>]+>)"                 # 裸 HTML 标签
                      )
_CODEBLOCK = re.compile(r"```.*?```", re.S)


# 翻译时必须保留原文的品牌/产品名（Google 会把 Gemini 译成「双子座」之类）
TERMS = ["Gemini", "Claude", "Grok", "Copilot", "Llama", "Mistral", "ChatGPT",
         "iPhone", "iPad", "MacBook", "AirPods", "Vision Pro", "iOS", "Android",
         "PlayStation", "Xbox", "Cybertruck", "Cybercab", "Robotaxi", "Starship",
         "Starlink", "YouTube", "TikTok", "Instagram", "WhatsApp", "Pixel", "Galaxy"]
_TERM_RE = re.compile(r"\b(" + "|".join(re.escape(t) for t in TERMS) + r")\b")


def translate_md(md, sl="en"):
    """翻译 markdown 正文，保留图片/链接/代码块/HTML 标签/品牌名原样。"""
    if not md or not md.strip():
        return md
    stash = {}

    def _keep(m):
        key = "⟦%d⟧" % len(stash)
        stash[key] = m.group(0)
        return key

    body = _CODEBLOCK.sub(_keep, md)       # 代码块 → 占位
    body = _INLINE.sub(_keep, body)        # 图片/链接/行内代码/标签 → 占位
    body = _TERM_RE.sub(_keep, body)       # 品牌名 → 占位（翻完还原）

    # 按空行分段，再按 SEG 合并成若干请求
    paras = [p for p in body.split("\n\n")]
    chunks, buf, blen = [], [], 0
    for p in paras:
        if not p.strip():
            continue
        # 超长单段：按句子切
        if len(p) > SEG:
            sents = re.split(r"(?<=[.!?])\s+", p)
            cur = ""
            for s in sents:
                if len(cur) + len(s) + 1 > SEG and cur:
                    chunks.append(cur)
                    cur = s
                else:
                    cur = (cur + " " + s).strip() if cur else s
            if cur:
                chunks.append(cur)
            continue
        if blen + len(p) + 2 > SEG and buf:
            chunks.append("\n\n".join(buf))
            buf, blen = [], 0
        buf.append(p)
        blen += len(p) + 2
    if buf:
        chunks.append("\n\n".join(buf))

    out = []
    for c in chunks:
        # 全占位段（纯图片）不送翻译
        if re.fullmatch(r"(\s*⟦\d+⟧\s*)+", c):
            out.append(c)
            continue
        out.append(tr(c, sl=sl))
    text = "\n\n".join(out)

    # 还原占位符（多做一轮，防翻译器重排引号之类）
    for _ in range(2):
        for k, v in stash.items():
            text = text.replace(k, v)
    return text


def translate_title(t):
    """标题翻译：去掉尾部的站点名噪声后翻译。"""
    if not t:
        return t
    return tr(t)


# 译文收尾清理用
_ZH_DATE = re.compile(
    r"^\s*[^。！？]{0,24}?\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日\s*"
    r"(上午|下午|凌晨|晚上|中午|早上)?\s*\d{1,2}\s*[:：]\s*\d{2}")
_TAIL_HEADS = ("受到推崇的", "推荐阅读", "相关推荐", "更多来自", "更多文章",
               "为您推荐", "延伸阅读", "相关文章", "热门推荐")


def _short_nav(s):
    """像栏目名/作者名的导航短行：≤10 字、无句读标点。"""
    return len(s) <= 10 and not re.search(r"[。！？，、；：,.!?;:]", s)


def polish_zh(md, min_para=40):
    """清理译文里的英文站残留：全角井号、发布时间行、栏目短行、尾部推荐区。"""
    if not md:
        return md
    md = md.replace("＃", "#").replace("＊", "*")

    # 尾部推荐区整段截断
    for kw in _TAIL_HEADS:
        i = md.find("\n## " + kw)
        if i < 0:
            i = md.find("\n#" + kw)
        if i > 0:
            md = md[:i].rstrip()
            break

    lines = md.split("\n")
    out = []
    run_short = 0
    for ln in lines:
        s = ln.strip()
        if s and _ZH_DATE.match(s) and len(s) < 44:
            continue
        # 英文站「Add us on Google」这类社交引导行
        if s and re.search(r"(在.{0,12}上(添加|关注)|添加.{0,12}(获取|了解)|关注我们的)", s) and len(s) < 40:
            continue
        if s and not s.startswith(("#", "![", "---", ">", "*", "-", "|", "`")):
            if _short_nav(s):
                run_short += 1
                if run_short <= 6:      # 只吃开头的栏目串，正文里的短句保留
                    continue
            else:
                run_short = 0
        out.append(ln)
    md = "\n".join(out)

    # 段首无意义短段（如「大型科技公司」单段）合并清理：删掉独立成段的 ≤6 字栏目
    paras = md.split("\n\n")
    cleaned = []
    for p in paras:
        if p.strip() and len(p.strip()) <= 6 and not re.search(r"[，。！？]", p):
            continue
        cleaned.append(p)
    md = "\n\n".join(cleaned).strip()
    return re.sub(r"\n{3,}", "\n\n", md)


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2 or sys.argv[1].startswith("-"):
        print("用法: python3 trans.py '<英文文本>'", file=sys.stderr)
        print("示例: python3 trans.py 'Apple plans to release a foldable iPhone next year.'", file=sys.stderr)
        sys.exit(2)
    src = sys.argv[1]
    print("is_english:", is_english(src))
    print("title:", translate_title(src))
    print("md:", translate_md(src))