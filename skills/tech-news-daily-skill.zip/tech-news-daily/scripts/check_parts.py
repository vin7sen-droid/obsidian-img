#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parts 自校验（③）——队员交付前必跑：python3 check_parts.py parts/A.md [parts/B.md …]
校验项：板块标题格式与计数 / 条目两行式（标题行+缩进3空格摘要行）/ 编号连续 /
摘要行带（[来源](url) 时间）/ URL 合法 / 英文标题残留警告 / 板块名白名单。
全过 exit 0；有 FAIL exit 1（自己修复后再交）。
"""
import re, sys

BOARDS = {'一': '芯片与硬件', '二': '消费电子与终端', '三': '互联网与大厂动态', '四': '通信与网络',
 '五': '软件、游戏与开源', '六': '网络安全与数据', '七': '航天、能源与前沿科学',
 '八': '生物科技与医疗硬件', '九': '政策、监管与商业', '十': '融资与并购'}

def check(path):
    lines = open(path, encoding='utf-8').read().split('\n')
    errs, warns = [], []
    cur, seq, total = None, 0, 0
    for i, ln in enumerate(lines, 1):
        m = re.match(r'^## ([一二三四五六七八九十]+)、(.+?)（(\d+) 条）\s*$', ln)
        if m:
            if m.group(1) not in BOARDS: errs.append(f'L{i} 板块名不认识: {ln[:30]}')
            if m.group(2).strip() != BOARDS.get(m.group(1), '?'): errs.append(f'L{i} 板块名不符: {ln[:30]}')
            cur, seq = m.group(1), 0; total += 0  # 板块切换，total 继续累加
            continue
        m = re.match(r'^(\d+)\. \*\*\[(.+?)\]\((https?://[^)\s]+)\)\*\*\s*$', ln)
        if m:
            seq += 1; total += 1
            if int(m.group(1)) != seq: errs.append(f'L{i} 编号不连续: {m.group(1)} 应为 {seq}')
            if re.search(r'[A-Za-z]{3,}( [A-Za-z]{3,}){2,}', m.group(2)):
                warns.append(f'L{i} 标题疑似英文未译中: {m.group(2)[:36]}')
            nxt = ''
            for j in range(i, min(i+3, len(lines))):
                if lines[j].strip(): nxt = lines[j]; break
            if not re.match(r'^   \S', nxt):
                if re.match(r'^    \S', nxt): warns.append(f'L{i+1} 摘要行缩进 4 空格（应为 3）')
                elif nxt: errs.append(f'L{i} 缺缩进 3 空格的摘要行')
                else: errs.append(f'L{i} 缺摘要行')
            else:
                # 三行式：标题 / 摘要 / （[源](url)、…） YYYY-MM-DD HH:MM
                src_line = ''
                for j in range(i+1, min(i+4, len(lines))):
                    if lines[j].strip().startswith('（['): src_line = lines[j]; break
                if not src_line: errs.append(f'L{i} 缺（[来源](url)）源行')
                elif not re.search(r'（\[[^\]]+\]\(https?://', src_line): errs.append(f'L{i} 源行缺[来源](url)')
                elif not re.search(r'）\s*\d{4}-\d{2}-\d{2} \d{2}:\d{2}\s*$', src_line): warns.append(f'L{i} 源行时间格式非 YYYY-MM-DD HH:MM')
                if len(re.sub(r'（\[[^\]]+\]\(https?://[^)]+\)[^）]*）?$', '', nxt).strip()) < 6:
                    warns.append(f'L{i+1} 摘要行疑似只有来源标注、无正文')
            continue
        if re.match(r'^\d+\. ', ln) and 'http' not in ln and cur:
            errs.append(f'L{i} 条目不是 [标题](url) 形式: {ln[:36]}')
    if total == 0: errs.append('未解析到任何条目')
    # 板块计数与实际一致性（分段只按下一个 ## 标题截，容忍空行）
    body = '\n'.join(lines)
    heads = list(re.finditer(r'^## ([一二三四五六七八九十]+)、(.+?)（(\d+) 条）', body, re.M))
    for k, m in enumerate(heads):
        seg = body[m.end(): heads[k+1].start() if k+1 < len(heads) else len(body)]
        n = len(re.findall(r'^\d+\. \*\*\[', seg, re.M))
        if n != int(m.group(3)): errs.append(f'板块「{m.group(1)}」标题写 {m.group(3)} 条，实际 {n} 条')
    return errs, warns, total

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(2)
    all_ok = True
    for p in sys.argv[1:]:
        errs, warns, total = check(p)
        tag = 'PASS' if not errs else 'FAIL'
        print(f"== {p}: {tag}（{total} 条）")
        for e in errs: print('  ✗', e)
        for w in warns: print('  ⚠', w)
        if errs: all_ok = False
    sys.exit(0 if all_ok else 1)

if __name__ == '__main__':
    main()
