#!/usr/bin/env python3
"""json2techmd.py —— 队员 JSON 输出 → 两行式 parts/*.md（借鉴 news-ai JSON 模式，2026-11-12）

队员不再手写 markdown 版式（分节标题/缩进/编号/来源括注全是格式错误高发区），
改为输出结构化 JSON，版式细节全部由本脚本生成。news-ai A/B 实测：md 版 100% 触发
格式返工（174s），JSON 版 0 返工（70s）。

输入 schema（每队一份 json/T<n>.json）：
{
  "items": [
    {"board": "一",                       # 板块序号：一~十（必填）
     "title": "中文标题",                  # ≤45 字，英文已译中
     "url":   "主源原文 URL",              # 原样取自素材
     "summary": "摘要 30–80 字，含具体数字",  # 不含来源括注
     "sources": [{"name": "IT之家", "url": "https://...", "time": "11-12 08:47"}]}
  ],
  "dropped": [{"title": "丢弃的组标题", "reason": "为什么丢"}]
}

用法：python3 json2techmd.py <outdir>/json/T1.json [T2.json ...]   # 生成 <outdir>/parts/A.md ...
T1→parts/A.md、T2→B、T3→C、T4→D。空板块不落；dropped 打印给领队审。
"""
import json, os, re, sys

import datetime
YEAR = os.environ.get('NEWS_YEAR') or str(datetime.date.today().year)

BOARDS = {'一': '芯片与硬件', '二': '消费电子与终端', '三': '互联网与大厂动态', '四': '通信与网络',
          '五': '软件、游戏与开源', '六': '网络安全与数据', '七': '航天、能源与前沿科学',
          '八': '生物科技与医疗硬件', '九': '政策、监管与商业', '十': '融资与并购'}
ORDER = list(BOARDS)

def conv(jpath):
    team_n = int(re.search(r'T(\d+)\.json$', jpath).group(1))
    part = chr(64 + team_n)  # T1→A
    d = json.load(open(jpath, encoding='utf-8'))
    items, warns = d.get('items', []), []
    by = {}
    for i, it in enumerate(items):
        b = (it.get('board') or '?').strip()
        if b not in BOARDS: warns.append(f'item{i} 未知板块「{b}」→ 弃'); continue
        if not it.get('title') or not (it.get('url') or '').startswith('http'): warns.append(f'item{i} 缺标题/URL → 弃'); continue
        if not it.get('summary'): warns.append(f'item{i}「{it["title"][:18]}」缺摘要 → 弃'); continue
        if not it.get('sources'):
            warns.append(f'item{i}「{it["title"][:18]}」缺 sources'); continue
        if not isinstance(it.get('sources'), list) or any(
                not isinstance(s, dict) or not s.get('name') or
                not re.match(r'^https?://\S+$', str(s.get('url') or ''))
                for s in it['sources']):
            warns.append(f'item{i}「{it["title"][:18]}」sources 格式或 URL 无效 → 弃'); continue
        by.setdefault(b, []).append(it)
    lines = []
    for b in ORDER:
        rows = by.get(b)
        if not rows: continue
        lines += [f'## {b}、{BOARDS[b]}（{len(rows)} 条）', '']
        for n, it in enumerate(rows, 1):
            # 源名带链接、顿号分隔；时间只取主源、补全年份、放在括号外（2026-11-12 定版）
            srcs = '、'.join(f"[{s.get('name','?')}]({s['url']})" for s in it['sources'] if s.get('url'))
            t0 = next((s.get('time') for s in it['sources'] if s.get('time')), '')
            stamp = (f'{YEAR}-{t0}' if t0 and not re.match(r'\d{4}-', t0) else t0)
            tail = f'（{srcs}）' + (f' {stamp}' if stamp else '')
            lines += [f'{n}. **[{it["title"].strip()}]({it["url"].strip()})**',
                      f'   {it["summary"].strip()}', f'   {tail}', '']
    return part, '\n'.join(lines).rstrip() + '\n', warns, d.get('dropped', [])

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    for jpath in sys.argv[1:]:
        outdir = os.path.dirname(os.path.dirname(os.path.abspath(jpath)))  # <outdir>/json/T*.json
        part, md, warns, dropped = conv(jpath)
        pdir = os.path.join(outdir, 'parts'); os.makedirs(pdir, exist_ok=True)
        open(os.path.join(pdir, f'{part}.md'), 'w', encoding='utf-8').write(md)
        n = md.count('\n. ') + len(re.findall(r'^\d+\. ', md, re.M))
        total = sum(len(re.findall(r'^\d+\. ', open(os.path.join(pdir, f'{p}.md'), encoding='utf-8').read(), re.M))
                    for p in 'ABCD' if os.path.exists(os.path.join(pdir, f'{p}.md')))
        print(f'{jpath} → parts/{part}.md（{n} 条）')
        for w in warns: print(f'  ⚠ {w}')
        for x in dropped: print(f'  ✂ dropped: {x.get("title","?")[:40]} — {x.get("reason","")[:60]}')
    print(f'parts 合计 {total} 条')

if __name__ == '__main__':
    main()
