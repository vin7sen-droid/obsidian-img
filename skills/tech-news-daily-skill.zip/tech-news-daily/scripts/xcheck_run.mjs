// xcheck_run.mjs — 日报管线接入真源（AI 日报 news-ai/ 与科技日报 news-tools/ 共用，2026-11-16 单一真源收敛）
// 队员 JSON（中文）vs raw 英文原文池 数字/质检机检；raw 探测顺序：raw_<date>.json（argv[3] 指定/缺省最新）→ raw.json
// 用法：node xcheck_run.mjs <workdir> [date]
// 产出：<workdir>/xcheck_人工审.md（flagged>0 时），stdout 汇总。不阻塞发布（退出码恒 0）。
import { crossCheck, writeReviewList, parseNums, parseZhNums } from "./xcheck.mjs";
import fs from "node:fs";
import path from "node:path";

const wd = process.argv[2] && path.resolve(process.argv[2]);
if (!wd || !fs.existsSync(wd)) { console.error("用法: node xcheck_run.mjs <workdir>"); process.exit(2); }

const j = (p) => (fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, "utf-8")) : null);

function itemsFromJson(o) {
  if (Array.isArray(o)) return o;
  if (o && typeof o === "object") return o.items || o.merged || Object.values(o).find(Array.isArray) || [];
  return [];
}

// 与 publish.py/summary_check.py 同逻辑：merged 优先，兼容 review/merged、items、merged、裸数组；否则合并 T*.json
function loadItems() {
  const paths = [path.join(wd, "merged.json"), path.join(wd, "review", "merged.json")];
  for (const p of paths) {
    const o = j(p);
    const xs = itemsFromJson(o);
    if (xs.length) return { items: xs, src: path.relative(wd, p) };
  }
  const dir = path.join(wd, "json");
  const files = fs.existsSync(dir) ? fs.readdirSync(dir).filter((x) => /^T\d+\.json$/.test(x)).sort() : [];
  const seen = new Set(), items = [];
  for (const f of files) {
    for (const it of itemsFromJson(j(path.join(dir, f)))) {
      const k = normUrl(it.url);
      if (!k || !seen.has(k)) { if (k) seen.add(k); items.push(it); }
    }
  }
  return { items, src: "json/T*.json" };
}

const normUrl = (u) => {
  if (!u) return "";
  try {
    const x = new URL(u);
    x.hash = "";
    [...x.searchParams.keys()].filter((k) => /^utm_|^ref|^from$|^fbclid|^gclid/i.test(k)).forEach((k) => x.searchParams.delete(k));
    let s = x.toString();
    return s.endsWith("/") ? s.slice(0, -1) : s;
  } catch { return u.trim(); }
};

// raw 英文原文池（list，字段 title/desc/src/url）：argv[3] 指定日期 → raw_<date>.json；否则取最新 raw_<date>.json；无则回落 raw.json（AI 线）
function rawPath() {
  if (process.argv[3]) return path.join(wd, `raw_${process.argv[3]}.json`);
  const cands = fs.readdirSync(wd).filter((f) => /^raw_\d{4}-\d{2}-\d{2}\.json$/.test(f)).sort();
  if (!cands.length) return path.join(wd, "raw.json");
  return path.join(wd, cands[cands.length - 1]);
}
function rawIndex() {
  const raw = j(rawPath());
  const m = new Map();
  for (const it of Array.isArray(raw) ? raw : (raw && raw.items) || []) {
    const k = normUrl(it.url);
    if (k && !m.has(k)) m.set(k, it);
  }
  return m;
}

const { items, src } = loadItems();
const ri = rawIndex();
const zhRatio = (t) => { const s=(t||""); const zh=(s.match(/[\u4e00-\u9fff]/g)||[]).length; return s.length ? zh/s.length : 1; };
const pairs = []; let unmatched = 0, zhSrc = 0;
for (const it of items) {
  const en = ri.get(normUrl(it.url));
  if (!en || !(en.title || "").trim()) { unmatched++; continue; }
  // 中文源（IT之家/量子位等）无翻译发生，不送检；队员摘要是浓缩改写，长度比判据天然误报
  if (zhRatio(en.title + " " + (en.desc || en.summary || "")) >= 0.25) { zhSrc++; continue; }
  pairs.push({
    url: it.url, cat: it.cat || it.board || "",   // AI 线 schema=cat / 科技线 schema=board
    title: en.title, title_zh: it.title || "",
    // 剥 X 条目的「（推文，N 转发）/（N 条转发）」式前缀——纯元信息，送检会触发噪音
    summary: (en.desc || en.summary || "").replace(/^\s*（[^（）]*转发[^（）]*）\s*/, "").trim(), summary_zh: it.summary || "",
  });
}
if (!pairs.length) {
  console.log(`xcheck: 0/${items.length} 配对成功（raw.json 无对应英文原文），跳过机检`);
  process.exit(0);
}

process.stdout.write(`xcheck: ${pairs.length}/${items.length} 配对（源 ${src}，未配对 ${unmatched}）· 彩云第二通道机检中…\n`);
const r = await crossCheck({ items: pairs }, { engine: "caiyun", budgetMs: 150000 });
// 浓缩摘要天然短：长度比类全放行；「部分数字对不上」里译文数字是原文数字子集（浓缩删数字）的也放行
const close = (a, b) => { if (!isFinite(a) || !isFinite(b)) return false; const m = Math.max(Math.abs(a), Math.abs(b), 1e-9); return Math.abs(a - b) / m < 0.01; };
const subset = (f) => {
  const it = pairs[f.idx]; if (!it) return false;
  const en = f.kind === "title" ? it.title : it.summary;
  const zh = f.kind === "title" ? it.title_zh : it.summary_zh;
  const E = (parseNums(en) || []).map((x) => x.si), T = (parseZhNums(zh) || []).map((x) => x.si);
  if (!T.length) return false;
  return T.every((t) => E.some((e) => close(t, e)));
};
const kept = r.flagged.filter((f) => {
  if (f.reason.startsWith("疑似漏译（长度比")) return false;
  if (/数字/.test(f.reason) && subset(f)) return false;
  // 实体关键词丢失：标题/摘要只写产品名（Claude Fable 5.2）不写公司名（Anthropic）是日报摘要的正常形态，放行
  if (/实体关键词/.test(f.reason)) {
    const it = pairs[f.idx]; if (!it) return true;
    const zh = f.kind === "title" ? it.title_zh : it.summary_zh;
    const words = (String(f.reason.match(/：\s*(.+)$/)?.[1] || "").trim()).split(/\s+/).filter(Boolean);
    // 译文只要含被丢实体词的任一「词干」（如 Anthropic 专名整词）之外的长度≥2 拉丁词，且原文该词只是所属公司名 → 噪音放行
    if (words.length && zh && /[一-鿿]/.test(zh)) return false;  // 译文是正常中文且只丢公司名 → 放行
  }
  return true;
});
r.flagged = kept;
const hi = kept.filter((f) => f.level === "high").length;
const mid = kept.length - hi;
r.flagged.forEach((f) => console.log(`[${f.level.toUpperCase()}] ${f.kind}#${f.idx} — ${f.reason}`));
let p = null;
if (r.flagged.length) p = writeReviewList(wd, "xcheck", r.flagged, { checked: r.checked, skipped: r.skipped });
console.log(`xcheck: 英文配对 ${pairs.length}/${items.length}（中文源 ${zhSrc} 跳过）· 机检 ${r.checked} · flagged ${r.flagged.length}（HIGH ${hi} / MID ${mid}）${p ? " → " + p : " · 清洁"}`);
process.exit(0);
