#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""mkhtml_sticky.py —— 科技日报 HTML 薄转发（真源本目录 mdhtml.py，theme=tech）

沿用旧习惯：不带参数时读当前目录 out.md、写 out.html（publish.py 就是这样调的）；
也可以显式 `python3 mkhtml_sticky.py <in.md> [out.html]`。改渲染逻辑请改 mdhtml.py。
"""
import os
import runpy
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
argv = [a for a in sys.argv[1:] if a != "--tech"]
if not argv:
    argv = ["out.md"] if os.path.exists("out.md") else []
sys.argv = [sys.argv[0]] + argv + ["--theme", "tech"]
runpy.run_path(os.path.join(HERE, "mdhtml.py"), run_name="__main__")
