#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""每日非 AI 科技新闻日报——抓取+过滤管线（一站式，feedparser 版）
用法: python3 daily_fetch.py [YYYY-MM-DD] [--out DIR]
  省略日期 = 今天(北京时间)。输出: <out>/raw_<date>.json 与 <out>/pool_<date>.json
流程: 16 源抓取 → 时间窗(前一日18:00起) → AI/汽车/导购过滤 → vs 最近两期日报去重 → 池内去重
解析层: feedparser（RSS2.0/Atom/RDF 统一，CDATA/命名空间自动处理）；下载层: urllib+UA+timeout。
例外: techmeme 原文链接藏在 description 的 <A HREF>（手写提取）；readhub 是 JSON API。
"""
import os
import re, sys, json, gzip, io, time, calendar, threading, urllib.request, datetime as dt
from collections import Counter
import feedparser

UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36'

# ---- 源清单（全部走 feedparser；techmeme 特殊；readhub=API）----
FEEDS = {
 'ithome':    'https://www.ithome.com/rss/',
 'cnbeta':    'https://www.cnbeta.com.tw/backend.php',
 'phoronix':  'https://www.phoronix.com/rss.php',
 'tomshw':    'https://www.tomshardware.com/feeds/all',
 'ars':       'https://feeds.arstechnica.com/arstechnica/index',
 'arslab':    'https://feeds.arstechnica.com/arstechnica/technology-lab',
 'techcrunch':'https://techcrunch.com/feed/',
 '9to5mac':   'https://9to5mac.com/feed/',
 'bleeping':  'https://www.bleepingcomputer.com/feed/',
 'securityweek':'https://www.securityweek.com/feed/',
 'techradar': 'https://www.techradar.com/feeds.xml',
 'engadget':  'https://www.engadget.com/rss.xml',
 'wired':     'https://www.wired.com/feed/rss',
 'mydrivers': 'https://plink.anyfeeder.com/mydrivers',   # 快科技镜像,仅5条
 'solidot':   'https://www.solidot.org/index.rss',
 'verge':     'https://www.theverge.com/rss/index.xml',  # atom,feedparser 自动处理
 'hndaily':   'https://www.daemonology.net/hn-daily/index.rss',  # HN 每日 top10(借鉴 tech-digest,需代理)
}
TECHMEME = ('techmeme', 'https://www.techmeme.com/feed.xml')
PROXY_SRCS = {'cnbeta','hndaily'}  # 直连静默失效的源，自动走 MIHOMO（2026-11-16 实测）
NAIVE_CST = {'mydrivers'}  # pubDate 是北京时间字符串（无时区），不能按 UTC 解析
SRCNAME = {'ithome':'IT之家','cnbeta':'cnBeta','solidot':'Solidot','phoronix':'Phoronix',
 'tomshw':"Tom's Hardware",'ars':'Ars Technica','arslab':'Ars Technica','techcrunch':'TechCrunch',
 '9to5mac':'9to5Mac','bleeping':'BleepingComputer','securityweek':'SecurityWeek','techradar':'TechRadar',
 'engadget':'Engadget','wired':'Wired','verge':'The Verge','mydrivers':'快科技','techmeme':'TechMeme',
 'readhub':'ReadHub'}

MIHOMO = 'http://127.0.0.1:7890'   # 本机 mihomo（cnbeta 直连失效，须走代理 2026-11-16 实测）

def get(url, referer=None, timeout=25, proxy=False):
    """下载 → bytes（gzip 已解，含无 Content-Encoding 头的假 gzip 兜底）"""
    req = urllib.request.Request(url, headers={'User-Agent': UA,
        'Accept-Encoding': 'gzip', 'Accept': '*/*',
        **({'Referer': referer} if referer else {})})
    if proxy:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler(
            {'http': MIHOMO, 'https': MIHOMO}))
        r = opener.open(req, timeout=timeout)
    else:
        r = urllib.request.urlopen(req, timeout=timeout)
    d = r.read()
    if r.headers.get('Content-Encoding') == 'gzip' or d[:2] == b'\x1f\x8b':
        d = gzip.decompress(d)
    return d

def clean(s):
    s = re.sub(r'<!\[CDATA\[|\]\]>', '', s or '')
    return re.sub(r'<[^>]+>', '', s).strip()

def bjt(datestr):
    """各种日期串 → (北京时间 'MM-DD HH:MM', ts)。失败返回 ('',None)"""
    datestr = re.sub(r'\s+', ' ', (datestr or '').strip())  # 双空格兜底（anyfeeder/iThome TW 系）
    t = None
    for fmt in ('%a, %d %b %Y %H:%M:%S %Z', '%a, %d %b %Y %H:%M:%S %z',
                '%Y-%m-%dT%H:%M:%S%z', '%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%d %H:%M:%S'):
        try:
            t = dt.datetime.strptime(datestr, fmt); break
        except Exception: pass
    if t is None:
        try:
            t = dt.datetime.fromisoformat(datestr.replace('Z', '+00:00'))
        except Exception: return ('', None)
    if t.tzinfo is None: t = t.replace(tzinfo=dt.timezone.utc)
    b = t.astimezone(dt.timezone(dt.timedelta(hours=8)))
    return (b.strftime('%m-%d %H:%M'), b.timestamp())

def parse_fp(data, naive_cst=False):
    """feedparser 统一解析（RSS2.0/Atom/RDF）→ 行列表。
    日期优先 published_parsed（UTC struct_time）；naive_cst 源按北京时间字符串解析。"""
    out = []
    for e in feedparser.parse(data).entries:
        title = (e.get('title') or '').strip()
        url = (e.get('link') or '').strip()
        if not title or not url.startswith('http'): continue
        ts = None
        if naive_cst:
            try:
                t = dt.datetime.strptime((e.get('published') or '').strip(), '%Y-%m-%d %H:%M:%S'
                                         ).replace(tzinfo=dt.timezone(dt.timedelta(hours=8)))
                ts = t.timestamp()
            except Exception: pass
        else:
            st = e.get('published_parsed') or e.get('updated_parsed')
            if st:
                ts = calendar.timegm(st)          # struct_time 按 UTC
            else:
                ts = bjt(e.get('published') or e.get('updated') or '')[1]
        desc = e.get('summary') or ''
        if not desc and e.get('content'):
            desc = (e['content'][0] or {}).get('value', '')
        out.append({'title': title, 'url': url, 'date': '', 'ts': ts,
                    'desc': clean(desc)[:500]})
    return out


def parse_hndaily(txt, days=2):
    """daemonology hn-daily:每天 1 个 item,description HTML 含当日 top10 storylink(借鉴 tech-digest 配方)"""
    import html as _h
    import feedparser as _fp
    out = []
    try:
        feed = _fp.parse(txt)
    except Exception:
        return out
    for e in (feed.entries or [])[:days]:
        m = re.search(r'(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{4})', e.get('published',''))
        if m:
            mon = 'Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split().index(m.group(2)) + 1
            date = f"{int(m.group(3))}-{mon:02d}-{int(m.group(1)):02d}"
        else:
            date = ''
        for url, title in re.findall(r'class="storylink"><a href="([^"]+)">([^<]+)</a>', e.get('description','')):
            out.append({'title': _h.unescape(title).strip(), 'url': url, 'date': date, 'ts': None, 'desc': ''})
    return out

def parse_techmeme(txt):
    """item.link 是 techmeme 锚点;原文链接在 description 第一个外部 <A HREF>;
    来源名取 title 尾括号,标题取括号前主句"""
    out = []
    for it in re.findall(r'<item\b[\s\S]*?</item>', txt):
        mt = re.search(r'<title\b[^>]*>([\s\S]*?)</title>', it)
        md = re.search(r'<description\b[^>]*>([\s\S]*?)</description>', it)
        mp = re.search(r'<pubDate\b[^>]*>([\s\S]*?)</pubDate>', it)
        if not (mt and md): continue
        title = clean(mt.group(1))
        m = re.search(r'^(.*?)\s*\(([^()]+)\)\s*$', title)
        main, src = (m.group(1), m.group(2)) if m else (title, 'TechMeme')
        ml = re.search(r"<A HREF=\"(https?://(?!www\.techmeme\.com)[^\"]+)\"", md.group(1), re.I) \
             or re.search(r'href="(https?://(?!www\.techmeme\.com)[^"]+)"', md.group(1), re.I)
        if not ml: continue
        date, ts = bjt(clean(mp.group(1)) if mp else '')
        out.append({'title': main, 'url': ml.group(1), 'date': date, 'ts': ts,
                    'desc': '', 'src': 'techmeme', 'srcname': src.strip()})
    return out

def fetch_readhub(date):
    """daily?date= → {"data":[{title,uid,summary}]} → detail → {"data":{items:[…,newsAggList]}}"""
    out = []
    try:
        d = json.loads(get('https://api.readhub.cn/topic/daily?date=' + date))
        topics = d.get('data', d) if isinstance(d, dict) else d
        if isinstance(topics, dict): topics = topics.get('topics', [])
        for tp in (topics or [])[:14]:
            uid = tp.get('uid') or ''
            if not uid: continue
            try:
                det = json.loads(get('https://api.readhub.cn/topic/detail?uid=' + uid, timeout=20))
                data = det.get('data') if isinstance(det, dict) else None
                items = (data or {}).get('items') if isinstance(data, dict) else None
                if items is None and isinstance(data, list): items = data
                for n in (items or []):
                    agg = n.get('newsAggList') if isinstance(n, dict) else None
                    # 日期在话题本体（newsAggList 聚合条目无日期字段）——透传给每条报道
                    tdate = str(n.get('publishDate') or n.get('createdAt') or '') if isinstance(n, dict) else ''
                    rows = agg if isinstance(agg, list) else ([n] if isinstance(n, dict) and n.get('url') else [])
                    for x in rows:
                        url, title = x.get('url') or '', x.get('title') or ''
                        if not url or not title: continue
                        date_, ts = bjt(str(x.get('publishDate') or x.get('createdAt') or tdate))
                        src = 'readhub:' + (x.get('siteNameDisplay') or 'ReadHub')
                        out.append({'title': title, 'url': url, 'date': date_, 'ts': ts,
                                    'desc': '', 'src': src, 'srcname': x.get('siteNameDisplay') or ''})
            except Exception: continue
            time.sleep(0.3)
    except Exception as e:
        print('readhub FAIL', e)
    return out

def fetch_all(sources=None):
    """sources=None 抓全部；传集合则只抓指定源（--src 快源模式）"""
    res, lock = {}, threading.Lock()
    def job(name, url):
        try:
            rows = parse_fp(get(url, proxy=name in PROXY_SRCS,
                            referer=url.split('//')[0] + '//' + url.split('//')[1].split('/')[0] if '//' in url else None),
                            naive_cst=name in NAIVE_CST)
        except Exception as e:
            print(name, 'FAIL', e); rows = []
        with lock: res[name] = rows
    ths = []
    for n, u in FEEDS.items():
        if sources and n not in sources:
            continue
        t = threading.Thread(target=job, args=(n, u)); t.start(); ths.append(t)
    for t in ths: t.join()
    if sources and 'hndaily' not in sources:
        res['hndaily'] = []
    else:
        rows = []
        for _att in range(5):   # daemonology 链路间歇抖动(TLS 握手被 RST),5 次退避,全败则空着不阻塞
            try:
                rows = parse_hndaily(get(FEEDS['hndaily'], proxy=True).decode('utf-8','replace')); break
            except Exception as e:
                print('hndaily attempt', _att + 1, 'FAIL', str(e)[:60]); time.sleep(3 + 3 * _att)
        res['hndaily'] = rows
    if sources and 'techmeme' not in sources:
        res['techmeme'] = []
    else:
        try:
            res['techmeme'] = parse_techmeme(get(TECHMEME[1]).decode('utf-8', 'replace'))
        except Exception as e:
            print('techmeme FAIL', e); res['techmeme'] = []
    return res

# ---- 过滤 ----
AI = re.compile(r'AI|人工智能|大模型|LLM|GPT|OpenAI|ChatGPT|Gemini|Claude|Anthropic|Copilot|'
    r'DeepSeek|Qwen|通义|文心|Kimi|豆包|Sora|Midjourney|Grok|Firefly|生成式|智能体|AGI|Altman|Apple 智能|Apple Intelligence|Siri|英伟达|NVIDIA|黄仁勋', re.I)
CAR = re.compile(r'汽车|新能源车|SUV|续航|车企|比亚迪|蔚来|小鹏|理想汽车|问界|小米汽车|吉利银河|'
    r'福特|Mach-E|康林松|vehicles|A350|奔驰|宝马车|丰田|本田', re.I)
# 特斯拉/Tesla 为例外：不被 CAR 过滤（用户 2026-11-16/19 定）
JUNK = re.compile(r'Quordle|Deals:|喜加一|今日值买|段子|拼团|NYT .*(hints|answers)|How to watch|Not sure what|best .* deals'
                  r'|buying guide|roundup|hands-on|black friday|prime day|how to (choose|pick|buy)'
                  r'|everything you need to know|explained|what (is|are) .*(and (why|how))|science behind'
                  r'|\bbest\b.*\b(buy|deal|gift|budget|cheap)\b|top \d+ .*(you can|to buy|worth)|worth buying', re.I)

def norm_url(u):
    """跨抓取/质检/已发日报统一 URL 归一：去 hash 与追踪参数。"""
    if not u:
        return ''
    try:
        from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
        p = urlsplit(str(u).strip())
        drop = re.compile(r'^(?:utm_|ref$|from$|fbclid$|gclid$)', re.I)
        q = urlencode([(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if not drop.search(k)])
        path = p.path.rstrip('/') or '/'
        return urlunsplit((p.scheme.lower(), p.netloc.lower(), path, q, ''))
    except Exception:
        return str(u).strip().rstrip('/')


def norm_title(t):
    return re.sub(r'\W', '', (t or ''))[:18]


def last_two_issues(today):
    """从 Obsidian 目录找最近两期科技新闻日报的 (urls, title前14字)"""
    import glob as _g, os
    urls, t14 = set(), set()
    files = sorted(_g.glob('/sdcard/Obsidian/dsh/新闻/科技新闻_2026-*.md'))
    for f in files[-2:]:
        try: txt = open(f, encoding='utf-8').read()
        except Exception: continue
        for u in re.findall(r'\]\((https?://[^)]+)\)', txt):
            urls.add(norm_url(u))
        for m in re.findall(r'^\d+\.\s*\*\*\[([^\]]+)\]', txt, re.M): t14.add(re.sub(r'\W', '', m)[:14])
    return urls, t14

def main():
    args = sys.argv[1:]
    date = args[0] if args and re.match(r'\d{4}-\d\d-\d\d', args[0]) else dt.datetime.now(
        dt.timezone(dt.timedelta(hours=8))).strftime('%Y-%m-%d')
    outdir = args[args.index('--out') + 1] if '--out' in args else '.'
    sources = set()
    for i, a in enumerate(args):
        if a == '--src' and i + 1 < len(args):
            sources.update(s.strip() for s in args[i + 1].split(',') if s.strip())
    if sources:
        print('快源模式，只抓:', ' '.join(sorted(sources)))
    import os; os.makedirs(outdir, exist_ok=True)

    res = fetch_all(sources or None)   # --src 快源模式传子集
    raw = []
    for src, rows in res.items():
        for r in rows:
            r.setdefault('src', src)
            r.setdefault('srcname', SRCNAME.get(src.split(':')[0], src))
            raw.append(r)
    rh = fetch_readhub(date) if (not sources or 'readhub' in sources) else []
    for r in rh: r.setdefault('srcname', SRCNAME.get(r['src'].split(':')[0], r['src']))
    raw += rh
    # date 统一由 ts 生成（北京时间）
    for r in raw:
        if r.get('ts'):
            b = dt.datetime.fromtimestamp(r['ts'], dt.timezone(dt.timedelta(hours=8)))
            r['date'] = b.strftime('%m-%d %H:%M')
    json.dump(raw, open(f'{outdir}/raw_{date}.json', 'w', encoding='utf-8'), ensure_ascii=False)
    failed_sources = sorted(s for s in FEEDS if s in res and not res.get(s) and (not sources or s in sources))
    coverage_warn = False
    status = {'date': date, 'raw_count': len(raw), 'source_counts': dict(Counter(r.get('src','').split(':')[0] for r in raw)),
              'failed_sources': failed_sources, 'degraded': bool(failed_sources) or coverage_warn, 'coverage_warn': coverage_warn}
    json.dump(status, open(f'{outdir}/fetch_status.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print('fetch_status', os.path.join(outdir, 'fetch_status.json'))
    print('raw', len(raw))

    # coverage 反向校验：与最近一期 raw 对比，单源骤降/总数骤降 WARN（如 cnbeta RSS 静默失效 200→0）
    try:
        import glob as _g
        prev_raws = sorted(_g.glob(f'{outdir}/raw_*.json'))
        prev_raws = [p for p in prev_raws if not p.endswith(f'raw_{date}.json')]
        if prev_raws:
            prev = json.load(open(prev_raws[-1]))
            pc, cc = Counter(e['src'].split(':')[0] for e in prev), Counter(e['src'].split(':')[0] for e in raw)
            for s in set(pc) | set(cc):
                p, c = pc.get(s, 0), cc.get(s, 0)
                if p >= 10 and c < p * 0.5:
                    coverage_warn = True
                    print(f'  ⚠ coverage WARN: 源 {s} {p}→{c} 骤降 ≥50%，可能 RSS 失效，考虑换源')
            if len(prev) >= 100 and len(raw) < len(prev) * 0.7:
                coverage_warn = True
                print(f'  ⚠ coverage WARN: raw 总数 {len(prev)}→{len(raw)} 骤降 ≥30%，检查网络/代理')
    except Exception as _e:
        print('  coverage 对比跳过:', _e)

    # 时间窗: 前一日 18:00 起（无 ts 的保留,靠后续人工/队员判断）
    lo = (dt.datetime.strptime(date, '%Y-%m-%d') - dt.timedelta(days=1)
          ).replace(hour=18, tzinfo=dt.timezone(dt.timedelta(hours=8))).timestamp()
    w = [e for e in raw if e['ts'] is None or e['ts'] >= lo]
    print('window', len(w))
    # AI/汽车/导购
    f1 = [e for e in w if not (AI.search(e['title']) and not re.search(r'芯片|半导体|算力|GPU 服务器', e['title']))]
    f1 = [e for e in f1 if not CAR.search(e['title']) and not JUNK.search(e['title'])]
    print('filtered', len(f1))
    # vs 最近两期
    urls, t14 = last_two_issues(date)
    f2, seen = [], set()
    for e in f1:
        if norm_url(e['url']) in urls: continue
        k14 = re.sub(r'\W', '', e['title'])[:14]
        if k14 and k14 in t14: continue
        k18 = norm_title(e['title'])
        if k18 in seen: continue
        seen.add(k18); f2.append(e)
    json.dump(f2, open(f'{outdir}/pool_{date}.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('pool', len(f2), Counter(e['src'].split(':')[0] for e in f2).most_common())

if __name__ == '__main__':
    main()
