#!/usr/bin/env python3
# 从当日 radar JSON（digests/<date>.json）筛出未解码的 Google News 跳转链线索，
# 落 <工作目录>/gnews_pool.json（title/source/theme/time/url），供队员按需自解码。
# 用法：python3 gnews_pool.py <date:YYYY-MM-DD> --out <工作目录>/dN
# 配套：队员自己跑 gnews_url.py --json gnews_pool.json --match/--theme --limit N --workers 2
import json, sys, argparse

ap = argparse.ArgumentParser()
ap.add_argument("date")  # YYYY-MM-DD
ap.add_argument("--out", required=True)
a = ap.parse_args()

DIGESTS = os.environ.get("DSH_DIGESTS_DIR") or os.path.expanduser("~/digests")
src = os.path.join(DIGESTS, f"{a.date}.json")
d = json.load(open(src))
items = d.get("items", [])
pool = [
    {"title": it.get("title", ""), "title_zh": it.get("title_zh") or "",
     "source": it.get("source", ""), "theme": it.get("theme", ""),
     "time": it.get("date", ""), "url": it["url"]}
    for it in items if "news.google.com" in (it.get("url") or "")
]
import os
os.makedirs(a.out, exist_ok=True)
out = f"{a.out.rstrip('/')}/gnews_pool.json"
json.dump(pool, open(out, "w"), ensure_ascii=False)
print(f"gnews_pool {len(pool)} 条 → {out}（跳过已解码/原站链接 {len(items)-len(pool)} 条）")
