#!/usr/bin/env python3
"""hn_algolia.py —— HN Algolia 补量入口（科技日报线）

薄转发到本目录 hn.py，自动补 --ai tag：全量保留 + is_ai 打标（科技线要人工判 AI 漏网）。
"""
import os
import runpy
import sys

if "--ai" not in sys.argv:
    sys.argv += ["--ai", "tag"]
runpy.run_path(os.path.join(os.path.dirname(os.path.abspath(__file__)), "hn.py"), run_name="__main__")
