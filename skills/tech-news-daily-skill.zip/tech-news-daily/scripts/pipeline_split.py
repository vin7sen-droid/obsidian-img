#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""派单前预处理：事件聚类（①）+ 板块预分类（②）→ pack_{A..D}.json + borderline.json
用法: python3 pipeline_split.py <pool.json> [--out DIR]
产物（--out 目录，默认 pool 同目录）:
  pack_A/B/C/D.json  各队素材（每条附 board 初判/置信度/cluster 信息）
  cluster.json       聚类组明细（size>1 的组=多源合并候选，交同一队员写）
  borderline.json    低置信度条目（领队人工拍板后再派）
  clusters_{A,B,CD}.json  簇结构（完整多队模式按此派单：一簇一条成稿，main=主源，sources=同事件其他源）
  clusters.md        簇派单人读视图
"""
import os, re, sys, json, time, argparse
from concurrent.futures import ThreadPoolExecutor
from collections import defaultdict

# ---- 十板块关键词表（子串匹配，不区分大小写；顺序敏感：越靠前越优先决胜）----
BOARDS = {
 '一': '芯片与硬件', '二': '消费电子与终端', '三': '互联网与大厂动态', '四': '通信与网络',
 '五': '软件、游戏与开源', '六': '网络安全与数据', '七': '航天、能源与前沿科学',
 '八': '生物科技与医疗硬件', '九': '政策、监管与商业', '十': '融资与并购'}
KW = {
 '一': ['芯片','半导体','光刻','晶圆','制程','2nm','3nm','5nm','gpu','cpu','内存','dram','nand','存储','封测','先进封装','cowos','台积电','三星电子','英特尔','intel','amd','英伟达','nvidia','高通','联发科','arm ','risc-v','服务器','ssd','硬盘','hbm','euv','代工','中芯','微电子','rapidus','钜成','晶合','fpga','asic','指令集','处理器','主板','电源','散热','机箱','测试设备','掩膜','硅片','互联 ip','ip 核','玄铁','主控','芯片组'],
 '二': ['手机','iphone','galaxy','pixel','小米','oppo','vivo','华为','荣耀','一加','平板','ipad','macbook','笔记本','电脑','pc ','手表','watch','手环','耳机','音箱','相机','无人机','大疆','vr','ar','眼镜','头显','折叠屏','电池','充电','屏幕','oled','lcd','mini-led','电视','家电','空调','冰箱','洗衣机','路由器','摄像头','扫地机','tws','快充','手柄','智能穿戴','智能家居','流媒体','盒子','机顶盒'],
 '三': ['谷歌','google','苹果','apple','微软','microsoft','meta','亚马逊','amazon','阿里','腾讯','百度','字节','抖音','tiktok','快手','美团','拼多多','京东','网易','b站','bilibili','微博','小红书','youtube','instagram','whatsapp','telegram','discord','reddit','社交','搜索','浏览器','chrome','safari','edge','防火墙','地图','外卖','电商','支付','支付宝','微信','qq ','云服务','aws','azure','百度网盘','会员','订阅','用户数','mau','dau','上线','下架','内测','公测','停运','关停','roku','app ','linkedin','夸克','community'],
 '四': ['5g','6g','基站','运营商','中国移动','中国电信','中国联通','宽带','光纤','卫星互联网','starlink','星链','海底电缆','海缆','wi-fi','wifi','蓝牙','nfc','频谱','漫游','携号转网','sub-6','毫米波','卫星电话','直连卫星','天线','号段','携转'],
 '五': ['游戏','gta','steam','playstation','ps5','ps5 pro','xbox','switch','switch 2','任天堂','索尼互动','epic','unity','unreal','虚幻','原神','王者荣耀','吃鸡','dnf','魔兽','宝可梦','马里奥','塞尔达','时之笛','版号','独立游戏','dlc','mod','补丁?游戏','beta','linux','windows','android','ios','ipados','macos','开源','github','firefox','chromeos','内核','驱动','编程','语言','框架','数据库','开发者','sdk','api','git ','python','rust','blender','obs ','gpl','asahi','wine','proton'],
 '六': ['黑客','攻击','漏洞','cve','勒索','病毒','木马','钓鱼','泄露','数据泄露','隐私','gdpr','加密','密码','零日','0day','apt ','ddos','恶意','信息安全','网络安全','安全','安全补丁','security','patch','zero-day','zero day','hotfix','certificate','hacked','hackers','cyber','breach','ransomware','hacker','exploit','malware','spyware','phishing','backdoor','后门','rootkit','凭证','拖库','撞库','社工','供应链攻击','ciso','防火墙'],
 '七': ['nasa','spacex','星舰','火箭','猎鹰','发射','轨道','月球','火星','空间站','探测器','飞船','宇航员','天文','望远镜','韦伯','哈勃','系外','行星','小行星','彗星','黑洞','引力波','物理','粒子','量子','quantum','核聚变','托卡马克','人造太阳','旅行者','厄尔尼诺','气象','供暖','热源','再生水','深空','核电站','核电','风电','光伏','太阳能','储能','电网','石油','天然气','氢能','可控核','材料','超导','基因','dna','恐龙','化石','考古','大脑','神经','细胞','实验','研究','发现','论文','science ','nature ','气象','台风','地震','深海','南极','北极'],
 '八': ['药物','药片','疫苗','临床','fda','nmpa','医疗','医院','医生','患者','癌症','肿瘤','手术','基因编辑','crispr','诊断','器械','血糖','血压','cgm','胰岛素','阿尔茨海默','帕金森','glp-1','司美格鲁肽','mrna','抗体','疗法','移植','影像','ct ','mri','超声','脑机接口','genome','基因'],
 '九': ['监管','法案','立法','反垄断','罚款','诉讼','法院','判决','禁令','审查','牌照','许可','政策','工信部','网信办','fcc','sec ','ftc','doj','消协','12306','欧盟','欧洲议会','国会','参议院','众议院','商务部','关税','出口管制','制裁','调查','听证','裁员','财报','营收','业绩','市值','股价','ipo 上市','招股书','招标','合同','工会','罢工','劳动','版权','商标','专利','数据合规','个人信息保护','未成年','实名'],
 '十': ['融资','投资','领投','跟投','估值','收购','并购','合并?公司|换股','注资','a 轮','b 轮','c 轮','pre-a','天使轮','风投','vc ','私募','软银','红杉','高瓴','老虎基金','银湖','kek ','基石','战投',' Divestiture','剥离','spac'],
}
# 边界修正表：(子串, 板块) —— 按顺序扫描，命中即改判（解决跨板块关键词冲突）
OVERRIDE = [
 ('版号', '五'), ('补丁日', '六'), ('数据泄露', '六'), ('专利', '九'), ('版权', '九'),
 ('股票|股价|市值|财报|营收|招股书|上市申请|ipo', '九'),   # 上市动态归九，融资事件归十
 ('卫星', '四'), ('卫星互联网|直连卫星|星链|starlink', '四'),
 ('量子计算机|量子比特', '七'), ('量子通信', '四'),
 ('电池|充电', '二'), ('data center|数据中心|idc|算力中心', '九'),
 ('太空|航天|火箭|星舰|发射', '七'), ('手术机器人|医疗', '八'),
]
TEAMS = {'A': ['一', '二'], 'B': ['三', '四', '五'], 'CD': ['六', '七', '八', '九', '十']}  # 2026-11-12 用户定：C/D 合并为 CD

# ---- 实体族表（同一公司/人物跨板块的条目整族交同一队员，防「各写各的再去重」）----
ENTITIES = {
 '英伟达': ['英伟达', 'nvidia', '黄仁勋', 'jensen'], '苹果': ['苹果', 'apple', 'iphone', 'ipad', 'macbook', '库克', 'airpods', 'watch'],
 '台积电': ['台积电', 'tsmc'], '三星': ['三星', 'samsung', 'galaxy'], '英特尔': ['英特尔', 'intel'],
 'AMD': ['amd', '苏姿丰'], '谷歌': ['谷歌', 'google', 'deepmind', 'android', 'youtube', 'pixel'],
 '微软': ['微软', 'microsoft', 'windows', 'xbox', 'surface'], 'Meta': ['meta', 'facebook', 'instagram', 'whatsapp', '扎克伯格'],
 '亚马逊': ['亚马逊', 'amazon', 'aws', 'alexa'], '字节': ['字节', 'tiktok', '抖音', '今日头条'],
 '阿里': ['阿里', '淘宝', '天猫', '夸克'], '腾讯': ['腾讯', '微信', '王者荣耀'], '小米': ['小米', 'redmi', '澎湃os', '雷军'],
 '华为': ['华为', '鸿蒙', 'harmonyos', '麒麟'], 'SpaceX': ['spacex', '马斯克', '星舰', 'starlink'],
 '索尼': ['索尼', 'playstation', 'ps5'], '任天堂': ['任天堂', 'switch'], '高通': ['高通', 'qualcomm', '骁龙'],
 '博通': ['博通', 'broadcom'], '美光': ['美光', 'micron'], 'sk海力士': ['sk 海力士', 'hynix'],
 'IBM': ['ibm'], 'Roku': ['roku'], '联发科': ['联发科', 'mediatek'], '甲骨文': ['甲骨文', 'oracle'],
 '360': ['360', '周鸿祎', '奇虎'], '大麦娱乐': ['大麦娱乐'], '迪士尼': ['迪士尼', 'disney'],
 '微博': ['微博', 'weibo'], '京东': ['京东', 'jd.com'], '京东物流': ['京东物流'], '阿里云': ['阿里云'], '腾讯云': ['腾讯云'], '腾讯音乐': ['腾讯音乐'], '虎牙': ['虎牙', 'huya'],
 '哔哩哔哩': ['哔哩哔哩', 'b站', 'bilibili'], '快手': ['快手'], '美团': ['美团'], '滴滴': ['滴滴'],
 '鸿海': ['鸿海', '富士康', 'foxconn'], '长鑫': ['长鑫', 'cxmt'], '中芯国际': ['中芯国际', 'smic'],
 '索尼半导体': ['索尼半导体'], '海力士': ['海力士', 'hynix'], '高通': ['高通', 'qualcomm', '骁龙'],
}

def grams(title, n=2):
    """标题 → 字符 2-gram 集合（去标点转小写；英文也按字符对，短标题可比）"""
    s = re.sub(r'\W+', '', (title or '').lower())
    return {s[i:i+n] for i in range(max(0, len(s)-n+1))} if len(s) >= n else ({s} if s else set())

def jac(a, b):
    if not a or not b: return 0.0
    return len(a & b) / len(a | b)

def domain(url):
    m = re.match(r'https?://([^/]+)', url or '')
    d = m.group(1).lower() if m else ''
    return re.sub(r'^(www|m|mobile|news|www2)\.', '', d)

def lcs(a, b):
    """最长公共子串长度（标题层面兜底：中文同事件常是前缀截断/加前缀关系）"""
    a, b = re.sub(r'\W+', '', (a or '').lower()), re.sub(r'\W+', '', (b or '').lower())
    if not a or not b: return 0
    prev = [0]*(len(b)+1); best = 0
    for x in a:
        cur = [0]*(len(b)+1)
        for y_i, y in enumerate(b):
            if x == y:
                cur[y_i+1] = prev[y_i]+1
                if cur[y_i+1] > best: best = cur[y_i+1]
        prev = cur
    return best

def ent_of(title):
    """标题命中哪个实体族（小写匹配）；无命中返回 None"""
    t = title.lower()
    for ent, kws in ENTITIES.items():
        if any(k in t for k in kws): return ent
    return None

STOP = {'the','and','for','with','new','how','why','what','from','that','this','your','its','are','was',
        'has','have','will','can','not','you','out','now','top','best','more','than','over','into','after'}

def entset_of(title):
    """标题命中的实体族。最长关键词优先：命中「京东物流」就不再算「京东」（防同集团子公司混族）"""
    t = (title or '').lower()
    hits = {}
    for ent, kws in ENTITIES.items():
        L = max((len(k) for k in kws if k in t), default=0)
        if L: hits[ent] = L
    if not hits: return set()
    mx = max(hits.values())
    keep = {e for e, L in hits.items() if L == mx}
    return keep if mx >= 3 else set(hits)

def proper_of(title):
    """标题里的专有词/型号（英文词 ≥2 字母、去通用词）——同事件强信号"""
    return {w.lower() for w in re.findall(r'[A-Za-z][A-Za-z0-9\.\-]{1,}', title or '')
            if w.lower() not in STOP}

def model_of(title):
    """含数字的型号/版本号（HBM5、GTA6、iOS 27.3、Server 2016）——最强同事件信号"""
    return {w.lower() for w in re.findall(r'[A-Za-z]*\d+[A-Za-z0-9\.\-]*', title or '')}

def lcs_str(a, b):
    """最长公共子串本身（lcs() 只返回长度；lcs_ok 需要看子串内容）"""
    a, b = re.sub(r'\W+', '', (a or '').lower()), re.sub(r'\W+', '', (b or '').lower())
    if not a or not b: return ''
    prev = ['']*(len(b)+1); best = ''
    for x in a:
        cur = ['']*(len(b)+1)
        for y_i, y in enumerate(b):
            if x == y:
                cur[y_i+1] = prev[y_i]+x
                if len(cur[y_i+1]) > len(best): best = cur[y_i+1]
        prev = cur
    return best

GENERIC_RAW = {'vulnerabilities', 'vulnerability', 'security', 'patch', 'patches', 'update', 'updates',
               'release', 'releases', 'critical', 'zeroday', 'highseverity', 'report', 'reported', 'ces',
               'startingwitha', 'blackfriday', 'hasreturned', 'comingto', 'setto'}
GENERIC = {re.sub(r'[\s-]+', '', w) for w in GENERIC_RAW}

def lcs_ok(a, b):
    """lcs≥12 且最长公共子串不含领域/季节通用词（黏连形态如 'yvulnerabilities' 也算）"""
    s = lcs_str(a, b)
    if len(s) < 12: return False
    return not any(w in s for w in GENERIC)

def cluster(entries):
    """事件聚类：同域 jaccard≥0.36、跨域 ≥0.42、或公共子串≥12 → 同组（并查集）
    保护（借鉴 news-ai 教训：同实体不同事件被 0.40 阈值糊成一条，一夜丢 9 条新闻）：
    同一实体的两条（如英伟达的董事会调查 vs 股东诉讼）阈值提到 0.55/0.60，宁拆勿并。"""
    n = len(entries)
    parent = list(range(n))
    def find(x):
        while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
        return x
    def uni(a, b):
        ra, rb = find(a), find(b)
        if ra != rb: parent[rb] = ra
    G = [grams(e['title']) for e in entries]
    D = [domain(e['url']) for e in entries]
    E = [ent_of(e['title']) for e in entries]
    ES = [entset_of(e['title']) for e in entries]
    PR = [proper_of(e['title']) for e in entries]
    MO = [model_of(e['title']) for e in entries]
    BD = [e.get('board') or '' for e in entries]
    for i in range(n):
        for j in range(i+1, n):
            j12 = jac(G[i], G[j])
            same = D[i] == D[j]
            same_ent = E[i] and E[i] == E[j]
            th = (0.55, 0.60) if same_ent else (0.36, 0.42)  # 同实体对：阈值抬高
            ok_lcs = (lcs(entries[i]['title'], entries[j]['title']) >= 14) if same_ent else lcs_ok(entries[i]['title'], entries[j]['title'])
            # 硬否决一：各有实体但完全不相交（京东/微博/腾讯音乐三份财报同模板）
            if ES[i] and ES[j] and not (ES[i] & ES[j]):
                continue
            # 硬否决二：一方实体集是另一方的真子集（「三星 HBM5」⊂「苹果+三星 DRAM 协议」，
            # 后者是双主体事件、前者是单主体快讯，不能并）
            if ES[i] and ES[j] and (ES[i] < ES[j] or ES[j] < ES[i]):
                continue
            # 第三类：同事件强信号——同板块 + 实体集相等 +（j12≥0.30 或 共享含数字型号）
            ok_ent = ES[i] and ES[i] == ES[j] and (not BD[i] or not BD[j] or BD[i] == BD[j]) \
                     and (j12 >= 0.30 or bool(MO[i] & MO[j]))
            if (same and j12 >= th[0]) or (not same and j12 >= th[1]) or ok_lcs or ok_ent:
                uni(i, j)
    groups = defaultdict(list)
    for i in range(n): groups[find(i)].append(i)
    # 编号: 组 size>1 才给 c<序号>，孤条 c0
    cid, out = 0, [0]*n
    for root, members in groups.items():
        if len(members) > 1:
            cid += 1
            for m in members: out[m] = f'c{cid}'
        else: out[members[0]] = ''
    return out

def classify(title):
    """返回 (板块或'', 命中明细 list[(板块, 命中词…)])"""
    t = (title or '').lower()
    hits = {}
    for b, kws in KW.items():
        hit = [k for k in kws if k in t]
        if hit: hits[b] = hit
    # 边界修正
    for pat, b in OVERRIDE:
        if re.search(pat, t) and b not in hits:
            hits[b] = [f'override:{pat}']
        elif re.search(pat, t):
            hits[b] = hits[b] + [f'override:{pat}']
    if not hits: return '', []
    ranked = sorted(hits.items(), key=lambda kv: (-len(kv[1]), list(KW).index(kv[0])))
    top, second = ranked[0], (ranked[1] if len(ranked) > 1 else (None, []))
    # 置信度：无命中 → low(borderline)；并列命中 → mid（按表顺序取先者，仍可判）
    if second[0] and len(top[1]) == len(second[1]): return top[0], ranked
    return top[0], ranked

# ---- 簇结构（2026-11-17 用户定：完整多队模式按簇派单，替代「一条素材一篇」）----
# 主源选择：聚合/二手源不能当主源（它们的 desc 是别人的摘要或空壳）
SRC_RANK = {'ithome': 9, 'cnbeta': 8, 'bleeping': 9, 'securityweek': 8, 'ars': 8, 'verge': 8,
            'techcrunch': 8, 'wired': 8, 'engadget': 7, 'phoronix': 7, 'tomshw': 7, 'techradar': 7,
            '9to5mac': 7, 'mydrivers': 7, 'solidot': 6, 'thenextweb': 6,
            'readhub': 2, 'techmeme': 2, 'hndaily': 3, 'hn': 3}
AGG = {'readhub', 'techmeme'}          # 聚合源：只能进 sources，不能当主源

def _rank(e):
    return SRC_RANK.get(e.get('src') or '', 5)

def _main_score(e):
    """主源得分：desc 信息量（封顶 400 字）+ 源权威度；聚合源重罚"""
    d = len(e.get('desc') or '')
    sc = min(d, 400) + _rank(e) * 20
    if (e.get('src') or '') in AGG: sc -= 600
    return sc

def build_clusters(pool, cids, outdir):
    os.makedirs(outdir, exist_ok=True)
    """把每队素材切成「簇」：一簇 = 一条成稿（size=1 的孤条也各成一簇，结构统一）"""
    from collections import defaultdict as _dd
    teams = _dd(list)
    for i, e in enumerate(pool):
        for tm, bs in TEAMS.items():
            if e['board'] in bs: teams[tm].append(i)
    # 全局簇编号：同 cluster id 的素材必须落在同一队（同簇板块已投票统一）
    gmap = _dd(list)
    for i, e in enumerate(pool):
        key = cids[i] or f'solo{i}'
        gmap[key].append(i)
    out = {}
    for tm, idxs in teams.items():
        rows, seen = [], set()
        for i in idxs:
            key = cids[i] or f'solo{i}'
            if key in seen: continue
            seen.add(key)
            members = [m for m in gmap[key] if pool[m]['board'] in TEAMS[tm]]
            if not members: members = [i]
            cand = sorted(members, key=lambda m: (-_main_score(pool[m]), len(pool[m].get('desc') or '')))
            main = pool[cand[0]]
            rows.append({
                'cluster_id': key,
                'board': main['board'],
                'size': len(members),
                'main': {k: main.get(k) for k in ('src', 'srcname', 'title', 'url', 'date', 'desc')},
                'sources': [{k: pool[m].get(k) for k in ('src', 'srcname', 'title', 'url', 'date')}
                            for m in cand],
            })
        rows.sort(key=lambda r: (r['board'], -r['size']))
        out[tm] = rows
        json.dump(rows, open(f'{outdir}/clusters_{tm}.json', 'w', encoding='utf-8'),
                  ensure_ascii=False, indent=1)
    # 人读视图
    lines = ['# 簇派单素材（一簇 = 一条成稿；只写主源能落到的事实，其他 sources 只补链接）', '']
    for tm in sorted(out):
        multi = sum(1 for r in out[tm] if r['size'] > 1)
        lines.append(f'## {tm} 队：{len(out[tm])} 簇（其中多源簇 {multi}）')
        for r in out[tm]:
            m = r['main']
            others = '、'.join(x['srcname'] or x['src'] for x in r['sources'][1:])
            lines.append(f"- [{r['cluster_id']}] {r['board']} {m['title'][:56]}"
                         f"（主源 {m['srcname'] or m['src']} {m['date']}｜{r['size']} 源"
                         + (f"：{others}" if others else '') + '）')
        lines.append('')
    open(f'{outdir}/clusters.md', 'w', encoding='utf-8').write('\n'.join(lines))
    return out


def _enricher():
    """加载正文补料真源（tools/enrich.py），复用其 fetch_text。"""
    import importlib.util
    spec = importlib.util.spec_from_file_location('_enrich_tool', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'enrich.py'))
    em = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(em)
    return em


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('pool'); ap.add_argument('--out', default=None)
    ap.add_argument('--no-enrich', action='store_true', help='跳过正文补料（默认抓，约 20-40 秒）')
    ap.add_argument('--enrich-chars', type=int, default=900)
    ap.add_argument('--mode', choices=['auto', 'full', 'fast'], default='auto',
                    help='完整模式=簇结构派单(full)、快速模式=扁平 pack 派单(fast)；auto 抓两者并集')
    a = ap.parse_args()
    pool = json.load(open(a.pool, encoding='utf-8'))
    outdir = a.out or a.pool.rsplit('/', 1)[0]
    # desc 常带站点 HTML（<p data-vmark=...>），剥成纯文本再进素材
    _tag = re.compile(r'<[^>]+>')
    for e in pool:
        if e.get('desc') and '<' in e['desc']:
            e['desc'] = _tag.sub(' ', e['desc']).strip()
    # ② 预分类（先分类再聚类：簇的强信号合并要用 board 做「同板块」约束，否则跨板块误并）
    for i, e in enumerate(pool):
        b, ranked = classify(e['title'])
        e['board'] = b
        e['board_conf'] = 'low' if not b else ('mid' if len(ranked) > 1 and len(ranked[0][1]) == len(ranked[1][1]) else 'high')
        e['board_hits'] = [f"{bb}:{','.join(h[:3])}" for bb, h in ranked[:2]]
    # ① 聚类
    cids = cluster(pool)
    groups = defaultdict(list)
    for i, c in enumerate(cids):
        if c: groups[c].append(i)
    for i, e in enumerate(pool):
        e['cluster'] = cids[i]
    # borderline = 完全无板块命中的条目；组内冲突成员跟多数板块走（标 low→多数）
    borderline = [pool[i] for i, e in enumerate(pool) if not e['board']]
    for c, members in groups.items():
        bs = {pool[m]['board'] for m in members if pool[m]['board']}
        if len(bs) > 1:
            for m in members: pool[m]['board_conf'] = 'low'; borderline.append(pool[m])
    seen, bl2 = set(), []
    for e in borderline:
        if e['url'] not in seen: seen.add(e['url']); bl2.append(e)
    # 组内 board 投票：低置信成员跟多数板块走
    for c, members in groups.items():
        bs = [pool[m]['board'] for m in members if pool[m]['board'] and pool[m]['board_conf'] != 'low']
        if bs:
            from collections import Counter
            maj = Counter(bs).most_common(1)[0][0]
            for m in members:
                if not pool[m]['board']: pool[m]['board'] = maj; pool[m]['board_conf'] = 'low→多数'
    # ③ 按队打包（条目级派单，保留兼容）
    packs = {}
    for team, boards in TEAMS.items():
        packs[team] = [e for e in pool if e['board'] in boards]
    # ③c 簇结构（完整多队模式按簇派单：一簇一条成稿，main=主源）
    cl = build_clusters(pool, cids, outdir)
    for tm in sorted(cl):
        multi = sum(1 for r in cl[tm] if r['size'] > 1)
        print(f"  clusters_{tm}: {len(cl[tm])} 簇（多源 {multi}）")
    print(f"  簇派单素材 → clusters.md / clusters_*.json")
    # ③b/③d 正文补料：抓取单位 = 簇主源（派单单位），pack 条目按 URL 复用同一份
    enrich = {}
    for cand in (f'{outdir}/enrich.json', f'{outdir}/prep/enrich.json'):
        if os.path.exists(cand):
            try: enrich = json.load(open(cand, encoding='utf-8'))
            except Exception: enrich = {}
            break
    # 完整模式用簇主源、快速模式用 pack 全量 → 抓取集合取并集（多抓的只是同簇非主源稿，约 10 条）
    mains = []
    for tm, rows in cl.items():
        for c in rows:
            u = (c.get('main') or {}).get('url')
            if u and u not in mains:
                mains.append(u)
    if a.mode == 'full':
        want = list(mains)
    elif a.mode == 'fast':
        want = []
        for e in (e for rows in packs.values() for e in rows):
            if e.get('url') and e['url'] not in want:
                want.append(e['url'])
    else:
        want = list(mains) + [e['url'] for rows in packs.values() for e in rows
                              if e.get('url') and e['url'] not in mains]
    if not a.no_enrich and want:
        todo = [u for u in want if not enrich.get(u, {}).get('ok')]
        if todo:
            em = _enricher()
            print(f"正文补料：{len(mains)} 簇主源 / {len(want)} 条待料（模式 {a.mode}）· 待抓 {len(todo)} 条")
            t0 = time.time()
            with ThreadPoolExecutor(6) as ex:
                enrich.update(dict(ex.map(lambda u: (u, em.fetch_text(u, a.enrich_chars)), todo)))
            ok = sum(1 for u in todo if enrich.get(u, {}).get('ok'))
            print(f"  可用 {ok} · 太薄/失败 {len(todo)-ok} · {time.time()-t0:.1f}s")
            json.dump(enrich, open(f'{outdir}/enrich.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    cn = 0
    for tm, rows in cl.items():
        for c in rows:
            m = c.get('main') or {}
            r = enrich.get(m.get('url') or '')
            if r and r.get('ok'):
                m['body'] = r['text']
                cn += 1
        json.dump(rows, open(f'{outdir}/clusters_{tm}.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    if cn:
        print(f"正文节选：{cn}/{len(mains)} 簇主源带 body → clusters_*.json")
    en = 0
    for team, rows in packs.items():
        for e in rows:
            r = enrich.get(e.get('url') or '')
            if r and r.get('ok'):
                e['body'] = r['text']
                en += 1
        json.dump(rows, open(f'{outdir}/pack_{team}.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    if en:
        print(f"正文节选：{en} 条素材带 body → pack_*.json")
    # ④ 实体族（借鉴 news-ai 派单铁律：同实体跨板块整族交一人）
    fam = defaultdict(list)
    for i, e in enumerate(pool):
        t = e['title'].lower()
        for ent, kws in ENTITIES.items():
            if any(k in t for k in kws): fam[ent].append(i); break
    fam_lines = []
    for ent, members in sorted(fam.items(), key=lambda kv: -len(kv[1])):
        if len(members) < 2: continue
        boards = sorted({pool[m]['board'] or '?' for m in members})
        teams = sorted({next((tm for tm, bs in TEAMS.items() if pool[m]['board'] in bs), '?') for m in members})
        mark = ' ⚠️ 跨队整族——必须交同一队员' if len(teams) > 1 else ''
        fam_lines.append(f"{ent}  {len(members)} 条 → {'、'.join(boards)}（{'/'.join(teams)}）{mark}")
        for m in members: pool[m]['family'] = ent
    open(f'{outdir}/families.md', 'w', encoding='utf-8').write('# 实体族（派单前必看）\n\n'
        + ('\n'.join(fam_lines) if fam_lines else '（无跨条目实体）') + '\n\n'
        + '> 聚类只做提示不做决定：跨语种同事件（英文源+中文源）标题字面几乎无重叠，2-gram 认不出；'
          '真正的合并判断仍由队员在写作时做（派单模板已含「同事件多源合并」）。\n')
    json.dump({'groups': {c: [{'title': pool[i]['title'][:40], 'url': pool[i]['url'], 'src': pool[i]['src'],
                               'board': pool[i]['board']} for i in ms] for c, ms in groups.items()}},
              open(f'{outdir}/cluster.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    json.dump(bl2, open(f'{outdir}/borderline.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    # 统计
    print(f"pool {len(pool)} | 聚类组 {len(groups)}（多源候选 {sum(1 for ms in groups.values() if len(ms)>1)} 组）| 实体族 {sum(1 for l in fam_lines if '⚠️' in l)} 个跨队族 → families.md")
    print(f"borderline {len(bl2)} 条 → borderline.json（领队拍板后再派）")
    for t in sorted(packs):
        from collections import Counter
        bc = Counter(e['board'] for e in packs[t])
        print(f"  pack_{t}: {len(packs[t])} 条  {' '.join(f'{b}{n}' for b, n in sorted(bc.items()))}")

if __name__ == '__main__':
    main()
