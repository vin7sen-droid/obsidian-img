# -*- coding: utf-8 -*-
"""把基准 out.md（73 条）与四队增量 JSON 合并 → out_merged.md（板块内并入 + 全文重编号 + 重算计数）
用法: python3 merge_inc.py <base.md> <digest.txt> <T1.json> [T2.json ...]
"""
import os
import re, json, sys

BOARDS = {'一':'芯片与硬件','二':'消费电子与终端','三':'互联网与大厂动态','四':'通信与网络',
 '五':'软件、游戏与开源','六':'网络安全与数据','七':'航天、能源与前沿科学',
 '八':'生物科技与医疗硬件','九':'政策、监管与商业','十':'融资与并购'}
ORDER = ['一','二','三','四','五','六','七','八','九','十']

def parse_base(path):
    """→ {序号: [(title_line, summary, meta)]}, 以及已用 URL 集合"""
    secs = {b: [] for b in ORDER}
    cur = None; used = set()
    for ln in open(path, encoding='utf-8'):
        ln = ln.rstrip('\n')
        m = re.match(r'^## ([一二三四五六七八九十])、(.+?)（\d+ 条）\s*$', ln)
        if m:
            cur = m.group(1); continue
        if not cur: continue
        m = re.match(r'^(\d+)\. \*\*\[(.+?)\]\((https?://[^)]+)\)\*\*\s*$', ln)
        if m:
            secs[cur].append([m.group(2), m.group(3), '', ''])
            used.add(m.group(3)); continue
        if re.match(r'^\s+\S', ln) and secs[cur]:
            it = secs[cur][-1]
            if not it[2]: it[2] = ln.strip()
            elif not it[3]: it[3] = ln.strip()
    return secs, used

def main():
    base, digest_path, *jpaths = sys.argv[1:]
    secs, used = parse_base(base)
    added = []   # (board, title, url)
    for jp in jpaths:
        d = json.load(open(jp, encoding='utf-8'))
        for it in d.get('items', []):
            b = (it.get('board') or '').strip()
            url = (it.get('url') or '').strip()
            if b not in ORDER or not url.startswith('http'): 
                print('  skip bad:', it.get('title','')[:30]); continue
            if url in used:
                print('  dup url:', it['title'][:36]); continue
            srcs = '、'.join(f"[{s.get('name','?')}]({s['url']})" for s in it.get('sources', []) if s.get('url'))
            t0 = next((s.get('time') for s in it.get('sources', []) if s.get('time')), '')
            stamp = f'2026-{t0}' if t0 and not re.match(r'\d{4}-', t0) else t0
            meta = f'（{srcs}）' + (f' {stamp}' if stamp else '')
            secs[b].append([it['title'].strip(), url, it['summary'].strip(), meta])
            used.add(url); added.append((b, it['title'], url))
    total = sum(len(v) for v in secs.values())
    digest = open(digest_path, encoding='utf-8').read().strip()
    out = [f'# 今日科技新闻 {total} 条（2026-11-12，不含 AI）', '',
           '> 时间：北京时间 2026-11-12 全天为主；部分条目回溯至 11-11 傍晚', '']
    if digest: out += [digest, '']
    for b in ORDER:
        rows = secs[b]
        out.append(f'## {b}、{BOARDS[b]}（{len(rows)} 条）')
        out.append('')
        if not rows:
            out += ['（今日无）', '']; continue
        for n, (t, u, s, m) in enumerate(rows, 1):
            out.append(f'{n}. **[{t}]({u})**')
            out.append(f'   {s}')
            out.append(f'   {m}')
            out.append('')
    open(os.path.join(os.getcwd(), 'out_merged.md'), 'w', encoding='utf-8').write('\n'.join(out).rstrip() + '\n')
    print('新增', len(added), '总条数', total)
    from collections import Counter
    print(' '.join(f'{b}{len(secs[b])}' for b in ORDER))
    for b, t, u in added: print('  +', b, t[:50])

main()
