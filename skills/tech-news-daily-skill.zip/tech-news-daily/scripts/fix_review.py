# -*- coding: utf-8 -*-
"""复核修订（领队代跑 tech-review 未产出）：增量/基线跨集去重 + 摘要扩写 + 重编号
删 6 条：T2 Meta(撞基线211) / T2 微软更新连环(并入基线255) / T2 Outlook(基线208已有)
        T2 R星营销(并入基线271) / T3 N-central(基线345加源) / T3 eMudhra(基线337加源)
        T4 T-Mobile(基线495加源) / T4 欧盟诱导订阅(基线491加源) / 基线175 Meta(撞基线211)
"""
import re
LINES = open('out_merged.md', encoding='utf-8').read().split('\n')

# ---- 定位工具 ----
def find(title_key):
    """返回标题行索引（按标题片段）"""
    for i, ln in enumerate(LINES):
        if title_key in ln and re.match(r'^\d+\. \*\*\[', ln):
            return i
    raise SystemExit('not found: ' + title_key)

def replace_title(i, new_title):
    LINES[i] = re.sub(r'\]\(.*$', f']({new_title[0]})**', LINES[i]) if False else re.sub(r'^\d+\. \*\*\[(.+?)\]\(.*\)\*\*$', lambda m: f'  0. **[{new_title[0]}]({m.group(1) if False else ""})**', LINES[i])

def set_field(i, field, value):
    """i=标题行索引；field=title/summary/meta；value=新文本（不含前缀）"""
    if field == 'title':
        url = re.search(r'\]\((https?://[^)]+)\)', LINES[i]).group(1)
        LINES[i] = f'0. **[{value}]({url})**'
    else:
        j = i + (1 if field == 'summary' else 2)
        LINES[j] = ('   ' + value)

def get_meta_urls(i):
    return re.findall(r'\]\((https?://[^)]+)\)', LINES[i + 2])

def add_source(i, name, url, time):
    """在源行括号内、时间戳前插入新源；若 URL 已存在则跳过"""
    meta = LINES[i + 2]
    if url in meta: return
    m = re.match(r'^(   （(.*)）) (\d{4}-\d{2}-\d{2} \d{2}:\d{2})$', meta)
    if not m: raise SystemExit('meta 格式不认识: ' + meta[:40])
    inner = m.group(2)
    new_inner = (inner + '、' if inner else '') + f'[{name}]({url})'
    LINES[i + 2] = f'   （{new_inner}） {m.group(3)}'

def del_entry(i):
    """删标题行+后两行（共3行）+ 可能的空行"""
    del LINES[i:i + 3]
    if i < len(LINES) and LINES[i].strip() == '': del LINES[i]

# ---- 1) 删基线内部重复：Meta 两条合一 ----
i_tc = find('Meta 基础设施负责人 Santosh Janardhan 将卸任')
i_ith = find('Meta 基础设施负责人卸任：掌舵 17 年')
add_source(i_ith, 'TechCrunch', 'https://techcrunch.com/2026/11/11/meta-is-losing-its-longtime-head-of-infrastructure/', '2026-11-12 04:12')
del_entry(i_tc)
print('合并基线 Meta 双条 →', LINES[i_ith][:60])

# ---- 2) 增量撞基线条目：删增量行（增量在 JSON 里，成品里也要删）----
DEL = [       '微软承认 Windows 更新连环出问题',                        # 并入 255
       'R 星开启《GTA 6》新一轮营销',                            # 并入 271
       'N-central 曝 30 余个零日',                               # 基线 345 加源
       'eMudhra 再撤 8 张中间证书',                              # 基线 337 加源
       '纽约州要求 T-Mobile 取消',                               # 基线 495 加源
       '欧盟拟立法打击诱导订阅']                                  # 基线 491 加源
for key in DEL:
    i = find(key); del_entry(i); print('删增量/重复:', key[:36])

# ---- 3) 摘要扩写与加源 ----
i = find('微软 11 月累积更新：修复 USB 音频问题')
set_field(i, 'summary', '微软 2026 年 11 月累积更新修复 9 月安全更新以来困扰 Windows 用户的 USB 音频问题；晚间微软承认 KB5132061 在部分设备上安装失败并报错，且近几个月的 Windows 更新还会拖慢 SQL Server 性能。')
add_source(i, 'BleepingComputer', 'https://www.bleepingcomputer.com/news/microsoft/microsoft-confirms-kb5132061-installation-issues-0x80070306-0x800f0989-0x800f0993-errors/', '2026-11-12 18:24')
add_source(i, 'BleepingComputer', 'https://www.bleepingcomputer.com/news/microsoft/microsoft-recent-windows-updates-cause-sql-server-performance-issues/', '2026-11-12 20:11')
print('并入+扩写: 微软累积更新')

i = find('R 星入驻抖音')
set_field(i, 'summary', 'Rockstar Games 入驻抖音（IP 属地上海），首条视频为 11 月 19 日发售的《GTA6》宣传预载；晚间 R 星又开新账号放出罪恶城海滩与道路画面，展开新一轮营销。')
add_source(i, 'IT之家', 'https://www.ithome.com/1/026/274.htm', '2026-11-12 17:11')

for key, name, url, t in [
    ('N-able 紧急修复 N-central', 'SecurityWeek', 'https://www.securityweek.com/hackers-target-n-central-zero-days-as-n-able-rushes-patches/', '2026-11-12 17:39'),
    ('eMudhra 私钥处理不当', 'cnBeta', 'https://www.cnbeta.com.tw/articles/tech/1586030.htm', '2026-11-12 13:50'),
    ('纽约州要求 T-Mobile 停止', 'cnBeta', 'https://www.cnbeta.com.tw/articles/tech/1586072.htm', '2026-11-12 20:07'),
    ('数字公平法案》草案', 'cnBeta', 'https://www.cnbeta.com.tw/articles/tech/1586026.htm', '2026-11-12 13:48')]:
    i = find(key); add_source(i, name, url, t); print('加源:', key[:28])

# ---- 4) 全文重编号 + 重算板块计数 + 重写标题行 ----
sec_total = {}
cur = None
for i, ln in enumerate(LINES):
    m = re.match(r'^## ([一二三四五六七八九十])、', ln)
    if m:
        cur = m.group(1); sec_total[cur] = 0; continue
    m = re.match(r'^\d+\. \*\*\[', ln)
    if m and cur:
        sec_total[cur] += 1
        LINES[i] = re.sub(r'^\d+\.', f'{sec_total[cur]}.', ln)
for i, ln in enumerate(LINES):
    m = re.match(r'^## ([一二三四五六七八九十])、(.+?)（\d+ 条）', ln)
    if m:
        LINES[i] = f"## {m.group(1)}、{m.group(2)}（{sec_total[m.group(1)]} 条）"
total = sum(sec_total.values())
LINES[0] = f'# 今日科技新闻 {total} 条（2026-11-12，不含 AI）'
open('out_final.md', 'w', encoding='utf-8').write('\n'.join(LINES))
print('板块', ' '.join(f'{b}{sec_total[b]}' for b in ['一','二','三','四','五','六','七','八','九','十']), '总', total)
