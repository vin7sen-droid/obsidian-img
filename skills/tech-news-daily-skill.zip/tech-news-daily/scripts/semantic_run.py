#!/usr/bin/env python3
"""semantic_run.py — 日报线语义/文笔初筛适配器（2026-11-20，借鉴剪藏会话四层质检）。

队员中文摘要（标题+summary） vs raw 英文原文（title+desc）成对送 GLM 初筛，
补 xcheck（数字/单位）与 summary_check（数字对正文）抓不到的语义层：
译反/方向性习语（be months away）/术语错（personal intelligence）/机翻腔病句。

规则真源 = scripts/semantic_check.py（importlib 动态加载，五类判定 PROMPT）。
配对逻辑与 xcheck_run.mjs 同构（merged 优先 → review/merged → json/T*.json；
raw_<date>.json 最新 → raw.json；normUrl 配对；中文源 zhRatio≥0.25 跳过）。

用法:
  python3 semantic_run.py <workdir> [date]   # 清单落 <workdir>/semantic_人工审.md
  DSH_AI_RESEARCH_SEMANTIC=0 跳过（默认开）
退出码恒 0（清单制不阻断发布；GLM 慢，约 15 对/批 × 240s 超时/批）。
"""
import glob, importlib.util, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = "semantic_人工审.md"


def norm_url(u):
    if not u:
        return ""
    try:
        from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
        sp = urlsplit(u.strip())
        q = [(k, v) for k, v in parse_qsl(sp.query) if not re.match(r"^utm_|^ref$|^from$|^fbclid|^gclid", k, re.I)]
        return urlunsplit((sp.scheme, sp.netloc, sp.path, urlencode(q), ""))
    except Exception:
        return u.strip()


def load_semantic():
    spec = importlib.util.spec_from_file_location("semchk", os.path.join(os.path.dirname(os.path.abspath(__file__)), "semantic_check.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def jload(p):
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return None


def items_of(o):
    if isinstance(o, list):
        return o
    if isinstance(o, dict):
        for k in ("items", "merged"):
            if isinstance(o.get(k), list):
                return o[k]
        for v in o.values():
            if isinstance(v, list):
                return v
    return []


def load_items(wd):
    for rel in ("merged.json", os.path.join("review", "merged.json")):
        xs = items_of(jload(os.path.join(wd, rel)))
        if xs:
            return xs, rel
    items, seen = [], set()
    for f in sorted(glob.glob(os.path.join(wd, "json", "T*.json"))):
        for it in items_of(jload(f)):
            k = norm_url(it.get("url"))
            if k and k not in seen:
                seen.add(k)
                items.append(it)
    return items, "json/T*.json"


def raw_index(wd, date):
    """多源合并：workdir 的 raw*.json（desc 质量好）优先，digests/<date>.json 共享雷达池补盲区源。"""
    m = {}
    files = sorted(glob.glob(os.path.join(wd, "raw*.json")))
    if date:
        files.insert(0, os.path.join(wd, "raw_%s.json" % date))
    for p in files:
        raw = jload(p) or []
        for it in (raw if isinstance(raw, list) else raw.get("items", [])):
            k = norm_url(it.get("url"))
            if k and k not in m and (it.get("title") or it.get("desc")):
                m[k] = it
    # 共享雷达池（盲区源 AWS ML/The Information/FT 等的原文在这里）
    if date:
        for p in (os.path.join(os.environ.get("DSH_DIGESTS_DIR") or os.path.expanduser("~/digests"), "%s.json" % date),):
            d = jload(p) or []
            for it in (d if isinstance(d, list) else d.get("items", [])):
                k = norm_url(it.get("url"))
                if k and k not in m and it.get("title"):
                    m[k] = {"title": it.get("title", ""), "desc": it.get("summary") or it.get("desc") or "", "src": it.get("source", "")}
    return m


def zh_ratio(t):
    s = t or ""
    zh = len(re.findall(r"[\u4e00-\u9fff]", s))
    return zh / len(s) if s else 1.0


TRUNC_RE = re.compile(r"(?:\.\.\.|…|&#8230;?)\s*$")
TRUNC_TAG = "（原文摘录在此截断，未出现的细节不算臆造）"


def clean_desc(d):
    d = (d or "").strip()
    return re.sub(r"^\s*（[^（）]*转发[^（）]*）\s*", "", d).strip()


def _grams(t, n=3):
    t = re.sub(r"\s+", "", t or "").lower()
    return {t[i:i + n] for i in range(max(0, len(t) - n + 1))}


def _rel(a, b):
    A, B = _grams(a), _grams(b)
    if not A or not B:
        return 0.0
    return len(A & B) / len(A | B)


def merge_sources(it, ri, budget=1400, rel_min=0.08):
    """多源合并（2026-11-21 用户建议：只取主 URL 一条 desc 会把多源细节误判成臆造）。
    主 URL 优先，再把 sources[] 里其他源的 title+desc 接上，标注 [源名]；
    desc 高度重合（前 40 字相同）视为同稿转载跳过。返回 (en_text, n_src, any_trunc)。"""
    urls, names = [it.get("url")], [""]
    for s in (it.get("sources") or []):
        if isinstance(s, dict) and s.get("url"):
            urls.append(s["url"])
            names.append((s.get("name") or "").strip())
        elif isinstance(s, str):
            urls.append(s)
            names.append("")
    seen, parts, trunc, odd, only_t = [], [], False, 0, False
    for i, u in enumerate(urls):
        e = ri.get(norm_url(u))
        if not e:
            continue
        t = (e.get("title") or "").strip()
        d = clean_desc(e.get("desc") or e.get("summary") or "")
        key = re.sub(r"\s+", "", d)[:40]
        if key and key in seen:
            continue
        # 异源剔除：sources[] 偶尔挂错不相干文章（11-14 FAA 条挂了鱼叉邮件稿与 Razor Lake 稿），
        # 与主源（或已收任一段）几乎无字面重叠的一律不收，免得把噪音喂给质检模型。
        if parts:
            ref = " ".join(parts)
            if _rel(t + " " + d, ref) < rel_min and _rel(t, ref) < rel_min * 2:
                odd += 1
                continue
        seen.append(key)
        body = ("%s — %s" % (t, d)).strip(" —")
        if len(re.sub(r"\s+", "", d)) < 40:
            only_t = True      # HN/聚合条目常常只有标题，摘要的细节来自正文，不该判臆造
        if TRUNC_RE.search(d):
            trunc = True
        if i > 0 and names[i]:
            body = "[%s] %s" % (names[i], body)
        if len(" ".join(parts)) + len(body) > budget:
            break
        parts.append(body)
    if odd:
        print("semantic:   异源剔除 %d 段（与主源无字面重叠）" % odd)
    return " ／ ".join(parts), len(parts), trunc, only_t


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    wd = os.path.abspath(sys.argv[1])
    date = sys.argv[2] if len(sys.argv) > 2 else None
    # --label：管线名（清单标题与 LLM label）。薄转发方（科技日报线）传「科技日报」。
    label = "AI日报"
    if "--label" in sys.argv:
        i = sys.argv.index("--label")
        if i + 1 < len(sys.argv):
            label = sys.argv[i + 1]
    if os.environ.get("DSH_AI_RESEARCH_SEMANTIC") == "0":
        print("semantic: DSH_AI_RESEARCH_SEMANTIC=0，跳过")
        return
    sem = load_semantic()
    items, src = load_items(wd)
    ri = raw_index(wd, date)
    pairs, unmatched, zh_src, multi, trunc_n = [], 0, 0, 0, 0
    for it in items:
        en_main = ri.get(norm_url(it.get("url")))
        if not en_main or not (en_main.get("title") or "").strip():
            unmatched += 1
            continue
        # 语言判定只看主源（多源里有中文转载不该把英文条目判成中文源）
        if zh_ratio((en_main.get("title") or "") + " " + clean_desc(en_main.get("desc") or en_main.get("summary") or "")) >= 0.25:
            zh_src += 1
            continue
        en_text, n_src, trunc, only_t = merge_sources(it, ri)
        marks = []
        if only_t:
            marks.append("（EN 仅标题、无正文：摘要中标题之外的细节是多源/正文补充，不算臆造）")
            trunc_n += 1
        elif trunc:
            marks.append(TRUNC_TAG)
            trunc_n += 1
        if "hacker news" in json.dumps(it.get("sources") or [], ensure_ascii=False).lower():
            marks.append("（HN 聚合条目：摘要里的「HN 讨论 N 分／M 评论」「Hacker News·N分」是条目标注的社区热度元数据，非原文内容）")
        if marks:
            en_text += " " + " ".join(marks)
        if n_src > 1:
            multi += 1
        pairs.append({
            "en": en_text,
            "zh": "%s — %s" % (it.get("title") or "", it.get("summary") or ""),
            "cat": it.get("cat") or it.get("board") or "",
        })
    if not pairs:
        print("semantic: 0/%d 配对成功，跳过" % len(items))
        return
    print("semantic: %d/%d 配对（源 %s，未配对 %d，中文源 %d 跳过，多源合并 %d，截断标注 %d）· GLM 初筛中（%d 对）…" %
          (len(pairs), len(items), src, unmatched, zh_src, multi, trunc_n, len(pairs)))
    flags = sem.run(pairs, label + " 语义初筛") or []
    if not flags:
        stale = os.path.join(wd, OUT)
        if os.path.exists(stale):
            os.remove(stale)          # 清洁时清掉上一轮清单，否则旧 flagged 会被误读成本轮结果
        print("semantic: 清洁（0 flagged）")
        return
    lines = ["# %s 语义审清单（GLM 初筛，%d flagged）" % (label, len(flags)), ""]
    for f in flags:
        i = f.get("idx")
        p = pairs[i - 1] if isinstance(i, int) and 0 < i <= len(pairs) else {}
        lines.append("## #%s [%s] %s" % (i, f.get("type"), f.get("why")))
        if p:
            lines.append("- EN: %s" % p["en"][:200])
            lines.append("- ZH: %s" % p["zh"][:200])
        lines.append("")
    out = os.path.join(wd, OUT)
    open(out, "w", encoding="utf-8").write("\n".join(lines))
    print("semantic: flagged %d → %s" % (len(flags), out))


if __name__ == "__main__":
    main()
