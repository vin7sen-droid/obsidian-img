#!/usr/bin/env python3
"""publish.py —— 日报一键发布（复核产物 → md → HTML → 链接核查 → 落盘 Obsidian）

2026-11-14 建立（11-13 期「复核完了却 7 小时没落盘」的复盘结论：落盘优先，拼装五步
必须是一条命令，不允许拆成多轮对话）。

用法：
  python3 publish.py <工作目录>/d9 --date 2026-11-14
  python3 publish.py <工作目录>/d9 --date 2026-11-14 --no-linkcheck
  python3 publish.py <工作目录>/d9 --date 2026-11-14 --dry     # 只生成不落盘

输入（二选一，优先 merged）：
  <workdir>/merged.json     复核员产物，schema 同队员 JSON：{"items":[{board,title,url,summary,sources:[{name,url,time}]}]}
  <workdir>/json/T*.json    无复核产物时直接合并三/四队 JSON（按 URL 去重 + 全文重编号）
  <workdir>/digest.txt      可选，当日总结（整块原样插入，`>` 行保留；重点词用 **加粗**）

输出：
  <workdir>/final/out.md、<workdir>/final/out.html
  <OBSIDIAN_ROOT>/dsh/新闻/科技新闻_<date>_<N>条.md / .html（同日旧条数版本移入 bak 后替换）

校验（任一失败即非零退出）：条目数 = HTML <li> 数、板块数 = 10（缺板块只告警）、
空摘要 0、暗色残留 0、markdown 三空格缩进完整。
"""
import argparse, datetime, glob, json, os, re, shutil, subprocess, sys

BOARDS = {'一': '芯片与硬件', '二': '消费电子与终端', '三': '互联网与大厂动态', '四': '通信与网络',
          '五': '软件、游戏与开源', '六': '网络安全与数据', '七': '航天、能源与前沿科学',
          '八': '生物科技与医疗硬件', '九': '政策、监管与商业', '十': '融资与并购'}
ORDER = list(BOARDS)
ORDER_ALT = '|'.join(ORDER)
HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(HERE)
DIGESTS = os.environ.get("DSH_DIGESTS_DIR") or os.path.expanduser("~/digests")
NEWS_TOOLS = HERE
LINKCHECK = os.path.join(HERE, 'linkcheck.py')   # 单一真源（此前误指向工作目录副本）
OBSIDIAN_ROOT = os.environ.get("OBSIDIAN_ROOT") or ("/sdcard/Obsidian" if os.path.isdir("/sdcard/Obsidian") else os.path.expanduser("~/Obsidian"))
OBSIDIAN = os.path.join(OBSIDIAN_ROOT, 'dsh', '新闻')
BAK = os.path.join(PKG_ROOT, 'bak', 'news')


def norm_url(u):
    """统一 URL 归一，与 xcheck/summary_check 的匹配契约一致。"""
    if not u:
        return ''
    try:
        from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
        p = urlsplit(str(u).strip())
        drop = re.compile(r'^(?:utm_|ref$|from$|fbclid$|gclid$)', re.I)
        q = urlencode([(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if not drop.search(k)])
        return urlunsplit((p.scheme.lower(), p.netloc.lower(), p.path.rstrip('/') or '/', q, ''))
    except Exception:
        return str(u).strip().rstrip('/')


def _validate_sources(it):
    srcs = it.get('sources')
    if not isinstance(srcs, list) or not srcs:
        return '缺 sources'
    for s in srcs:
        if not isinstance(s, dict) or not s.get('name') or not re.match(r'^https?://\S+$', str(s.get('url') or '')):
            return 'sources 项缺 name 或合法 URL'
    return None


def load_items(workdir, year):
    """优先 merged.json；否则合并 json/T*.json（URL 去重）"""
    mp = os.path.join(workdir, 'merged.json')
    if os.path.exists(mp):
        try:
            d = json.load(open(mp, encoding='utf-8'))
        except json.JSONDecodeError as e:
            sys.exit('✗ merged.json 不是合法 JSON（第 %d 行第 %d 列：%s）——复核产物可能只写了一半，重跑那一步再发布'
                     % (e.lineno, e.colno, e.msg))
        if isinstance(d, dict):
            items = d.get('items') or d.get('merged') or next(
                (v for v in d.values() if isinstance(v, list)), [])
        elif isinstance(d, list):
            items = d
        else:
            sys.exit('✗ merged.json 顶层既不是 object 也不是 array（实际 %s）' % type(d).__name__)
        if not isinstance(items, list) or not all(isinstance(x, dict) for x in items):
            sys.exit('✗ merged.json 里的条目不是「对象数组」（items=%s）' % type(items).__name__)
        src = 'merged.json'
    else:
        frames = sorted(glob.glob(os.path.join(workdir, 'json', 'T*.json')))
        if not frames:
            sys.exit(f'✗ {workdir} 下既无 merged.json 也无 json/T*.json')
        items, seen = [], set()
        for f in frames:
            try:
                _fr = json.load(open(f, encoding='utf-8'))
            except json.JSONDecodeError as e:
                sys.exit('✗ %s 不是合法 JSON（第 %d 行：%s）' % (os.path.basename(f), e.lineno, e.msg))
            for it in (_fr if isinstance(_fr, list) else _fr.get('items', [])):
                u = norm_url(it.get('url') or '')
                if u in seen:
                    continue
                seen.add(u)
                items.append(it)
        src = f'{len(frames)} 个 json 合并'
    # 清洗 + 丢弃不合规
    out, warns = [], []
    for i, it in enumerate(items):
        b = (it.get('board') or '?').strip()
        if b not in BOARDS:
            warns.append(f'未知板块「{b}」→ 弃：{(it.get("title") or "")[:24]}')
            continue
        if not it.get('title') or not (it.get('url') or '').startswith('http'):
            warns.append(f'缺标题/URL → 弃：{(it.get("title") or "")[:24]}')
            continue
        if not (it.get('summary') or '').strip():
            warns.append(f'缺摘要 → 弃：{it["title"][:24]}')
            continue
        if not it.get('sources'):
            warns.append(f'缺 sources → 弃：{it["title"][:24]}')
            continue
        src_err = _validate_sources(it)
        if src_err:
            warns.append(f'{src_err} → 弃：{it["title"][:24]}')
            continue
        out.append(it)
    return out, src, warns


def atomic_copy(src, dst):
    """写同目录临时文件再 os.replace：/sdcard 是 FUSE，copy2 中途断会留半截文件。"""
    tmp = "%s.tmp%d" % (dst, os.getpid())
    try:
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
    finally:
        if os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass


def render_md(items, date, time_line, digest_lines):
    by = {}
    for it in items:
        by.setdefault(it['board'].strip(), []).append(it)
    total = len(items)
    L = [f'# 今日科技新闻 {total} 条（{date}，不含 AI）', '', f'> 时间：{time_line}', '']
    if digest_lines:
        L += digest_lines + ['']
    # 必看守卫（2026-11-20 加，11-16/17/19 三次重演后定）：条目摘要 ** 计数=0 → 醒目警告
    n_must = sum(1 for it in items if '**' in (it.get('summary') or ''))
    if n_must == 0:
        print('  ⚠⚠ 本期必看挑条 = 0：请挑 5-6 条（影响面×信息增量×决策有用）给摘要加 ** 后重跑；'
              '快速模式/修复轮也不许跳过（11-17 期教训）')
    # HN 条目评价性推断守卫（2026-11-20 加）：HN 挖出的条目若摘要含「引发热议/意识淡薄/缺位/争议」类评价词 → 提醒回源
    _EVAL = re.compile(r'引发.{0,6}热议|热议：|意识淡薄|保护缺位|制度缺位|遭质疑|饱受争议')
    for it in items:
        srcs = json.dumps(it.get('sources', []), ensure_ascii=False)
        if 'news.ycombinator.com' in srcs and _EVAL.search(it.get('summary') or ''):
            print(f"  ⚠ HN 条目摘要含评价性推断，合并前应回源原帖（SKILL 2.9）：{it.get('title','')[:30]}")
    # 摘要尾括注清理（2026-11-20 加）：尾部「（... 11-19 03:07）」式括注与来源行重复，自动剥
    _tail = re.compile(r'（[^（）]{2,24}\s*\d{2}-\d{2}\s+\d{1,2}:\d{2}\s*）\s*$')
    for it in items:
        sm = it.get('summary')
        if sm and _tail.search(sm):
            it['summary'] = _tail.sub('', sm).rstrip()
            print(f"  ⚠ 摘要尾括注已剥：{it.get('title','')[:30]}")
    for b in ORDER:
        rows = by.get(b)
        if not rows:
            continue
        # 排序（2026-11-17 用户定）：必看（摘要含 **）头位 → HN 高分条目按分数降序 → 其余原顺序
        def _hn_pts(it):
            m = re.search(r'Hacker News·(\d+)分', json.dumps(it.get('sources', []), ensure_ascii=False))
            return int(m.group(1)) if m else 0
        rows = sorted(rows, key=lambda it: (0, 0) if '**' in (it.get('summary') or '') else
                      ((1, -_hn_pts(it)) if _hn_pts(it) else (2, 0)))
        L += [f'## {b}、{BOARDS[b]}（{len(rows)} 条）', '']
        for n, it in enumerate(rows, 1):
            srcs = '、'.join(f"[{s.get('name','?')}]({s['url']})" for s in it['sources'] if s.get('url'))
            t0 = next((s.get('time') for s in it['sources'] if s.get('time')), '')
            stamp = (f'{date[:4]}-{t0}' if t0 and not re.match(r'\d{4}-', t0) else t0)
            tail = f'（{srcs}）' + (f' {stamp}' if stamp else '')
            L += [f'{n}. **[{it["title"].strip()}]({it["url"].strip()})**',
                  f'   {it["summary"].strip()}', f'   {tail}', '']
    return '\n'.join(L).rstrip() + '\n'


def read_digest(workdir, date=None):
    """digest 真源 = 同日已发 Obsidian md 的「当日总结」块（旧标题「当日风向小结」仍可读）（增量发布时继承最新人工维护版）；
    找不到已发版才回落 workdir/digest.txt。2026-11-16 定：防旧 digest.txt 与已发 md 脱节。"""
    if date:
        import glob as _g
        prev = sorted(_g.glob(f'{OBSIDIAN}/科技新闻_{date}_*.md'))
        if prev:
            out, on = [], False
            for l in open(prev[-1], encoding='utf-8').read().splitlines():
                s = l.rstrip()
                if '当日总结' in s or '当日风向小结' in s:
                    on = True
                    out.append(s if s.startswith('>') else '> ' + s)
                    continue
                if on:
                    if s.startswith('>'):
                        out.append(s)
                    else:
                        break
            if out:
                # 读旧标题、写新标题：继承时把标题行统一成「当日总结」
                for i, l in enumerate(out):
                    if '当日风向小结' in l:
                        out[i] = '> **当日总结**'
                        break
                print(f'  digest：从已发 md 继承小结 {len(out)} 行（{os.path.basename(prev[-1])}）')
                print('  ⚠ 增补期提醒：请检查小结是否需要按新增条目改写（新主线→改写，零星补条→沿用）')
                return out
    p = os.path.join(workdir, 'digest.txt')
    if not os.path.exists(p):
        return []
    lines = [l.rstrip() for l in open(p, encoding='utf-8').read().splitlines() if l.strip()]
    has_head = any(('当日总结' in l or '当日风向小结' in l) for l in lines)
    if not has_head:
        lines = ['> **当日总结**', '>'] + lines
    return lines


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('workdir')
    ap.add_argument('--date', required=True, help='YYYY-MM-DD')
    ap.add_argument('--time-line', default=None)
    ap.add_argument('--no-linkcheck', action='store_true')
    ap.add_argument('--dry', action='store_true', help='只生成 final/out.*，不落盘 Obsidian')
    ap.add_argument('--no-digest', action='store_true', help='明确允许本次不生成当日总结')
    a = ap.parse_args()
    workdir = os.path.abspath(a.workdir)
    date = a.date
    time_line = a.time_line or f'北京时间 {date} 全天为主；部分条目回溯至前一日傍晚'

    items, src, warns = load_items(workdir, date[:4])
    if not items:
        sys.exit('✗ 无可用条目')
    for w in warns:
        print(f'  ⚠ {w}')
    if warns:   # 丢弃清单落盘（2026-11-17）：事后能追溯「这批为什么丢」
        os.makedirs(os.path.join(workdir, 'final'), exist_ok=True)
        with open(os.path.join(workdir, 'final', 'dropped.md'), 'w', encoding='utf-8') as _f:
            _f.write('# 本轮丢弃清单（%d 条）\n\n' % len(warns)
                     + ''.join('- ' + w + '\n' for w in warns))

    digest = read_digest(workdir, a.date)
    if not digest and not a.no_digest:
        sys.exit('✗ 缺少当日总结：请写 digest.txt，或明确使用 --no-digest')
    if not digest:
        print('  ⚠ 已用 --no-digest 明确跳过当日总结')
    status_path = os.path.join(workdir, 'fetch_status.json')
    if os.path.exists(status_path):
        try:
            st = json.load(open(status_path, encoding='utf-8'))
            if st.get('degraded'):
                print('  ⚠ 抓取降级：失败源=%s coverage_warn=%s' % (','.join(st.get('failed_sources', [])) or '无', st.get('coverage_warn')))
        except Exception as e:
            print('  ⚠ fetch_status.json 读取失败：%s' % e)
    pool_files = glob.glob(os.path.join(workdir, 'pool_*.json'))
    if pool_files:
        try:
            pool_n = len(json.load(open(sorted(pool_files)[-1], encoding='utf-8')))
            if pool_n >= 20 and len(items) / pool_n >= 0.85:
                print('  ⚠ 极速模式护栏：merged 条目占 pool %.0f%%，疑似未充分筛选（%d/%d）' % (len(items) / pool_n * 100, len(items), pool_n))
            if len(items) >= 20 and len({it.get('board') for it in items}) == 1:
                print('  ⚠ 极速模式护栏：全部条目归入同一板块，请人工确认')
        except Exception as e:
            print('  ⚠ pool 筛选护栏跳过：%s' % e)

    md = render_md(items, date, time_line, digest)
    final = os.path.join(workdir, 'final')
    os.makedirs(final, exist_ok=True)
    out_md = os.path.join(final, 'out.md')
    open(out_md, 'w', encoding='utf-8').write(md)

    n_items = len(re.findall(r'^\d+\. \*\*.', md, re.M))   # 带链接/无链接条目都算
    boards = re.findall(r'^## (.+?)（\d+ 条）$', md, re.M)
    print(f'[1/5] 拼装：{src} → {n_items} 条 / {len(boards)} 板块')
    missing = [b for b in ORDER if b not in md]
    if missing:
        print(f'  ⚠ 缺板块：{"".join(missing)}（当日无料属正常，勿凑数）')
    if n_items != len(items):
        sys.exit(f'✗ 条目数不符：渲染 {n_items} ≠ 输入 {len(items)}')

    # HTML：mkhtml_sticky.py 显式传参（打包版不写技能目录，产物只落 <workdir>/final/）
    out_html = os.path.join(final, 'out.html')
    r = subprocess.run([sys.executable, os.path.join(NEWS_TOOLS, 'mkhtml_sticky.py'),
                        out_md, out_html], capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(f'✗ mkhtml_sticky.py 失败：\n{r.stderr[-800:]}')
    h = open(out_html, encoding='utf-8').read()
    n_li = len(re.findall(r'<li', h))
    empty = len(re.findall(r"<div class=['\"]s['\"]>\s*</div>", h))   # 允许中间有空白
    dark = h.count('#0f1115') + h.count('#171a21')
    # 渲染器已统一到 tools/mdhtml.py：class 用单引号、摘要加粗用 <strong>（digest 首行仍是 <b>），
    # 校验必须两种引号、两种加粗标签都认，否则会误报 digest=0 / b=1
    print(f'[2/5] HTML：li={n_li} h2={len(re.findall(r"<h2", h))} '
          f'nav={len(re.findall(chr(39) + "nav" + chr(39) + "|" + chr(34) + "nav" + chr(34), h))} '
          f'digest={len(re.findall(chr(39) + "digest" + chr(39) + "|" + chr(34) + "digest" + chr(34), h))} '
          f'b={len(re.findall("<b>|<strong>", h))}')
    if n_li != n_items:
        sys.exit(f'✗ HTML li {n_li} ≠ md 条目 {n_items}')
    if empty:
        sys.exit(f'✗ 空摘要 {empty} 处（摘要行 3 空格缩进被剥或缺正文）')
    if dark:
        sys.exit(f'✗ 暗色残留 {dark} 处')
    _dm = re.search(r'class=[\x27"]digest[\x27"]([\s\S]*?)</blockquote>', h)
    if digest and not (_dm and re.search(r"<strong>", _dm.group(1))):
        print('  ⚠ digest 已插入但小结段内没有加粗（**…**）：确认是否故意不加')

    # 链接核查（增量模式：同日旧版存在时只查新增 URL）
    if a.no_linkcheck:
        print('[3/5] 链接核查：跳过（--no-linkcheck）')
    else:
        chk_md = out_md
        import glob as _g
        old_files = [p for p in _g.glob(f'{OBSIDIAN}/科技新闻_{a.date}_*.md') if os.path.abspath(p) != os.path.abspath(out_md)]
        if old_files:
            old_urls = set(re.findall(r'\((https?://[^)]+)\)', open(sorted(old_files)[-1]).read()))
            new_urls = set(re.findall(r'\((https?://[^)]+)\)', open(out_md).read()))
            delta = new_urls - old_urls
            if new_urls and len(delta) < len(new_urls):
                sub = os.path.join(workdir, 'final', '.linkcheck_subset.md')
                with open(sub, 'w') as f:
                    for ln in open(out_md):
                        if any(u in ln for u in delta):
                            f.write(ln)
                chk_md = sub
                print(f'[3/5] 链接核查：增量模式（同日旧版 {len(old_urls)} 链，只查新增 {len(delta)}）')
        try:
            r = subprocess.run([sys.executable, LINKCHECK, chk_md], capture_output=True, text=True, timeout=900)
            tail = (r.stdout or '') + (r.stderr or '')
        except subprocess.TimeoutExpired:
            print('[3/5] 链接核查：⚠ 超时 900s，跳过（产物在 %s，可待网络好后重跑 --no-linkcheck 外）' % os.path.join(workdir, 'final'))
            tail = ''
        # 死链判定读汇总计数 + DEAD 行；不能用 \b404\b 匹配（汇总行「需处理(404/超时): 0」自身会命中）
        m_cnt = re.search(r'需处理\(404/超时\):\s*(\d+)', tail)
        dead = [l for l in tail.splitlines() if l.strip().startswith('DEAD')] \
            if (m_cnt and int(m_cnt.group(1)) > 0) else []
        print(f'[3/5] 链接核查：{tail.strip().splitlines()[-1] if tail.strip() else "无输出"}')
        if dead:
            for l in dead[:10]:
                print(f'  ✗ 死链 {l.strip()}')
            sys.exit('✗ 存在 404/410 死链，换源或删条后重跑（Phoronix/Bloomberg 403 属正常）')

    # 发布质量报告：两道检查均为清单制，不因 flagged 自动阻断发布。
    quality = []
    for label, cmd in (
        ('summary_check', [sys.executable, os.path.join(HERE, 'summary_check.py'), workdir, date]),
        ('xcheck', ['node', os.path.join(HERE, 'xcheck_run.mjs'), workdir, date]),
    ):
        try:
            qr = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
            qout = (qr.stdout or '') + (qr.stderr or '')
            last = qout.strip().splitlines()[-1] if qout.strip() else '无输出'
            quality.append('%s: %s' % (label, last))
        except subprocess.TimeoutExpired:
            quality.append('%s: 超时，清单待单独重跑' % label)
        except Exception as e:
            quality.append('%s: 执行失败（%s）' % (label, e))
    for q in quality:
        print('  质量报告：' + q)
    with open(os.path.join(final, 'quality_report.txt'), 'w', encoding='utf-8') as qf:
        qf.write('\n'.join(quality) + '\n')

    if a.dry:
        print(f'[4/5] --dry：跳过落盘。产物 {out_md} / {out_html}')
        return

    # 落盘事务：先在目标目录写入并校验临时文件，再归档旧版并原子替换。
    os.makedirs(OBSIDIAN, exist_ok=True)
    os.makedirs(BAK, exist_ok=True)
    stem = f'科技新闻_{date}_'
    md_dst = os.path.join(OBSIDIAN, f'{stem}{n_items}条.md')
    html_dst = os.path.join(OBSIDIAN, f'{stem}{n_items}条.html')
    md_tmp = md_dst + f'.pending.{os.getpid()}'
    html_tmp = html_dst + f'.pending.{os.getpid()}'
    try:
        shutil.copy2(out_md, md_tmp)
        shutil.copy2(out_html, html_tmp)
        if os.path.getsize(md_tmp) != os.path.getsize(out_md) or os.path.getsize(html_tmp) != os.path.getsize(out_html):
            raise OSError('临时产物大小校验失败')
        # 临时文件已成功写入，才处理旧版；旧版均保留副本。
        stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
        _keep = (os.path.basename(md_dst), os.path.basename(html_dst))
        moved = []
        try:
            for p in sorted(glob.glob(os.path.join(OBSIDIAN, stem + '*'))):
                name = os.path.basename(p)
                if '.pending.' in name:
                    continue
                if name in _keep:
                    shutil.copy2(p, os.path.join(BAK, name + '.' + stamp))
                    print(f'[4/5] 旧版已备份到 bak：{name}')
                else:
                    target = os.path.join(BAK, name + '.' + stamp)
                    shutil.move(p, target)
                    moved.append((target, p))
                    print(f'[4/5] 旧条数版本移入 bak：{name}')
            os.replace(md_tmp, md_dst)
            os.replace(html_tmp, html_dst)
        except Exception:
            for target, original in reversed(moved):
                if os.path.exists(target) and not os.path.exists(original):
                    shutil.move(target, original)
            raise
    finally:
        for p in (md_tmp, html_tmp):
            if os.path.exists(p):
                try: os.unlink(p)
                except OSError: pass
    print(f'[4/5] 落盘：{md_dst} ({os.path.getsize(md_dst)}B) / {html_dst} ({os.path.getsize(html_dst)}B)')

    dist = dict(re.findall(rf'^## ({ORDER_ALT})、.*（(\d+) 条）$', md, re.M))
    print('[5/5] 完成：' + ' '.join(f'{b}{dist.get(b, 0)}' for b in ORDER) + f' = {n_items} 条')


if __name__ == '__main__':
    main()