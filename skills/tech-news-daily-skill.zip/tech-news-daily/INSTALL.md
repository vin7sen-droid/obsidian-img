# tech-news-daily 技能包

每期非 AI 科技新闻日报的完整流水线：17 源抓取→分类/聚簇→（三队编辑或领队一人）→复核→三道机检（xcheck 译文校验 / summary_check 摘要数字 / semantic_check 语义初筛）→一键发布（md + 浅色 HTML + 链接核查 + 落 Obsidian）。任何识别 SKILL.md（Agent Skills 格式）的 AI 软件都能安装。

## 包内容
- SKILL.md —— 完整 SOP（抓取/派单/复核/机检/发布/增量补量/已发修正），含各源踩坑记录
- scripts/ —— 25 个脚本（抓取、聚簇、发布、机检、翻译与渲染），路径已自适应
- INSTALL.md —— 本文件

## 安装
| 软件 | 安装位置 |
|---|---|
| DSH（本包来源） | ~/.agents/skills/tech-news-daily/ |
| Claude Code | ~/.claude/skills/tech-news-daily/（或项目 .claude/skills/） |
| OpenClaw / OpenCode 等 | 各自的 skills 目录下建 tech-news-daily/，放入包内全部文件 |

## 环境要求
- python3 ≥3.10 + node ≥18（xcheck/翻译走 node）
- pip 依赖：`feedparser`（抓 RSS 必需）、`playwright`（可选，仅正文回源/JS 页面用）
- 发布落点：`<OBSIDIAN_ROOT>/dsh/新闻/`（OBSIDIAN_ROOT 默认 /sdcard/Obsidian，否则 ~/Obsidian）

## 一键跑通（极速模式，单人 3-5 分钟）
```bash
cd <技能目录>/scripts
python3 daily_fetch.py 2026-11-21 --src ithome,cnbeta,solidot,mydrivers,readhub,techradar --out <工作目录>
python3 pipeline_split.py <工作目录>/pool_2026-11-21.json --no-enrich
#   领队按板块从 pack_*.json 拣条，写 <工作目录>/merged.json
python3 semantic_run.py <工作目录> 2026-11-21
python3 publish.py <工作目录> --date 2026-11-21
```

## 凭据与环境变量（全部可选，缺了自动降级）
| 项 | 位置 | 用途 | 缺失时 |
|---|---|---|---|
| 代理 | http_proxy/https_proxy | cnBeta/Engadget/Bleeping 反爬 | 这几个源 403/空，其余正常 |
| GLM 凭据 | ~/.config/tagllm/{key,base} | semantic_check 语义初筛 | 跳过该道机检 |
| 翻译缓存 | ~/.dsh-ai-research/ | 机翻结果复用 | 每次真请求（慢但可用） |
| OBSIDIAN_ROOT | 环境变量 | 发布落点根目录 | 自动探测 /sdcard/Obsidian 或 ~/Obsidian |
| DSH_DIGESTS_DIR | 环境变量 | 机检清单目录 | ~/digests |
| PS_SANS / DS_SANS | 环境变量 | 内嵌 GoogleSans 字体 | 未启用/无字体 → 系统字体 |

## 降级差异
- **三队并行编辑 + 复核员**是 DSH 多代理特性：其他软件里改为「领队一人全流程」（SKILL 第 3 节极速模式），或由主代理依次扮三队角色写 JSON。
- HN 数据源走 `hn.algolia.com` 直连（匿名免 key），无需代理。
- 正文回源（HN 条目核实事实）优先 urllib 抓 og:description；装 playwright 才能过 403/JS 页，没装就换其他来源。
- 无 Obsidian 也能用：把 `OBSIDIAN_ROOT` 指向任意目录，产物仍是 md + html。

## 更新
本包是工作区 news-tools/ + tools/ + news-ai/ 真源的导出物；真源改动后需重新打包。
