---
name: tech-news-daily
description: 每日非 AI 科技新闻日报全流程 SOP——16 源抓取→4 队并行编辑→拼装→当日总结→浅色 HTML→链接核查→落盘 Obsidian。定时任务「每日非 AI 科技新闻抓取归档」或用户说「抓取/出今天的科技日报」时用。
---

## 路径与可移植性（打包版）

- `scripts/` 下所有路径相对**本技能目录**：命令示例里的 `scripts/publish.py` 即本技能目录下 scripts/publish.py；需要 `cd` 进去跑的命令写 `<技能目录>/scripts`。
- **工作目录**（每期产物，替代原工作区 dN/ 目录）：任意可写目录，下文用 `<工作目录>` 表示，例如 `~/tech-daily/d<MM-DD>`。
- 发布落点 = `$OBSIDIAN_ROOT/dsh/新闻/科技新闻_<date>_<N>条.{md,html}`；`OBSIDIAN_ROOT` = 环境变量优先，否则有 `/sdcard/Obsidian`（Android）用之，否则 `~/Obsidian`。同日旧备份落 `<技能目录>/bak/news/`。
- 机检清单落 `~/digests/`（可用环境变量 `DSH_DIGESTS_DIR` 覆盖）。
- 代理是**可选**：设 `http_proxy/https_proxy` 后 cnBeta/Engadget/BleepingComputer 更稳；不设代理时这几个源可能 403/空 feed，其余源正常。
- HTML 字体（GoogleSans）属 Google 专有字体、**不随包分发**，缺失自动回落系统字体，版式不受影响。
- 多代理编排（三队编辑、复核员）是 DSH 特性：其他软件里由主代理按同一 SOP 自己做（极速模式的「领队一人全流程」本来就是单人可跑）。

# 每日非 AI 科技新闻日报 SOP

范围硬规则：只收非 AI 科技新闻（大模型/生成式 AI/AI Agent 为主体的不收，顺带提一句的可收但不展开）；**汽车与出行一律不收，例外：特斯拉及旗下车型可收（用户 2026-11-19 确认）**；判断口径看新闻**主体**。不编造，每条可追溯来源；凑不满 100 条就如实写实际条数。

## 0. 资产清单（全部现成，勿重写）
- 抓取+过滤管线：`scripts/daily_fetch.py`（`python3 daily_fetch.py YYYY-MM-DD --out <工作目录>/dN` → raw_<date>.json + pool_<date>.json；17 源 = 15 RSS2.0 + verge atom + techmeme + readhub API + hndaily）
- HN 每日榜（2026-11-17 借鉴 tech-digest 加）：`https://www.daemonology.net/hn-daily/index.rss`，每天 1 个 item、description HTML 里当日 top10 storylink（解析=parse_hndaily，feedparser+`class="storylink"><a href=…>` 正则，与 tech-digest 配方一致）；**间歇限流**（对数据中心 IP 时通时断，全节点一样），fetch 已内置 5 次退避重试、全败返回空不阻塞管线；走 mihomo 代理（PROXY_SRCS 含 hndaily）。
- HN 补量主通道（2026-11-17 借鉴 AI 日报 hn.py 定）：`python3 scripts/hn_algolia.py --date YYYY-MM-DD --min-points 100 --zh --list-ai`——**必带 --zh**；**合并进 merged.json 前必跑 --list-ai 看一遍 is_ai 清单**（2026-11-20 定：11-19 期 3 条 AI 漏网 Genie 4/DaisyRose-27B/微软新模型全是补量条目；清单只提示不自动滤，Nvidia 商业新闻会误标，人工判）。养表纪律：每轮发现 AI 漏网词回写 tools/hn.py 的 AI_RE 词表（2026-11-19 用户定「标题和摘要都要中文」：真源 hn.py 内置机翻打底，title+desc 经 zh.mjs 译中，缓存命中秒回、失败兜底原文不阻塞；机翻有硬伤（如 Neon→氖、canary→预警信号），高票条目入 merged.json 前领队人工过一遍修正）——HN Algolia API 直连（匿名免 key、直连可用无需代理、几秒、稳定），输出统一条目 JSON（src=hackernews，is_ai 已标）；`--dir <workdir>` 合并进 raw.json（按 URL 去重），`--desc` 抓原文 og:description 打底，`--window` 回溯窗口默认 86400（高票常是旧文复活/跨日帖，发帖时间窗口）。daemonology hndaily 源降级为「有就用、没有不等」的兜底。（真源=scripts/hn.py，与 AI 日报线共用单一真源；news-tools/hn_algolia.py 是薄转发层，自动补 --ai tag 保持科技线全量+打标行为，勿迭代）
- HN 补量条目显眼规则（2026-11-17 用户定）：凡 HN/Algolia 挖出的条目，sources 里必须补一条 `{name:"Hacker News·<当前分>分", url:"https://news.ycombinator.com/item?id=<objectID>", time:<HN 帖北京时间>}`（HN 讨论页=HN 的原始来源，还多一个可点入口）；mkhtml_sticky.py 渲染端自动把来源名以 Hacker News 开头的渲染成橙色胶囊徽标（#ff6600），md 里文字直接可见。注意 Algolia 每页默认 20（hn.py 已按 200/页自动翻页拉满 nbHits，2026-11-17 前写死 60 且只取一页会静默截断，实测 7 天窗口真值 330 只回 60）；条目 URL 用 hits 的原始 url 字段（截断 URL 会 404，实例：apnews 银行宕机条曾缺 truist-50fee2 尾巴）。
- HTML 生成：`scripts/mkhtml_sticky.py`（读当前目录 out.md → out.html，**必须 cd 到 news-tools 跑**，它用相对路径）
- 链接核查：`scripts/linkcheck.py`（`python3 linkcheck.py out.md [sample]`，并发 12）
- 派单前预处理：`scripts/pipeline_split.py`（事件聚类 + 板块预分类 → pack_A-D.json + cluster.json + borderline.json）
- 队员自校验：`scripts/check_parts.py`（parts 格式校验，exit 0 才算交付）
- JSON→md 转换：`scripts/json2techmd.py`（队员 json/T*.json → parts/A-D.md，版式全脚本生成；借鉴 news-ai JSON 模式 2026-11-12）
- **一键发布：`scripts/publish.py、draft_summary.py（中文源摘要自动打底，快速模式挑条时用；**真源 scripts/draft_summary.py 已进 gh_sync 白名单，news-tools/ 下是薄转发层——改代码只改 tools 真源**）；daily_fetch.py 加 --src 快源模式（--src ithome,cnbeta,solidot,mydrivers,readhub,techradar 逗号分隔，只抓指定源，cnbeta 自动走 mihomo 7890；晚间增量约 11s vs 全量 150s）`**（拼装+digest+HTML+核查+落盘一条命令，见第 3 节；旧的多脚本分步做法已废弃）
- 落盘目录：`$OBSIDIAN_ROOT/dsh/新闻/`，命名 `科技新闻_YYYY-MM-DD_<N>条.md` + 同名 `.html`
- 可选补充通道（借鉴 news-ai 2026-11-13）：①雷达盲区源——ai_news_radar 的 28 个我们没有的源（Bloomberg/WSJ/NYT/FT/IEEE Spectrum/The Register/ZDNet/少数派/极客公园/智东西/钛媒体/新浪科技等），`--only` 限源不重复抓；②Google News 跳转链解码 `scripts/gnews_url.py`（全局可用，两步法解 `news.google.com/rss/articles/…` 新格式，`--theme`/`--match` 按主题关键词抽样，workers 2~3 稳，单条 5-12s，40 条 workers=6 → 97% 但 100 条只 57%）。十板块融资并购这类薄弱板块可按需补捞；解出的链接同样过时间窗+与池去重再进 raw（via=radar-gnews）；共享缓存 `~/digests/<今天>.json` 4 小时内直接复用
- 样例 md **三行式**条目见最近一期日报（$OBSIDIAN_ROOT/dsh/新闻/）：标题行 / 缩进 3 空格摘要行 / 缩进 3 空格源行 `（[源1](url)、[源2](url)） YYYY-MM-DD HH:MM`（源名带链接顿号分隔，时间只取主源、放括号外、带年份；2026-11-12 定版）

## 1. 抓取（daily_fetch.py 一键）
1. **先挂代理再抓**（2026-11-16 定，硬规则）：`bash ~/opt/mihomo/keepalive.sh（可选，见 INSTALL）` 起 mihomo（127.0.0.1:7890），然后 `http_proxy=http://127.0.0.1:7890 https_proxy=http://127.0.0.1:7890 python3 daily_fetch.py <date> --out <工作目录>/d<N>`——cnBeta（`backend.php`）、Engadget、BleepingComputer 直连已不可靠（403/空 feed），挂代理全部正常；不要花时间做「直连 vs 代理」对照实测，默认代理。
2. `mkdir -p <工作目录>/d<N>/parts` 后跑上一条命令即可
2. 产出的 pool 已做：时间窗（前一日 18:00 起）、AI/汽车/导购正则、vs 最近两期日报去重（URL+标题前 14 字）、池内标题前 18 字去重。coverage 反向校验（防源静默失效）：daily_fetch.py 落 raw 后自动与上一期 raw 对比——单源骤降 ≥50% 或总数骤降 ≥30% 打 WARN（cnbeta RSS 曾静默失效 150→2，靠此兜住）。导购/科普诱饵正则已并入 JUNK（buying guide/roundup/hands-on/black friday/explained/everything you need to know/worth buying/how to choose 等；`review` 一词不加，防误杀 EU review 类新闻）。
3. **人工扫一遍 pool**：正则拦不住的垃圾（餐饮/教育/纯导购/答题提示类）手动删；readhub 条目按「独立事件」合并视角看，同话题多源留代表。

已知源特性（踩坑记录，改动前先读）：
- solidot 的 `<link><![CDATA[url]]></link>`——正则已容忍 CDATA，勿改回。
- techmeme 的 item.link 是站内锚点，原文在 description 第一个外部 `<A HREF>`，来源名取 title 尾括号。
- readhub：`topic/daily?date=` → 每日 14 话题 → `topic/detail?uid=` → `{"data":{items:[…newsAggList]}}`；同事件多源同质报道极多，单日非 AI 合格通常只 5-6 个事件。
- verge 是 atom（entry/link@href/published）；快科技镜像 anyfeeder 仅 5 条、pubDate 已是北京时间。
- IT之家 pubDate 是 GMT 需 +8（脚本已处理）；Phoronix 对一切 UA 403 属正常，勿改。
- node 子进程输出偶含非法 UTF-8：必须 stdout 落文件再 `decode(errors="replace")`，`text=True` 会在 128KB 边界抛 UnicodeDecodeError（借鉴 news-ai 2026-11-13；调 zh.mjs/翻译通道时适用）。
- 环境无 curl，脚本用 python3 urllib+gzip；**不要用 web_fetch**（本机 provider 歧义会报错）。

## 1.5 派单前预处理（pipeline_split.py，先聚类再派单）
1. `python3 scripts/pipeline_split.py <pool>.json` → 各队素材（每队两套：`clusters_{A,B,CD}.json` 簇结构＝主派单单位，一簇一条成稿、main=主源；`pack_*.json` 条目级，保留兼容）+ cluster.json + borderline.json + families.md。
   **正文补料内置（2026-11-17 定；单一真源 `scripts/enrich.py`，与 AI 日报共用）**：抓正文节选（去站点样板、取 900 字）写进素材，两种派单模式都覆盖——
   · **完整模式（簇结构派单）** → `clusters_*.json` 的 `main.body`（一簇一条成稿，只给主源补料即可）
   · **快速模式（扁平 pack 派单）** → `pack_*.json` 每条条目的 `body`
   · `--mode auto`（默认）抓两者并集，`--mode full` / `--mode fast` 只抓对应模式；`--no-enrich` 关闭、`--enrich-chars N` 调长度；同目录已有 `enrich.json` 直接复用缓存。
   实测 11-17 期（auto，77 条）：**54 条拿到 body（70%）**、簇主源 50/68、约 1 分钟；收益最大的是 main.desc 为空的簇（readhub/CNBC 源常空，样例：desc 空 → body 641 字）。desc 的站点 HTML 标签也在本步剥成纯文本。
2. **领队只审 borderline**：真边角料（评测/导购/娱乐/慈善/汽车）直接删，能判的从 borderline 挑回 pack（脚本里有组内板块投票兜底）。
3. **派单铁律：同实体整族交同一队员**——派单前必看 `families.md`：同公司/人物跨板块跨队的条目（如「苹果 18 条 → 三、二、六（A/B/C）⚠️」）必须整族给一个队员写，别按板块切给不同队（否则拼装时同事件去重会白写四分之一）。聚类组（cluster.json）同理整组交一人。
4. **聚类只做提示不做决定**：跨语种同事件（英文源+中文源）标题字面几乎无重叠，2-gram 认不出——真正的合并判断仍由队员写作时做（派单模板已含「同事件多源合并」），领队拼装时仍要扫一遍跨队重复。
5. 词表（KW/OVERRIDE/ENTITIES）在脚本顶部，判错的条目优先补词而不是人工搬——补一次长期生效。

- 可选提速（2026-11-16 借鉴 news-ai「机翻打底全上」）：派单前可对英文素材批量预翻——把 pack 里的英文 title+desc 喂 zh.mjs（缓存命中秒回，180s 超时降级英文原文），把「摘要素材（机翻打底，先校再压缩）+原文」两行附进派单条目；中文源（zh 比例 ≥0.25 或 desc<60 字）不送翻、直接 desc 打底。队员以译文打底校数字/人名/语序后压缩到 40-120 字。

## 2. 三队并行编辑（持久队员优先；队员输出 JSON，不写 markdown）
优先用持久队员（spawn_teammate，会话内跨期复用、可 interrupt_agent 中断、可 send_message 续任务/补捞）；无持久队员时退回一次性 subagent。首次创建给完整 SOP 提示词，之后每期派单只发素材路径+输出路径+当日板块分配（规则队员已知）。
每队提示词必须自包含（队员看不到会话）：
- A=一 芯片与硬件 + 二 消费电子与终端；B=三 互联网与大厂 + 四 通信与网络 + 五 软件游戏开源；CD=六 网络安全与数据 + 七 航天能源前沿科学 + 八 生物科技医疗硬件 + 九 政策监管商业 + 十 融资并购（2026-11-12 用户定：C/D 两队任务轻，合并为 tech-cd 一队；原 11-12 的「二↔八」调换随之撤销，「二」回归 A）
- **输入：簇结构 `clusters_{A,B,CD}.json`（2026-11-17 用户定，完整多队模式按簇派单）**——数组，每项 `{cluster_id, board, size, main:{src,srcname,title,url,date,desc}, sources:[...]}`；`main` 是自动选出的主源（聚合源 readhub/techmeme 已降权排除，按 desc 信息量+源权威度打分），`sources` 含同事件全部来源（第 1 条即主源）。人读视图 `clusters.md`。旧的 `pack_{A,B,CD}.json`（扁平、一条素材一篇）仍会生成，供对照/兜底。
- **簇派单三条硬规则（写进队员提示词）**：①**一簇 = 一条成稿**，同簇不要拆成多条、也不要把不同簇并成一条；②**只写 `main` 能落到的事实**，其余 `sources` **只补链接、不补事实**（11-12 期把 Megaspeed 创始人回北京并进婚外情条目就是这么错的）；③`size=1` 的簇占多数，仍需自己判断是否漏并——**聚类宁拆勿并**（跨语种同事件、单主体快讯 vs 双主体协议 都会被拆开），遇到明显同事件的多条单独簇，按「同事件多源合并」自行合并。
- **输出：`<工作目录>/dN/json/T{1..3}.json`（严格 JSON；T1→A 队、T2→B 队、T3→CD 队）**，schema：
  `{"items":[{"board":"一","title":"中文标题≤45字","url":"主源URL原样","summary":"30–80字含具体数字","sources":[{"name":"IT之家","url":"...","time":"11-12 08:47"}]}],"dropped":[{"title":"...","reason":"..."}]}`
- 队员只做内容判断（挑条/译中/同组多源合并/写摘要），**版式一律不碰**——分节标题/缩进/编号/来源括注全由 json2techmd.py 生成（news-ai A/B 实测：md 版 100% 格式返工 174s vs JSON 0 返工 70s）
- 中文源 desc 打底（2026-11-16 借鉴 AI 日报会话折中方案，省约 1/3 写作时间）：**中文源**（IT之家/cnBeta/快科技/虎嗅等）的条目不必从零写摘要——以 RSS desc 为底稿，**校对数字与事实一致 + 压缩到 40–120 字**即可；**英文源**照旧精编（译中+重写）。质量损失很小，desc 本就是媒体编辑摘要。
- **URL 纪律（2026-11-16 强化，tech-cd2 实测编造 2 条后定）**：`url` 与 `sources[].url` 一律**原样复制自素材池条目**（pack_*.json / pool_*.json），禁止手打、拼接、改 slug、改年份栏目；主 URL 用哪条素材就与该素材完全一致。领队发布前用 linkcheck 兜底，但 404 拦截不能替代队员源头纪律。
- 硬规则：英文译中——**zh.mjs 机翻打底，人工只修四类硬伤（人名/数字/否定/双关）**，短梗/表情/口号不进机翻直接写（按长度分流，见 hot-comments 技能「英文内容的翻译规矩」第 5 条）；专名保留；摘要必须含正文语句，**绝不允许只剩来源括注**；同组多源合并 1 条、用到的源全放 sources；不同组各 1 条；非科技主体（导购/娱乐/慈善/汽车，特斯拉及旗下车型除外可收）放 dropped 并写原因；宁缺毋滥每板块 8–14；不联网不 spawn 只写自己 json
- **翻译缓存与数字机检三条纪律**（借鉴 mm.mjs 抽样纪律 2026-11-15，zh.mjs 同样有共享缓存 `~/.dsh-ai-research/translate-cache.json`）：
  1. **缓存错译不自愈**——重测可疑译文必须显式清缓存（删整个 translate-cache.json 或先备份），直接重跑同一句只会命中同一个错译，得出「稳定错误」的错误结论；
  2. **短句+常见搭配是机翻旧语料重灾区，且本机 Transmart 比借鉴的 MyMemory 更糟**（2026-11-15 全量实测，清缓存后 fresh 请求复现）：`raised $13 billion`→「10亿美元」、换措辞 `13 billion dollars`→「13亿美元」（量级仍错 100 倍）、`40 billion dollars`→「40 10亿美元」崩坏——**含 billion/million/trillion 的数字一律人工按原文重写进译文，不信任机翻数字**；换措辞对照只作定性参考，「换措辞即对」仅对 MyMemory 成立，对 Transmart 不成立；
  3. **数字判定用机检不用人眼**——numcheck.py **v2**（2026-11-15 升级）（2026-11-17 起 numcheck.py 只是薄转发层，真源是 scripts/xcheck.mjs 的 numDiff：跨语言 SI 归一，`$13 billion↔130 亿` 自动放行、认 crore/lakh/万亿/亿/万千瓦与全角逗号；scale_risk 命中时 missing/extra 是同一处量级错，按一条算）含**量级换算检测**：`printf '<原文>' > /tmp/n1.txt && printf '<译文>' > /tmp/n2.txt && python3 scripts/numcheck.py /tmp/n1.txt /tmp/n2.txt`（参数是两个文件路径）；输出 scale_risk 字段（billion→预期译文含 N*10 亿或 N*1000 万、million→N 百万或 N*100 万），负例（130 亿美元/500 万美元）实测不误报，正例（13亿/10亿/崩坏串）全抓。
- 队员自检：`python3 -c "import json;d=json.load(open('json/T1.json'));print(len(d['items']))"`
- **等队员期间跑 dry-run 预检**（2026-11-16 定）：派单后队员写作的 20+ 分钟里，领队先用上一期数据跑一次 `cd <技能目录>/scripts && python3 publish.py <上一期 workdir> --date <昨日> --dry`，把脚本层问题（键名不兼容、路径约定、HTML 渲染）提前暴露；另用 `python3 -c "import json;json.load(open('<workdir>/merged.json'))"` 之类探针确认输入格式。本期教训：复核产物落 `review/` 未 cp 到工作区根会导致机检读旧数据，本可在等待期暴露，白花 4 分钟往返（`load_items` 只认 `items` 键那条 KeyError 已于 2026-11-17 修掉：`items`/`merged`/裸数组三种包装都认，JSON 截断与顶层类型错误也会友好退出；被弃条目见 `final/` 同级的丢弃清单输出）。
- **编辑队员失联止损**（借鉴 news-ai 2026-11-13）：派单后 **第 4 分钟先 send_message 问一句进展**（接手的素材同样读 clusters_*.json）（实测「问一句」常直接触发队员交付，11-15/11-16 两期均如此，比干等 6 分钟更快）；问过仍无交付、且约 6 分钟未交付且 list_agents 显示 inactive / 收到 failed 通知 → 队长直接接手：读 pack_N.json 素材按同 schema 自己写 json/TN.json（硬规则同队员契约），不干等不重派。
- **队员按需自解码 Google News**（借鉴 news-ai 2026-11-13 改版）：领队走雷达补充通道后跑 `python3 scripts/gnews_pool.py <date> --out <工作目录>/dN`——从 digests/<date>.json 筛出未解码的 news.google.com 跳转链，落 `dN/gnews_pool.json`（title/source/theme/time/url）。**派单提示词必须含自解码节**，告知队员按需解：
  ```bash
  python3 scripts/gnews_url.py --json <工作目录>/dN/gnews_pool.json --theme chips --limit 8 --workers 2   # 按主题
  python3 scripts/gnews_url.py --json <工作目录>/dN/gnews_pool.json --match "台积电|TSMC" --limit 5 --workers 2   # 按关键词
  ```
  **全队并发 ≤3**（多队员叠加会撞 Google 限流），解不出的跳过、**不许编 URL**；领队不再统一全量解。
- **队员交付后领队转换**：`python3 scripts/json2techmd.py dN/json/T1.json dN/json/T2.json dN/json/T3.json dN/json/T4.json` → parts/A-D.md（自动板块排序/计数/三行式/源行；未知板块与缺摘要条目会打警告），再 `python3 check_parts.py dN/parts/<X>.md` 复核 exit 0。

- 【2026-11-15 更新】量级词保护已固化进 zh.mjs（数字+trillion/billion/million 整组 NUM 占位 + SI 换算还原 + scaleOk 数值回检 + 重翻 2 次 + 原文兜底），正常语序量级句 100% 正确；被动语态顽固行兜底原文人工接手，或改主动语态重翻。占位坏译会固化进缓存——改占位逻辑后必须清 ~/.dsh-ai-research/translate-cache.json。

## 2.7 xcheck 交叉校验（**必跑步骤**；2026-11-16 借鉴 news-ai 前置：领队先跑、清单随复核单发给复核员，复核员只精查 flagged+抽查其余、不再逐条回源；发布前再跑一遍终版兜底。来不及就发布后补跑再就地修）
- **每期必跑**，真问题修完再发；它是复核员的互补——复核员管跨队合并/分类/回源，xcheck 管「中文摘要 vs 英文原文」一致性，独有覆盖 URL 错配与编造细节两类（人工通读最难发现）。
- 共享引擎 scripts/xcheck.mjs（彩云小译第二通道 + Google clients5 备选 + MyMemory 抽样回退，SI 归一数字对比，缓存 ~/.dsh-ai-research/xcheck-cache.json）；科技日报适配版 scripts/xcheck_run.mjs。
- 用法：`cd <技能目录>/scripts && node xcheck_run.mjs <workdir> [YYYY-MM-DD]`（date 缺省取 workdir 最新 raw_*.json；配对用 merged.json 优先、否则合并 json/T*.json）。产物 <workdir>/xcheck_人工审.md，退出码恒 0 不阻塞发布。
- 三层放行（浓缩摘要产物的核心适配）：①中文源跳过（zhRatio≥0.25）；②「疑似漏译（长度比」全放行；③译文数字是原文数字子集放行（含摘要把数字删光的 T 空场景）；④版本号形态（Wine 11.22/Plasma 6.9）两侧都在 → 放行（版本号是 ID 非数量级）；⑤实体关键词丢失（标题只写产品名不写公司名）且译文仍是正常中文 → 放行（2026-11-16 抄 news-ai 适配层）。
- 分工定性（2026-11-16 借鉴 AI 日报会话）：**机检兜底，占位/词表防错，人工终审**——xcheck 只抓「已知的错」（ALIAS_BAD/习语表里没有的坏译名抓不到，如 AP→美联社这类语义错），别把机检当保险；语义错主力仍是送翻前的主题占位词表+人工抽查。
- **养表是每期收尾默认动作**（2026-11-16 用户定）：每期复核/质检发现真错译名或坏习语后，顺手回写 scripts/xcheck.mjs 的 ALIAS_BAD（坏译名→规范名）与 translate.mjs 的 IDIOM_ZH（习语定译），越用越准；改表后清对应缓存（translate-cache / xcheck-cache）。
## 2.8 摘要数字机检（必跑步骤；2026-11-16 借鉴 AI 日报会话「摘要数字机检」提案；单一真源 scripts/summary_check.py，与 numcheck/xcheck 质检家族并列）
- **管的是「摘要 vs 正文」数字一致性**，与 xcheck（译文 vs 英文原文）互补；抓人工最容易漏的「over six million→650 万」约数被合理化成精确数。
- 用法：`python3 scripts/summary_check.py <workdir> [YYYY-MM-DD]`（workdir 如 <工作目录>/d10）；基准=raw_<date>.json 的原始 title+desc（merged title 是队员改写版不作依据）；判定方向=摘要数字 ⊆ 素材数字（SI 归一复用 xcheck.mjs 的 parseNums/parseZhNums，双方纯数比数值、任一带单位比 SI）。
- **只出清单不当阻断闸**（摘要是作者改写，允许补背景数/跨币种换算；flagged 由人 30 秒过一遍放行或修）；产物 <workdir>/summary_人工审.md，exit 恒 0。
- 已知噪音与防线：desc 截断（cnBeta/Tom's 短 desc）会造成「摘要有据但 desc 无」的假 flag——清单已附「源 desc 不在 raw」标注；长度单位（英寸/寸/"）自动归一成毫米比对；型号数字（QN10/KB5132057）与 x86/x64、中文习语（二次开发）自动剥离。
- 三道闸分工：摘要数字机检（摘要 vs 正文，清单提示 30 秒）｜xcheck（译文 vs 英文原文，交付前兜底）｜人工抽查五处（语义/专名，终审）。
- 实测 11-14 期：78 条 → 英文配对 23（中文源 55 跳）→ flagged 10→4（放行规则升级后）。剩余 flagged 判读要点（11-14 期实测，flagged 9 条逼出 3 条真问题）：①先查「摘要内容 vs raw desc 是否同一事件侧面」——真问题三类：URL 与摘要内容错配（KMS 摘要配了打印文章 URL）、编造细节（「无人持有钥匙」原文没有）、无据细节（「物流拦截」raw 无依据）；②误报三类：浓缩删数字（CMF 只写造型删 $39/$20）、多源信息差（摘要含 cnBeta 源细节但 desc 是 bleeping 的）、彩云自身错（Microsoft 365 译成「365 次停机」）。修复走 T*.json 改字段后重跑 publish.py，不手改 md。
## 2.9 HN 补量条目回源（2026-11-20 定，随机抽查逼出的真错）
HN 补量条目（raw_hn.json 只有 HN 标题、无 desc）的摘要**合并前必须回源原帖验证事实句**——机翻/改写时禁止带「引发热议：XX意识淡薄」这类评价性推断，只写可溯源的事实。11-19 期实例：YC/LinkedIn 条原摘要写「抓数据用于背景调查」，原帖实为「试用期按要求绑定 LinkedIn 后被冒用账号发招聘消息」，事实句整个偏了。
回源通道（按优先级）：
1. 原文 URL 直抓 og:description / 正文（urllib，普通站够用）；
2. 原文站 403/付费墙时走 Playwright CDP（enrich.py 已内置，PLAYWRIGHT_HOSTS 命中即走）；
3. Reddit 本体全 403，用 Photon 归档：`https://arctic-shift.photon-reddit.com/api/posts/ids?ids=<postid>`（免 key 直连，返回 data[].title/selftext），兜底 `https://api.pullpush.io/reddit/search/submission/?ids=`。
回源后摘要只写原帖正文能落到的事实（标题+正文首段），评价与情绪一律不加。

## 2.5 复核员（三 JSON 齐 → 拼装前，借鉴 news-ai ai-news-review 模式 2026-11-12）
- 触发（2026-11-16 借鉴 news-ai「复核流水化」改）：**来一批审一批**——某队 JSON 交付即先送复核员，不等三队齐（三队交付与复核重叠，省墙钟）；复核员对已到的 JSON 先跑跨队合并，后续队到达再增量复核。领队无空时可亲自按同规则复核。
- 四职责（复核员不写条目、不改四队原始 JSON、不写 Obsidian，落盘由领队负责）：
  1. **跨队同事件合并**——A 队某条主链出现在 B 队某条 sources 里且标题 2-gram 重合 ≥0.5 → 合并成一条（sources 并集）。
  2. **分类边界复核**——固定规则：半导体涨价/架构/产能归「一 芯片与硬件」，只有股价/评级/财报预期归「九 政策商业」或「十 融资并购」；技术方案与开源项目归「五 软件游戏开源」；立法执法归「九 政策监管」。
  3. **摘要数字回源核对**——摘要中的金额/百分比/数量逐条对照 sources；找不到依据就删掉或标注。**精确数必须回源**（2026-11-16 借鉴）：英文原稿常是 "over/about/nearly six million" 这类约数，被队员合理化成「650 万」精确数——发现精确数而对应用文原文是约数时改回约数表述。
  4. **非科技主体剔除**——评测/导购/娱乐/慈善/AI 主体补漏丢弃。
- 交付：`dN/review/merged.json`（合并后终版，schema 同队员 JSON）+ `dN/review/report.md`（四节：合并/改判/摘要/丢弃，每条可追溯）。
- 领队对 report.md 四节逐条过目后再进转换。
> **增量补量同样必须过本流程**（2026-11-12 晚踩坑：下午已发 73 条版直接 merge_inc 拼接没走复核，结果 126 条里查出 7 处增量/基线同事件重复——Meta 卸任两条、N-central 零日、eMudhra、T-Mobile、微软更新、R 星 GTA6、欧盟 DFA，复核后删到 119 条）。
> **复核员唤醒失败止损**：send_message 唤醒 inactive 复核员可能连续两次"failed before it finished"且不落盘——不要干等第三次，领队用脚本自跑四职责（URL + 标题 2-gram + 实体关键词三级撞车扫描，见 d6b 内联用法）。

## 2.6 同日增量补量（下午已发版 → 晚间补料 → 改名替换）
用户当天第二次说「抓取」时走本节，**不要整期重做**：
1. `python3 daily_fetch.py <date> --out <工作目录>/d<N>b` 重抓（RSS 滑动窗口，raw 会比上午多几十条，pool 大概率翻倍）。
2. **不要用差集逻辑**：两次 daily_fetch 的 pool 不互为超集（实测：上午 pool 与已发 md 重合 89 条、晚间 pool 重合 0 条），只能用「已发 md 的 URL + 标题前 14 字」逐条比对筛增量。
3. 领队**预挑**：按标题关键词 KEYS 字典从 pool 挑出候选（miss 会打印，便于发现新事件），砍掉导购/评测/黑五/优惠码/汽车/AI 主体再派单——预挑 + 队员复核双层过滤（实测：209 条预挑后队员又砍 73 条）。
4. 派 4 个持久队员写 json/T{1..4}.json（**也必过复核员**，见 2.5；增量与下午基线撞车是复核重点：GTA6/微软补丁/马士基/无印良品/TrendForce 这类基线已有条目最容易被二次收）。
5. 合并用 `scripts/merge_inc.py <base md> <digest> T1.json T2.json …`：板块内并入 + URL 去重 + 全文重编号 + 重算板块计数 + digest 重写。
6. 复核后领队改稿参考 `scripts/fix_review.py`（删增量条 / 摘要扩写 / 源行并集 / 重编号），注意：删除标题条目时**先 find 再删**，同名标题可能撞上想保留的那条（Meta 卸任条目 ithome 版与 TechCrunch 版同事件不同标题，合并要保留信息全的那版）。
7. 落盘后按「同一天条数变化直接改名替换旧文件」规则删掉上午版本（不留旧条数副本）。

## 2.10 语义初筛（semantic_check，2026-11-20 借鉴 AI 日报线）
xcheck/summary_check 只抓数字/格式，语义错（否定方向、主体张冠李戴、机翻腔、术语错译）是机检盲区，由 LLM 语义初筛兜底：
- 命令：`python3 news-tools/semantic_run.py <workdir> [date]`（薄转发 → news-ai/semantic_run.py 真源，--label 科技日报自动带上）
- 配对逻辑与 xcheck 同构：merged.json 优先 → json/T*.json；raw_<date>.json → raw.json → digests/<date>.json 雷达池；中文源（zhRatio≥0.25）跳过；约 3.7s/对
- 环境变量：SEMANTIC_MAX_TOKENS=16000（防推理模型思考链吃光 token 返回空）；SEMANTIC_REASONING=low（默认已 low）
- 真源 tools/semantic_check.py：非 JSON 批 salvage 容错（先抓整段数组、再逐对象提取）；PROMPT_HEAD 第 6 条——EN 端可能只有标题（HN 补量条目 raw desc 空），ZH 摘要含标题外细节是正常多源补充，只报主体/公司错、夸大、技术栈臆断、报告数与风险混淆，不报「补充细节」本身（否则 HN 条目 78% 假阳）
- 清单落 <workdir>/semantic_人工审.md，清单制不阻断；本轮实测：flagged 18→5（第 6 条规则生效），5 条全真（报告数≠风险、Codeberg 夸大、Ruby 臆断、机翻腔）
- 时机：publish 落盘前、xcheck 之后（与 AI 日报线一致）；耗时约 2 分钟/45 对

## 3. 极速模式：领队一人全流程（publish.py —— 落盘优先，只有这一条命令）

> **极速模式定义（2026-11-18 用户定）**：取消三队并行编辑，**领队直接从 pack/簇素材挑条写增量 JSON**，其余流程（xcheck、summary_check、digest、publish、linkcheck、落盘）不变。适用于「快速抓取 → 增量补量」全天内多轮场景，单人 5-10 分钟出稿。
>
> **扁平模式（2026-11-18 用户定）**：**不再使用簇结构派单**，直接读扁平 `pack_{A,B,CD}.json` 条目级素材，领队人工按板块拣条、写增量 JSON。省去 `pipeline_split.py` 的簇生成与 enrich 正文补料步骤（`--no-enrich`），进一步压缩到 3-5 分钟。适用于增量条数极少（<10 条）或时间极其紧迫的场景。

> **tools 脚本同步白名单纪律（2026-11-17 定）**：publish 链路以写死路径调用的脚本必须同时在 `（本机同步清单，打包版无此项）` 的 `FILES` 白名单里，否则换设备或 proot 重置后 `publish.py` 会直接崩（`FileNotFoundError: md2html.py`）。已补齐：`mdhtml.py`（438 行 HTML 渲染真源）、`md2html.py`（转发层，`assemble.py:29`/`append.py:28`/`publish.py:40` 三处写死它）、`claim_check.py`、`linkcheck.py`、`lookup_meta.py`。新增管线必经脚本时同法加白名单，判据＝被两条以上管线以写死路径调用；只被一条管线用且可内联的不必同步。
- 发布前**三道机检均必跑**（少跑任何一道都算漏检，2026-11-20 用户追问后补定）：
  1. 2.7 xcheck 交叉校验 —— `publish.py` 已自动内联，无需单独跑；
  2. 2.8 摘要数字机检 —— `publish.py` 已自动内联同一份；
  3. **2.10 semantic_check 语义初筛** —— `python3 scripts/semantic_run.py <workdir> <date>`，**publish 不会自动跑，必须手动执行**（英文配对少时仅十几秒，61 条 6 对实测 4 秒）。
  flagged 里真问题修完再发；来不及就发布后补跑、按第 5 节就地修。极速/扁平模式同样三道全跑（模式只减人力，不减机检）。
复核产物（`dN/merged.json`）一出来**立刻跑**，不要等所有核查完美：
```bash
cd <技能目录>/scripts
python3 publish.py <工作目录>/d9 --date 2026-11-14            # 完整：拼装→HTML→核查→落盘
python3 publish.py <工作目录>/d9 --date 2026-11-14 --dry      # 只生成 final/out.*，不落盘
python3 publish.py <工作目录>/d9 --date 2026-11-14 --no-linkcheck
# 增量模式：同日旧版 md 存在时自动只查新增 URL（delta=0 秒过）；首次发布自动全量查
```
输入二选一：`<workdir>/merged.json`（复核产物，优先）或 `<workdir>/json/T*.json`（无复核时按 URL 去重合并）；`<workdir>/digest.txt` 可选。
输出：`<workdir>/final/out.md` + `out.html`；落盘 `$OBSIDIAN_ROOT/dsh/新闻/科技新闻_<date>_<N>条.{md,html}`，同日旧条数版本先移入 `<工作目录>/bak/news/` 再替换（不留旧条数副本、不改创建日期）。
脚本内置校验，任一失败即非零退出并说明原因：条目数=HTML `<li>` 数、空摘要 0、暗色残留 0、404/410 死链（Phoronix/Bloomberg 403 属正常）、缺板块只告警不拦。

> **为什么必须一条命令**（2026-11-14 复盘 11-13 期）：复核 71 条源数据 20:36 就绪，但拼装五步被拆进多轮对话，20:36→03:56 空转 7 小时没落盘，用户催了三次；这五步真跑只用 5 分钟。**规则：复核一出 merged.json 立即 `publish.py` 出 v1 落盘（哪怕条目还要调），后续就地改（`open(path,"w")` 同路径 / 改名用 `mv`，改前 `cp -p` 备份）。禁止「先完美后落盘」。**

## 3.9 publish 内置守卫（2026-11-20 加）
- **必看守卫**：条目摘要 ** 计数=0 → 「⚠⚠ 本期必看挑条 = 0」醒目警告（非阻断）——快速模式/修复轮也不许跳过挑必看。
- **摘要尾括注清理**：渲染前自动剥摘要尾部「（... 11-19 03:07）」式括注（与来源行重复），打印被剥条目。
- 发布输出里 digest 的 b 与条目必看分开看：b=9 全在当日总结里不代表条目已加粗，以「必看条目 5 条」这类输出为准。

## 4. 当日总结（digest.txt，2026-11-17 用户定版：总结式，几个面重点）
写 `<workdir>/digest.txt`，publish.py 会整块插到时间行之后。**形态定版：不逐事件罗列，按「面」组织——3~4 个面，每面一句话串 2~3 个重点，全篇 4~6 行**（此前 9-10 条事件式被判「太多」）。标题行用 `> **当日总结**`：
```
> **当日总结**
>
> - **服务可靠性连环爆**：微软 365 …致 15 人氯气中毒…；同日美国四大银行也报告服务中断。
>
> - **安全与数据治理吃紧**：NoisyTCP 潜伏 11 年…；无印良品 109 万条泄露、工信部通报 46 款 App。
>
> - **半导体与航天硬进展**：SK 海力士 10.5 亿美元…；星舰 V4 公布（+40%、9 台发动机）。
>
> - **年末消费与游戏季**：GTA6 盒装不含光盘…；黑五优惠被指大量无折扣。
```
**每个面之间必须空一行**（`>` 空引用行，2026-11-17 用户定「每个面要换行」）——md 在 Obsidian 里各面分开显示；HTML 端 mkhtml_sticky.py 自动把每面包成 `<div class='f'>`（margin 8px），digest 解析跳过 `>` 空行，两端口径一致。
- 面的划分按当天主线归簇（服务/安全/硬科技/消费游戏/政策融资…当天哪几个面重就写哪几个），每面内把同主题事件串成一句，每面 2~3 处 `**重点**` 加粗（mkhtml_sticky.py 自动转紫色 `<b>`，勿在脚本里重复 escape）。
- **HN 高分条目板块内排序**（2026-11-17 用户定「高分排太后」）：publish.py 的 render_md 排序=必看（摘要含 **）→ HN 条目按「Hacker News·N分」分数降序 → 其余原顺序（稳定排序，组内保持原相对顺序）。HN 分数从 sources 的 name 提取，无需单独字段。
- **增补要看情况重写**（2026-11-17 用户定）：每次增补/二次抓取后，不能无脑沿用已发版总结——新增条目引入新的面或改变某面重点时改写；零星补条、面的结构不变时才原样继承（publish.py 继承时会打印提醒）。
- 写完先 `head -12 <workdir>/final/out.md` 确认总结段在文件里（历史坑：digest 放错目录时 assemble 零警告、md 与 HTML 双双缺小结）。

## 5. 已发日报的修正（就地改，不重建）
- `open(path,"w")` 写回同路径（inode 不变、只有 mtime 变）；条数变化用 `mv` 改名（/sdcard FUSE 上 mv 是 rename，mtime/inode 保留）。
- **绝不写新文件+删旧文件**——重建会改创建日期，影响 Obsidian 排序；改前 `cp -p` 备份到 <工作目录>/bak/news/。
- 若已误重建，可用 `touch -r <备份>` 把 mtime 改回原时间恢复排序。
- 改完重跑 `python3 publish.py <workdir> --date <date> --dry` 复核校验，再手工覆盖落盘文件。
